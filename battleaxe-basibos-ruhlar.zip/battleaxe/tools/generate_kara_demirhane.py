#!/usr/bin/env python3
"""
Kara Demirhane (Kara Körük'ün Nether yapısı) üreticisi.

Çıktılar (proje köküne göre):
  src/main/resources/data/battleaxe/structure/kara_demirhane/forge.nbt          yapı şablonu (blok + TEK boss)
  src/main/resources/data/battleaxe/worldgen/structure/kara_demirhane.json      jigsaw yapı tanımı
  src/main/resources/data/battleaxe/worldgen/structure_set/kara_demirhane.json  yerleşim kuralı (nadirlik)
  src/main/resources/data/battleaxe/worldgen/template_pool/kara_demirhane/start.json
  src/main/resources/data/battleaxe/tags/worldgen/biome/has_structure/kara_demirhane.json

Gereksinim: pip install nbtlib
Çalıştırma:  python tools/generate_kara_demirhane.py
Yapıyı değiştirmek istersen bu dosyayı düzenleyip yeniden çalıştır.
"""
import json, math, os, random, sys
import nbtlib
from nbtlib import Compound, List, Int, String, Double, Float, Byte

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "src/main/resources/data/battleaxe")

# Şablon DataVersion'ı bilerek 1.21.11 sürümüdür (4671): oyun, daha yeni sürümlerdeki blok/format
# değişikliklerini kendisi günceller; böylece 26.2 ile uyumlu kalır.
DATA_VERSION = 4671

SX, SY, SZ = 35, 28, 35      # şablon boyutu
C = 17                       # merkez (x ve z)
FLOOR = 8                    # zemin yüksekliği (üst yüzey)
START_Y = 26                 # dünyada şablonun taban yüksekliği (zemin = 34, lav denizinin 2 blok üstü)

rng = random.Random(20260618)
cells = {}   # (x,y,z) -> (isim, {özellikler})

def put(x, y, z, name, **props):
    if 0 <= x < SX and 0 <= y < SY and 0 <= z < SZ:
        cells[(x, y, z)] = (name, {k: str(v).lower() if isinstance(v, bool) else str(v) for k, v in props.items()})

def dist(x, z):
    return math.hypot(x - C, z - C)

def weighted(options):
    r = rng.random() * sum(w for _, w in options)
    for name, w in options:
        r -= w
        if r <= 0:
            return name
    return options[-1][0]

# 1) Temiz bir boşluk oyul (yapı toprağa gömülmesin): zeminin üstü, yuvarlak bir hacim
for y in range(FLOOR + 1, SY):
    for x in range(SX):
        for z in range(SZ):
            if dist(x, z) <= 17.5:
                put(x, y, z, "minecraft:air")

# 2) Ada tabanı: aşağı doğru daralan koni (y=0..7)
for y in range(0, FLOOR):
    radius = 7.0 + y * 0.85
    for x in range(SX):
        for z in range(SZ):
            d = dist(x, z) + (rng.random() * 0.8 - 0.4 if y < FLOOR - 1 else 0.0)
            if d <= radius:
                options = [("minecraft:blackstone", 40), ("minecraft:basalt", 30), ("minecraft:smooth_basalt", 15),
                           ("minecraft:polished_basalt", 5)]
                if y <= 5:
                    options.append(("minecraft:magma_block", 6))
                name = weighted(options)
                if name in ("minecraft:basalt", "minecraft:polished_basalt"):
                    put(x, y, z, name, axis="y")
                else:
                    put(x, y, z, name)

# 3) Zemin (y=8): cilalı karataş tuğlalar, halka ve çatlaklar
for x in range(SX):
    for z in range(SZ):
        d = dist(x, z)
        if d <= 12.5:
            if 10.8 < d <= 11.8:
                name = weighted([("minecraft:polished_blackstone", 80), ("minecraft:gilded_blackstone", 6),
                                 ("minecraft:chiseled_polished_blackstone", 14)])
            else:
                name = weighted([("minecraft:polished_blackstone_bricks", 78),
                                 ("minecraft:cracked_polished_blackstone_bricks", 14), ("minecraft:blackstone", 8)])
            put(x, FLOOR, z, name)

# 4) Lav kanalları: dört yönde, zemin seviyesinde; iki yanı ve altı kapalı (taşmaz)
LAVA = set()
for sign in (-1, 1):
    for d in range(6, 11):
        for (x, z) in ((C + sign * d, C), (C, C + sign * d)):
            put(x, FLOOR, z, "minecraft:lava", level=0)
            LAVA.add((x, FLOOR, z))

# 5) Ocak kaidesi (9x9, köşeleri kesik) ve Ruh Örsü zemini
for dx in range(-4, 5):
    for dz in range(-4, 5):
        if abs(dx) == 4 and abs(dz) == 4:
            continue
        put(C + dx, FLOOR + 1, C + dz, "minecraft:polished_blackstone_bricks")
put(C, FLOOR + 1, C - 3, "minecraft:crying_obsidian")

# 6) Ocak: 5x5 halka (2 blok yüksek), içi 3x3 lav havuzu
for dx in range(-2, 3):
    for dz in range(-2, 3):
        ring = max(abs(dx), abs(dz)) == 2
        if ring:
            put(C + dx, FLOOR + 2, C + dz, "minecraft:polished_blackstone_bricks")
            put(C + dx, FLOOR + 3, C + dz, "minecraft:chiseled_polished_blackstone" if abs(dx) == abs(dz) else "minecraft:polished_blackstone_bricks")
        else:
            put(C + dx, FLOOR + 1, C + dz, "minecraft:magma_block")
            put(C + dx, FLOOR + 2, C + dz, "minecraft:lava", level=0)
            LAVA.add((C + dx, FLOOR + 2, C + dz))

# 7) Çatı: dört sütun + 7x7 çerçeve, merkezde duman deliği; zincirle sarkan ruh fenerleri
for sx in (-3, 3):
    for sz in (-3, 3):
        for y in range(FLOOR + 2, FLOOR + 12):
            put(C + sx, y, C + sz, "minecraft:polished_blackstone_bricks")
CANOPY_Y = FLOOR + 12
for dx in range(-3, 4):
    for dz in range(-3, 4):
        if max(abs(dx), abs(dz)) == 3:
            put(C + dx, CANOPY_Y, C + dz, "minecraft:blackstone")
            put(C + dx, CANOPY_Y + 1, C + dz, "minecraft:polished_blackstone_brick_slab", type="bottom")
for (dx, dz) in ((3, 0), (-3, 0), (0, 3), (0, -3)):
    for y in range(CANOPY_Y - 1, CANOPY_Y - 6, -1):
        put(C + dx, y, C + dz, "minecraft:iron_chain", axis="y")
    put(C + dx, CANOPY_Y - 6, C + dz, "minecraft:soul_lantern", hanging=True)

# 8) Demirci eşyaları: örs, yanan yüksek fırınlar, çekme masası, bileği taşı, lav kazanı
put(C, FLOOR + 2, C - 3, "battleaxe:kara_koruk_ors", facing="east")
put(C + 3, FLOOR + 2, C, "minecraft:blast_furnace", facing="east", lit=True)
put(C - 3, FLOOR + 2, C, "minecraft:blast_furnace", facing="west", lit=True)
put(C, FLOOR + 2, C + 3, "minecraft:smithing_table")
put(C + 3, FLOOR + 2, C + 2, "minecraft:grindstone", face="floor", facing="east")
put(C - 3, FLOOR + 2, C - 2, "minecraft:lava_cauldron")

# 9) Çevre sütunları (8 adet) ve alçak siper
for k in range(8):
    a = k * math.pi / 4
    px, pz = round(C + 11 * math.cos(a)), round(C + 11 * math.sin(a))
    for y in range(FLOOR + 1, FLOOR + 6):
        put(px, y, pz, "minecraft:polished_blackstone_bricks")
    put(px, FLOOR + 6, pz, "minecraft:chiseled_polished_blackstone")
    put(px, FLOOR + 7, pz, "minecraft:soul_lantern", hanging=False)
for x in range(SX):
    for z in range(SZ):
        d = dist(x, z)
        if 11.9 < d <= 12.5 and abs(x - C) > 2 and abs(z - C) > 2 and (x, FLOOR + 1, z) not in cells:
            put(x, FLOOR + 1, z, "minecraft:polished_blackstone_brick_slab", type="bottom")

# 10) Dört yönde köprü (3 geniş), şablon kenarına kadar
for sign in (-1, 1):
    for off in range(13, 18):
        for w in (-1, 0, 1):
            for (x, z) in ((C + sign * off, C + w), (C + w, C + sign * off)):
                put(x, FLOOR, z, "minecraft:blackstone" if (off + w) % 2 else "minecraft:polished_blackstone_bricks")

# ---- Denetimler -------------------------------------------------------------
def solid(x, y, z):
    c = cells.get((x, y, z))
    return c is not None and c[0] != "minecraft:air"

for (x, y, z) in LAVA:
    for (dx, dz) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        n = (x + dx, y, z + dz)
        assert solid(*n), f"Lav taşabilir: {(x, y, z)} -> {n}"
    assert solid(x, y - 1, z), f"Lav altı boş: {(x, y, z)}"

anvils = [p for p, v in cells.items() if v[0] == "battleaxe:kara_koruk_ors"]
assert len(anvils) == 1, "Tam olarak bir örs olmalı"
assert not any(v[0] == "minecraft:lava" and p not in LAVA for p, v in cells.items())

BOSS = (C + 3, FLOOR + 1, C - 6)           # blok konumu
assert cells.get(BOSS, ("minecraft:air",))[0] == "minecraft:air", "Boss'un durduğu hücre boş olmalı"
assert solid(BOSS[0], FLOOR, BOSS[2]) and BOSS not in LAVA and (BOSS[0], FLOOR, BOSS[2]) not in LAVA
assert cells.get((BOSS[0], BOSS[1] + 1, BOSS[2]), ("minecraft:air",))[0] == "minecraft:air"

# ---- NBT yaz ---------------------------------------------------------------
palette_index, palette = {}, []
blocks = []
for (x, y, z), (name, props) in sorted(cells.items()):
    key = (name, tuple(sorted(props.items())))
    if key not in palette_index:
        palette_index[key] = len(palette)
        entry = {"Name": String(name)}
        if props:
            entry["Properties"] = Compound({k: String(v) for k, v in props.items()})
        palette.append(Compound(entry))
    blocks.append(Compound({"pos": List[Int]([Int(x), Int(y), Int(z)]), "state": Int(palette_index[key])}))

boss = Compound({
    "pos": List[Double]([Double(BOSS[0] + 0.5), Double(float(BOSS[1])), Double(BOSS[2] + 0.5)]),
    "blockPos": List[Int]([Int(BOSS[0]), Int(BOSS[1]), Int(BOSS[2])]),
    "nbt": Compound({
        "id": String("battleaxe:kara_koruk"),
        "PersistenceRequired": Byte(1),
        "Rotation": List[Float]([Float(0.0), Float(0.0)]),
    }),
})

root = Compound({
    "DataVersion": Int(DATA_VERSION),
    "size": List[Int]([Int(SX), Int(SY), Int(SZ)]),
    "palette": List[Compound](palette),
    "blocks": List[Compound](blocks),
    "entities": List[Compound]([boss]),   # TAM OLARAK BİR boss
})

def write(path, text=None, nbt=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if nbt is not None:
        nbtlib.File(nbt, gzipped=True).save(path)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)

write(os.path.join(DATA, "structure/kara_demirhane/forge.nbt"), nbt=root)

def dump(obj):
    return json.dumps(obj, indent=2) + "\n"

write(os.path.join(DATA, "worldgen/structure/kara_demirhane.json"), dump({
    "type": "minecraft:jigsaw",
    "biomes": "#battleaxe:has_structure/kara_demirhane",
    "max_distance_from_center": 80,
    "size": 1,
    "spawn_overrides": {},
    "start_height": {"absolute": START_Y},
    "start_pool": "battleaxe:kara_demirhane/start",
    "step": "surface_structures",
    "use_expansion_hack": False,
}))
write(os.path.join(DATA, "worldgen/structure_set/kara_demirhane.json"), dump({
    "placement": {
        "type": "minecraft:random_spread",
        "exclusion_zone": {"chunk_count": 4, "other_set": "minecraft:nether_complexes"},
        "frequency": 0.6,
        "frequency_reduction_method": "legacy_type_1",
        "salt": 1384293847,
        "separation": 6,
        "spacing": 20,
    },
    "structures": [{"structure": "battleaxe:kara_demirhane", "weight": 1}],
}))
write(os.path.join(DATA, "worldgen/template_pool/kara_demirhane/start.json"), dump({
    "elements": [{
        "element": {
            "element_type": "minecraft:single_pool_element",
            "location": "battleaxe:kara_demirhane/forge",
            "processors": "minecraft:empty",
            "projection": "rigid",
        },
        "weight": 1,
    }],
    "fallback": "minecraft:empty",
}))
write(os.path.join(DATA, "tags/worldgen/biome/has_structure/kara_demirhane.json"), dump({
    "values": ["minecraft:basalt_deltas"],
}))

print(f"Yazıldı: {len(cells)} blok hücresi, {len(palette)} palet girdisi, 1 boss, {len(LAVA)} lav hücresi, 1 örs")
