#!/usr/bin/env python3
"""Hiddet Evrimi dil girdilerini en_us/tr_tr dosyalarına yazar (yalnızca 'evolution.*' ve iki tuş anahtarı)."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
L = {
 "key.battleaxe.evolution": "Hiddet Evrimi Ekranı",
 "key.battleaxe.final_threshold": "Son Eşik",
 "evolution.screen.title": "Hiddet Evrimi",
 "evolution.stage.0": "Uykuda", "evolution.stage.1": "Kıvılcım", "evolution.stage.2": "Uyanış",
 "evolution.stage.3": "Taşkınlık", "evolution.stage.4": "Son Eşik",
 "evolution.path.blood_whirl": "Kan Kasırgası",
 "evolution.path.blood_whirl.desc": "Kombo ve ivme: art arda güçlü vuruşlar saldırı hızını, hasarı ve Savaş Özü kazanımını artırır. Boşta kalırsan ivme çözülür.",
 "evolution.path.blood_whirl.limit": "Gelen hasar biraz artar; zayıf vuruşlar ivmeyi düşürür.",
 "evolution.path.last_breath": "Son Nefes",
 "evolution.path.last_breath.desc": "Can azaldıkça hasar azaltma ve hasar artar. Ölümcül bir vuruşta (uzun beklemeyle, 15 öz karşılığı) ayakta kalırsın.",
 "evolution.path.last_breath.limit": "Sağlıklıyken neredeyse etkisizdir; ölümden dönüş 5 dakikada bir.",
 "evolution.path.soul_render": "Ruh Yırtıcısı",
 "evolution.path.soul_render.desc": "Yar Geç ve balta fırlatma güçlenir; güçlü düşmanların ruh ödülü artar; bu saldırılar Savaş Özü kazandırır.",
 "evolution.path.soul_render.limit": "Sıradan yakın dövüş vuruşları daha az öz verir.",
 "evolution.hud.no_path": "Dal yok", "evolution.hud.essence": "Öz %s",
 "evolution.hud.overload": "Aşırı yük! %s sn", "evolution.hud.burnout": "Tükendi %s sn",
 "evolution.hud.final_active": "SON EŞİK %s sn", "evolution.hud.final_cooldown": "Son Eşik: %s sn",
 "evolution.hud.final_ready": "[V] Son Eşik hazır", "evolution.hud.choose": "[B] dal seç",
 "evolution.ui.select": "Dalı Seç", "evolution.ui.selected": "Seçili", "evolution.ui.limit": "Sınırlama:",
 "evolution.ui.mastery": "Ustalık Sv. %1$s  (%2$s)",
 "evolution.ui.summary": "Dal: %1$s  -  Aşama: %2$s  -  Savaş Özü: %3$s/%4$s",
 "evolution.ui.keys": "B: bu ekran  -  V: Son Eşik (Taşkınlık aşamasında, 50 öz harcar)",
 "evolution.ui.rules": "Dal değiştirmek: Hiddet aşaması dışında, savaş dışında ve %s dakikada bir yapılabilir. İlk seçim serbesttir. Ustalık her dalda ayrı ve kalıcıdır; dal değiştirince kaybolmaz.",
 "evolution.ui.rules_wait": "Kalan bekleme: %s sn.",
 "evolution.msg.stage_up": "Hiddet: %s", "evolution.msg.mastery_up": "%1$s ustalığı: seviye %2$s",
 "evolution.msg.overload": "Aşırı yüklendin! Toparlanıyorsun...", "evolution.msg.burnout": "Son Eşik söndü. Güçsüz kaldın...",
 "evolution.msg.path_selected": "Dal seçildi: %s", "evolution.msg.final_started": "SON EŞİK!",
 "evolution.msg.defiance": "Son Nefes! Ölümden döndün.",
 "evolution.msg.path.same": "Bu dal zaten seçili.",
 "evolution.msg.path.in_use": "Hiddet aşamasındayken dal değiştirilemez.",
 "evolution.msg.path.combat": "Savaşta dal değiştirilemez.",
 "evolution.msg.path.cooldown": "Dal değiştirmek için biraz beklemelisin.",
 "evolution.msg.path.invalid": "Geçersiz dal.",
 "evolution.msg.final.no_path": "Önce bir evrim dalı seçmelisin (B).",
 "evolution.msg.final.not_holding": "Son Eşik için baltayı elinde tutmalısın.",
 "evolution.msg.final.stage_too_low": "Son Eşik için Taşkınlık aşaması gerekir.",
 "evolution.msg.final.not_enough_essence": "Son Eşik için yeterli Savaş Özü yok.",
 "evolution.msg.final.cooldown": "Son Eşik henüz hazır değil.",
 "evolution.msg.final.recovering": "Toparlanırken Son Eşik kullanılamaz.",
 "evolution.msg.final.overloaded": "Aşırı yüklüsün; Son Eşik için önce soğumalısın.",
 "evolution.msg.final.already_active": "Son Eşik zaten aktif.",
}
for fn in ("en_us.json", "tr_tr.json"):
    path = os.path.join(ROOT, "src/main/resources/assets/battleaxe/lang", fn)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    for k in [k for k in data if k.startswith("evolution.") or k in ("key.battleaxe.evolution", "key.battleaxe.final_threshold")]:
        del data[k]
    data.update(L)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
print("evolution lang:", len(L), "anahtar")
