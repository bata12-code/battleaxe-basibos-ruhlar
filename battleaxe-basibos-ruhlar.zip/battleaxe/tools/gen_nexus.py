#!/usr/bin/env python3
"""
Ruh Agi (Soul Nexus) dugum tablosu: tek kaynak.

Bu betik
  1) 5 dal x 20 = 100 dugumu tanimlar (12 kucuk, 5 orta, 2 buyuk, 1 dal sonu / dal); her dugumun bir ROLU vardir
     (temel / mekanik / uzmanlik / sinerji / buyuk) ve sinerji dugumleri baska daldan ONKOSUL (requires) ister,
  2) agi DOGRULAR (sayilar, baglantilar, erisilebilirlik, kopuk dugum yok, her dugumun etkisi var),
  3) src/main/java/com/battleaxe/nexus/NexusNodes.java dosyasini uretir,
  4) dil dosyalarina (en_us / tr_tr) dugum adlarini yazar,
  5) (matplotlib varsa) tools/nexus_preview.png onizlemesini cizer.

Calistirma:  python3 tools/gen_nexus.py          (proje kokunden)

Dugum ADLARI burada, dugum ACIKLAMALARI ise oyun icinde etkilerden otomatik uretilir
(boylece aciklama ile gercek etki asla birbirinden ayrilmaz).
"""
import json
import math
import os
import sys
from collections import deque

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------------------
# Dal ve tur tanimlari
# ---------------------------------------------------------------------------
BRANCHES = ["soul", "exec", "rift", "guard", "mind"]
BRANCH_JAVA = {"soul": "SOUL", "exec": "EXECUTIONER", "rift": "RIFT", "guard": "GUARD", "mind": "MIND"}
# Dal acisi (derece). Ust (-90) den baslayip saat yonunde 72 derece.
BRANCH_ANGLE = {b: -90 + 72 * i for i, b in enumerate(BRANCHES)}

TYPE_JAVA = {"S": "SMALL", "M": "MEDIUM", "L": "LARGE", "C": "CAPSTONE"}

# ---------------------------------------------------------------------------
# 20 dugumluk sablon: (no, tur, u, v, baglantilar)  u = dal boyunca, v = yanal
# no 1 cekirdege baglanir. Baglantilar ayni dalin dugumleri (no) listesidir.
# ---------------------------------------------------------------------------
TEMPLATE = [
    (1,  "S", 1.00,  0.00, []),            # cekirdege bagli
    (2,  "S", 1.95, -1.05, [1]),
    (3,  "S", 1.95,  1.05, [1]),
    (4,  "M", 2.30,  0.00, [1, 2, 3]),
    (5,  "S", 3.00, -1.70, [2]),
    (6,  "S", 3.00,  1.70, [3]),
    (7,  "S", 3.30,  0.00, [4]),
    (8,  "M", 4.20, -2.15, [5]),
    (9,  "M", 4.20,  2.15, [6]),
    (10, "S", 4.45, -0.95, [7, 5]),
    (11, "S", 4.45,  0.95, [7, 6]),
    (12, "M", 4.70,  0.00, [7, 10, 11]),
    (13, "S", 5.50, -1.85, [8, 10]),
    (14, "S", 5.50,  1.85, [9, 11]),
    (15, "S", 5.75,  0.00, [12]),
    (16, "S", 6.40,  1.05, [14, 15]),
    (17, "M", 6.40, -1.05, [13, 15]),
    (18, "L", 7.15,  0.00, [15, 16, 17]),
    (19, "L", 7.20, -2.30, [13, 17]),
    (20, "C", 8.40, -0.80, [18, 19]),
]

# Dallar arasi gecis kopruleri (sinirli): (dal, no) <-> (sonraki dal, no)
# Her dalin sag kanat orta dugumu (9) -> sonraki dalin sol kanat orta dugumu (8).
BRIDGES = [(BRANCHES[i], 9, BRANCHES[(i + 1) % 5], 8) for i in range(5)]

# Dugum numarasina gore ROL (boyut/maliyet TEMPLATE'teki tur ile belirlenir).
ROLE_BY_NO = {1: "BASE", 2: "BASE", 3: "BASE", 4: "MECHANIC", 5: "SPECIALTY", 6: "SPECIALTY", 7: "SPECIALTY",
              8: "SYNERGY", 9: "SYNERGY", 10: "SPECIALTY", 11: "SPECIALTY", 12: "MECHANIC", 13: "SPECIALTY",
              14: "SPECIALTY", 15: "SPECIALTY", 16: "SPECIALTY", 17: "MECHANIC", 18: "MAJOR", 19: "MAJOR", 20: "MAJOR"}

# Sinerji dugumlerinin (8 ve 9) ek onkosulu: BASKA daldan ERKEN (no <= 7) bir dugum. Dongu ve zorunlu dal gecisi olmaz.
REQUIRES = {
    ("soul", 8): ("exec", 4), ("soul", 9): ("guard", 4),
    ("exec", 8): ("soul", 4), ("exec", 9): ("rift", 4),
    ("rift", 8): ("exec", 4), ("rift", 9): ("mind", 3),
    ("guard", 8): ("rift", 4), ("guard", 9): ("mind", 3),
    ("mind", 8): ("exec", 4), ("mind", 9): ("soul", 4),
}

# Dugumlerin maliyeti: NexusConfig.COST_* ile ayni olmali (dogrulama bunu denetler).
COST = {"S": 1, "M": 2, "L": 4, "C": 5}

# ---------------------------------------------------------------------------
# Etki kimlikleri (Java'daki Stat enum adlariyla birebir)
# ---------------------------------------------------------------------------
# Her etki: (STAT, deger[, param])
E = lambda stat, value, param=0: (stat, value, param)

NODES = {
 # ======================= RUH HAKIMIYETI =======================
 "soul": {
  1:  ("Ruh Çekirdeği",      [E("SOUL_GAIN_PCT", 3)]),
  2:  ("İlk Hasat",          [E("SOUL_GAIN_PCT", 3)]),
  3:  ("Soluk Alev",         [E("XP_ON_KILL", 1)]),
  4:  ("Ruh Girdabı",        [E("SOUL_GAIN_PCT", 6), E("SOUL_STRONG_FLAT", 1)]),
  5:  ("Gölge Toplayıcı",    [E("SOUL_GAIN_PCT", 4)]),
  6:  ("Hasat Ritmi",        [E("HEAL_PER_SOUL", 0.10)]),
  7:  ("Derin Ruh",          [E("RANK_ARMOR", 1, 3)]),
  8:  ("Yoğun Kudret",       [E("RANK_DAMAGE_PCT", 4, 4), E("FINISHER_KILL_SOULS", 1)]),
  9:  ("Ruh Hazinesi",       [E("RESET_DISCOUNT_PCT", 10), E("SOUL_GAIN_PCT", 3), E("HEAL_ON_KILL", 0.5)]),
  10: ("Eşik Bekçisi",       [E("LEDGER_DAMAGE_PCT", 2, 500)]),
  11: ("Ruh Emici",          [E("HEAL_PER_SOUL", 0.15)]),
  12: ("Güçlü Av",           [E("SOUL_STRONG_FLAT", 1), E("SOUL_ELITE_PCT", 15)]),
  13: ("Aç Hayalet",         [E("SOUL_GAIN_PCT", 4)]),
  14: ("Soluk Adımlar",      [E("RANK_SPEED_PCT", 3, 5)]),
  15: ("Binlerin Eşiği",     [E("LEDGER_DAMAGE_PCT", 2, 2000)]),
  16: ("Verimli Hasat",      [E("RESET_DISCOUNT_PCT", 8)]),
  17: ("Ruh Bilgesi",        [E("XP_ON_KILL", 2), E("SOUL_GAIN_PCT", 5)]),
  18: ("Ruh Selini Çağıran", [E("SOUL_ELITE_PCT", 40), E("SOUL_STRONG_FLAT", 1)]),
  19: ("Sonsuz Açlık",       [E("SOUL_GAIN_PCT", 12), E("HEAL_PER_SOUL", 0.15)]),
  20: ("Ruh Hâkimi",         [E("SOUL_GAIN_PCT", 10), E("SOUL_ELITE_PCT", 30), E("LEDGER_DAMAGE_PCT", 6, 5000), E("FINISHER_KILL_SOULS", 1)]),
 },
 # ======================= CELLAT YOLU =======================
 "exec": {
  1:  ("Keskin Eğim",        [E("DAMAGE_PCT", 2)]),
  2:  ("Soğuk Bakış",        [E("CRIT_CHANCE_PCT", 3)]),
  3:  ("Ağır Bilek",         [E("HEAVY_DAMAGE_PCT", 3)]),
  4:  ("Cellat Duruşu",      [E("DAMAGE_PCT", 3), E("CRIT_DAMAGE_PCT", 5)]),
  5:  ("Kanlı Sezgi",        [E("LOW_TARGET_DAMAGE_PCT", 4, 35)]),
  6:  ("Hız Kesen",          [E("STREAK_DAMAGE_PCT", 1)]),
  7:  ("Keskin Kenar",       [E("CRIT_DAMAGE_PCT", 5)]),
  8:  ("Seri Katil",         [E("STREAK_MAX_STACKS", 2), E("STREAK_DAMAGE_PCT", 1), E("SOUL_GAIN_PCT", 3)]),
  9:  ("Hükümdarın Fermanı", [E("HEAVY_DAMAGE_PCT", 5), E("STRONG_TARGET_DAMAGE_PCT", 4), E("EXEC_CHANCE_PCT", 5)]),
  10: ("Av Başlar",          [E("FULL_HEALTH_TARGET_DAMAGE_PCT", 4)]),
  11: ("Zırh Yarıcı",        [E("ARMORED_TARGET_DAMAGE_PCT", 4)]),
  12: ("Kan Kokusu",         [E("KILL_HASTE_PCT", 10)]),
  13: ("Soğukkanlı",         [E("CRIT_CHANCE_PCT", 3)]),
  14: ("Ölümcül Ritim",      [E("STREAK_WINDOW_TICKS", 40)]),
  15: ("Öfkenin Tadı",       [E("BERSERK_DAMAGE_PCT", 6)]),
  16: ("Fırlatma Ustası",    [E("THROW_DAMAGE_PCT", 8)]),
  17: ("Son Darbe",          [E("LOW_TARGET_DAMAGE_PCT", 8, 25), E("CRIT_CHANCE_PCT", 2), E("EXEC_HEALTH_RATIO_PCT", 5)]),
  18: ("Kan Borcu",          [E("DAMAGE_PCT", 25), E("MAX_HEALTH_PCT", -20)]),
  19: ("Kırmızı Hesap",      [E("CRIT_CHANCE_PCT", 8), E("CRIT_DAMAGE_PCT", 15)]),
  20: ("Cellat'ın Hükmü",    [E("EXECUTE_THRESHOLD_PCT", 12), E("DAMAGE_PCT", 5), E("KILL_HASTE_PCT", 10), E("EXEC_CHANCE_PCT", 15), E("EXEC_HEALTH_RATIO_PCT", 5)]),
 },
 # ======================= YARIK GEZGINI =======================
 "rift": {
  1:  ("Yarık Fısıltısı",    [E("CLEAVE_COOLDOWN_PCT", 3)]),
  2:  ("Keskin Savruluş",    [E("CLEAVE_DAMAGE_PCT", 4)]),
  3:  ("Geniş Kavis",        [E("CLEAVE_ANGLE_DEG", 5)]),
  4:  ("Boşluk Adımı",       [E("SHUNPO_WINDOW_TICKS", 20), E("POST_CLEAVE_SPEED_PCT", 12)]),
  5:  ("Uzanan Bıçak",       [E("CLEAVE_REACH_PCT", 4)]),
  6:  ("Zaman Çatlağı",      [E("CLEAVE_COOLDOWN_PCT", 4)]),
  7:  ("Çatlak Hasadı",      [E("CLEAVE_KNOCKBACK_PCT", 10)]),
  8:  ("Yarığın Dengesi",    [E("CLEAVE_DAMAGE_PCT", 6), E("CLEAVE_DURABILITY_SAVE_PCT", 30), E("COMBO_FINISH_PCT", 12)]),
  9:  ("Hızlanan Gelgit",    [E("POST_CLEAVE_DAMAGE_PCT", 8), E("HIDDET_COMBO_PCT", 10)]),
  10: ("Geniş Yarık",        [E("CLEAVE_TARGETS", 1)]),
  11: ("Gölge Sıçrayışı",    [E("POST_CLEAVE_SPEED_PCT", 8), E("SHUNPO_HASTE_PCT", 8)]),
  12: ("Yırtılan Perde",     [E("COMBO_RETARGET", 1), E("CLEAVE_TIER3_DAMAGE_PCT", 12), E("CLEAVE_REACH_PCT", 4)]),
  13: ("Dilimleyici",        [E("CLEAVE_DAMAGE_PCT", 4)]),
  14: ("Boşluk Şifası",      [E("CLEAVE_HEAL_PER_HIT", 0.3)]),
  15: ("Ritmik Darbe",       [E("CLEAVE_COOLDOWN_PCT", 4), E("COMBO_DAMAGE_PCT", 4)]),
  16: ("Açılan Kapı",        [E("CLEAVE_ANGLE_DEG", 5), E("COMBO_DAMAGE_PCT", 4)]),
  17: ("Yarık Uzmanı",       [E("COMBO_SWEEP_TARGETS", 1), E("CLEAVE_TARGETS", 1), E("CLEAVE_COOLDOWN_PCT", 5)]),
  18: ("Yarığın Çağrısı",    [E("COMBO_RETARGET_RADIUS", 2), E("COMBO_FINISH_PCT", 10), E("CLEAVE_REACH_PCT", 15), E("CLEAVE_TARGETS", 2), E("CLEAVE_ANGLE_DEG", 10)]),
  19: ("Boşluk Çarpması",    [E("COMBO_SWEEP_TARGETS", 1), E("COMBO_FINISH_PCT", 12), E("CLEAVE_TIER3_DAMAGE_PCT", 25), E("CLEAVE_KNOCKBACK_PCT", 20), E("POST_CLEAVE_DAMAGE_PCT", 8)]),
  20: ("Yarığın Efendisi",   [E("COMBO_DAMAGE_PCT", 10), E("SHUNPO_WINDOW_TICKS", 20), E("SHUNPO_HASTE_PCT", 15), E("CLEAVE_RHYTHM", 35), E("CLEAVE_DAMAGE_PCT", 8), E("CLEAVE_COOLDOWN_PCT", 5)]),
 },
 # ======================= RUH MUHAFIZI =======================
 "guard": {
  1:  ("Taş Kabuk",          [E("ARMOR_FLAT", 1)]),
  2:  ("Sağlam Duruş",       [E("KNOCKBACK_RESIST", 0.10)]),
  3:  ("Soluk Kalkan",       [E("DAMAGE_REDUCTION_PCT", 2)]),
  4:  ("Ruh Zırhı",          [E("ARMOR_FLAT", 1), E("ON_HIT_ARMOR", 2)]),
  5:  ("Kanın Direnci",      [E("MAX_HEALTH_FLAT", 2)]),
  6:  ("Ok Savuşturan",      [E("DR_PROJECTILE_PCT", 5)]),
  7:  ("Alev Perdesi",       [E("DR_FIRE_PCT", 6)]),
  8:  ("Son Nefes",          [E("DR_LOW_HEALTH_PCT", 8), E("SHUNPO_ARMOR", 3), E("SHUNPO_HEAL", 1)]),
  9:  ("Yarık Kalkanı",      [E("POST_CLEAVE_ARMOR", 3), E("BERSERK_DR_PCT", 3)]),
  10: ("Patlama Kabuğu",     [E("DR_EXPLOSION_PCT", 6)]),
  11: ("Düşüş Yastığı",      [E("DR_FALL_PCT", 8)]),
  12: ("Demir İrade",        [E("TOUGHNESS_FLAT", 2), E("MAX_HEALTH_FLAT", 2)]),
  13: ("Yaşam Gıdası",       [E("HEAL_ON_KILL", 0.5)]),
  14: ("Pençe Direnci",      [E("DR_MELEE_PCT", 3)]),
  15: ("Öfke Kabuğu",        [E("BERSERK_DR_PCT", 5)]),
  16: ("Kan Emici",          [E("LIFESTEAL_PCT", 2), E("EXEC_FINISH_HEAL", 1)]),
  17: ("Ruh Duvarı",         [E("DR_MELEE_PCT", 4), E("KNOCKBACK_RESIST", 0.10)]),
  18: ("Dev Kabuk",          [E("MAX_HEALTH_FLAT", 6), E("ARMOR_FLAT", 3), E("TOUGHNESS_FLAT", 1), E("DAMAGE_PCT", -15)]),
  19: ("Ruh Kalesi",         [E("DAMAGE_REDUCTION_PCT", 7), E("ON_HIT_ARMOR", 3), E("SHUNPO_ARMOR", 3), E("DAMAGE_PCT", -10)]),
  20: ("Ölümsüz Muhafız",    [E("LAST_STAND", 300), E("HEAL_ON_KILL", 0.5), E("DAMAGE_REDUCTION_PCT", 3), E("SHUNPO_HEAL", 2), E("EXEC_FINISH_HEAL", 1)]),
 },
 # ======================= LANETLI BILINC =======================
 # WHISPER_UNLOCK param: 1 KILL, 2 BOSS(Kara Koruk), 3 BIG(Wither/Warden/Ejderha), 4 RANKUP(kullanilmaz),
 #                       5 BERSERK, 6 CLEAVE, 7 THROW, 8 LOWHP, 9 NODE, 10 MILESTONE, 11 SENTIENT
 "mind": {
  1:  ("Uyanan Ses",         [E("WHISPER_UNLOCK", 1, 1)]),
  2:  ("Rütbe Yankısı",      [E("RANK_REACT", 1, 2)]),
  3:  ("Öfke Fısıltısı",     [E("WHISPER_UNLOCK", 1, 5)]),
  4:  ("Ruhların Korosu",    [E("WHISPER_COOLDOWN_PCT", 15), E("VISUAL_KILL_WISP", 1)]),
  5:  ("Yarık Sesi",         [E("WHISPER_UNLOCK", 1, 6)]),
  6:  ("Rütbe Yankısı II",   [E("RANK_REACT", 1, 4)]),
  7:  ("Fırlatış Notu",      [E("WHISPER_UNLOCK", 1, 7)]),
  8:  ("Kan Hafızası",       [E("WHISPER_UNLOCK", 1, 8), E("WHISPER_HEAL", 1), E("HIDDET_ROAR_HEAL", 1)]),
  9:  ("Kara Körük'ün Gölgesi", [E("WHISPER_UNLOCK", 1, 2), E("KARA_DAMAGE_PCT", 5), E("SOUL_ELITE_PCT", 10)]),
  10: ("Nöbetçi Zihin",      [E("WHISPER_UNLOCK", 1, 9)]),
  11: ("Rütbe Yankısı III",  [E("RANK_REACT", 1, 6)]),
  12: ("Lanetli Aura",       [E("VISUAL_AURA", 1), E("WHISPER_BUFF_PCT", 6)]),
  13: ("Büyük Avcı",         [E("WHISPER_UNLOCK", 1, 3)]),
  14: ("Eşik Fısıltısı",     [E("WHISPER_UNLOCK", 1, 10)]),
  15: ("Rütbe Yankısı IV",   [E("RANK_REACT", 1, 8)]),
  16: ("Yankılanan Rünler",  [E("VISUAL_RANKUP", 1)]),
  17: ("Soğuk Sezgi",        [E("BOSS_SENSE", 1), E("KARA_DR_PCT", 8)]),
  18: ("Baltanın Hafızası",  [E("HIDDET_COMBO_PCT", 5), E("WHISPER_COOLDOWN_PCT", 25), E("WHISPER_HEAL", 2), E("WHISPER_BUFF_PCT", 6)]),
  19: ("Kutsal Lanet",       [E("HIDDET_COMBO_PCT", 15), E("HIDDET_COMBO_COST", 1), E("HIDDET_ROAR_HEAL", 1), E("KARA_DAMAGE_PCT", 10), E("KARA_DR_PCT", 8), E("VISUAL_CLEAVE", 1)]),
  20: ("Lanetli Bilinç",     [E("HIDDET_ROAR_HEAL", 2), E("SENTIENT", 1), E("WHISPER_UNLOCK", 1, 11), E("WHISPER_BUFF_PCT", 8), E("RANK_REACT", 1, 9)]),
 },
}

BRANCH_NAMES_TR = {
    "soul": "Ruh Hâkimiyeti", "exec": "Cellat Yolu", "rift": "Yarık Gezgini",
    "guard": "Ruh Muhafızı", "mind": "Lanetli Bilinç",
}


STATIC_LANG = {
 "key.battleaxe.nexus": "Ruh Ağı'nı Aç",
 "item.battleaxe.battle_axe.nexus": "» Ruh Ağı: %s",
 "nexus.screen.title": "Ruh Ağı",
 "nexus.type.small": "Küçük düğüm", "nexus.type.medium": "Orta düğüm", "nexus.type.large": "Büyük düğüm",
 "nexus.type.capstone": "Dal sonu uzmanlaşması",
 "nexus.ui.center": "Merkez", "nexus.ui.zoom_in": "+", "nexus.ui.zoom_out": "-",
 "nexus.ui.buy": "Satın Al", "nexus.ui.reset": "Sıfırla", "nexus.ui.close": "Kapat",
 "nexus.ui.confirm": "Onayla", "nexus.ui.cancel": "Vazgeç",
 "nexus.ui.balance": "Ruh bakiyesi: %s",
 "nexus.ui.points": "Yetenek puanı: %1$s (kazanılan %2$s)",
 "nexus.ui.xp": "XP: sv. %1$s (%2$s puan)",
 "nexus.ui.rank": "Rütbe: %s",
 "nexus.ui.next_point": "Sonraki puana: %s ruh",
 "nexus.ui.next_max": "Tüm puanlar kazanıldı",
 "nexus.ui.effects": "Etkiler",
 "nexus.ui.hint": "Sürükle: gez  -  Tekerlek: yakınlaştır  -  Tıkla: düğüm seç. Bir düğüm seçip Satın Al'a bas.",
 "nexus.ui.state.unlocked": "Açık", "nexus.ui.state.available": "Açılabilir",
 "nexus.ui.state.lacking": "Kaynak yetersiz", "nexus.ui.state.locked": "Kilitli (bağlantı yok)",
 "nexus.ui.req.link": "Açık bir komşu düğüme bağlı",
 "nexus.ui.req.node": "Önkoşul: %1$s (%2$s)",
 "nexus.ui.role": "Rol",
 "nexus.role.base": "Temel düğüm", "nexus.role.mechanic": "Mekanik düğüm", "nexus.role.specialty": "Uzmanlık düğümü",
 "nexus.role.synergy": "Sinerji düğümü", "nexus.role.major": "Büyük düğüm",
 "nexus.ui.req.points": "Maliyet: %1$s puan (elinde %2$s)",
 "nexus.ui.req.xp": "Ek maliyet: %1$s seviye değerinde XP (%2$s puan)",
 "nexus.ui.req.capstone": "Dalda en az %1$s düğüm ve %2$s büyük düğüm (şu an %3$s / %4$s)",
 "nexus.ui.need_axe": "Satın almak ve sıfırlamak için baltayı elinde tut.",
 "nexus.ui.reset.title": "Ruh Ağı sıfırlansın mı?",
 "nexus.ui.reset.body": "%s düğüm kapatılacak ve harcadığın yetenek puanları iade edilecek.",
 "nexus.ui.reset.cost": "Bedel: %1$s ruh + %2$s XP puanı (%3$s seviye değerinde).",
 "nexus.ui.reset.keeps": "Rütben, ruh geçmişin, fısıltılar ve Kara Çubuk yükseltmen korunur.",
 "nexus.ui.reset.insufficient": "Yetersiz kaynak: ruh bakiyesi veya XP eksik.",
 "nexus.msg.unknown_node": "Bilinmeyen düğüm.", "nexus.msg.already_owned": "Bu düğüm zaten açık.",
 "nexus.msg.not_reachable": "Önce bu düğüme bağlı bir düğümü aç.",
 "nexus.msg.requirements": "Bu sinerji düğümünün önkoşulu (başka daldaki düğüm) açık değil.",
 "nexus.msg.migrated": "Ruh Ağı yenilendi: %s düğümün kapatıldı (önkoşul/tablo değişti); yetenek puanların iade edildi.",
 "nexus.msg.capstone_progress": "Dal sonu için bu dalda yeterli ilerleme yok.",
 "nexus.msg.not_enough_points": "Yeterli yetenek puanın yok.",
 "nexus.msg.not_enough_xp": "Yeterli deneyimin yok.",
 "nexus.msg.not_enough_souls": "Yeterli ruh bakiyen yok.",
 "nexus.msg.nothing_to_reset": "Sıfırlanacak düğüm yok.",
 "nexus.msg.count_mismatch": "Düğüm sayısı değişti; sıfırlamayı yeniden onayla.",
 "nexus.msg.need_axe": "Baltayı elinde tutmalısın.", "nexus.msg.too_fast": "Çok hızlı; biraz bekle.",
 "nexus.msg.bad_request": "Geçersiz istek.", "nexus.msg.purchased": "Düğüm açıldı.",
 "nexus.msg.reset_done": "Ruh Ağı sıfırlandı; yetenek puanların iade edildi.",
 "nexus.msg.points_gained": "+%s yetenek puanı (Ruh Ağı)",
 "nexus.msg.last_stand": "Son Direniş! Balta seni ayakta tuttu.",
 "nexus.event.1": "bir düşmanı öldürdüğünde", "nexus.event.2": "Kara Körük'ü yendiğinde",
 "nexus.event.3": "büyük bir düşmanı (Wither, Warden, Ejderha) yendiğinde", "nexus.event.5": "Hiddet başladığında",
 "nexus.event.6": "Yar Geç kullandığında", "nexus.event.7": "baltayı fırlattığında", "nexus.event.8": "canın çok düştüğünde",
 "nexus.event.9": "yeni bir düğüm açtığında", "nexus.event.10": "yeni bir yetenek puanı kazandığında",
 "nexus.event.11": "kendiliğinden (uyanmış bilinç)",
 # --- Etki sablonlari: %1$s isaretli deger, %2$s parametre, %3$s isaretsiz deger ---
 "nexus.stat.SOUL_GAIN_PCT": "Öldürmelerden kazanılan ruh %1$s%%",
 "nexus.stat.SOUL_STRONG_FLAT": "Güçlü düşmanlardan (60+ can) %1$s ek ruh",
 "nexus.stat.SOUL_ELITE_PCT": "Elit düşman ve boss'lardan (160+ can) ruh %1$s%%",
 "nexus.stat.XP_ON_KILL": "Her öldürmede %3$s deneyim puanı",
 "nexus.stat.HEAL_PER_SOUL": "Kazanılan her ruh için %3$s can (öldürme başına en çok 4)",
 "nexus.stat.RESET_DISCOUNT_PCT": "Sıfırlama ruh bedeli %3$s%% daha ucuz",
 "nexus.stat.RANK_ARMOR": "Balta %2$s. rütbe ve üstündeyken zırh %1$s",
 "nexus.stat.RANK_DAMAGE_PCT": "Balta %2$s. rütbe ve üstündeyken hasar %1$s%%",
 "nexus.stat.RANK_SPEED_PCT": "Balta %2$s. rütbe ve üstündeyken hareket hızı %1$s%%",
 "nexus.stat.LEDGER_DAMAGE_PCT": "Toplam ruh ilerlemen %2$s'e ulaşınca hasar %1$s%%",
 "nexus.stat.DAMAGE_PCT": "Balta hasarı %1$s%% (tüm hasar bonuslarının toplamı sınırlıdır)",
 "nexus.stat.CRIT_CHANCE_PCT": "Tam şarjlı vuruşta %3$s%% ihtimalle Cellat darbesi (1,5x hasar)",
 "nexus.stat.CRIT_DAMAGE_PCT": "Kritik vuruş hasarı %1$s%%",
 "nexus.stat.HEAVY_DAMAGE_PCT": "Tam şarjlı (ağır) vuruşlarda hasar %1$s%%",
 "nexus.stat.LOW_TARGET_DAMAGE_PCT": "Canı %2$s%% ve altındaki hedeflere hasar %1$s%%",
 "nexus.stat.STREAK_DAMAGE_PCT": "Öldürme serisinin her kademesi için hasar %1$s%%",
 "nexus.stat.STREAK_MAX_STACKS": "Öldürme serisi azami kademesi %1$s (temel 3)",
 "nexus.stat.STREAK_WINDOW_TICKS": "Öldürme serisi süresi %1$s tick (20 tick = 1 sn)",
 "nexus.stat.STRONG_TARGET_DAMAGE_PCT": "100+ canlı hedeflere hasar %1$s%%",
 "nexus.stat.FULL_HEALTH_TARGET_DAMAGE_PCT": "Canı tam dolu hedeflere hasar %1$s%%",
 "nexus.stat.ARMORED_TARGET_DAMAGE_PCT": "Zırhı 8 ve üstü hedeflere hasar %1$s%%",
 "nexus.stat.KILL_HASTE_PCT": "Öldürünce 3 saniye saldırı hızı %1$s%%",
 "nexus.stat.BERSERK_DAMAGE_PCT": "Hiddet aktifken hasar %1$s%%",
 "nexus.stat.THROW_DAMAGE_PCT": "Fırlatılan balta hasarı %1$s%%",
 "nexus.stat.MAX_HEALTH_PCT": "Azami can %1$s%%",
 "nexus.stat.EXECUTE_THRESHOLD_PCT": "İnfaz: vuruş hedefi azami canının %3$s%% altına düşürecekse hedefi öldürür (boss ve oyuncular hariç)",
 "nexus.stat.SHUNPO_WINDOW_TICKS": "Shunpo: balta bir canavara isabet ettikten sonra ikinci tuş için süre %3$s tick uzar (temel 80 tick = 4 sn)",
 "nexus.stat.SHUNPO_HASTE_PCT": "Shunpo sonrası 3 saniye saldırı hızı %1$s%%",
 "nexus.stat.COMBO_DAMAGE_PCT": "Shunpo kombosunun tüm vuruşlarının hasarı %1$s%%",
 "nexus.stat.COMBO_FINISH_PCT": "Kombonun bitirici (3.) vuruşunun hasarı %1$s%%",
 "nexus.stat.COMBO_RETARGET": "Ana hedef ikinci vuruştan önce ölürse kombo 4 blok yakınındaki başka bir düşmana geçer (kombo başına bir kez)",
 "nexus.stat.COMBO_RETARGET_RADIUS": "Kombonun hedef değiştirme yarıçapı %3$s blok artar (temel 4)",
 "nexus.stat.COMBO_SWEEP_TARGETS": "Bitirici vuruş, ana hedefin yanındaki %3$s ek düşmana da hasarının %%60'ını verir",
 "nexus.stat.EXEC_CHANCE_PCT": "Execution bitirici olasılığı %3$s puan artar (temel %%25)",
 "nexus.stat.EXEC_HEALTH_RATIO_PCT": "Execution için hedefin can eşiği %3$s puan yükselir (temel %%30)",
 "nexus.stat.FINISHER_KILL_SOULS": "Bitirici öldürüşlerden (Execution, kombo bitirici) %3$s ek ruh",
 "nexus.stat.SHUNPO_ARMOR": "Shunpo sonrası 4 saniye zırh %1$s",
 "nexus.stat.SHUNPO_HEAL": "Canın yarının altındayken Shunpo %3$s can yeniler",
 "nexus.stat.EXEC_FINISH_HEAL": "Execution bitiricisi tamamlanınca %3$s can yenilersin",
 "nexus.stat.HIDDET_COMBO_PCT": "Hiddet aktifken kombo vuruşlarının hasarı %1$s%%",
 "nexus.stat.HIDDET_COMBO_COST": "BEDEL: Hiddet aktifken her kombo başlangıcında %3$s can harcarsın (seni asla öldürmez; canın düşükse harcanmaz)",
 "nexus.stat.HIDDET_ROAR_HEAL": "Hiddet aktifken kritik öldürüş kükremesi %3$s can yeniler",
 "nexus.stat.CLEAVE_COOLDOWN_PCT": "Yar Geç bekleme süresi %3$s%% kısalır (asla sıfırlanmaz)",
 "nexus.stat.CLEAVE_DAMAGE_PCT": "Yar Geç hasarı %1$s%%",
 "nexus.stat.CLEAVE_REACH_PCT": "Yar Geç menzili %1$s%%",
 "nexus.stat.CLEAVE_ANGLE_DEG": "Yar Geç açısı %1$s derece",
 "nexus.stat.CLEAVE_TARGETS": "Yar Geç %3$s ek hedef vurur",
 "nexus.stat.CLEAVE_KNOCKBACK_PCT": "Yar Geç itme gücü %1$s%%",
 "nexus.stat.CLEAVE_DURABILITY_SAVE_PCT": "Yar Geç'te %3$s%% ihtimalle dayanıklılık harcanmaz",
 "nexus.stat.POST_CLEAVE_SPEED_PCT": "İsabetli Yar Geç sonrası 3 saniye hareket hızı %1$s%%",
 "nexus.stat.POST_CLEAVE_DAMAGE_PCT": "İsabetli Yar Geç sonrası 5 saniye hasar %1$s%%",
 "nexus.stat.CLEAVE_HEAL_PER_HIT": "Yar Geç'in her isabeti (ilk 3 hedef) %3$s can iyileştirir",
 "nexus.stat.CLEAVE_TIER3_DAMAGE_PCT": "Tam şarjlı (3. kademe) Yar Geç hasarı %1$s%%",
 "nexus.stat.CLEAVE_RHYTHM": "Bir Yar Geç 3+ düşmana vurursa sonraki Yar Geç'in beklemesi bir kez daha %3$s%% kısalır",
 "nexus.stat.ARMOR_FLAT": "Zırh %1$s (baltayı tutarken)",
 "nexus.stat.TOUGHNESS_FLAT": "Zırh sertliği %1$s",
 "nexus.stat.KNOCKBACK_RESIST": "İtilme direnci %1$s",
 "nexus.stat.MAX_HEALTH_FLAT": "Azami can %1$s",
 "nexus.stat.HEAL_ON_KILL": "Her öldürmede %3$s can iyileşirsin",
 "nexus.stat.ON_HIT_ARMOR": "Başarılı vuruştan sonra 3 saniye zırh %1$s",
 "nexus.stat.POST_CLEAVE_ARMOR": "İsabetli Yar Geç sonrası 4 saniye zırh %1$s",
 "nexus.stat.LIFESTEAL_PCT": "Verdiğin hasarın %3$s%%'i kadar can çalarsın (vuruş başına en çok 4)",
 "nexus.stat.DAMAGE_REDUCTION_PCT": "Gelen hasar %3$s%% azalır",
 "nexus.stat.DR_PROJECTILE_PCT": "Mermi hasarı %3$s%% azalır",
 "nexus.stat.DR_FIRE_PCT": "Ateş ve lav hasarı %3$s%% azalır",
 "nexus.stat.DR_EXPLOSION_PCT": "Patlama hasarı %3$s%% azalır",
 "nexus.stat.DR_FALL_PCT": "Düşme hasarı %3$s%% azalır",
 "nexus.stat.DR_LOW_HEALTH_PCT": "Canın yarının altındayken gelen hasar %3$s%% azalır",
 "nexus.stat.DR_MELEE_PCT": "Yakın dövüş hasarı %3$s%% azalır",
 "nexus.stat.BERSERK_DR_PCT": "Hiddet aktifken gelen hasar %3$s%% azalır",
 "nexus.stat.LAST_STAND": "Son Direniş: ölümcül vuruşta hayatta kalırsın (can %%30'a döner), %3$s saniye bekleme",
 "nexus.stat.WHISPER_UNLOCK": "Balta şu olayda konuşur: %2$s",
 "nexus.stat.RANK_REACT": "Balta %2$s. rütbeye ulaşınca sana özel konuşur",
 "nexus.stat.WHISPER_COOLDOWN_PCT": "Baltanın konuşma beklemesi %3$s%% kısalır",
 "nexus.stat.WHISPER_HEAL": "Balta konuştuğunda %3$s can iyileşirsin",
 "nexus.stat.WHISPER_BUFF_PCT": "Balta konuştuğunda 4 saniye hareket hızı %1$s%%",
 "nexus.stat.KARA_DAMAGE_PCT": "Kara Körük'e hasar %1$s%%",
 "nexus.stat.KARA_DR_PCT": "Kara Körük'ten gelen hasar %3$s%% azalır",
 "nexus.stat.VISUAL_KILL_WISP": "Öldürmelerde ruh dumanı yükselir",
 "nexus.stat.VISUAL_AURA": "Baltayı tutarken etrafında lanetli bir ruh aurası belirir",
 "nexus.stat.VISUAL_RANKUP": "Rütbe atlarken ruh alevi yankılanır",
 "nexus.stat.VISUAL_CLEAVE": "Yar Geç'in izinde ruh alevi kalır",
 "nexus.stat.BOSS_SENSE": "Yakınlarda (48 blok) Kara Körük varsa balta seni uyarır",
 "nexus.stat.SENTIENT": "Balta uyanır: ara sıra kendiliğinden konuşur",
 "nexus.whisper.sense": "Balta titredi... Kara Körük çok uzakta değil. Yaklaşık %s blok.",
 "nexus.rank_react.2": "Artık beni sadece bir demir sanmıyorsun, %s. İyi.",
 "nexus.rank_react.4": "Dördüncü eşik. Ruhlar seni tanıyor artık.",
 "nexus.rank_react.6": "Altıncı eşik... Eli ağırlaşıyor, ama kalbi hafifliyor mu?",
 "nexus.rank_react.8": "Sekiz. Tanrılar bile bizi hatırlayacak.",
 "nexus.rank_react.9": "Dokuz. Artık ben senim, sen de benim, %s.",
}
WHISPERS = {
 "kill": ["Bir tane daha. Say onları.", "Güzel keser, güzel doyar.", "Adını hatırlamayacaklar, ama ben hatırlayacağım, %s."],
 "boss": ["Demirhane'nin sahibi düştü. Kor bile soğudu.", "Kara Körük sustu. Şimdi sıra sende, %s.", "Bu ruh... çok eski bir ateşten. Kokusunu içime çektim."],
 "big": ["Büyük bir av. Ruhu ağır, tadı derin.", "Böylesi nadirdir. Bu zafer beni uyandırır.", "Dünyanın efsanelerinden biri eksildi, %s."],
 "berserk": ["Kan kaynıyor! Bırak, ben yöneteyim!", "Öfken benim yakıtım. Devam et!", "İşte bu. Şimdi gerçekten uyanıyoruz, %s."],
 "cleave": ["Havayı yardın. Perde ince.", "Yarık güldü.", "Boşluk senin elinde kılıç oldu, %s."],
 "throw": ["Uç! Sana geri döneceğim.", "Havada özgürüm... kısa süreliğine.", "Beni bırakmanı sevmem. Ama dönmeyi severim, %s."],
 "low_health": ["Kanın akıyor. Bırakma beni!", "Dişlerini sık. Beraber ölmek yok.", "Hâlâ buradayım, %s. Sen de kal."],
 "node": ["Ağ gerildi. Ruhlarım yeni bir yol buldu.", "Hissettin mi? Bir bağ daha kuruldu.", "Seçimini yaptın, %s. Artık geri dönüşü yalnızca bedeli var."],
 "milestone": ["Ruhlar yetti. Yeni bir güç doğuyor.", "Bir eşik daha geçildi.", "Doyduk, %s. Şimdi seç."],
 "sentient": ["Hâlâ burada mısın? İyi. Ben de.", "Bazen sessizlik kanımdan ağır geliyor.", "Düşünüyorum da, %s... ikimizden hangisi kimi taşıyor?"],
}
for _ev, _lines in WHISPERS.items():
    for _i, _t in enumerate(_lines, 1):
        STATIC_LANG["nexus.whisper.%s.%d" % (_ev, _i)] = _t

STATS_IN_USE = set()
for _b in NODES.values():
    for _n in _b.values():
        for _e in _n[1]:
            STATS_IN_USE.add(_e[0])


# ---------------------------------------------------------------------------
# Dugum listesi ve dogrulama
# ---------------------------------------------------------------------------
def node_id(branch, no):
    return "%s_%02d" % (branch, no)


def build():
    nodes = {}
    for b in BRANCHES:
        ang = math.radians(BRANCH_ANGLE[b])
        ca, sa = math.cos(ang), math.sin(ang)
        for (no, typ, u, v, links) in TEMPLATE:
            # yerel (u, v) -> dunya (x, y); v, daldan saat yonune dogru yanal eksen.
            x = u * ca - v * sa
            y = u * sa + v * ca
            name, effects = NODES[b][no]
            nodes[node_id(b, no)] = {
                "id": node_id(b, no), "branch": b, "no": no, "type": typ,
                "x": x, "y": y, "name": name, "effects": effects,
                "role": ROLE_BY_NO[no],
                "requires": [node_id(*REQUIRES[(b, no)])] if (b, no) in REQUIRES else [],
                "links": set(node_id(b, l) for l in links),
            }
    # cift yonlu baglantilar
    for n in list(nodes.values()):
        for l in n["links"]:
            nodes[l]["links"].add(n["id"])
    for (b1, n1, b2, n2) in BRIDGES:
        a, c = node_id(b1, n1), node_id(b2, n2)
        nodes[a]["links"].add(c)
        nodes[c]["links"].add(a)
    return nodes


def validate(nodes):
    errors = []
    if len(nodes) != 100:
        errors.append("dugum sayisi 100 degil: %d" % len(nodes))
    for b in BRANCHES:
        bn = [n for n in nodes.values() if n["branch"] == b]
        cnt = {t: sum(1 for n in bn if n["type"] == t) for t in "SMLC"}
        if len(bn) != 20 or cnt != {"S": 12, "M": 5, "L": 2, "C": 1}:
            errors.append("dal %s dagilimi hatali: %s" % (b, cnt))
    # her dugumun en az bir etkisi, tum kimlikler benzersiz
    if len(set(nodes)) != len(nodes):
        errors.append("kimlik cakismasi")
    # roller, onkosullar, maliyet
    total = 0
    for n in nodes.values():
        total += COST[n["type"]]
        if n["role"] == "SYNERGY" and not n["requires"]:
            errors.append("%s sinerji ama onkosulu yok" % n["id"])
        if n["role"] != "SYNERGY" and n["requires"]:
            errors.append("%s sinerji degil ama onkosulu var" % n["id"])
        for r in n["requires"]:
            if r not in nodes:
                errors.append("%s onkosulu bilinmiyor: %s" % (n["id"], r))
            elif nodes[r]["branch"] == n["branch"] or nodes[r]["no"] > 7:
                errors.append("%s onkosulu baska daldan ve erken (no<=7) olmali: %s" % (n["id"], r))
    cfg = open(os.path.join(ROOT, "src/main/java/com/battleaxe/nexus/NexusConfig.java"), encoding="utf-8").read()
    import re as _re
    mp = int(_re.search(r"MAX_POINTS = (\d+);", cfg).group(1))
    if mp != total:
        errors.append("NexusConfig.MAX_POINTS (%d) agacin toplam maliyetine (%d) esit olmali" % (mp, total))
    for key, val in (("COST_SMALL", 1), ("COST_MEDIUM", 2), ("COST_LARGE", 4), ("COST_CAPSTONE", 5)):
        if int(_re.search(key + r" = (\d+);", cfg).group(1)) != val:
            errors.append("NexusConfig.%s betikteki COST ile uyumsuz" % key)
    for st in STATS_IN_USE:
        if "nexus.stat." + st not in STATIC_LANG:
            errors.append("etki icin dil sablonu yok: " + st)
    for n in nodes.values():
        if not n["effects"]:
            errors.append("%s etkisiz" % n["id"])
        if not n["links"] and n["no"] != 1:
            errors.append("%s bagli degil" % n["id"])
    # erisilebilirlik: cekirdek -> n1 (her dal) -> tum agac
    start = [node_id(b, 1) for b in BRANCHES]
    seen, dq = set(start), deque(start)
    while dq:
        cur = dq.popleft()
        for l in nodes[cur]["links"]:
            if l not in seen:
                seen.add(l)
                dq.append(l)
    if len(seen) != len(nodes):
        errors.append("ulasilamayan dugumler: %s" % sorted(set(nodes) - seen))
    # her dal kendi basina cekirdekten ulasilabilir olmali (diger dallar zorunlu olmasin)
    for b in BRANCHES:
        s0 = node_id(b, 1)
        seen_b, dq = {s0}, deque([s0])
        while dq:
            cur = dq.popleft()
            for l in nodes[cur]["links"]:
                if nodes[l]["branch"] == b and l not in seen_b:
                    seen_b.add(l)
                    dq.append(l)
        if len(seen_b) != 20:
            errors.append("dal %s kendi icinde tam baglanti degil (%d/20)" % (b, len(seen_b)))
    # dallar arasi baglanti sayisi sinirli
    cross = set()
    for n in nodes.values():
        for l in n["links"]:
            if nodes[l]["branch"] != n["branch"]:
                cross.add(tuple(sorted((n["id"], l))))
    if len(cross) != 5:
        errors.append("kopru sayisi 5 olmali: %d" % len(cross))
    # dugumler cakismasin (ekranda ust uste binmesin)
    pts = list(nodes.values())
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            d = math.hypot(pts[i]["x"] - pts[j]["x"], pts[i]["y"] - pts[j]["y"])
            if d < 0.55:
                errors.append("%s ve %s cok yakin (%.2f)" % (pts[i]["id"], pts[j]["id"], d))
    return errors


# ---------------------------------------------------------------------------
# Cikti: Java
# ---------------------------------------------------------------------------
def fnum(v):
    if isinstance(v, float) and not float(v).is_integer():
        return repr(round(v, 4)) + "D"
    return "%dD" % int(v)


def emit_java(nodes):
    lines = []
    w = lines.append
    w("package com.battleaxe.nexus;")
    w("")
    w("import static com.battleaxe.nexus.Branch.*;")
    w("import static com.battleaxe.nexus.NodeType.*;")
    w("import static com.battleaxe.nexus.Stat.*;")
    w("")
    w("import java.util.ArrayList;")
    w("import java.util.List;")
    w("")
    w("/**")
    w(" * Ruh Ağı'nın 100 düğümlük TANIM TABLOSU (rol + önkoşul + etki). BU DOSYA tools/gen_nexus.py TARAFINDAN ÜRETİLİR;")
    w(" * elle düzenlemek yerine betiği düzenleyip yeniden çalıştır (betik ağı da doğrular).")
    w(" * Elle düzenlersen: NexusTree'nin açılışta çalıştırdığı doğrulama (sayılar, bağlantılar,")
    w(" * erişilebilirlik) hatalı bir tabloyu reddeder.")
    w(" *")
    w(" * <p>Her satır: kimlik, dal, tür, x, y (ağ koordinatı), bağlantılar, etkiler. Ad ve açıklamalar")
    w(" * dil dosyasından gelir (nexus.node.&lt;kimlik&gt;); açıklama etkilerden otomatik kurulur.")
    w(" */")
    w("final class NexusNodes {")
    w("\tprivate NexusNodes() {")
    w("\t}")
    w("")
    w("\t/** Bu dallar tabloda dönüşümlü olarak 20'şer düğüm içerir. */")
    w("\tstatic List<NodeDef> create() {")
    w("\t\tList<NodeDef> n = new ArrayList<>(100);")
    for b in BRANCHES:
        w("")
        w("\t\t// ---- %s ----" % BRANCH_NAMES_TR[b])
        for (no, typ, u, v, links) in TEMPLATE:
            nd = nodes[node_id(b, no)]
            link_ids = sorted(nd["links"])
            effs = ", ".join("fx(%s, %s%s)" % (e[0], fnum(e[1]), (", %d" % e[2]) if e[2] else "")
                             for e in nd["effects"])
            w('\t\tn.add(new NodeDef("%s", %s, %s, NodeRole.%s, %.3ff, %.3ff,' % (
                nd["id"], BRANCH_JAVA[b], TYPE_JAVA[typ], nd["role"], nd["x"], nd["y"]))
            w('\t\t\t\tnew String[] {%s},' % ", ".join('"%s"' % l for l in link_ids))
            w('\t\t\t\tnew String[] {%s},' % ", ".join('"%s"' % r for r in nd["requires"]))
            w('\t\t\t\tnew Effect[] {%s}));' % effs)
    w("")
    w("\t\treturn n;")
    w("\t}")
    w("")
    w("\tprivate static Effect fx(Stat stat, double value) {")
    w("\t\treturn new Effect(stat, value, 0);")
    w("\t}")
    w("")
    w("\tprivate static Effect fx(Stat stat, double value, int param) {")
    w("\t\treturn new Effect(stat, value, param);")
    w("\t}")
    w("}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Cikti: dil dosyalari (yalnizca nexus.node.* anahtarlari uretilir/guncellenir)
# ---------------------------------------------------------------------------
def update_lang(nodes):
    changed = []
    for fn in ("en_us.json", "tr_tr.json"):
        path = os.path.join(ROOT, "src/main/resources/assets/battleaxe/lang", fn)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        for k in [k for k in data if k.startswith("nexus.")]:
            del data[k]
        data.update(STATIC_LANG)
        data["nexus.ui.balance"] = STATIC_LANG["nexus.ui.balance"]
        for b in BRANCHES:
            data["nexus.branch." + b] = BRANCH_NAMES_TR[b]
        for n in nodes.values():
            data["nexus.node." + n["id"]] = n["name"]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        changed.append(fn)
    return changed


def preview(nodes):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return False
    colors = {"soul": "#6fe3ff", "exec": "#ff5a4a", "rift": "#c780ff", "guard": "#ffc84a", "mind": "#7dff9a"}
    size = {"S": 40, "M": 110, "L": 260, "C": 520}
    fig, ax = plt.subplots(figsize=(12, 12), facecolor="#0a0810")
    ax.set_facecolor("#0a0810")
    for n in nodes.values():
        for l in n["links"]:
            m = nodes[l]
            ax.plot([n["x"], m["x"]], [n["y"], m["y"]], color="#443a55", lw=1, zorder=1)
    for b in BRANCHES:
        a = nodes[node_id(b, 1)]
        ax.plot([0, a["x"]], [0, a["y"]], color="#443a55", lw=1, zorder=1)
    ax.scatter([0], [0], s=700, c="#ffffff", zorder=3)
    for n in nodes.values():
        ax.scatter([n["x"]], [n["y"]], s=size[n["type"]], c=colors[n["branch"]], zorder=3, edgecolors="#ffffff", linewidths=0.5)
        ax.annotate(str(n["no"]), (n["x"], n["y"]), fontsize=6, ha="center", va="center", zorder=4)
    ax.set_aspect("equal")
    ax.invert_yaxis()
    ax.axis("off")
    fig.savefig(os.path.join(ROOT, "tools/nexus_preview.png"), dpi=110, bbox_inches="tight", facecolor=fig.get_facecolor())
    return True


def main():
    nodes = build()
    errors = validate(nodes)
    if errors:
        print("DOGRULAMA HATALARI:")
        for e in errors:
            print("  -", e)
        sys.exit(1)
    out = os.path.join(ROOT, "src/main/java/com/battleaxe/nexus/NexusNodes.java")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(emit_java(nodes))
    langs = update_lang(nodes)
    ok = preview(nodes)
    per = {b: sum(1 for n in nodes.values() if n["branch"] == b) for b in BRANCHES}
    print("Tamam: %d dugum %s; kullanilan etki turu: %d; lang: %s; onizleme: %s" % (
        len(nodes), per, len(STATS_IN_USE), langs, "tools/nexus_preview.png" if ok else "(matplotlib yok)"))
    print("Kullanilan etkiler:", ", ".join(sorted(STATS_IN_USE)))


if __name__ == "__main__":
    main()
