#!/usr/bin/env python3
"""
Kara Körük'ün demirci çekicinin dokusunu kara_koruk.png dosyasına boyar.

Doku 128x128'dir; gövde/baş/kollar üst yarıda (y < 50) durur. Çekiç, boş alana (x 0..62, y 64..124) şu düzenle yerleşir
(KaraKorukModel'deki texOffs değerleriyle birebir aynı olmak zorundadır):
  sap       : texOffs(0, 66),   kutu 2 x 29 x 2   -> x 0..8,   y 66..97
  sap ucu   : texOffs(50, 66),  kutu 3 x 2 x 3    -> x 50..62, y 66..71
  sap bandı : texOffs(50, 74),  kutu 3 x 2 x 3    -> x 50..62, y 74..79
  baş       : texOffs(0, 100),  kutu 8 x 9 x 14   -> x 0..44,  y 100..123
Betik idempotenttir: her çalışmada çekiç bölgesini silip yeniden boyar (gövde dokusuna dokunmaz).
Çalıştırma:  python3 tools/gen_hammer_texture.py
"""
import os
import random
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH = os.path.join(ROOT, "src/main/resources/assets/battleaxe/textures/entity/kara_koruk.png")

random.seed(1337)
im = Image.open(PATH).convert("RGBA")
px = im.load()

# Çekiç bölgesini temizle (yalnızca y >= 64)
for y in range(64, 128):
    for x in range(0, 128):
        px[x, y] = (0, 0, 0, 0)


def jitter(c, n):
    return tuple(max(0, min(255, v + random.randint(-n, n))) for v in c[:3]) + (255,)


def fill(x0, y0, x1, y1, base, noise=5):
    for y in range(y0, y1):
        for x in range(x0, x1):
            px[x, y] = jitter(base, noise)


IRON = (38, 34, 40)
IRON_WORN = (66, 62, 70)
IRON_EDGE = (84, 78, 86)
WOOD = (62, 40, 28)
WOOD_DARK = (44, 28, 20)
EMBER = (255, 132, 38)
EMBER_HOT = (255, 206, 90)


def cracks(x0, y0, x1, y1, count, hot=True):
    """Kızgın turuncu çatlaklar: kısa, kırık çizgiler."""
    for _ in range(count):
        x = random.randint(x0, x1 - 1)
        y = random.randint(y0, y1 - 1)
        for _step in range(random.randint(3, 7)):
            if x0 <= x < x1 and y0 <= y < y1:
                px[x, y] = EMBER_HOT if (hot and random.random() < 0.3) else EMBER
                if random.random() < 0.35 and x + 1 < x1:
                    px[x + 1, y] = (200, 90, 24, 255)
            x += random.choice((-1, 0, 1))
            y += random.choice((0, 1, 1))


# ---- Sap: 2x29x2 @ (0, 66): üst/alt 2x2, yan yüzler 2x29 (d x h)
fill(0, 66, 8, 97, WOOD, 4)
for y in range(68, 97, 3):  # damar çizgileri
    for x in (0, 1, 2, 3, 4, 5, 6, 7):
        px[x, y] = jitter(WOOD_DARK, 4)
for y in range(66, 68):  # üst/alt: koyu demir başlık
    for x in range(2, 6):
        px[x, y] = jitter(IRON, 3)

# ---- Sap ucu ve sap bandı: 3x2x3 -> 12x5
fill(50, 66, 62, 71, IRON, 4)
fill(50, 74, 62, 79, IRON, 4)
for x in range(50, 62):
    px[x, 66] = jitter(IRON_EDGE, 3)
    px[x, 74] = jitter(IRON_EDGE, 3)

# ---- Baş: 8x9x14 @ (0, 100); d=14, w=8, h=9
# üst  : x 14..22, y 100..114   alt : x 22..30, y 100..114
# sol  : x 0..14,  y 114..123   ön  : x 14..22, y 114..123
# sağ  : x 22..36, y 114..123   arka: x 36..44, y 114..123
fill(0, 100, 44, 123, IRON, 5)
fill(14, 100, 30, 114, IRON, 5)
# vuruş yüzleri (ön/arka): aşınmış, parlak demir + kenar çerçevesi
for (x0, x1) in ((14, 22), (36, 44)):
    fill(x0, 114, x1, 123, IRON_WORN, 6)
    for x in range(x0, x1):
        px[x, 114] = jitter(IRON_EDGE, 4)
        px[x, 122] = jitter(IRON_EDGE, 4)
    for y in range(114, 123):
        px[x0, y] = jitter(IRON_EDGE, 4)
        px[x1 - 1, y] = jitter(IRON_EDGE, 4)
    cracks(x0 + 1, 115, x1 - 1, 122, 2, hot=False)
# uzun yanlar (sol/sağ) ve üst yüz: kızgın çatlaklar
cracks(0, 114, 14, 123, 5)
cracks(22, 114, 36, 123, 5)
cracks(14, 100, 22, 114, 4)
cracks(22, 100, 30, 114, 2)
# kenar bantları (yan yüzlerin üst ve alt kenarı)
for (x0, x1) in ((0, 14), (22, 36)):
    for x in range(x0, x1):
        px[x, 114] = jitter(IRON_EDGE, 3)
        px[x, 122] = jitter(IRON_EDGE, 3)

im.save(PATH)
print("Çekiç dokusu boyandı:", PATH)
