import java.util.HashSet;
import java.util.Set;

import com.battleaxe.execution.ExecutionCatalog;
import com.battleaxe.execution.ExecutionCatalog.Flair;
import com.battleaxe.execution.ExecutionCatalog.Profile;
import com.battleaxe.execution.ExecutionConfig;
import com.battleaxe.execution.ExecutionTiming;

/** Minecraft gerektirmeyen Execution katalog testleri. Çalıştırma: tools/test/run_tests.sh */
public final class ExecutionCatalogTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) {
		// Katalog dolu ve her kayıt kendi kimliğiyle bulunuyor.
		check(ExecutionCatalog.all().size() >= 16, "katalog en az 16 mob içerir");
		Set<String> seen = new HashSet<>();
		for (Profile p : ExecutionCatalog.all()) {
			check(seen.add(p.entityId()), "kimlik benzersiz: " + p.entityId());
			check(ExecutionCatalog.byId(p.entityId()) == p, "byId döner: " + p.entityId());
			check(p.entityId().startsWith("minecraft:"), "vanilla kimliği: " + p.entityId());
			ExecutionTiming t = p.timing();
			check(t.impactTick() <= ExecutionCatalog.MAX_IMPACT_TICKS, "süre sınırı içinde: " + p.entityId());
			check(t.secondsToImpact() <= 1.5, "en çok 1,5 sn: " + p.entityId());
			check(t.impactTick() >= 10, "en az yarım sn okunur: " + p.entityId());
			check(t.swingTicks().length >= 1 && t.swingTicks().length <= 3, "1-3 savurma: " + p.entityId());
			// Son savurma ile darbe arasında en az 2 tick: darbe savurmanın "sonucu" gibi görünür, aynı anda değil.
			int last = t.swingTicks()[t.swingTicks().length - 1];
			check(t.impactTick() - last >= 2, "son savurma ile darbe arası >= 2 tick: " + p.entityId());
			check(p.knockback() >= 0.0 && p.knockback() <= 2.0, "geri savrulma makul: " + p.entityId());
			check(p.shake() > 0.0F && p.shake() <= 0.6F, "sarsıntı kamerayı bozmaz: " + p.entityId());
			// Perde: her savurma sesi duyulabilir aralıkta.
			for (int i = 0; i < t.swingTicks().length; i++) {
				float pitch = p.swingPitch(i);
				check(pitch >= 0.5F && pitch <= 1.6F, "savurma perdesi aralıkta: " + p.entityId() + " #" + i);
				check(p.lastSwing(i) == (i == t.swingTicks().length - 1), "lastSwing doğru: " + p.entityId() + " #" + i);
			}
		}

		// Zombi ve İskelet katalogda DEĞİL (kendi sınıfları var; çift tanım olmasın).
		check(ExecutionCatalog.byId("minecraft:zombie") == null, "zombi katalogda yok");
		check(ExecutionCatalog.byId("minecraft:skeleton") == null, "iskelet katalogda yok");
		// Güvenli olmayan moblar bilerek yok.
		for (String unsafe : new String[] {"minecraft:creeper", "minecraft:enderman", "minecraft:blaze", "minecraft:ghast",
				"minecraft:slime", "minecraft:magma_cube", "minecraft:witch", "minecraft:phantom", "minecraft:wither",
				"minecraft:ender_dragon", "minecraft:warden"}) {
			check(ExecutionCatalog.byId(unsafe) == null, "kapsam dışı: " + unsafe);
		}
		check(ExecutionCatalog.byId(null) == null, "null kimlik null döner");
		check(ExecutionCatalog.byId("battleaxe:kara_koruk") == null, "boss katalogda yok");
		check(ExecutionCatalog.byId("") == null, "boş kimlik yok");

		// Belirli kayıtların karakteri
		Profile spider = ExecutionCatalog.byId("minecraft:spider");
		check(spider != null && spider.timing().swingTicks().length == 3 && !spider.heavy(), "örümcek: 3 hızlı kesik");
		Profile ws = ExecutionCatalog.byId("minecraft:wither_skeleton");
		check(ws != null && ws.flair() == Flair.SOUL && ws.heavy(), "wither iskeleti: ruh + ağır");
		check(ws != null && ws.timing().impactTick() > ExecutionCatalog.byId("minecraft:stray").timing().impactTick(),
				"wither iskeleti strayden yavaş");
		Profile vind = ExecutionCatalog.byId("minecraft:vindicator");
		check(vind != null && vind.flair() == Flair.SPARK && vind.timing().swingTicks().length == 3, "korucu: 3 savurmalı düello");
		check(vind != null && !vind.lastSwing(0) && !vind.lastSwing(1) && vind.lastSwing(2), "korucu: çarpışma, çarpışma, son darbe");
		// Art arda savurmalar gerilimi artırır (perde yükselir), ağır olan hafif olandan alçak başlar.
		check(vind != null && vind.swingPitch(1) > vind.swingPitch(0) && vind.swingPitch(2) > vind.swingPitch(1), "perde yükselir");
		check(vind != null && spider != null && vind.swingPitch(0) < spider.swingPitch(0), "ağır savurma hafiften alçak");
		check(vind != null && vind.swingPitch(-5) == vind.swingPitch(0), "negatif indeks sıfır sayılır");

		// Genişleme: devler yavaş ve ağır, ama savrulmaları kamerayı ve oyuncuyu bozmaz
		Profile rav = ExecutionCatalog.byId("minecraft:ravager");
		check(rav != null && rav.heavy() && rav.timing().impactTick() > ws.timing().impactTick(), "yıkıcı en yavaşlardan");
		check(rav != null && rav.knockback() < ExecutionCatalog.byId("minecraft:husk").knockback(), "dev geri savrulmaz (sınırlı)");
		for (String id : new String[] {"minecraft:bogged", "minecraft:zombie_villager", "minecraft:pillager", "minecraft:evoker",
				"minecraft:ravager", "minecraft:hoglin", "minecraft:zoglin", "minecraft:piglin"}) {
			check(ExecutionCatalog.byId(id) != null, "genişleme mobu kayıtlı: " + id);
		}

		// Doğrulama: bozuk tarifler fırlatır.
		ExecutionTiming ok = new ExecutionTiming(new int[] {5}, 15, 2);
		check(throwsOnProfile("zombie", ok, 1.0, 0.3F, 5, 0, 0, 1.0F), "iki nokta içermeyen kimlik geçersiz");
		check(throwsOnProfile("minecraft:", ok, 1.0, 0.3F, 5, 0, 0, 1.0F), "boş ad geçersiz");
		check(throwsOnProfile(":x", ok, 1.0, 0.3F, 5, 0, 0, 1.0F), "boş ad alanı geçersiz");
		check(throwsOnProfile("minecraft:x", new ExecutionTiming(new int[] {5}, 31, 2), 1.0, 0.3F, 5, 0, 0, 1.0F), "30 tick'ten uzun geçersiz");
		check(throwsOnProfile("minecraft:x", ok, -0.1, 0.3F, 5, 0, 0, 1.0F), "negatif geri savrulma geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 3.5, 0.3F, 5, 0, 0, 1.0F), "aşırı geri savrulma geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 1.0, 1.5F, 5, 0, 0, 1.0F), "aşırı sarsıntı geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 1.0, Float.NaN, 5, 0, 0, 1.0F), "NaN sarsıntı geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 1.0, 0.3F, 0, 0, 0, 1.0F), "0 tick sarsıntı geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 1.0, 0.3F, 5, 0, 0, 0.0F), "0 boyutlu toz geçersiz");
		check(throwsOnProfile("minecraft:x", ok, 1.0, 0.3F, 5, 0x01FFFFFF, 0, 1.0F), "alfa kanallı renk geçersiz");
		check(!throwsOnProfile("minecraft:x", ok, 1.0, 0.3F, 5, 0xFFFFFF, 0x000000, 1.0F), "geçerli tarif kabul edilir");
		check(throwsOnProfile(null, ok, 1.0, 0.3F, 5, 0, 0, 1.0F), "null kimlik geçersiz");

		// Ayar mantığı
		Set<String> none = Set.of();
		check(ExecutionCatalog.isEnabled(true, none, "minecraft:spider"), "açık ve kapatılmamış -> etkin");
		check(!ExecutionCatalog.isEnabled(false, none, "minecraft:spider"), "ana anahtar kapalı -> devre dışı");
		check(!ExecutionCatalog.isEnabled(true, Set.of("minecraft:spider"), "minecraft:spider"), "listede -> devre dışı");
		check(ExecutionCatalog.isEnabled(true, Set.of("minecraft:spider"), "minecraft:husk"), "başka mob kapatılınca etkilenmez");
		check(ExecutionCatalog.isEnabled(true, null, "minecraft:spider"), "null liste = hiçbiri kapalı değil");
		check(!ExecutionCatalog.isEnabled(true, none, null), "null kimlik devre dışı");
		check(ExecutionConfig.EXTRA_MOBS_ENABLED, "varsayılan: ek moblar açık");
		check(ExecutionConfig.DISABLED_EXTRA_IDS.isEmpty(), "varsayılan: kapatılmış mob yok");

		if (failed == 0) {
			System.out.println("ExecutionCatalogTest: tüm testler geçti (" + ExecutionCatalog.all().size() + " mob).");
		} else {
			System.out.println("ExecutionCatalogTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}

	static boolean throwsOnProfile(String id, ExecutionTiming timing, double kb, float shake, int shakeTicks, int c1, int c2, float size) {
		try {
			new Profile(id, timing, kb, shake, shakeTicks, c1, c2, size, Flair.NONE, false);
			return false;
		} catch (IllegalArgumentException e) {
			return true;
		}
	}
}
