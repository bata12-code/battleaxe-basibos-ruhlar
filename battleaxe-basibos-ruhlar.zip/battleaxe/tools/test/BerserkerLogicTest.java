import com.battleaxe.berserker.BerserkerLogic;
import com.battleaxe.berserker.BerserkerState;

import static com.battleaxe.berserker.BerserkerState.ACTIVE;
import static com.battleaxe.berserker.BerserkerState.INACTIVE;

/** Minecraft gerektirmeyen Berserker eşik testleri. Çalıştırma: tools/test/run_tests.sh */
public final class BerserkerLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static BerserkerState step(BerserkerState s, boolean axe, double hp, double max) {
		return BerserkerLogic.nextState(s, true, axe, hp, max);
	}

	public static void main(String[] args) {
		// Aktivasyon: tam %50 (20 canda 10 HP) ve altı
		check(step(INACTIVE, true, 10.0, 20.0) == ACTIVE, "10/20 HP aktifleşir (tam %50)");
		check(step(INACTIVE, true, 9.5, 20.0) == ACTIVE, "9.5/20 aktifleşir");
		check(step(INACTIVE, true, 10.5, 20.0) == INACTIVE, "10.5/20 aktifleşmez");
		check(step(INACTIVE, true, 14.0, 20.0) == INACTIVE, "14/20 aktifleşmez (eski %30'da da değildi)");
		check(step(INACTIVE, true, 6.0, 20.0) == ACTIVE, "6/20 (eski eşik) hâlâ aktifleşir");
		// Balta şartı korunur
		check(step(INACTIVE, false, 4.0, 20.0) == INACTIVE, "balta elde değilse aktifleşmez");
		// Farklı azami can: oran güncel azami cana göre
		check(step(INACTIVE, true, 20.0, 40.0) == ACTIVE, "40 azami canda 20 HP = %50 aktifleşir");
		check(step(INACTIVE, true, 21.0, 40.0) == INACTIVE, "40 azami canda 21 HP aktifleşmez");
		check(step(INACTIVE, true, 8.0, 16.0) == ACTIVE, "16 azami canda (Kan Borcu) 8 HP aktifleşir");
		check(step(INACTIVE, true, 9.0, 16.0) == INACTIVE, "16 azami canda 9 HP aktifleşmez");
		// Kapanma: histerezis (%60 üstü)
		check(step(ACTIVE, true, 11.0, 20.0) == ACTIVE, "aktifken 11/20 (%55) açık kalır");
		check(step(ACTIVE, true, 12.0, 20.0) == ACTIVE, "aktifken 12/20 (tam %60) açık kalır");
		check(step(ACTIVE, true, 12.5, 20.0) == INACTIVE, "aktifken %60 üstü kapanır");
		// Baltayı bırakmak state'i bozmaz (mevcut tasarım), bonus kalkar
		check(step(ACTIVE, false, 5.0, 20.0) == ACTIVE, "aktifken balta elden çıkınca state korunur");
		check(!BerserkerLogic.bonusesActive(ACTIVE, false), "balta yoksa bonus yok");
		check(BerserkerLogic.bonusesActive(ACTIVE, true), "balta varsa bonus var");
		// Ölüm / geçersiz azami can
		check(BerserkerLogic.nextState(ACTIVE, false, true, 5.0, 20.0) == INACTIVE, "ölünce sıfırlanır");
		check(step(ACTIVE, true, 5.0, 0.0) == INACTIVE, "azami can 0 ise güvenle kapanır");

		// Titreme testi: 10 HP civarında yarım kalp dalgalanması tekrar tetiklemez
		BerserkerState s = INACTIVE;
		int activations = 0;
		double[] wiggle = {11, 10, 10.5, 11, 10, 11.5, 10, 11, 10.5, 10, 11.9, 10};
		for (double hp : wiggle) {
			BerserkerState n = step(s, true, hp, 20.0);
			if (s == INACTIVE && n == ACTIVE) {
				activations++;
			}
			s = n;
		}
		check(activations == 1, "sınırda dalgalanma yalnızca 1 aktivasyon üretir (üretilen: " + activations + ")");

		// Tam iyileşip tekrar düşme: ikinci aktivasyon meşrudur
		s = step(s, true, 20.0, 20.0);
		check(s == INACTIVE, "tam canda kapanır");
		s = step(s, true, 9.0, 20.0);
		check(s == ACTIVE, "yeniden düşünce tekrar aktifleşir");

		// Eşik tutarlılığı: kapanma > aktivasyon olmalı
		check(com.battleaxe.berserker.BerserkerConfigProbe.hysteresisOk(), "DEACTIVATION > ACTIVATION");

		if (failed == 0) {
			System.out.println("BerserkerLogicTest: tüm testler geçti.");
		} else {
			System.out.println("BerserkerLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
