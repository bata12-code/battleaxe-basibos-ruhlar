import com.battleaxe.chain.ChainLogic;
import com.battleaxe.execution.ExecutionConfig;
import com.battleaxe.execution.ExecutionLogic;

/** Kıyım Zinciri - Execution şans bağlantısı. Minecraft gerektirmez. */
public final class ChainExecutionLinkTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) {
		check(ExecutionLogic.chainChanceBonus(0) == 0.0 && ExecutionLogic.chainChanceBonus(-5) == 0.0, "kademe 0/negatif bonus yok");
		double prev = 0.0;
		for (int t = 1; t <= ChainLogic.MAX_TIER; t++) {
			double b = ExecutionLogic.chainChanceBonus(t);
			check(b > prev, "bonus artar t" + t);
			prev = b;
		}
		check(ExecutionLogic.chainChanceBonus(99) == ExecutionLogic.chainChanceBonus(4), "4. kademenin üstü sayılmaz");
		double max = ExecutionConfig.CHANCE + ExecutionLogic.chainChanceBonus(4);
		check(max < 0.6, "zincirli en yüksek şans hâlâ nadir (" + max + ")");
		check(max > ExecutionConfig.CHANCE, "zincir şansı gerçekten artırır");
		check(Math.abs(ExecutionLogic.chainChanceBonus(1) - ExecutionConfig.CHAIN_CHANCE_PER_TIER) < 1.0E-12, "kademe 1 = temel miktar");
		if (failed == 0) {
			System.out.println("ChainExecutionLinkTest: tüm testler geçti.");
		} else {
			System.out.println("ChainExecutionLinkTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
