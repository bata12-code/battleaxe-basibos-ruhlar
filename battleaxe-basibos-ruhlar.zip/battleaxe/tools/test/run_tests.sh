#!/bin/bash
# Ruh Ağı saf çekirdek testleri (Minecraft/Gradle gerekmez; yalnızca JDK 17+).
cd "$(dirname "$0")/../.." || exit 1
OUT=$(mktemp -d)
P=src/main/java/com/battleaxe/nexus
javac -d "$OUT" $P/Branch.java $P/NodeType.java $P/NodeRole.java $P/Effect.java $P/NodeDef.java $P/Stat.java $P/NexusEvent.java \
  $P/NexusConfig.java $P/NexusMath.java $P/NexusData.java $P/NexusStats.java $P/NexusNodes.java $P/NexusTree.java \
  $P/NexusRules.java tools/test/NexusLogicTest.java && java -cp "$OUT" NexusLogicTest

# Berserker Evrimi saf çekirdek testleri
E=src/main/java/com/battleaxe/evolution
javac -d "$OUT" $E/EvolutionPath.java $E/EvolutionStage.java $E/Recovery.java $E/EvolutionConfig.java $E/EvolutionData.java \
  $E/EvolutionLogic.java tools/test/EvolutionLogicTest.java && java -cp "$OUT" EvolutionLogicTest

# Kara Körük savaş durum makinesi testleri
K=src/main/java/com/battleaxe/boss
javac -d "$OUT" $K/KaraKorukConfig.java $K/KaraKorukLogic.java tools/test/KaraKorukBrainTest.java && java -cp "$OUT" KaraKorukBrainTest

# Berserker aktivasyon eşiği testleri
B=src/main/java/com/battleaxe/berserker
javac -d "$OUT" $B/BerserkerState.java $B/BerserkerConfig.java $B/BerserkerLogic.java \
  tools/test/com/battleaxe/berserker/BerserkerConfigProbe.java tools/test/BerserkerLogicTest.java && java -cp "$OUT" BerserkerLogicTest

# Baltanın Çağrısı saf çekirdek testleri
C=src/main/java/com/battleaxe/call
javac -d "$OUT" $C/CallConfig.java $C/CallMoon.java $C/CallLogic.java tools/test/CallLogicTest.java && java -cp "$OUT" CallLogicTest

# Baltanın Çağrısı - Öncü Belirtiler saf mantık/geometri/ritim testleri
javac -d "$OUT" $C/CallConfig.java $C/CallMoon.java $C/CallLogic.java $C/CallData.java $C/OmenCategory.java $C/OmenKind.java $C/OmenConfig.java \
  $C/OmenGeometry.java $C/OmenLogic.java $C/OmenShapes.java $C/SunAnomalyLogic.java $C/AllWatchingLogic.java tools/test/OmenLogicTest.java && java -cp "$OUT" OmenLogicTest

# Execution (bitirici animasyon) saf mantık testleri
X=src/main/java/com/battleaxe/execution
javac -d "$OUT" $X/ExecutionConfig.java $X/ExecutionTiming.java $X/ExecutionLogic.java tools/test/ExecutionLogicTest.java && java -cp "$OUT" ExecutionLogicTest

# Execution katalogu (ek mob bitiricileri) saf veri/doğrulama testleri
javac -d "$OUT" $X/ExecutionConfig.java $X/ExecutionTiming.java $X/ExecutionCatalog.java tools/test/ExecutionCatalogTest.java && java -cp "$OUT" ExecutionCatalogTest

# Shunpo (balta isabeti sonrası ışınlanma) saf mantık testleri
S=src/main/java/com/battleaxe/shunpo
javac -d "$OUT" $S/ShunpoConfig.java $S/ShunpoLogic.java $S/ComboConfig.java $S/ComboLogic.java $S/vfx/RiftKind.java $S/vfx/RiftConfig.java $S/vfx/RiftStyle.java $S/vfx/RiftGeometry.java $S/vfx/RiftLogic.java src/main/java/com/battleaxe/berserker/HiddetRoarLogic.java tools/test/ShunpoLogicTest.java && java -cp "$OUT" ShunpoLogicTest

# Kıyım Zinciri (art arda öldürme) saf mantık testleri
H=src/main/java/com/battleaxe/chain
javac -d "$OUT" $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $H/ChainHudMath.java tools/test/ChainLogicTest.java && java -cp "$OUT" ChainLogicTest

# Kıyım Zinciri -> Evrim (Savaş Özü) bağlantısı
javac -d "$OUT" $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $E/EvolutionPath.java $E/EvolutionStage.java $E/Recovery.java $E/EvolutionConfig.java $E/EvolutionData.java $E/EvolutionLogic.java tools/test/ChainEvolutionLinkTest.java && java -cp "$OUT" ChainEvolutionLinkTest

# Baltanın zincir fısıltıları (saf mantık + çeviri bütünlüğü) ve zincir -> Execution şans bağlantısı
javac -d "$OUT" $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $H/ChainWhisperLogic.java $H/ChainEchoLogic.java tools/test/ChainWhisperTest.java && java -cp "$OUT" ChainWhisperTest
javac -d "$OUT" $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $X/ExecutionConfig.java $X/ExecutionTiming.java $X/ExecutionLogic.java tools/test/ChainExecutionLinkTest.java && java -cp "$OUT" ChainExecutionLinkTest

# Kozmik Anomaliler: türler, maskeler, takvim (Parçalanmış Güneş), Bütün Canlılar, halka/ay geometrisi
javac -d "$OUT" $C/CallConfig.java $C/CallMoon.java $C/CallLogic.java $C/CallData.java $C/OmenCategory.java $C/OmenKind.java $C/OmenConfig.java \
  $C/OmenGeometry.java $C/OmenLogic.java $C/OmenShapes.java $C/SunAnomalyLogic.java $C/SunAnomalyShapes.java $C/AllWatchingLogic.java $C/AnomalyWhisperLogic.java \
  $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $H/ChainWhisperLogic.java tools/test/AnomalyLogicTest.java && java -cp "$OUT" AnomalyLogicTest

# Başıboş Ruhlar: ortak mantık (hasar/iyileşme/geometri), üç savaş durum makinesi, aile/karşılaşma/fısıltı/çeviri bütünlüğü
SP=src/main/java/com/battleaxe/spirit
SPURE="$SP/SpiritKind.java $SP/SpiritConfig.java $SP/SavrulmusConfig.java $SP/RuhYiyenConfig.java $SP/ZincirliConfig.java $SP/SpiritLogic.java \
  $SP/SavrulmusLogic.java $SP/RuhYiyenLogic.java $SP/ZincirliLogic.java"
javac -d "$OUT" $SPURE tools/test/SpiritLogicTest.java && java -cp "$OUT" SpiritLogicTest
javac -d "$OUT" $SPURE tools/test/SpiritBrainTest.java && java -cp "$OUT" SpiritBrainTest
javac -d "$OUT" $SPURE $SP/SpiritEncounter.java $SP/SpiritWhisperLogic.java $H/ChainConfig.java $H/ChainState.java $H/ChainLogic.java $H/ChainWhisperLogic.java \
  $X/ExecutionConfig.java $X/ExecutionTiming.java $X/ExecutionCatalog.java tools/test/SpiritFamilyTest.java && java -cp "$OUT" SpiritFamilyTest
