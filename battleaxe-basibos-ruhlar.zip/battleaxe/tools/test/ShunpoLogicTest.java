import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.battleaxe.berserker.HiddetRoarLogic;
import com.battleaxe.shunpo.ComboConfig;
import com.battleaxe.shunpo.ComboLogic;
import com.battleaxe.shunpo.ComboLogic.FinishDecision;
import com.battleaxe.shunpo.ComboLogic.Phase;
import com.battleaxe.shunpo.ComboLogic.SecondDecision;
import com.battleaxe.shunpo.vfx.RiftConfig;
import com.battleaxe.shunpo.vfx.RiftGeometry;
import com.battleaxe.shunpo.vfx.RiftKind;
import com.battleaxe.shunpo.vfx.RiftLogic;
import com.battleaxe.shunpo.vfx.RiftStyle;
import com.battleaxe.shunpo.ShunpoConfig;
import com.battleaxe.shunpo.ShunpoLogic.KeyAction;
import com.battleaxe.shunpo.ShunpoLogic;
import com.battleaxe.shunpo.ShunpoLogic.Check;

/** Minecraft gerektirmeyen Shunpo testleri. Çalıştırma: tools/test/run_tests.sh */
public final class ShunpoLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static Check c(boolean link, boolean owner, boolean dim, long now, long exp, boolean axe, boolean ench, boolean target) {
		return ShunpoLogic.check(link, owner, dim, now, exp, axe, ench, target);
	}

	public static void main(String[] args) {
		// Her şey geçerli
		check(c(true, true, true, 100, 180, true, true, true) == Check.OK, "tam geçerli bağlantı OK");
		// Bağlantı yok (blok/boşluk atışı bağ kurmaz)
		check(c(false, true, true, 100, 180, true, true, true) == Check.NO_LINK, "bağlantı yoksa ışınlanma yok");
		// Süre
		check(c(true, true, true, 180, 180, true, true, true) == Check.OK, "bitiş anı hâlâ geçerli");
		check(c(true, true, true, 181, 180, true, true, true) == Check.EXPIRED, "süre dolunca geçersiz");
		check(ShunpoLogic.expiry(100) == 100 + ShunpoConfig.WINDOW_TICKS, "bitiş = isabet + pencere");
		check(!ShunpoLogic.windowOpen(1000, 100), "eski isabet yeniden kullanılamaz");
		// Oyuncu / boyut / balta / büyü / hedef
		check(c(true, false, true, 100, 180, true, true, true) == Check.OWNER_INVALID, "ölü/izleyici oyuncu");
		check(c(true, true, false, 100, 180, true, true, true) == Check.WRONG_DIMENSION, "başka boyut");
		check(c(true, true, true, 100, 180, false, true, true) == Check.AXE_INVALID, "balta yok");
		check(c(true, true, true, 100, 180, true, false, true) == Check.NO_ENCHANT, "büyü yok");
		check(c(true, true, true, 100, 180, true, true, false) == Check.TARGET_INVALID, "hedef geçersiz");
		// Öncelik: süre dolmuşsa balta durumuna bakılmaksızın EXPIRED
		check(c(true, true, true, 999, 180, false, false, false) == Check.EXPIRED, "öncelik sırası");

		// Konum aday sırası
		List<int[]> o = ShunpoLogic.OFFSETS;
		int r = ShunpoConfig.SEARCH_RADIUS, u = ShunpoConfig.SEARCH_UP, d = ShunpoConfig.SEARCH_DOWN;
		check(o.size() == (2 * r + 1) * (2 * r + 1) * (u + d + 1), "aday sayısı");
		check(o.get(0)[0] == 0 && o.get(0)[1] == 0 && o.get(0)[2] == 0, "ilk aday fırlatma noktasının kendisi");
		int prev = -1;
		boolean sorted = true;
		Set<String> seen = new HashSet<>();
		for (int[] a : o) {
			int dist = a[0] * a[0] + a[1] * a[1] + a[2] * a[2];
			if (dist < prev) {
				sorted = false;
			}
			prev = dist;
			seen.add(a[0] + "," + a[1] + "," + a[2]);
			check(Math.abs(a[0]) <= r && Math.abs(a[2]) <= r && a[1] <= u && a[1] >= -d, "aday aralık içinde");
		}
		check(sorted, "adaylar yakından uzağa sıralı");
		check(seen.size() == o.size(), "tekrarlayan aday yok");
		List<int[]> again = ShunpoLogic.buildOffsets(r, u, d);
		boolean same = again.size() == o.size();
		for (int i = 0; same && i < o.size(); i++) {
			same = java.util.Arrays.equals(o.get(i), again.get(i));
		}
		check(same, "sıralama deterministik");

		// Sayı güvenliği
		check(ShunpoLogic.finite(1, 2, 3), "normal sayılar");
		check(!ShunpoLogic.finite(Double.NaN, 2, 3), "NaN reddedilir");
		check(!ShunpoLogic.finite(1, Double.POSITIVE_INFINITY, 3), "sonsuz reddedilir");

		// ---- Shunpo yaşam döngüsü: regresyon (ikinci R neden işlenmiyordu) ----
		long hit = 1000, exp = ShunpoLogic.expiry(hit);
		// 1) geçerli isabet + ikinci R, balta hâlâ dünyada
		check(c(true, true, true, hit + 20, exp, ShunpoLogic.axeUsable(false, true), true, true) == Check.OK, "senaryo1: isabetten sonra ikinci R geçerli");
		check(ShunpoLogic.keyAction(false, Check.OK) == KeyAction.SHUNPO, "senaryo1: tuş Shunpo'ya gider");
		// 2-3) blok/boşluk: bağ hiç yok -> normal akışa bırakılır (ışınlanma yok)
		check(ShunpoLogic.keyAction(false, Check.NO_LINK) == KeyAction.PASS_THROUGH, "senaryo2-3: bağ yoksa tuş normal akışa");
		check(!ShunpoLogic.canOpenLink(true, false, false, true, true, true), "blok isabeti (canavar değil) bağ açmaz");
		check(!ShunpoLogic.canOpenLink(false, true, false, true, true, true), "büyüsüz fırlatma bağ açmaz");
		check(!ShunpoLogic.canOpenLink(true, true, false, true, true, false), "büyü baltadan gitmişse bağ açmaz");
		// KÖK NEDEN 1: balta hedefi öldürse de isabet geçerlidir (canlılık şartı yok)
		check(ShunpoLogic.canOpenLink(true, true, false, true, true, true), "öldüren isabet de bağ açar (hedef kaldırılmadıkça)");
		check(!ShunpoLogic.canOpenLink(true, true, true, true, true, true), "dünyadan kaldırılmış hedef bağ açmaz");
		// KÖK NEDEN 2: hedef sonradan ölse bile Shunpo hakkı sürer (ışınlanma fırlatma konumuna)
		check(c(true, true, true, hit + 20, exp, true, true, true) == Check.OK, "hedef ölse de hak sürer");
		// KÖK NEDEN 3 / senaryo 4: Sadakat baltayı geri getirdi (teslim) -> hak silinmez
		check(ShunpoLogic.axeUsable(true, false), "teslim edilmiş balta hakkı bozmaz");
		check(c(true, true, true, hit + 25, exp, ShunpoLogic.axeUsable(true, false), true, true) == Check.OK, "senaryo4: Sadakat sonrası ikinci R hâlâ geçerli");
		check(!ShunpoLogic.axeUsable(false, false), "teslim edilmeden kaybolan balta hakkı siler");
		check(c(true, true, true, hit + 25, exp, ShunpoLogic.axeUsable(false, false), true, true) == Check.AXE_INVALID, "kayıp balta: AXE_INVALID");
		// 5) süre dolduktan sonra
		check(c(true, true, true, exp + 1, exp, true, true, true) == Check.EXPIRED, "senaryo5: süre dolunca ikinci R geçersiz");
		check(ShunpoLogic.keyAction(false, Check.EXPIRED) == KeyAction.PASS_THROUGH, "senaryo5: süre dolunca normal akış");
		// 6) kombo sürerken R
		check(ShunpoLogic.keyAction(true, Check.OK) == KeyAction.SWALLOW_COMBO && ShunpoLogic.keyAction(true, Check.NO_LINK) == KeyAction.SWALLOW_COMBO, "senaryo6: kombo sürerken R yutulur");
		// 7) ölüm / boyut / izleyici
		check(c(true, false, true, hit + 5, exp, true, true, true) == Check.OWNER_INVALID, "senaryo7: ölü oyuncu");
		check(c(true, true, false, hit + 5, exp, true, true, true) == Check.WRONG_DIMENSION, "senaryo7: boyut değişti");
		check(c(true, true, true, hit + 5, exp, true, false, true) == Check.NO_ENCHANT, "senaryo7: büyü baltadan gitti");
		// Pencere Ruh Ağı ile uzar ama asla geriye gitmez
		check(ShunpoLogic.windowOpen(exp + 40, exp + 40) && !ShunpoLogic.windowOpen(exp + 41, exp + 40), "uzatılmış pencere sınırı");
		// Tek hak: kullanımdan sonra bağ yoksa tuş normal akışa gider (çift ışınlanma yok)
		check(ShunpoLogic.keyAction(false, Check.NO_LINK) == KeyAction.PASS_THROUGH, "kullanılmış hak tekrar ışınlamaz");

		// ---- Gerçeklik yarığı görselleri ----
		// 1-2) Olay türü: başarılı ışınlanma SHUNPO görseli, başarısız girişim yalnızca küçük FAIL kıvılcımı
		check(RiftLogic.kindForOutcome(true) == RiftKind.SHUNPO, "başarılı ışınlanma yarık görseli verir");
		check(RiftLogic.kindForOutcome(false) == RiftKind.FAIL && RiftKind.FAIL != RiftKind.SHUNPO, "başarısız girişim yarık/iz görseli vermez");
		check(RiftLogic.failAllowed(0, RiftConfig.FAIL_MIN_GAP_TICKS) && !RiftLogic.failAllowed(0, RiftConfig.FAIL_MIN_GAP_TICKS - 1), "başarısızlık kıvılcımı hız sınırı");
		// tür kodları benzersiz ve geri çözülebilir
		java.util.Set<Integer> codes = new java.util.HashSet<>();
		for (RiftKind k : RiftKind.values()) { check(codes.add(k.code) && RiftKind.byCode(k.code) == k, "tür kodu " + k); }
		check(RiftKind.byCode(99) == null && RiftKind.byCode(-1) == null, "bilinmeyen tür null");
		// 3) Çift işleme koruması
		long sig = RiftLogic.signature(RiftKind.SHUNPO.code, 7, 10, 64, 10, 14, 64, 10);
		check(RiftLogic.isDuplicate(sig, 100, sig, 100 + RiftConfig.DUPLICATE_WINDOW_TICKS), "aynı olay pencerede tekrar yok sayılır");
		check(!RiftLogic.isDuplicate(sig, 100, sig, 100 + RiftConfig.DUPLICATE_WINDOW_TICKS + 1), "pencere sonrası yeni olay işlenir");
		check(!RiftLogic.isDuplicate(sig, 100, RiftLogic.signature(RiftKind.SHUNPO.code, 7, 10, 64, 10, 20, 64, 10), 101), "farklı varış konumu farklı olaydır");
		check(!RiftLogic.isDuplicate(sig, 100, RiftLogic.signature(RiftKind.COMBO_FIRST.code, 7, 10, 64, 10, 14, 64, 10), 101), "farklı tür farklı olaydır");
		check(RiftLogic.signature(1, 2, 3, 4, 5, 6, 7, 8) == RiftLogic.signature(1, 2, 3, 4, 5, 6, 7, 8), "imza deterministik");
		// 4) Rütbeye bağlı görsel parametreler sınırlı ve monoton (hasar/menzil/süre ile ilgisi yok)
		RiftStyle prevStyle = null;
		for (int rank = -3; rank <= 15; rank++) {
			RiftStyle st = RiftStyle.main(rank);
			check(st.height() >= 1.9 - 1e-9 && st.height() <= 2.6, "yükseklik sınırı rütbe " + rank + ": " + st.height());
			check(st.totalTicks() >= 10 && st.totalTicks() <= 18, "ömür sınırlı rütbe " + rank + ": " + st.totalTicks());
			check(st.edgeParticles() >= 2 && st.edgeParticles() <= 6, "kenar parçacığı sınırı rütbe " + rank);
			check(st.halfWidth() > 0 && st.halfWidth() < 0.5, "genişlik sınırı rütbe " + rank);
			if (prevStyle != null && rank > 0 && rank <= RiftStyle.MAX_RANK) {
				check(st.height() >= prevStyle.height() && st.edgeParticles() >= prevStyle.edgeParticles() && st.totalTicks() >= prevStyle.totalTicks(), "rütbeyle yalnızca artar " + rank);
			}
			prevStyle = st;
		}
		check(!RiftStyle.main(2).secondLine() && RiftStyle.main(3).secondLine(), "ikinci çizgi orta rütbede");
		check(!RiftStyle.main(5).runes() && RiftStyle.main(6).runes(), "rün çatlakları yüksek rütbede");
		check(!RiftStyle.main(8).signature() && RiftStyle.main(9).signature() && !RiftStyle.main(0).signature(), "imza yalnızca en yüksek rütbede");
		check(RiftStyle.main(100).equals(RiftStyle.main(9)) && RiftStyle.main(-5).equals(RiftStyle.main(0)), "rütbe sınırlanır");
		RiftStyle small = RiftStyle.small(9, 0.5, 99);
		check(small.height() < RiftStyle.main(9).height() && small.totalTicks() < RiftStyle.main(9).totalTicks() && !small.signature(), "küçük yarık daha kısa ve sade");
		// aşamalar
		RiftStyle phased = RiftStyle.main(5);
		check(RiftLogic.phase(-1, phased) == RiftLogic.Phase.WAITING && RiftLogic.phase(0, phased) == RiftLogic.Phase.OPENING
				&& RiftLogic.phase(phased.openTicks(), phased) == RiftLogic.Phase.HOLD
				&& RiftLogic.phase(phased.openTicks() + phased.holdTicks(), phased) == RiftLogic.Phase.CLOSING
				&& RiftLogic.phase(phased.totalTicks(), phased) == RiftLogic.Phase.DONE, "yarık aşamaları sırayla");
		check(RiftLogic.openProgress(0, phased) > 0 && RiftLogic.openProgress(phased.openTicks(), phased) == 1.0 && RiftLogic.closeProgress(0, phased) == 0.0
				&& RiftLogic.closeProgress(phased.totalTicks() - 1, phased) == 1.0, "açılış/kapanış ilerlemesi 0..1");
		// yeni Shunpo: eski yarık hızla kapanır, geri gitmez, süre aşılmaz
		check(RiftLogic.forcedCloseAge(0, phased) == phased.totalTicks() - RiftConfig.FORCED_CLOSE_TICKS, "eski yarık kapanışa zorlanır");
		check(RiftLogic.forcedCloseAge(phased.totalTicks() - 1, phased) == phased.totalTicks() - 1, "kapanış geri sarmaz");
		check(RiftLogic.phase(RiftLogic.forcedCloseAge(0, phased), phased) == RiftLogic.Phase.CLOSING, "zorlanan yarık kapanış aşamasında");
		// 7) Performans: bütçe ve yoğunluk
		check(RiftLogic.takeBudget(10, 4) == 4 && RiftLogic.takeBudget(3, 100) == 3 && RiftLogic.takeBudget(5, -2) == 0, "parçacık bütçesi aşılmaz");
		check(RiftLogic.tickBudget() <= RiftConfig.MAX_PARTICLES_PER_TICK * 2 && RiftLogic.tickBudget() >= 0, "tick bütçesi sınırlı");
		check(RiftLogic.scaled(4) >= 0 && RiftLogic.scaled(4) <= 8, "yoğunluk çarpanı sınırlı");
		check(RiftConfig.MAX_ACTIVE_RIFTS <= 8 && RiftConfig.TRAIL_MAX_POINTS <= 30, "etkin yarık/iz sınırları");
		// uzun mesafede iz noktası sınırı
		check(RiftGeometry.trailPoints(0) == 0 && RiftGeometry.trailPoints(-5) == 0 && RiftGeometry.trailPoints(1) >= 2, "kısa mesafe iz noktası");
		check(RiftGeometry.trailPoints(10_000) == RiftConfig.TRAIL_MAX_POINTS && RiftGeometry.trailPoints(Double.NaN) == 0, "uzun mesafede iz noktası sınırlı");
		// geometri: deterministik, sınırlı, uçlarda sivri
		double[] g1 = RiftGeometry.edgeProfile(42L, 0.3);
		double[] g2 = RiftGeometry.edgeProfile(42L, 0.3);
		check(java.util.Arrays.equals(g1, g2) && g1.length == RiftGeometry.POINTS, "yarık silueti deterministik");
		check(!java.util.Arrays.equals(g1, RiftGeometry.edgeProfile(43L, 0.3)), "tohum farklı siluet verir");
		for (long seed = 0; seed < 200; seed++) {
			double[] g = RiftGeometry.edgeProfile(seed * 977L, 0.3);
			for (double v : g) check(v >= 0.0 && v <= 0.3 * 1.3 + 1e-9, "profil sınırı");
			check(g[0] < 0.05 && g[g.length - 1] < 0.05, "uçlar sivri");
			double smp = RiftGeometry.sample(g, 0.5);
			check(smp >= 0.0 && smp <= 0.39 + 1e-9 && RiftGeometry.sample(g, -3) == g[0] && RiftGeometry.sample(g, 9) == g[g.length - 1], "örnekleme sınırlı");
		}
		// paket doğrulama: bozuk veri görsel üretmez
		check(RiftLogic.validPayload(0, 3, 1, 2, 3, 4, 5, 6), "geçerli paket");
		check(!RiftLogic.validPayload(42, 3, 1, 2, 3), "bilinmeyen tür reddedilir");
		check(!RiftLogic.validPayload(0, 3, Double.NaN, 2, 3) && !RiftLogic.validPayload(0, 3, 1, Double.POSITIVE_INFINITY, 3) && !RiftLogic.validPayload(0, 3, 1e9, 2, 3), "geçersiz konum reddedilir");
		check(!RiftLogic.validPayload(0, -1, 1, 2, 3) && !RiftLogic.validPayload(0, 500, 1, 2, 3), "geçersiz rütbe reddedilir");
		check(RiftKind.values().length == 7, "olay türleri: shunpo, isabet, 3 kombo, başarısızlık, iptal");

		// ---- Kombo dalları ----
		check(ComboLogic.decideSecond(true, false, false, false) == SecondDecision.HIT_MAIN, "ana hedef hayatta: ana hedefte sürer");
		check(ComboLogic.decideSecond(true, true, false, true) == SecondDecision.HIT_MAIN, "hayattaysa hedef değiştirilmez");
		check(ComboLogic.decideSecond(false, true, false, true) == SecondDecision.RETARGET, "ölü + izin + aday: hedef değişir");
		check(ComboLogic.decideSecond(false, false, false, true) == SecondDecision.END, "izin yoksa güvenle biter");
		check(ComboLogic.decideSecond(false, true, true, true) == SecondDecision.END, "kombo başına tek hedef değişimi");
		check(ComboLogic.decideSecond(false, true, false, false) == SecondDecision.END, "aday yoksa biter");
		check(ComboLogic.decideFinish(true, true) == FinishDecision.EXECUTION, "uygun hedef: bitirici animasyonu");
		check(ComboLogic.decideFinish(true, false) == FinishDecision.HEAVY, "uygun değil: normal bitirici vuruş");
		check(ComboLogic.decideFinish(false, true) == FinishDecision.FLOURISH, "hedef yok: hasarsız son hareket");
		check(ComboLogic.decideFinish(false, false) == FinishDecision.FLOURISH, "hedef yok (uygunsuz)");

		// ---- Kombo hasarı ----
		double base = 20.0;
		check(Math.abs(ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, 0) - 8.0) < 1e-9, "ilk vuruş = %40 saldırı hasarı");
		check(ComboLogic.damage(base, ComboConfig.FINISH_MULTIPLIER, 0) > ComboLogic.damage(base, ComboConfig.SECOND_MULTIPLIER, 0)
				&& ComboLogic.damage(base, ComboConfig.SECOND_MULTIPLIER, 0) > ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, 0), "vuruşlar kademeli güçlenir");
		check(ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, 1000) == ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, ComboConfig.BONUS_CAP_PCT), "yüzde sınırı aşılmaz (yığılma yok)");
		check(ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, -50) == ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, 0), "negatif yüzde sıfırlanır");
		check(ComboLogic.damage(0, 1, 10) == 0.0 && ComboLogic.damage(Double.NaN, 1, 10) == 0.0 && ComboLogic.damage(base, 0, 10) == 0.0, "geçersiz girdi hasar vermez");
		check(ComboLogic.damage(base, 1, Double.NaN) == 0.0, "NaN yüzde hasar vermez");
		double total = ComboLogic.damage(base, ComboConfig.FIRST_MULTIPLIER, 0) + ComboLogic.damage(base, ComboConfig.SECOND_MULTIPLIER, 0) + ComboLogic.damage(base, ComboConfig.FINISH_MULTIPLIER, 0);
		check(total < base * 2.5, "temel kombo toplamı saldırı hasarının 2.5 katını aşmaz: " + total);
		check(ComboLogic.multiplier(Phase.APPROACH) == 0.0, "yaklaşma adımı hasar vermez");

		// ---- Mesafe, süre, bedel ----
		check(ComboLogic.withinReach(ComboConfig.STRIKE_REACH * ComboConfig.STRIKE_REACH, ComboConfig.STRIKE_REACH), "menzil sınırı dahil");
		check(!ComboLogic.withinReach(ComboConfig.STRIKE_REACH * ComboConfig.STRIKE_REACH + 0.01, ComboConfig.STRIKE_REACH), "menzil dışı");
		check(!ComboLogic.timedOut(100, 100, ComboConfig.TIMEOUT_TICKS) && ComboLogic.timedOut(100 + ComboConfig.TIMEOUT_TICKS + 1, 100, ComboConfig.TIMEOUT_TICKS), "kombo zaman aşımı");
		check(ComboLogic.approachAllowed(ComboConfig.APPROACH_MAX_DISTANCE) && !ComboLogic.approachAllowed(ComboConfig.APPROACH_MAX_DISTANCE + 0.1), "yaklaşma mesafe sınırı");
		check(ComboLogic.retargetRadius(0) == ComboConfig.RETARGET_BASE_RADIUS && ComboLogic.retargetRadius(2) == ComboConfig.RETARGET_BASE_RADIUS + 2 && ComboLogic.retargetRadius(-5) == ComboConfig.RETARGET_BASE_RADIUS, "hedef değiştirme yarıçapı");
		check(ComboLogic.canPayCost(10f, 0) && ComboLogic.canPayCost(10f, 1) && !ComboLogic.canPayCost(3.5f, 1) && ComboLogic.canPayCost(4f, 1), "Hiddet bedeli oyuncuyu asla öldürmez");
		check(Math.abs(ComboLogic.pitchToward(4, 0)) < 1e-4 && ComboLogic.pitchToward(4, 4) < 0 && ComboLogic.pitchToward(4, -4) > 0, "bakış açısı");
		check(ComboConfig.FIRST_DELAY_TICKS >= 8 && ComboConfig.SECOND_DELAY_TICKS >= 10 && ComboConfig.FINISH_DELAY_TICKS >= 10, "vuruşlar vuruş sonrası dokunulmazlıktan (10 tick) sonra");

		// ---- Hiddet kükremesi ----
		long gap = HiddetRoarLogic.MIN_GAP_TICKS;
		check(HiddetRoarLogic.shouldRoar(true, true, true, true, false, gap), "doğru koşulda çalar");
		check(!HiddetRoarLogic.shouldRoar(false, true, true, true, false, gap), "Hiddet kapalıyken çalmaz");
		check(!HiddetRoarLogic.shouldRoar(true, false, true, true, false, gap), "balta elde değilken çalmaz");
		check(!HiddetRoarLogic.shouldRoar(true, true, false, true, false, gap), "kritik değilse çalmaz");
		check(!HiddetRoarLogic.shouldRoar(true, true, true, false, false, gap), "kurban ölmediyse çalmaz");
		check(!HiddetRoarLogic.shouldRoar(true, true, true, true, true, gap), "aynı ölüm iki kez işlenmez");
		check(!HiddetRoarLogic.shouldRoar(true, true, true, true, false, gap - 1), "çok yakın tekrar bastırılır");
		check(HiddetRoarLogic.shouldRoar(true, true, true, true, false, 1_000_000), "uzun aradan sonra çalar (gerçek öldürüşler yutulmaz)");

		if (failed == 0) {
			System.out.println("ShunpoLogicTest: tüm testler geçti.");
		} else {
			System.out.println("ShunpoLogicTest: " + failed + " başarısız.");
			System.exit(1);
		}
	}
}
