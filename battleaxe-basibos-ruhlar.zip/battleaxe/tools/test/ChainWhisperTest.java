import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

import com.battleaxe.chain.ChainEchoLogic;
import com.battleaxe.chain.ChainLogic;
import com.battleaxe.chain.ChainWhisperLogic;

/** Baltanın zincir fısıltıları: saf mantık ve ÇEVİRİ BÜTÜNLÜĞÜ (her anahtar iki dil dosyasında da bulunur). */
public final class ChainWhisperTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) throws Exception {
		// Bantlar
		for (int r = -3; r <= 2; r++) {
			check(ChainWhisperLogic.band(r) == 0, "rütbe " + r + " -> bant 0");
		}
		for (int r = 3; r <= 6; r++) {
			check(ChainWhisperLogic.band(r) == 1, "rütbe " + r + " -> bant 1");
		}
		for (int r = 7; r <= 12; r++) {
			check(ChainWhisperLogic.band(r) == 2, "rütbe " + r + " -> bant 2");
		}

		// Olasılık: artan, 0..1; geçersiz kademe sessiz
		check(ChainWhisperLogic.chance(0) == 0.0 && ChainWhisperLogic.chance(-4) == 0.0, "kademe 0/negatif konuşmaz");
		for (int t = 2; t <= 4; t++) {
			check(ChainWhisperLogic.chance(t) > ChainWhisperLogic.chance(t - 1), "olasılık artar t" + t);
		}
		check(ChainWhisperLogic.chance(4) == 1.0 && ChainWhisperLogic.chance(99) == 1.0, "en üst kademe her zaman konuşur");
		check(ChainWhisperLogic.chance(1) > 0.0 && ChainWhisperLogic.chance(1) < 1.0, "kademe 1 bazen konuşur");

		// Konuşma kararı
		check(!ChainWhisperLogic.shouldWhisper(0, 0.0, 1000L, -1L), "kademe 0 konuşmaz");
		check(ChainWhisperLogic.shouldWhisper(4, 0.999, 1000L, -1L), "kademe 4 ilk kez konuşur");
		check(!ChainWhisperLogic.shouldWhisper(1, 0.5, 1000L, -1L), "zar eşikte düşer (roll == olasılık)");
		check(ChainWhisperLogic.shouldWhisper(1, 0.49, 1000L, -1L), "zar eşiğin altında konuşur");
		check(!ChainWhisperLogic.shouldWhisper(4, 0.0, 1000L, 1000L - ChainWhisperLogic.COOLDOWN_TICKS + 1), "bekleme dolmadan susar");
		check(ChainWhisperLogic.shouldWhisper(4, 0.0, 1000L, 1000L - ChainWhisperLogic.COOLDOWN_TICKS), "bekleme dolunca konuşur");
		check(ChainWhisperLogic.shouldWhisper(4, 0.0, 500L, 9000L), "zaman geriye giderse takılı kalmaz");
		check(!ChainWhisperLogic.shouldWhisper(4, Double.NaN, 1000L, -1L), "NaN zar konuşturmaz");

		// Söz seçimi: aralıkta ve art arda aynı değil
		check(ChainWhisperLogic.VARIANTS >= 2, "en az iki söz");
		for (int last = 0; last <= ChainWhisperLogic.VARIANTS; last++) {
			for (int i = 0; i <= 100; i++) {
				double roll = i / 100.0;
				int pick = ChainWhisperLogic.pickVariant(roll, last);
				check(pick >= 1 && pick <= ChainWhisperLogic.VARIANTS, "söz aralıkta roll=" + roll);
				check(last == 0 || pick != last, "art arda aynı söz yok last=" + last + " roll=" + roll);
			}
		}
		check(ChainWhisperLogic.pickVariant(Double.NaN, 0) >= 1 && ChainWhisperLogic.pickVariant(5.0, 0) <= ChainWhisperLogic.VARIANTS, "uç zarlar güvenli");
		Set<Integer> seen = new HashSet<>();
		for (int i = 0; i < 100; i++) {
			seen.add(ChainWhisperLogic.pickVariant(i / 100.0, 0));
		}
		check(seen.size() == ChainWhisperLogic.VARIANTS, "tüm sözler seçilebilir");

		// Anahtarlar
		check(ChainWhisperLogic.allKeys().size() == ChainLogic.MAX_TIER * ChainWhisperLogic.BANDS * ChainWhisperLogic.VARIANTS, "anahtar sayısı");
		check(new HashSet<>(ChainWhisperLogic.allKeys()).size() == ChainWhisperLogic.allKeys().size(), "anahtarlar benzersiz");
		check(ChainWhisperLogic.key(99, 99, 99).equals(ChainWhisperLogic.key(4, 2, 2)), "anahtar girdileri sınırlanır");
		check(ChainWhisperLogic.key(-1, -1, -1).equals(ChainWhisperLogic.key(1, 0, 1)), "alt sınır");

		// Gözün Yankısı
		check(ChainEchoLogic.TRIGGER_TIER == ChainLogic.MAX_TIER, "yankı yalnızca Ragnarök'te");
		check(!ChainEchoLogic.triggers(0) && !ChainEchoLogic.triggers(3) && ChainEchoLogic.triggers(4) && ChainEchoLogic.triggers(9), "tetik kademesi");
		check(ChainEchoLogic.chance(0) == 1.0 && ChainEchoLogic.chance(-3) == 1.0, "ilk yankı kesin");
		double prevEcho = 1.0;
		for (int echoSeen = 1; echoSeen <= 200; echoSeen++) {
			double c = ChainEchoLogic.chance(echoSeen);
			check(c <= prevEcho + 1.0E-12 && c >= ChainEchoLogic.MIN_CHANCE && c <= ChainEchoLogic.REPEAT_BASE_CHANCE + 1.0E-12, "olasılık azalır ve sınırlı seen=" + echoSeen);
			prevEcho = c;
		}
		check(ChainEchoLogic.chance(1) == ChainEchoLogic.REPEAT_BASE_CHANCE, "ikinci yankı temel olasılık");
		check(ChainEchoLogic.chance(10_000) == ChainEchoLogic.MIN_CHANCE && ChainEchoLogic.MIN_CHANCE > 0.0, "yankı hiç imkânsızlaşmaz");
		check(ChainEchoLogic.shouldEcho(0, 0.999, 500L, -1L), "ilk yankı kesin, bekleme yok");
		check(!ChainEchoLogic.shouldEcho(1, 0.30, 500L, -1L) && ChainEchoLogic.shouldEcho(1, 0.29, 500L, -1L), "ikinci yankı olasılık eşiği");
		check(!ChainEchoLogic.shouldEcho(0, 0.0, 50_000L, 50_000L - ChainEchoLogic.COOLDOWN_TICKS + 1L), "bekleme dolmadan yankı yok");
		check(ChainEchoLogic.shouldEcho(0, 0.0, 50_000L, 50_000L - ChainEchoLogic.COOLDOWN_TICKS), "bekleme dolunca yankı");
		check(ChainEchoLogic.shouldEcho(0, 0.0, 100L, 90_000L), "zaman geriye giderse takılı kalmaz");
		check(!ChainEchoLogic.shouldEcho(0, Double.NaN, 100L, -1L), "NaN zar yankı vermez");
		check(ChainEchoLogic.COOLDOWN_TICKS >= 12_000L, "yankılar arası en az 10 dakika");
		for (int eyeTicks = 0; eyeTicks <= 800; eyeTicks += 10) {
			int d = ChainEchoLogic.whisperDelay(eyeTicks);
			check(d >= 20 && d <= ChainEchoLogic.WHISPER_DELAY_TICKS, "söz gecikmesi sınırlı eye=" + eyeTicks);
			check(eyeTicks < 100 || d <= eyeTicks - 40, "söz göz kaybolmadan önce gelir eye=" + eyeTicks);
		}
		check(ChainEchoLogic.nextSeen(0) == 1 && ChainEchoLogic.nextSeen(ChainEchoLogic.MAX_SEEN) == ChainEchoLogic.MAX_SEEN && ChainEchoLogic.nextSeen(-5) == 1, "sayaç artışı sınırlı");
		check(ChainEchoLogic.allKeys().size() == ChainWhisperLogic.BANDS * 2, "yankı anahtar sayısı");
		check(new HashSet<>(ChainEchoLogic.allKeys()).size() == ChainEchoLogic.allKeys().size(), "yankı anahtarları benzersiz");
		check(ChainEchoLogic.key(99, true).equals(ChainEchoLogic.key(2, true)) && ChainEchoLogic.key(-4, false).equals(ChainEchoLogic.key(0, false)), "yankı anahtarı sınırlı");

		// Çeviri bütünlüğü: her anahtar her dil dosyasında var ve boş değil
		for (String lang : new String[] {"tr_tr", "en_us"}) {
			String json = Files.readString(Path.of("src/main/resources/assets/battleaxe/lang/" + lang + ".json"), StandardCharsets.UTF_8);
			java.util.List<String> allKeys = new java.util.ArrayList<>(ChainWhisperLogic.allKeys());
			allKeys.addAll(ChainEchoLogic.allKeys());
			for (String key : allKeys) {
				int at = json.indexOf("\"" + key + "\"");
				check(at >= 0, lang + " dosyasında eksik: " + key);
				if (at >= 0) {
					int colon = json.indexOf(':', at);
					int open = json.indexOf('"', colon);
					int close = json.indexOf('"', open + 1);
					check(close - open > 8, lang + " metni çok kısa/boş: " + key);
				}
			}
		}

		if (failed == 0) {
			System.out.println("ChainWhisperTest: tüm testler geçti (" + (ChainWhisperLogic.allKeys().size() + ChainEchoLogic.allKeys().size()) + " söz x 2 dil).");
		} else {
			System.out.println("ChainWhisperTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
