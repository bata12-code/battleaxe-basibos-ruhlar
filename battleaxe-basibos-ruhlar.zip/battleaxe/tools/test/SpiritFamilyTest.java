import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.battleaxe.execution.ExecutionCatalog;
import com.battleaxe.spirit.RuhYiyenConfig;
import com.battleaxe.spirit.SavrulmusConfig;
import com.battleaxe.spirit.SpiritConfig;
import com.battleaxe.spirit.SpiritEncounter;
import com.battleaxe.spirit.SpiritKind;
import com.battleaxe.spirit.SpiritWhisperLogic;
import com.battleaxe.spirit.ZincirliConfig;

/**
 * Başıboş Ruh ailesi: spesifikasyon değerleri, karşılaşma düzenleri, mevcut sistemlerle çakışmama, fısıltılar ve ÇEVİRİ BÜTÜNLÜĞÜ.
 * Çalıştırma: tools/test/run_tests.sh
 */
public final class SpiritFamilyTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) throws Exception {
		// ---- Spesifikasyon değerleri
		check(SavrulmusConfig.MAX_HEALTH == 40.0 && SavrulmusConfig.ARMOR == 2.0, "Savrulmuş: 40 can, 2 zırh");
		check(RuhYiyenConfig.MAX_HEALTH == 60.0 && RuhYiyenConfig.ARMOR == 4.0, "Ruh Yiyen: 60 can, 4 zırh");
		check(ZincirliConfig.MAX_HEALTH == 120.0 && ZincirliConfig.ARMOR == 8.0, "Zincirli: 120 can, 8 zırh");
		check(SavrulmusConfig.CLAW_DAMAGE_MIN == 6.0F && SavrulmusConfig.CLAW_DAMAGE_MAX == 8.0F, "Savrulmuş hasarı 6-8");
		check(SavrulmusConfig.LEAP_DAMAGE >= 6.0F && SavrulmusConfig.LEAP_DAMAGE <= 8.0F, "sıçrayış hasarı 6-8 aralığında");
		check(RuhYiyenConfig.BOLT_DAMAGE_MIN == 5.0F && RuhYiyenConfig.BOLT_DAMAGE_MAX == 7.0F, "Ruh Yiyen hasarı 5-7");
		check(ZincirliConfig.SWEEP_DAMAGE_MIN == 9.0F && ZincirliConfig.SWEEP_DAMAGE_MAX == 12.0F, "Zincirli hasarı 9-12");
		check(ZincirliConfig.SLAM_DAMAGE >= 9.0F && ZincirliConfig.SLAM_DAMAGE <= 12.0F, "ruhani darbe hasarı 9-12 aralığında");
		check(SavrulmusConfig.MOVEMENT_SPEED > RuhYiyenConfig.MOVEMENT_SPEED && RuhYiyenConfig.MOVEMENT_SPEED > ZincirliConfig.MOVEMENT_SPEED,
				"hız sırası: Savrulmuş (yüksek) > Ruh Yiyen (orta) > Zincirli (düşük)");
		check(ZincirliConfig.MOVEMENT_SPEED < 0.23, "Zincirli zombiden yavaş");

		// ---- Adillik: her saldırının hazırlığı oyuncunun tepki verebileceği kadar uzun (>= 5 tick; en kısa: pençe ikinci vuruş)
		check(SavrulmusConfig.CLAW_WINDUP_TICKS >= 5 && SavrulmusConfig.CLAW_FOLLOWUP_WINDUP_TICKS >= 5, "pençe hazırlığı >= 5 tick");
		check(SavrulmusConfig.LEAP_WINDUP_TICKS >= 10, "sıçrayış hazırlığı >= 10 tick");
		check(RuhYiyenConfig.BOLT_WINDUP_TICKS >= 10 && RuhYiyenConfig.DRAIN_WINDUP_TICKS >= 20, "ok/emme hazırlığı uzun");
		check(ZincirliConfig.SWEEP_WINDUP_TICKS >= 14 && ZincirliConfig.SLAM_WINDUP_TICKS >= 20 && ZincirliConfig.CHAIN_WINDUP_TICKS >= 18, "ağır saldırı hazırlıkları uzun");
		check(ZincirliConfig.SLAM_WINDUP_TICKS > ZincirliConfig.SWEEP_WINDUP_TICKS, "ağır darbe hazırlığı savurmadan uzun");
		check(SavrulmusConfig.LEAP_RECOVER_TICKS >= 15 && RuhYiyenConfig.DRAIN_BROKEN_RECOVER_TICKS >= RuhYiyenConfig.DRAIN_RECOVER_TICKS, "başarısız/kopan yetenekten sonra savunmasızlık");
		check(SpiritConfig.SEAL_SPEED_PENALTY > -1.0, "mühür oyuncuyu TAMAMEN hareketsiz bırakmaz");
		check(SpiritConfig.SEAL_JUMP_PENALTY > -1.0, "mühür zıplamayı tamamen kapatmaz");
		check(SpiritConfig.SEAL_TICKS <= 60, "mühür kısa sürer");
		check(SpiritConfig.SEAL_IMMUNITY_TICKS >= SpiritConfig.SEAL_TICKS * 3, "art arda zincirleme yok: bağışıklık mühürden çok uzun");
		check(SpiritConfig.SHUNPO_ESCAPE_GRACE_TICKS > 0, "Shunpo kaçışı ek bağışıklık verir");
		check(SpiritConfig.CONTROL_GAP_TICKS > 0, "kontrol yetenekleri arası boşluk");
		check(ZincirliConfig.CHAIN_AIM_LOCK_PROGRESS < 1.0F && ZincirliConfig.SWEEP_AIM_LOCK_PROGRESS < 1.0F, "nişan hazırlığın sonunda kilitlenir");
		check(ZincirliConfig.CHAIN_SPEED * ZincirliConfig.CHAIN_MAX_THROW_TICKS >= ZincirliConfig.CHAIN_MAX_DISTANCE * 0.8, "zincir menzile ulaşabilir");

		// ---- Ruh ödülü: sabit, küçük, can formülüyle (maxHP/20) aynı denge; Kara Körük/Wither seviyesine yaklaşmaz
		check(SpiritKind.SAVRULMUS.soulReward() == (int) (SavrulmusConfig.MAX_HEALTH / 20.0), "Savrulmuş ödülü dengeyle aynı");
		check(SpiritKind.RUH_YIYEN.soulReward() == (int) (RuhYiyenConfig.MAX_HEALTH / 20.0), "Ruh Yiyen ödülü dengeyle aynı");
		check(SpiritKind.ZINCIRLI.soulReward() == (int) (ZincirliConfig.MAX_HEALTH / 20.0), "Zincirli ödülü dengeyle aynı");
		check(SpiritKind.ZINCIRLI.soulReward() < 15, "hiçbir ruh Wither (15) kadar ruh vermez");
		check(SpiritConfig.SOUL_REWARD_ENABLED, "ödül açık (kapatılabilir ayar)");

		// ---- Kimlikler
		Set<String> ids = new HashSet<>();
		for (SpiritKind kind : SpiritKind.values()) {
			check(ids.add(kind.id()), "benzersiz kimlik: " + kind.id());
			check(SpiritKind.byId(kind.id()) == kind, "byId: " + kind.id());
			check(ExecutionCatalog.byId("battleaxe:" + kind.id()) == null, "Execution kataloğunda yok: " + kind.id());
			check(!kind.id().contains(":"), "kimlik yol biçiminde: " + kind.id());
		}
		check(SpiritKind.values().length == 3 && SpiritKind.byId("yok") == null, "tam olarak üç tür");
		check(SpiritKind.SAVRULMUS.id().equals("savrulmus_ruh") && SpiritKind.RUH_YIYEN.id().equals("ruh_yiyen")
				&& SpiritKind.ZINCIRLI.id().equals("zincirli_ruh"), "kayıt kimlikleri");

		// ---- Karşılaşma düzenleri
		for (SpiritEncounter.Layout layout : SpiritEncounter.Layout.values()) {
			List<SpiritEncounter.Slot> slots = SpiritEncounter.slots(layout);
			check(slots.size() == layout.members().size(), "her üyenin yeri var: " + layout.id());
			check(slots.size() >= 1 && slots.size() <= SpiritConfig.ENCOUNTER_MAX_SIZE, "boyut sınırı: " + layout.id());
			check(SpiritEncounter.separated(slots, SpiritConfig.ENCOUNTER_MIN_SEPARATION), "yığılma yok (asgari mesafe): " + layout.id());
			long zincirli = layout.members().stream().filter(k -> k == SpiritKind.ZINCIRLI).count();
			long yiyen = layout.members().stream().filter(k -> k == SpiritKind.RUH_YIYEN).count();
			check(zincirli <= 1 && yiyen <= 1, "en çok bir Zincirli ve bir Ruh Yiyen: " + layout.id());
			check(SpiritEncounter.Layout.byId(layout.id()) == layout, "düzen kimliği: " + layout.id());
			check(layout.weight() > 0.0, "ağırlık pozitif: " + layout.id());
			for (SpiritEncounter.Slot slot : slots) {
				if (slot.kind() == SpiritKind.ZINCIRLI) {
					check(Math.abs(slot.angleDeg()) < 1.0E-9, "Zincirli öne yerleşir: " + layout.id());
				}
				if (slot.kind() == SpiritKind.RUH_YIYEN) {
					check(Math.abs(slot.angleDeg()) == 180.0, "Ruh Yiyen geride durur: " + layout.id());
				}
			}
		}
		// Tehlikeli birleşim mevcut: üçü birlikte
		boolean hasTriad = false;
		for (SpiritEncounter.Layout layout : SpiritEncounter.Layout.values()) {
			if (layout.members().containsAll(List.of(SpiritKind.values()))) {
				hasTriad = true;
			}
		}
		check(hasTriad, "üç ruhun birlikte olduğu düzen var");
		// Seçim: bütün düzenler seçilebilir, sınırlar güvenli
		Set<SpiritEncounter.Layout> picked = new HashSet<>();
		for (double r = 0.0; r < 1.0; r += 0.001) {
			picked.add(SpiritEncounter.pick(r));
		}
		check(picked.size() == SpiritEncounter.Layout.values().length, "ağırlıklı seçim tüm düzenleri üretir");
		check(SpiritEncounter.pick(-5.0) != null && SpiritEncounter.pick(99.0) != null && SpiritEncounter.pick(Double.NaN) != null, "seçim sınır dışı girdide güvenli");

		// ---- Fısıltılar
		check(SpiritWhisperLogic.band(0) == 0 && SpiritWhisperLogic.band(9) == 2, "bantlar");
		check(SpiritWhisperLogic.shouldWhisper(true, 0.99, 1000L, -1L), "ilk öldürme her zaman konuşur");
		check(!SpiritWhisperLogic.shouldWhisper(true, 0.5, 1100L, 1000L), "ilk-öldürme kısa bekleme: hemen tekrar yok");
		check(SpiritWhisperLogic.shouldWhisper(true, 0.5, 1000L + SpiritWhisperLogic.FIRST_COOLDOWN_TICKS, 1000L), "ilk-öldürme beklemeden sonra");
		check(!SpiritWhisperLogic.shouldWhisper(false, 0.99, 100000L, -1L), "sıradan öldürme çoğunlukla sessiz");
		check(SpiritWhisperLogic.shouldWhisper(false, 0.0, 100000L, -1L), "sıradan öldürme şansla konuşur");
		check(!SpiritWhisperLogic.shouldWhisper(false, 0.0, 1000L + 10, 1000L), "uzun bekleme sürerken konuşmaz");
		check(SpiritWhisperLogic.shouldWhisper(false, 0.0, 500L, 100000L), "zaman geriye giderse serbest");
		for (int last = 0; last <= SpiritWhisperLogic.VARIANTS; last++) {
			for (double r = 0.0; r < 1.0; r += 0.05) {
				int v = SpiritWhisperLogic.pickVariant(r, last);
				check(v >= 1 && v <= SpiritWhisperLogic.VARIANTS && (last == 0 || v != last), "söz seçimi geçerli ve tekrarsız: r=" + r + " last=" + last);
			}
		}
		check(SpiritWhisperLogic.pickVariant(Double.NaN, 0) >= 1, "NaN güvenli");

		// ---- Çeviri bütünlüğü: her anahtar iki dil dosyasında da var, boş değil, biçim belirteçleri tutarlı
		Set<String> keys = new HashSet<>();
		for (SpiritKind kind : SpiritKind.values()) {
			keys.add("entity.battleaxe." + kind.id());
			keys.add(SpiritWhisperLogic.firstKey(kind));
		}
		for (int band = 0; band < 3; band++) {
			for (int v = 1; v <= SpiritWhisperLogic.VARIANTS; v++) {
				keys.add(SpiritWhisperLogic.key(band, v));
			}
		}
		keys.add("message.battleaxe.spirit.cmd.summoned");
		keys.add("message.battleaxe.spirit.cmd.no_room");
		keys.add("message.battleaxe.spirit.cmd.encounter");
		keys.add("message.battleaxe.spirit.cmd.cleared");
		for (String lang : new String[] {"en_us", "tr_tr"}) {
			String json = Files.readString(Path.of("src/main/resources/assets/battleaxe/lang/" + lang + ".json"), StandardCharsets.UTF_8);
			for (String key : keys) {
				String needle = "\"" + key + "\": \"";
				int at = json.indexOf(needle);
				check(at >= 0, lang + " çevirisi var: " + key);
				if (at >= 0) {
					int start = at + needle.length();
					int end = json.indexOf('"', start);
					check(end > start, lang + " çevirisi boş değil: " + key);
				}
			}
		}
		// Ganimet tabloları ve dokular (varlık kayıtlarıyla eşleşir)
		for (SpiritKind kind : SpiritKind.values()) {
			check(Files.exists(Path.of("src/main/resources/data/battleaxe/loot_table/entities/" + kind.id() + ".json")), "ganimet tablosu: " + kind.id());
			check(Files.exists(Path.of("src/main/resources/assets/battleaxe/textures/entity/" + kind.id() + ".png")), "doku: " + kind.id());
		}

		if (failed == 0) {
			System.out.println("SpiritFamilyTest: tüm testler geçti.");
		} else {
			System.out.println("SpiritFamilyTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
