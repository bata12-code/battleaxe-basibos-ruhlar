import java.util.HashMap;
import java.util.Map;
import java.util.SplittableRandom;

import com.battleaxe.call.CallConfig;
import com.battleaxe.call.CallData;
import com.battleaxe.call.CallLogic;
import com.battleaxe.call.CallMoon;
import com.battleaxe.call.OmenConfig;
import com.battleaxe.call.OmenGeometry;
import com.battleaxe.call.OmenKind;
import com.battleaxe.call.OmenLogic;
import com.battleaxe.call.OmenShapes;

/**
 * Baltanın Çağrısı - Öncü Belirtiler: Minecraft gerektirmeyen mantık/geometri testleri.
 * Çalıştırma: tools/test/run_tests.sh. (Oyun içi görsel davranış, ağ ve kalıcı depolama BURADA test edilemez.)
 */
public final class OmenLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static boolean near(double a, double b, double eps) {
		return Math.abs(a - b) <= eps;
	}

	static OmenLogic.Env env(boolean ow, boolean sky, boolean rain, int tone, double travel) {
		return new OmenLogic.Env(ow, sky, rain, tone, travel);
	}

	public static void main(String[] args) {
		check(!OmenConfig.TEST_MODE, "üretim sürümünde TEST_MODE kapalı olmalı");
		kinds();
		tones();
		eligibility();
		gating();
		chanceAndChoice();
		placement();
		variants();
		messages();
		packing();
		geometry();
		shapes();
		permanence();
		pacing();
		if (failed == 0) {
			System.out.println("OmenLogicTest: tüm testler geçti.");
		} else {
			System.out.println("OmenLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}

	static void kinds() {
		int all = 0;
		for (OmenKind k : OmenKind.values()) {
			check(OmenKind.byId(k.id()) == k, "tür kimliği gidiş-dönüş " + k);
			check((all & k.bit()) == 0, "tür bitleri çakışmaz " + k);
			all |= k.bit();
		}
		check(OmenKind.byId(-1) == null && OmenKind.byId(99) == null, "geçersiz kimlik null");
		check(OmenKind.values().length == OmenKind.COUNT, "COUNT doğru");
		check(OmenKind.SKY_AXE.id() == 0 && OmenKind.WATCHER_EYE.id() == 1 && OmenKind.HORIZON_COLOSSUS.id() == 2
				&& OmenKind.IMPOSSIBLE_STRUCTURE.id() == 3, "kayıtlı kimlikler değişmedi");
	}

	static void tones() {
		check(OmenLogic.toneOf(6000) == OmenLogic.TONE_DAY, "öğle = gündüz");
		check(OmenLogic.toneOf(18000) == OmenLogic.TONE_NIGHT, "gece yarısı = gece");
		check(OmenLogic.toneOf(12900) == OmenLogic.TONE_TWILIGHT, "akşam = alacakaranlık");
		check(OmenLogic.toneOf(23000) == OmenLogic.TONE_TWILIGHT, "şafak = alacakaranlık");
		check(OmenLogic.toneOf(18000 + 24000L * 5) == OmenLogic.TONE_NIGHT, "gün sayısı tonu değiştirmez");
		check(OmenLogic.toneOf(-6000) == OmenLogic.TONE_NIGHT, "negatif zaman sarılır");
		// Ay sinyalinin görünür olduğu anlar gece kabul edilmeli (ay işareti ile tutarlılık).
		for (long t = 14000; t <= 22000; t += 500) {
			check(CallMoon.moonElevationSin(CallMoon.celestialAngle(t)) > 0.0 || OmenLogic.toneOf(t) == OmenLogic.TONE_NIGHT,
					"gece aralığı ay ile uyumlu t=" + t);
		}
	}

	static void eligibility() {
		int night = OmenLogic.TONE_NIGHT;
		check(OmenLogic.eligibleMask(env(false, true, false, night, 999)) == 0, "Overworld dışında olay yok");
		check(OmenLogic.eligibleMask(env(true, false, false, night, 999)) == 0, "gökyüzü görünmüyorsa olay yok");
		check(OmenLogic.eligibleMask(env(true, true, true, night, 999)) == 0, "yağmurda olay yok");
		check(OmenLogic.eligibleMask(null) == 0, "null ortam güvenli");

		int nightNoTravel = OmenLogic.eligibleMask(env(true, true, false, night, 0));
		check((nightNoTravel & OmenKind.SKY_AXE.bit()) != 0 && (nightNoTravel & OmenKind.WATCHER_EYE.bit()) != 0, "gece: balta ve göz uygun");
		check((nightNoTravel & OmenKind.HORIZON_COLOSSUS.bit()) == 0 && (nightNoTravel & OmenKind.IMPOSSIBLE_STRUCTURE.bit()) == 0,
				"yol yürünmeden dev/yapı yok (keşif şartı)");
		int dayFar = OmenLogic.eligibleMask(env(true, true, false, OmenLogic.TONE_DAY, 400));
		check((dayFar & (OmenKind.SKY_AXE.bit() | OmenKind.WATCHER_EYE.bit())) == 0, "gündüz balta/göz yok");
		check((dayFar & OmenKind.HORIZON_COLOSSUS.bit()) != 0 && (dayFar & OmenKind.IMPOSSIBLE_STRUCTURE.bit()) != 0,
				"gündüz yeterince yürünmüşse dev/yapı uygun");
		int unknown = OmenLogic.eligibleMask(env(true, true, false, OmenLogic.TONE_UNKNOWN, 400));
		check((unknown & OmenKind.SKY_AXE.bit()) == 0 && (unknown & OmenKind.WATCHER_EYE.bit()) == 0,
				"gün zamanı okunamıyorsa balta/göz kesinlikle çıkmaz");
		check((unknown & OmenKind.HORIZON_COLOSSUS.bit()) != 0, "gün zamanı okunamasa da ufuk olayı çalışır");
		int mid = OmenLogic.eligibleMask(env(true, true, false, night, OmenConfig.COLOSSUS_MIN_TRAVEL_BLOCKS + 1));
		check((mid & OmenKind.HORIZON_COLOSSUS.bit()) != 0 && (mid & OmenKind.IMPOSSIBLE_STRUCTURE.bit()) == 0,
				"yapı dev'den daha fazla keşif ister");
	}

	static void gating() {
		long q = OmenConfig.INITIAL_QUIET_TICKS;
		long age = OmenConfig.MIN_WORLD_AGE_TICKS + 1;
		long now = q + 100000L;
		check(OmenLogic.mayArm(now, 0, age, 0, 0, 0, 0, 0), "her şey uygunsa kurulabilir");
		check(!OmenLogic.mayArm(q - 1, 0, age, 0, 0, 0, 0, 0), "girişten hemen sonra sessizlik");
		check(!OmenLogic.mayArm(now, 0, 100, 0, 0, 0, 0, 0) || OmenConfig.MIN_WORLD_AGE_TICKS <= 100, "yeni dünyada sessizlik");
		check(!OmenLogic.mayArm(now, 0, age, OmenConfig.PER_SESSION, 0, 0, 0, 0), "oturum sınırı");
		check(!OmenLogic.mayArm(now, 0, age, 0, now - 10, 0, 0, 0), "olaylar arası bekleme");
		check(OmenLogic.mayArm(now, 0, age, 0, now - OmenConfig.MIN_GAP_TICKS, 0, 0, 0), "bekleme dolunca tekrar");
		check(!OmenLogic.mayArm(now, 0, age, 0, 0, now - 5, 0, 0), "mesaj/ay/demir sesinden hemen sonra olay yok");
		check(!OmenLogic.mayArm(now, 0, age, 0, 0, 0, now + 500, 0), "etkin olay varken (çakışma) yeni olay yok");
		check(OmenLogic.mayArm(now, 0, age, 0, 0, 0, now - 1, 0), "olay bitince serbest");
		check(!OmenLogic.mayArm(now, 0, age, 0, 0, 0, 0, now - 20), "hasardan hemen sonra (savaş) olay yok");
		check(OmenLogic.mayArm(now, 0, age, 0, 0, 0, 0, now - OmenConfig.QUIET_AFTER_DAMAGE_TICKS), "hasar sessizliği biter");
		// Dünya saati geriye giderse (eski veri) takılmaz.
		check(OmenLogic.mayArm(now, 0, age, 0, now + 99999, 0, 0, 0), "gelecekteki kayıt sistemi kilitlemez");
	}

	static void chanceAndChoice() {
		check(OmenLogic.chance(0, 0) > 0.0 && OmenLogic.chance(4, 0) <= 1.0, "olasılık aralığı");
		check(OmenLogic.chance(3, 0) > OmenLogic.chance(0, 0), "ilerleme olasılığı artırır");
		check(OmenLogic.chance(0, OmenConfig.PITY_FULL_TICKS) > OmenLogic.chance(0, 0), "uzun süre görmeyen şansı artar");
		check(near(OmenLogic.chance(0, 10 * OmenConfig.PITY_FULL_TICKS), OmenLogic.chance(0, OmenConfig.PITY_FULL_TICKS), 1e-12), "şans payı tavanlı");
		check(OmenLogic.chance(99, 0) == OmenLogic.chance(4, 0) && OmenLogic.chance(-5, 0) == OmenLogic.chance(0, 0), "ilerleme kırpılır");

		SplittableRandom r = new SplittableRandom(7);
		int all = (1 << OmenKind.COUNT) - 1;
		check(OmenLogic.choose(r, 0, 2, 0, -1) == null, "uygun tür yoksa sessizlik");
		for (OmenKind last : OmenKind.values()) {
			for (int i = 0; i < 2000; i++) {
				OmenKind k = OmenLogic.choose(r, all, i % 5, i % 16, last.id());
				check(k != null && k != last, "aynı tür art arda seçilmez");
			}
		}
		check(OmenLogic.choose(r, OmenKind.WATCHER_EYE.bit(), 4, 0, OmenKind.WATCHER_EYE.id()) == null, "tek uygun tür az önce gösterildiyse bekler");
		check(OmenLogic.choose(r, OmenKind.WATCHER_EYE.bit(), 4, 0, -1) == OmenKind.WATCHER_EYE, "tek uygun tür seçilir");
		for (int i = 0; i < 500; i++) {
			int mask = OmenKind.SKY_AXE.bit() | OmenKind.HORIZON_COLOSSUS.bit();
			OmenKind k = OmenLogic.choose(r, mask, 2, 0, -1);
			check(k == OmenKind.SKY_AXE || k == OmenKind.HORIZON_COLOSSUS, "yalnızca uygun maskedeki türler");
		}

		// Eğilim: yeni oyuncuya ölçek (ufuk) göz'den belirgin sıklıkta; Nether sonrası çağrı (balta) artar; balta görülünce göz artar.
		int[] early = new int[OmenKind.COUNT];
		int[] late = new int[OmenKind.COUNT];
		int[] afterAxe = new int[OmenKind.COUNT];
		for (int i = 0; i < 30000; i++) {
			early[OmenLogic.choose(r, all, 0, 0, -1).id()]++;
			late[OmenLogic.choose(r, all, 4, 0, -1).id()]++;
			afterAxe[OmenLogic.choose(r, all, 4, OmenKind.SKY_AXE.bit(), -1).id()]++;
		}
		check(early[2] > 1.5 * early[1], "başlangıçta ufuk dev'i göz'den çok daha olası");
		check(late[0] > early[0], "ilerleyince gökteki balta artar");
		check(afterAxe[1] > late[1] / 2 && (double) afterAxe[1] / 30000 > (double) late[1] / 30000 * 0.7, "balta görüldükten sonra göz geri kalmaz");
		for (OmenKind k : OmenKind.values()) {
			if (!k.scheduled()) {
				check(early[k.id()] == 0 && late[k.id()] == 0, "çizelgeyle seçilmeyen tür seçilmez " + k);
				continue;
			}
			check(early[k.id()] > 0 && late[k.id()] > 0, "her tür seçilebilir " + k);
		}
	}

	static void placement() {
		SplittableRandom r = new SplittableRandom(11);
		for (int i = 0; i < 3000; i++) {
			double yaw = r.nextDouble() * 720 - 360;
			double pitch = -r.nextDouble() * 80;
			OmenLogic.Placement axe = OmenLogic.place(r, OmenKind.SKY_AXE, yaw, pitch, null);
			check(axe.elevation() >= 32.0 && axe.elevation() <= 66.0, "balta yüksekliği aralıkta " + axe.elevation());
			check(Math.abs(OmenGeometry.wrap180(axe.azimuth() - yaw)) <= 40.0 + 1e-6, "balta bakışın yakınında doğar");
			OmenLogic.Placement eye = OmenLogic.place(r, OmenKind.WATCHER_EYE, yaw, pitch, null);
			check(eye.elevation() >= 26.0 && eye.elevation() <= 54.0, "göz yüksekliği aralıkta");
			OmenLogic.Placement giant = OmenLogic.place(r, OmenKind.HORIZON_COLOSSUS, yaw, 5.0, null);
			check(giant.elevation() == OmenLogic.COLOSSUS_BASE_ELEVATION && giant.elevation() >= -1.0 && giant.elevation() <= -0.2 && Math.abs(OmenGeometry.wrap180(giant.azimuth() - yaw)) <= 45.0 + 1e-6, "dev ufukta, bakışın yakınında");
			OmenLogic.Placement st = OmenLogic.place(r, OmenKind.IMPOSSIBLE_STRUCTURE, yaw, 5.0, null);
			check(st.elevation() >= -2.0 && st.elevation() <= 9.0, "yapı tabanı ufukta");
		}
		// Ay ile üst üste binmez.
		for (int i = 0; i < 3000; i++) {
			double moonAz = r.nextDouble() * 360;
			double moonEl = 10 + r.nextDouble() * 75;
			double[] moon = OmenGeometry.direction(moonAz, moonEl);
			double yaw = moonAz + (r.nextDouble() - 0.5) * 60; // oyuncu aya yakın bakarken en zor durum
			OmenKind k = i % 2 == 0 ? OmenKind.SKY_AXE : OmenKind.WATCHER_EYE;
			OmenLogic.Placement p = OmenLogic.place(r, k, yaw, -Math.max(15.0, moonEl), moon);
			double sep = OmenGeometry.angleDegrees(OmenGeometry.direction(p.azimuth(), p.elevation()), moon);
			check(sep >= OmenConfig.MOON_CLEARANCE_DEGREES - 1e-6 || sep >= 25.0, "gökteki olay aya binmez, açı=" + sep);
		}
		// Bakış kuralı
		check(OmenLogic.lookAllows(OmenKind.SKY_AXE, -30) && !OmenLogic.lookAllows(OmenKind.SKY_AXE, 0), "balta için yukarı bakış");
		check(OmenLogic.lookAllows(OmenKind.WATCHER_EYE, -14) && !OmenLogic.lookAllows(OmenKind.WATCHER_EYE, -5), "göz için yukarı bakış");
		check(OmenLogic.lookAllows(OmenKind.HORIZON_COLOSSUS, 0) && !OmenLogic.lookAllows(OmenKind.HORIZON_COLOSSUS, -70), "dev için ufka bakış");
		check(!OmenLogic.lookAllows(OmenKind.IMPOSSIBLE_STRUCTURE, 70), "yapı için yere bakış değil");
		// Determinizm
		OmenLogic.Placement a = OmenLogic.place(new SplittableRandom(5), OmenKind.SKY_AXE, 10, -30, null);
		OmenLogic.Placement b = OmenLogic.place(new SplittableRandom(5), OmenKind.SKY_AXE, 10, -30, null);
		check(a.equals(b), "aynı tohum aynı yerleşim");
	}

	static void variants() {
		SplittableRandom r = new SplittableRandom(3);
		int[][] axeDissolve = new int[1][3];
		boolean[] seenShape = new boolean[4];
		boolean[] seenColossus = new boolean[3];
		for (int i = 0; i < 4000; i++) {
			for (OmenKind k : OmenKind.values()) {
				int d = OmenLogic.duration(r, k);
				int min = switch (k) {
					case SKY_AXE -> OmenConfig.SKY_AXE_MIN_TICKS;
					case WATCHER_EYE -> OmenConfig.EYE_MIN_TICKS;
					case HORIZON_COLOSSUS -> OmenConfig.COLOSSUS_MIN_TICKS;
					case SECOND_MOON -> OmenConfig.SECOND_MOON_MIN_TICKS;
					case IMPOSSIBLE_RINGS -> OmenConfig.RINGS_MIN_TICKS;
					case MONOLITH -> OmenConfig.MONOLITH_MIN_TICKS;
					case ALL_WATCHING -> OmenConfig.ALL_WATCHING_MIN_TICKS;
					default -> OmenConfig.STRUCTURE_MIN_TICKS;
				};
				int max = switch (k) {
					case SKY_AXE -> OmenConfig.SKY_AXE_MAX_TICKS;
					case WATCHER_EYE -> OmenConfig.EYE_MAX_TICKS;
					case HORIZON_COLOSSUS -> OmenConfig.COLOSSUS_MAX_TICKS;
					case SECOND_MOON -> OmenConfig.SECOND_MOON_MAX_TICKS;
					case IMPOSSIBLE_RINGS -> OmenConfig.RINGS_MAX_TICKS;
					case MONOLITH -> OmenConfig.MONOLITH_MAX_TICKS;
					case ALL_WATCHING -> OmenConfig.ALL_WATCHING_MAX_TICKS;
					default -> OmenConfig.STRUCTURE_MAX_TICKS;
				};
				check(d >= min && d <= max, "süre aralıkta " + k);
				int v = OmenLogic.makeVariant(r, k);
				check((v & ~OmenLogic.VARIANT_MASK) == 0, "varyant 11 bit");
				if (k == OmenKind.SKY_AXE) {
					axeDissolve[0][OmenLogic.lowBits(v) & 3]++;
					check((OmenLogic.lowBits(v) & 3) <= 2, "balta kaybolma biçimi 0..2");
				}
				if (k == OmenKind.IMPOSSIBLE_STRUCTURE) {
					seenShape[OmenLogic.lowBits(v) & 3] = true;
				}
				if (k == OmenKind.HORIZON_COLOSSUS) {
					int shape = OmenLogic.lowBits(v) & 3;
					check(shape <= 2, "dev şekli 0..2");
					seenColossus[shape] = true;
					check(((OmenLogic.lowBits(v) >> 2) & 3) <= 2, "dev kaybolma biçimi 0..2");
					check(OmenLogic.coverLevel(v) == 0, "ufuk devi bulut örtüsü almaz");
				}
				if (k == OmenKind.IMPOSSIBLE_STRUCTURE) {
					check(((OmenLogic.lowBits(v) >> 2) & 3) <= 2 && OmenLogic.coverLevel(v) == 0, "yapı varyantı geçerli");
				}
			}
		}
		check(axeDissolve[0][0] > 0 && axeDissolve[0][1] > 0 && axeDissolve[0][2] > 0, "balta üç kaybolma biçimini de kullanır");
		for (boolean s : seenShape) {
			check(s, "yapının dört biçimi de üretilir");
		}
		for (boolean s : seenColossus) {
			check(s, "devin üç biçimi de üretilir");
		}
	}

	static void messages() {
		SplittableRandom r = new SplittableRandom(9);
		check(OmenLogic.starMessage(r, 0, 0, 100000, 0), "ilk balta tezahüründe mesaj kesin");
		check(OmenLogic.starMessage(r, 3, 0, 100000, 0), "yıldız yokken ilk balta mesajı");
		for (int i = 0; i < 500; i++) {
			check(!OmenLogic.starMessage(r, 4, 0, 100000L + i, 0), "Nether Yıldızı varken mesaj hiç gösterilmez");
			check(!OmenLogic.starMessage(r, 4, OmenKind.SKY_AXE.bit(), 100000L + i, 0), "yıldız varken tekrar da yok");
			check(!OmenLogic.starMessage(r, 1, OmenKind.SKY_AXE.bit(), 100000L, 100000L - 10), "aralık dolmadan mesaj yok");
		}
		int shown = 0;
		for (int i = 0; i < 10000; i++) {
			if (OmenLogic.starMessage(r, 1, OmenKind.SKY_AXE.bit(), 1_000_000L, 1000L)) {
				shown++;
			}
		}
		check(shown > 2000 && shown < 4000, "tekrar mesajı seyrek (~%30) shown=" + shown);
		// Mesaj yalnızca balta için sunucuda istenir; mantık türden bağımsız ama OmenManager yalnızca SKY_AXE'te çağırır.
	}

	static void packing() {
		for (int variant : new int[] {0, 1, 5, 0x7FF, 0x3A5, 0x400}) {
			for (int tone = -1; tone <= 2; tone++) {
				for (int flags : new int[] {0, 1, 2, 3, 0xFF}) {
					int p = OmenLogic.pack(variant, tone, flags);
					check(OmenLogic.unpackVariant(p) == variant && OmenLogic.unpackTone(p) == tone && OmenLogic.unpackFlags(p) == flags,
							"paket gidiş-dönüş v=" + variant + " t=" + tone + " f=" + flags);
					check(p >= 0, "paket negatif değil");
				}
			}
		}
		check(OmenLogic.envelope(0, 100, 20, 20) == 0.0 && OmenLogic.envelope(100, 100, 20, 20) == 0.0, "zarf uçlarda sıfır");
		check(near(OmenLogic.envelope(50, 100, 20, 20), 1.0, 1e-12), "zarf ortada bir");
		double prev = -1;
		for (int t = 0; t <= 20; t++) {
			double e = OmenLogic.envelope(t, 100, 20, 20);
			check(e >= prev - 1e-12 && e >= 0 && e <= 1, "zarf girişte tekdüze");
			prev = e;
		}
		check(OmenLogic.smooth(-5) == 0.0 && OmenLogic.smooth(5) == 1.0, "smooth kırpar");
	}

	static void geometry() {
		// projectClamped, CallMoon.project ile önündeki noktalarda aynı sonucu verir.
		SplittableRandom r = new SplittableRandom(21);
		for (int i = 0; i < 500; i++) {
			double yaw = r.nextDouble() * 360;
			double pitch = r.nextDouble() * 120 - 60;
			double[] dir = OmenGeometry.direction(yaw + r.nextDouble() * 40 - 20, pitch * -1 + r.nextDouble() * 20 - 10);
			double[] a = CallMoon.project(dir, yaw, pitch, 70, 854, 480);
			double[] b = OmenGeometry.projectClamped(dir, yaw, pitch, 70, 854, 480);
			if (a != null) {
				check(near(a[0], b[0], 1e-6) && near(a[1], b[1], 1e-6) && b[3] == 1.0, "izdüşüm CallMoon ile uyumlu");
			}
		}
		// Merkeze bakınca ekran ortasında.
		double[] c = OmenGeometry.projectClamped(OmenGeometry.direction(33, 20), 33, -20, 70, 800, 450);
		check(near(c[0], 400, 1e-6) && near(c[1], 225, 1e-6), "bakılan yön ekran ortasında");
		// Yön açısı arttıkça sağa, yükseklik arttıkça yukarı.
		double[] right = OmenGeometry.projectClamped(OmenGeometry.direction(43, 20), 33, -20, 70, 800, 450);
		double[] up = OmenGeometry.projectClamped(OmenGeometry.direction(33, 30), 33, -20, 70, 800, 450);
		check(right[0] > 400, "yön açısı artınca ekranda sağa");
		check(up[1] < 225, "yükseklik artınca ekranda yukarı");
		// Kameranın arkası: atılmaz, ekran dışına itilir ve işaretlenir.
		double[] behind = OmenGeometry.projectClamped(OmenGeometry.direction(33 + 180, 0), 33, 0, 70, 800, 450);
		check(behind[3] == 0.0 && Double.isFinite(behind[0]) && Double.isFinite(behind[1]), "arkadaki köşe sonlu ve işaretli");
		// Görünür açı yüksek açıda korunur (1/cos telafisi).
		for (double el : new double[] {0, 30, 60, 75}) {
			double[] mid = OmenGeometry.direction(100, el);
			double[] off = OmenGeometry.vertexDirection(100, el, 6, 0);
			double sep = OmenGeometry.angleDegrees(mid, off);
			check(near(sep, 6.0, 0.9), "6 derecelik yatay kayma el=" + el + " sep=" + sep);
		}
		check(near(OmenGeometry.wrap180(190), -170, 1e-9) && near(OmenGeometry.wrap180(-190), 170, 1e-9) && near(OmenGeometry.wrap180(540), 180, 1e-9), "wrap180");
	}

	static void shapes() {
		long[] seeds = {0, 1, 2, 12345, -999, Long.MAX_VALUE, 424242};
		for (OmenKind kind : OmenKind.values()) {
			if (kind == OmenKind.ALL_WATCHING || kind == OmenKind.FRACTURED_SUN) {
				// Görüntü sahnesi yok: davranış (Bütün Canlılar) ya da kendi çizimi (Parçalanmış Güneş, istemcide).
				check(OmenShapes.build(kind, 0, 1).polys().length == 0, "görüntüsüz tür boş sahne verir " + kind);
				continue;
			}
			int variantCount = switch (kind) {
				case SKY_AXE -> 8;
				case WATCHER_EYE -> 64; // bit 0 biçim, bit 1 bakış kaçınca sönme, bit 2-3 boyut, bit 4 gölge, bit 5 yarı gizli
				case HORIZON_COLOSSUS, IMPOSSIBLE_STRUCTURE -> 12;
				case SECOND_MOON -> 64; // biçim x boyut x yıldızsız boşluk
				case IMPOSSIBLE_RINGS -> 32; // hareket, göz, halka sayısı
				default -> 16; // Monolith: eğim
			};
			for (int v = 0; v < variantCount; v++) {
				for (long seed : seeds) {
					OmenShapes.Scene s = OmenShapes.build(kind, v, seed);
					String tag = kind + " v" + v + " s" + seed;
					check(s.polys().length > 0 && s.polys().length <= OmenShapes.MAX_POLYS, "çokgen sayısı sınırlı " + tag + " n=" + s.polys().length);
					boolean body = false;
					for (OmenShapes.Poly p : s.polys()) {
						check(p.x().length == p.y().length && p.x().length >= 3 && p.x().length <= OmenShapes.MAX_POINTS_PER_POLY,
								"çokgen köşe sayısı " + tag + " k=" + p.x().length);
						check(p.alpha() > 0.0F && p.alpha() <= 1.0F && p.style() >= 0 && p.style() <= OmenShapes.MAX_STYLE, "çokgen stili/saydamlığı " + tag);
						check(p.group() == 0 || ((kind == OmenKind.WATCHER_EYE || kind == OmenKind.IMPOSSIBLE_RINGS) && p.group() == 1), "yalnızca gözün bebek grubu var " + tag);
						for (int i = 0; i < p.x().length; i++) {
							check(Float.isFinite(p.x()[i]) && Float.isFinite(p.y()[i]) && Math.abs(p.x()[i]) < 200 && Math.abs(p.y()[i]) < 200, "köşe sonlu ve makul " + tag);
						}
						if (p.style() == OmenShapes.S_BODY || p.style() == OmenShapes.S_DEEP) {
							body = true;
						}
					}
					check(body, "gövde çokgeni var " + tag);
					check(s.glints().length % 3 == 0 && (!kind.legacy() || s.glints().length >= 3), "kıvılcım üçlüleri " + tag);
					for (float g : s.glints()) {
						check(Float.isFinite(g), "kıvılcım sonlu " + tag);
					}
					OmenShapes.Scene again = OmenShapes.build(kind, v, seed);
					check(sameScene(s, again), "şekil determinist " + tag);
					switch (kind) {
						case SKY_AXE -> check(s.halfHeight() >= 25 && s.halfHeight() <= 50 && s.halfWidth() >= 15, "balta ölçeği " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
						case WATCHER_EYE -> check(s.halfWidth() >= 9 && s.halfWidth() <= 62 && s.halfHeight() <= 48, "göz ölçeği " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
						case HORIZON_COLOSSUS -> check(s.halfHeight() >= 30 && s.halfHeight() <= 95, "dev ölçeği " + tag + " " + s.halfHeight());
						case SECOND_MOON -> check(s.halfWidth() >= 10 && s.halfWidth() <= 60 && s.halfHeight() <= 60, "ikinci ay ölçeği " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
						case IMPOSSIBLE_RINGS -> check(s.halfWidth() >= 15 && s.halfWidth() <= 60 && s.halfHeight() >= 6, "halka ölçeği " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
						case MONOLITH -> {
							// Çok uzun; toplam genişlik (taban sisi dâhil) dar. Gövde ise sisten de dar ve yukarı doğru YAKINSAR (perspektif).
							check(s.halfHeight() >= 70 && s.halfHeight() <= 92 && s.halfWidth() <= 9.0, "monolith ölçeği (çok uzun, çok dar) " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
							OmenShapes.Poly mono = null;
							for (OmenShapes.Poly p : s.polys()) {
								if (p.style() == OmenShapes.S_DEEP) {
									mono = p;
								}
							}
							check(mono != null && mono.x().length == 4, "monolith gövdesi tek yekpare dörtgen " + tag);
							if (mono != null && mono.x().length == 4) {
								float baseWidth = mono.x()[1] - mono.x()[0];
								float topWidth = mono.x()[2] - mono.x()[3];
								check(baseWidth > 0.0F && topWidth > 0.0F && topWidth < baseWidth * 0.6F, "monolith yukarı doğru yakınsar (perspektif) " + tag + " " + baseWidth + " -> " + topWidth);
							}
						}
						default -> check(s.halfWidth() >= 22 && s.halfHeight() >= 15, "yapı ölçeği " + tag + " " + s.halfWidth() + "x" + s.halfHeight());
					}
				}
				check(!sameScene(OmenShapes.build(kind, v, 1), OmenShapes.build(kind, v, 2)) || kind == OmenKind.SKY_AXE && false,
						"farklı tohum farklı şekil " + kind + " v" + v);
			}
		}
		// Gözün iki varyantı gerçekten farklı; yapının dört biçimi farklı.
		check(!sameScene(OmenShapes.build(OmenKind.WATCHER_EYE, 0, 5), OmenShapes.build(OmenKind.WATCHER_EYE, 1, 5)), "göz biçimleri farklı");
		for (int a = 0; a < 4; a++) {
			for (int b = a + 1; b < 4; b++) {
				check(!sameScene(OmenShapes.build(OmenKind.IMPOSSIBLE_STRUCTURE, a, 5), OmenShapes.build(OmenKind.IMPOSSIBLE_STRUCTURE, b, 5)), "yapı biçimleri farklı " + a + b);
			}
		}
		// Yapı: gerçek bir yapı/blok olmadığı için kapalı döngü değil; "kemerler birbirine bağlanmaz": her bacak ayrı çokgen.
		OmenShapes.Scene arches = OmenShapes.build(OmenKind.IMPOSSIBLE_STRUCTURE, 0, 77);
		int bodies = 0;
		for (OmenShapes.Poly p : arches.polys()) {
			if (p.style() == OmenShapes.S_BODY) {
				bodies++;
			}
		}
		check(bodies >= 8, "kemerler bacak bacak ayrı çokgenlerdir (apeks açık) n=" + bodies);
	}

	static boolean sameScene(OmenShapes.Scene a, OmenShapes.Scene b) {
		if (a.polys().length != b.polys().length || a.glints().length != b.glints().length) {
			return false;
		}
		for (int i = 0; i < a.polys().length; i++) {
			OmenShapes.Poly p = a.polys()[i];
			OmenShapes.Poly q = b.polys()[i];
			if (p.style() != q.style() || !java.util.Arrays.equals(p.x(), q.x()) || !java.util.Arrays.equals(p.y(), q.y())) {
				return false;
			}
		}
		return java.util.Arrays.equals(a.glints(), b.glints());
	}

	/**
	 * Kalıcı sona erme: gerçek kalıcılık Fabric attachment'ıdır (burada test edilemez); ama kararı veren veri modeli
	 * ({@link CallData}) ve bayrak mantığı test edilir: bayrak hiçbir güncellemeyle düşmez, oyuncular bağımsızdır.
	 */
	static void permanence() {
		CallData fresh = CallData.EMPTY;
		check(!CallLogic.silenced(fresh.flags()), "balta edinilmeden sistem açık");
		check(fresh.lastOmen() == 0 && fresh.omenSeen() == 0 && fresh.lastOmenKind() == -1 && fresh.lastStarMsg() == 0, "yeni veri boş");

		CallData withAxe = fresh.withFlags(fresh.flags() | CallLogic.F_AXE);
		check(CallLogic.silenced(withAxe.flags()), "balta edinilince sistem kapanır");

		// Her çağrı güncellemesi bayrağı korur (ölüm kopyası, yeniden giriş, boyut değişimi = aynı kayıt).
		CallData d = withAxe;
		d = d.withOmen(500, OmenKind.SKY_AXE, true);
		d = d.withMoon(600).withForge(700).withMessage(3L, 1, 800).withMilestones(5).withMilestoneShown(7, 900);
		d = d.withFlags(d.flags() | CallLogic.F_NETHER | CallLogic.F_STAR | CallLogic.F_WITHER_SEEN);
		check(CallLogic.silenced(d.flags()), "sonraki güncellemeler bayrağı düşürmez");
		check(CallLogic.progress(d.flags()) >= 0, "ilerleme hesabı susturulmuş veride çalışır");
		check(d.omenSeen() == OmenKind.SKY_AXE.bit() && d.lastOmenKind() == 0 && d.lastOmen() == 500 && d.lastStarMsg() == 500,
				"öncü belirti kaydı korunur (withMoon vb. ona dokunmaz)");
		check(fresh.flags() == 0, "kayıt değişmezdir (eski nesne etkilenmez)");

		// Mesajsız olay yıldız zamanını değiştirmez; mesajlı olay günceller.
		CallData noMsg = fresh.withOmen(100, OmenKind.WATCHER_EYE, false);
		check(noMsg.lastStarMsg() == 0 && noMsg.omenSeen() == OmenKind.WATCHER_EYE.bit(), "mesajsız olay yıldız zamanını yazmaz");
		CallData two = noMsg.withOmen(200, OmenKind.HORIZON_COLOSSUS, false);
		check(two.omenSeen() == (OmenKind.WATCHER_EYE.bit() | OmenKind.HORIZON_COLOSSUS.bit()) && two.lastOmenKind() == 2, "görülen türler birikir");

		// Çok oyunculu: bir oyuncunun kapanması diğerini etkilemez.
		Map<String, CallData> players = new HashMap<>();
		players.put("A", fresh);
		players.put("B", fresh);
		players.put("C", fresh.withFlags(CallLogic.F_NETHER));
		players.put("A", players.get("A").withFlags(players.get("A").flags() | CallLogic.F_AXE));
		check(CallLogic.silenced(players.get("A").flags()), "A susar");
		check(!CallLogic.silenced(players.get("B").flags()) && !CallLogic.silenced(players.get("C").flags()), "B ve C etkilenmez");
		check(OmenLogic.mayArm(10_000_000L, 0, 10_000_000L, 0, 0, 0, 0, 0), "B hâlâ olay kurabilir");

		// Susturma, özelliklerin hiçbirinde "geri açılmaz": F_AXE yalnızca OR ile eklenir.
		int flags = CallLogic.F_AXE;
		for (int bit = 0; bit < 8; bit++) {
			flags |= (1 << bit);
			check((flags & CallLogic.F_AXE) != 0, "OR ile eklenen bayraklar F_AXE'yi düşürmez");
		}
	}

	/**
	 * Ritim simülasyonu: gerçek karar mantığıyla (kurma zarı, bekleme, oturum sınırı, uygunluk) oyuncu oyunu.
	 * Yürüyen bir oyuncu, gerçek gün/gece döngüsü; her 5 sn'de bir denetim; kurulan olay oyuncu bakınca (varsayım:
	 * kurulumdan sonra 20 sn içinde uygun yöne bakar) başlatılır. Ölçüler yazdırılır ve makul aralıkla doğrulanır.
	 */
	static void pacing() {
		int trials = 400;
		long horizon = 3L * 72000L; // 3 saat oyun
		int sawIn1h = 0;
		int sawIn3h = 0;
		double totalFirst = 0;
		int counted = 0;
		double totalOmens = 0;
		int[] perKind = new int[OmenKind.COUNT];
		long minGapSeen = Long.MAX_VALUE;
		SplittableRandom r = new SplittableRandom(2026);
		for (int t = 0; t < trials; t++) {
			long now = OmenConfig.MIN_WORLD_AGE_TICKS + 10; // oyuncu zaten 1 oyun günü yaşlı bir dünyada oturuma girer
			long start = now;
			long lastOmen = 0;
			int lastKind = -1;
			int seen = 0;
			int omens = 0;
			double travel = 0;
			long first = -1;
			int progress = r.nextInt(3);
			long dayTime = r.nextInt(24000);
			long prev = -1;
			for (long tick = 0; tick < horizon; tick += OmenConfig.CHECK_INTERVAL_TICKS) {
				now = start + tick;
				long dt = dayTime + tick;
				travel += 12.0; // 5 sn'de ~12 blok (yarı zaman yürür, yarı durur)
				if (!OmenLogic.mayArm(now, start, now, omens, lastOmen, 0, 0, 0)) {
					continue;
				}
				int tone = OmenLogic.toneOf(dt);
				if (r.nextDouble() >= OmenLogic.chance(progress, lastOmen > 0 ? now - lastOmen : now - start) * OmenLogic.toneChanceMultiplier(tone)) {
					continue;
				}
				int mask = OmenLogic.eligibleMask(env(true, r.nextDouble() < 0.9, r.nextDouble() < 0.12, tone, travel));
				OmenKind k = OmenLogic.choose(r, mask, progress, seen, lastKind);
				if (k == null) {
					continue;
				}
				// Oyuncu uygun yöne bakar (kurulumdan sonra ~10 sn) ve olay başlar.
				long launch = now + 200;
				if (prev >= 0) {
					minGapSeen = Math.min(minGapSeen, launch - prev);
				}
				prev = launch;
				omens++;
				perKind[k.id()]++;
				lastOmen = launch;
				lastKind = k.id();
				seen |= k.bit();
				travel = 0;
				if (first < 0) {
					first = launch - start;
				}
				tick += OmenLogic.duration(r, k);
			}
			totalOmens += omens;
			if (first >= 0) {
				if (first <= 72000L) {
					sawIn1h++;
				}
				sawIn3h++;
				totalFirst += first;
				counted++;
			}
		}
		double firstMin = counted == 0 ? -1 : totalFirst / counted / 1200.0;
		System.out.printf("ritim: 3 saatlik oyunda ortalama %.2f olay; ilk olaya ortalama %.1f dk; 1 saatte görme %.0f%%, 3 saatte %.0f%%%n",
				totalOmens / trials, firstMin, 100.0 * sawIn1h / trials, 100.0 * sawIn3h / trials);
		System.out.printf("ritim: türler SKY_AXE=%d EYE=%d COLOSSUS=%d STRUCTURE=%d; en kısa olay aralığı %.1f dk%n",
				perKind[0], perKind[1], perKind[2], perKind[3], minGapSeen / 1200.0);
		check(sawIn3h >= trials * 0.9, "3 saatlik oyunda olayların çoğu en az bir kez görülür");
		check(sawIn1h >= trials * 0.35, "ilk saatte de görülebilir (test edilebilir sıklık)");
		check(sawIn1h <= trials * 0.97, "ama kesin değildir (seyrek)");
		check(totalOmens / trials <= 2.0 * 3, "oturum sınırı aşılmaz (3 saatte en fazla 2 olay/oturum, burada tek oturum)");
		check(totalOmens / trials <= OmenConfig.PER_SESSION + 1e-9, "tek oturumda PER_SESSION'dan fazla olay yok");
		check(minGapSeen >= OmenConfig.MIN_GAP_TICKS, "iki olay arası bekleme korunur");
		for (OmenKind k : OmenKind.values()) {
			if (!k.legacy()) {
				continue; // yeni anomaliler ayrı maskeyle (anomalyMask) seçilir; AnomalyLogicTest kapsar
			}
			check(perKind[k.id()] > 0, "simülasyonda her tür görüldü " + k);
		}
	}
}
