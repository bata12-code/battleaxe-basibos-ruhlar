import java.util.Random;

import com.battleaxe.chain.ChainConfig;
import com.battleaxe.chain.ChainHudMath;
import com.battleaxe.chain.ChainLogic;
import com.battleaxe.chain.ChainState;

/** Minecraft gerektirmeyen Kıyım Zinciri testleri. Çalıştırma: tools/test/run_tests.sh */
public final class ChainLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) {
		// Yapılandırma tutarlılığı
		int tiers = ChainConfig.TIER_THRESHOLDS.length;
		check(tiers == 4 && ChainLogic.MAX_TIER == 4, "4 kademe");
		check(ChainConfig.DAMAGE_BONUS.length == tiers + 1 && ChainConfig.SPEED_BONUS.length == tiers + 1, "bonus tabloları kademe+1 uzunlukta");
		for (int i = 1; i < tiers; i++) {
			check(ChainConfig.TIER_THRESHOLDS[i] > ChainConfig.TIER_THRESHOLDS[i - 1], "eşikler artan");
		}
		for (int t = 1; t <= tiers; t++) {
			check(ChainConfig.DAMAGE_BONUS[t] > ChainConfig.DAMAGE_BONUS[t - 1], "hasar bonusu artar t" + t);
			check(ChainConfig.SPEED_BONUS[t] > ChainConfig.SPEED_BONUS[t - 1], "hız bonusu artar t" + t);
		}
		check(ChainConfig.DAMAGE_BONUS[0] == 0.0 && ChainConfig.SPEED_BONUS[0] == 0.0, "kademe 0 bonussuz");
		check(ChainConfig.DAMAGE_BONUS[tiers] <= 2.5, "hasar bonusu küçük (denge)");
		check(ChainConfig.SPEED_BONUS[tiers] <= 0.2, "hız bonusu küçük (denge)");
		check(ChainConfig.BASE_WINDOW_TICKS >= 40, "pencere en az 2 sn");

		// Kademe sınırları
		check(ChainLogic.tierOf(0) == 0 && ChainLogic.tierOf(2) == 0, "2 -> kademe 0");
		check(ChainLogic.tierOf(3) == 1 && ChainLogic.tierOf(5) == 1, "3-5 -> kademe 1");
		check(ChainLogic.tierOf(6) == 2 && ChainLogic.tierOf(9) == 2, "6-9 -> kademe 2");
		check(ChainLogic.tierOf(10) == 3 && ChainLogic.tierOf(14) == 3, "10-14 -> kademe 3");
		check(ChainLogic.tierOf(15) == 4 && ChainLogic.tierOf(99) == 4, "15+ -> kademe 4");
		check(ChainLogic.tierOf(-5) == 0, "negatif -> 0");

		// Pencere kademeyle uzar; aralık dışı kademe sınırlanır
		check(ChainLogic.windowFor(0) == 100 && ChainLogic.windowFor(4) == 180, "pencere 100 -> 180");
		check(ChainLogic.windowFor(-3) == ChainLogic.windowFor(0) && ChainLogic.windowFor(99) == ChainLogic.windowFor(4), "pencere sınırlı");

		// Canlılık
		check(!ChainLogic.alive(0, 10L, 11L), "sayaç 0 -> canlı değil");
		check(!ChainLogic.alive(ChainState.NONE, 5L), "NONE canlı değil");
		check(ChainLogic.alive(2, 1000L, 1100L), "tam pencere sınırında canlı");
		check(!ChainLogic.alive(2, 1000L, 1101L), "pencere aşıldı");
		check(ChainLogic.alive(6, 1000L, 1140L), "kademe 2 penceresi 140");
		check(!ChainLogic.alive(6, 1000L, 1141L), "kademe 2 penceresi aşıldı");
		check(!ChainLogic.alive(5, 1000L, 900L), "zaman geriye gitti -> canlı sayılmaz (takılı kalmaz)");
		check(!ChainLogic.alive(5, -1L, 10L), "son öldürme yok -> canlı değil");

		// İlerleme
		check(ChainLogic.advance(0, -1L, 50L, 1) == 1, "ilk öldürme 1");
		check(ChainLogic.advance(2, 100L, 150L, 1) == 3, "canlı zincire eklenir");
		check(ChainLogic.advance(2, 100L, 250L, 1) == 1, "kopmuş zincir yeniden başlar");
		check(ChainLogic.advance(2, 100L, 150L, 3) == 5, "boss 3 sayılır");
		check(ChainLogic.advance(2, 100L, 150L, 0) == 3 && ChainLogic.advance(2, 100L, 150L, -4) == 3, "ağırlık en az 1");
		check(ChainLogic.advance(98, 100L, 101L, 3) == ChainConfig.MAX_COUNT, "üst sınır");
		check(ChainLogic.advance(ChainConfig.MAX_COUNT, 100L, 101L, 1) == ChainConfig.MAX_COUNT, "üst sınırda taşmaz");
		check(ChainLogic.advance(Integer.MAX_VALUE, 100L, 101L, 3) == ChainConfig.MAX_COUNT, "int taşması sınırlanır");

		// Ağırlık
		check(ChainLogic.weight(20.0F) == 1 && ChainLogic.weight(39.9F) == 1, "küçük mob 1");
		check(ChainLogic.weight(40.0F) == 2 && ChainLogic.weight(149.0F) == 2, "orta mob 2");
		check(ChainLogic.weight(150.0F) == 3 && ChainLogic.weight(300.0F) == 3, "boss 3");
		check(ChainLogic.weight(0.0F) == 1 && ChainLogic.weight(-1.0F) == 1 && ChainLogic.weight(Float.NaN) == 1, "geçersiz can 1");

		// Kademe atlama
		check(ChainLogic.isTierUp(2, 3), "2->3 kademe atlar");
		check(!ChainLogic.isTierUp(3, 4), "3->4 aynı kademe");
		check(ChainLogic.isTierUp(5, 10), "5->10 (iki kademe) atlar");
		check(!ChainLogic.isTierUp(0, 1), "0->1 atlamaz");
		check(!ChainLogic.isTierUp(10, 1), "azalma atlama değil");

		// Süre çubuğu
		check(ChainLogic.barCells(1000L, 1000L, 100, 10) == 10, "yeni öldürme çubuk dolu");
		check(ChainLogic.barCells(1050L, 1000L, 100, 10) == 5, "yarı süre yarı çubuk");
		check(ChainLogic.barCells(1099L, 1000L, 100, 10) == 1, "bitmeden en az 1 hücre");
		check(ChainLogic.barCells(1100L, 1000L, 100, 10) == 1, "pencerenin son tickinde zincir canlı: çubuk 1 hücre");
		check(ChainLogic.barCells(1101L, 1000L, 100, 10) == 0, "süre bitti -> 0");
		check(ChainLogic.barCells(10L, 1000L, 100, 10) == 0 && ChainLogic.barCells(5L, -1L, 100, 10) == 0 && ChainLogic.barCells(5L, 5L, 0, 10) == 0, "geçersiz girdi 0");
		check(ChainLogic.barText(3, 10).equals("|||......."), "çubuk metni");
		check(ChainLogic.barText(-2, 4).equals("....") && ChainLogic.barText(99, 4).equals("||||"), "çubuk metni sınırlı");
		check(ChainLogic.barText(3, 10).length() == 10, "çubuk uzunluğu sabit");

		// Çubuk ile canlılık aynı sınırı paylaşır
		for (long n = 1000L; n < 1300L; n++) {
			boolean al = ChainLogic.alive(6, 1000L, n);
			int cells = ChainLogic.barCells(n, 1000L, ChainLogic.windowFor(ChainLogic.tierOf(6)), 10);
			check(al == (cells > 0), "çubuk>0 <=> zincir canlı (n=" + n + ")");
		}

		// Aura geometrisi
		check(ChainLogic.orbiterCount(0) == 0 && ChainLogic.orbiterCount(1) == 2 && ChainLogic.orbiterCount(4) == 5, "dönen nokta sayısı");
		check(ChainLogic.orbitRadius(4) > ChainLogic.orbitRadius(0), "yarıçap büyür");
		for (int tier = 1; tier <= 4; tier++) {
			int n = ChainLogic.orbiterCount(tier);
			double r = ChainLogic.orbitRadius(tier);
			for (long tick = 0; tick < 400; tick += 7) {
				for (int i = 0; i < n; i++) {
					double a = ChainLogic.orbitAngle(tick, tier, i, n);
					double x = ChainLogic.orbitX(a, r);
					double z = ChainLogic.orbitZ(a, r);
					check(Math.abs(Math.hypot(x, z) - r) < 1.0E-9, "nokta yarıçapta kalır");
					double lift = ChainLogic.orbitLift(tick, i);
					check(lift >= -1.0E-9 && lift <= 0.5 + 1.0E-9, "yükselme 0..0.5");
				}
			}
			// Noktalar eşit aralıklı (komşu açı farkı 2π/n)
			double d = ChainLogic.orbitAngle(10L, tier, 1, n) - ChainLogic.orbitAngle(10L, tier, 0, n);
			check(Math.abs(d - 2.0 * Math.PI / n) < 1.0E-9, "eşit aralıklı noktalar");
		}
		check(ChainLogic.orbitAngle(10L, 4, 0, 5) > ChainLogic.orbitAngle(10L, 1, 0, 5), "yüksek kademe daha hızlı döner");
		check(ChainLogic.orbitAngle(10L, 1, 0, 0) == ChainLogic.orbitAngle(10L, 1, 3, 0), "total 0 bölme hatası vermez");

		// Sonraki kademeye ilerleme
		check(ChainLogic.nextThreshold(0) == 3 && ChainLogic.nextThreshold(3) == 6 && ChainLogic.nextThreshold(9) == 10, "sonraki eşik");
		check(ChainLogic.nextThreshold(15) == 0 && ChainLogic.nextThreshold(99) == 0, "en üst kademede sonraki eşik yok");
		check(ChainLogic.tierProgress(0) == 0.0F && Math.abs(ChainLogic.tierProgress(1) - 1.0F / 3.0F) < 1.0E-6F, "kademe 0 ilerleme");
		check(ChainLogic.tierProgress(3) == 0.0F, "kademe başında ilerleme 0");
		check(Math.abs(ChainLogic.tierProgress(5) - 2.0F / 3.0F) < 1.0E-6F, "3-6 arası ilerleme");
		check(ChainLogic.tierProgress(15) == 1.0F && ChainLogic.tierProgress(99) == 1.0F, "en üst kademede ilerleme 1");
		float prevProgress = -1.0F;
		int prevTierForProgress = 0;
		for (int c = 0; c <= 30; c++) {
			float pr = ChainLogic.tierProgress(c);
			check(pr >= 0.0F && pr <= 1.0F, "ilerleme 0-1 c=" + c);
			int tr = ChainLogic.tierOf(c);
			if (tr == prevTierForProgress && tr < ChainLogic.MAX_TIER) {
				check(pr >= prevProgress, "kademe içinde ilerleme azalmaz c=" + c);
			}
			prevProgress = pr;
			prevTierForProgress = tr;
		}

		// HUD animasyon matematiği
		check(ChainHudMath.killPulse(-5L) == 1.0F && ChainHudMath.killPulse(ChainHudMath.PULSE_MS) == 1.0F && ChainHudMath.killPulse(10_000L) == 1.0F, "vuruş süre dışında 1");
		check(Math.abs(ChainHudMath.killPulse(0L) - ChainHudMath.PULSE_PEAK) < 1.0E-6F, "vuruş başında tepe");
		for (long ms = 1; ms < ChainHudMath.PULSE_MS; ms++) {
			check(ChainHudMath.killPulse(ms) <= ChainHudMath.killPulse(ms - 1) + 1.0E-6F, "vuruş ölçeği azalır ms=" + ms);
			check(ChainHudMath.killPulse(ms) >= 1.0F, "vuruş ölçeği en az 1");
		}
		check(ChainHudMath.tierUpGlow(0L) == 1.0F && ChainHudMath.tierUpGlow(ChainHudMath.GLOW_MS) == 0.0F && ChainHudMath.tierUpGlow(-1L) == 0.0F, "ışıma 1 -> 0");
		check(ChainHudMath.bannerAlpha(-1L) == 0.0F && ChainHudMath.bannerAlpha(0L) == 0.0F && ChainHudMath.bannerAlpha(100L) == 1.0F, "başlık saydamlığı belirir");
		check(ChainHudMath.bannerAlpha(400L) == 1.0F && ChainHudMath.bannerAlpha(699L) == 1.0F, "başlık kısa süre tam görünür");
		check(ChainHudMath.bannerAlpha(ChainHudMath.BANNER_MS) == 0.0F && ChainHudMath.bannerAlpha(99_999L) == 0.0F, "başlık söner");
		for (long ms = -50; ms < ChainHudMath.BANNER_MS + 50; ms++) {
			float a = ChainHudMath.bannerAlpha(ms);
			check(a >= 0.0F && a <= 1.0F, "başlık saydamlığı 0-1 ms=" + ms);
			float sc = ChainHudMath.bannerScale(ms);
			check(sc >= 1.1F - 1.0E-6F && sc <= 1.5F + 1.0E-6F, "başlık ölçeği 1.1-1.5 ms=" + ms);
		}
		check(ChainHudMath.bannerScale(0L) > ChainHudMath.bannerScale(900L), "başlık yerine oturur");
		// Kalıcı gösterge göz yormasın: sönükleşme
		check(ChainHudMath.BANNER_MS <= 1200L && ChainHudMath.GLOW_MS <= 800L, "başlık ve ışıma kısa");
		check(ChainHudMath.hudAlpha(0L, 1.0F, 99_999L) == 1.0F && ChainHudMath.hudAlpha(ChainHudMath.IDLE_HOLD_MS - 1, 1.0F, 99_999L) == 1.0F, "öldürmeden sonra bir süre tam parlak");
		check(ChainHudMath.hudAlpha(ChainHudMath.IDLE_HOLD_MS + ChainHudMath.IDLE_FADE_MS, 1.0F, 99_999L) == ChainHudMath.IDLE_MIN_ALPHA, "bekleyince en düşük saydamlığa iner");
		check(ChainHudMath.hudAlpha(1_000_000L, 1.0F, 99_999L) == ChainHudMath.IDLE_MIN_ALPHA, "çok bekleyince sabit kalır");
		check(ChainHudMath.IDLE_MIN_ALPHA >= 0.4F, "gösterge hiç kaybolmaz");
		check(ChainHudMath.hudAlpha(1_000_000L, 0.2F, 99_999L) == 1.0F, "süre azalınca yeniden parlar");
		check(ChainHudMath.hudAlpha(1_000_000L, 1.0F, 100L) == 1.0F, "kademe atlayınca yeniden parlar");
		check(ChainHudMath.hudAlpha(1_000_000L, 1.0F, ChainHudMath.BANNER_MS) == ChainHudMath.IDLE_MIN_ALPHA, "kademe parlaması biter");
		float prevAlpha = 1.0F;
		for (long ms = 0; ms < 4000; ms += 5) {
			float al = ChainHudMath.hudAlpha(ms, 1.0F, 99_999L);
			check(al <= prevAlpha + 1.0E-6F && al >= ChainHudMath.IDLE_MIN_ALPHA - 1.0E-6F && al <= 1.0F, "sönükleşme tekdüze ve sınırlı ms=" + ms);
			prevAlpha = al;
		}
		check(ChainHudMath.shatterProgress(-3L) == 0.0F && ChainHudMath.shatterProgress(ChainHudMath.SHATTER_MS) == 1.0F && ChainHudMath.shatterProgress(1_000_000L) == 1.0F, "parçalanma 0 -> 1");
		check(ChainHudMath.barRatio(500L, 10) == 1.0F && ChainHudMath.barRatio(250L, 10) == 0.5F && ChainHudMath.barRatio(0L, 10) == 0.0F, "çubuk oranı");
		check(ChainHudMath.barRatio(-5L, 10) == 0.0F && ChainHudMath.barRatio(99_999L, 10) == 1.0F && ChainHudMath.barRatio(100L, 0) == 0.0F, "çubuk oranı sınırlı");
		check(ChainHudMath.lowTimeFlash(1234L, 0.5F) == 0.0F && ChainHudMath.lowTimeFlash(1234L, 0.25F) == 0.0F, "süre çoksa uyarı yok");
		for (long ms = 0; ms < 2000; ms += 13) {
			float f = ChainHudMath.lowTimeFlash(ms, 0.1F);
			check(f >= 0.0F && f <= 1.0F, "uyarı 0-1 ms=" + ms);
		}
		check(ChainHudMath.clamp01(Float.NaN) == 0.0F && ChainHudMath.clamp01(-2.0F) == 0.0F && ChainHudMath.clamp01(7.0F) == 1.0F, "clamp01 NaN ve sınırlar");
		check(ChainHudMath.easeOut(0.0F) == 0.0F && ChainHudMath.easeOut(1.0F) == 1.0F && ChainHudMath.easeOut(0.5F) > 0.5F, "easeOut hızlı başlar");
		check(ChainHudMath.easeOut(-1.0F) == 0.0F && ChainHudMath.easeOut(5.0F) == 1.0F, "easeOut sınırlı");
		// Kırıklar
		java.util.Set<Long> shardEnds = new java.util.HashSet<>();
		for (int i = 0; i < ChainHudMath.SHARDS; i++) {
			check(ChainHudMath.shardDx(i, 0.0F) == 0.0F, "kırık başta merkezde dx i=" + i);
			check(ChainHudMath.shardDy(i, 0.0F) == 0.0F, "kırık başta merkezde dy i=" + i);
			check(ChainHudMath.shardSize(i) >= 2 && ChainHudMath.shardSize(i) <= 4, "kırık boyutu 2-4 i=" + i);
			float prev = ChainHudMath.shardAlpha(0.0F);
			check(prev == 1.0F, "kırık başta opak");
			float dist = 0.0F;
			for (int k = 1; k <= 20; k++) {
				float t = k / 20.0F;
				float dx = ChainHudMath.shardDx(i, t);
				float dy = ChainHudMath.shardDy(i, t);
				check(!Float.isNaN(dx) && !Float.isNaN(dy) && Math.abs(dx) < 60.0F && Math.abs(dy) < 90.0F, "kırık makul mesafede i=" + i + " t=" + t);
				float a = ChainHudMath.shardAlpha(t);
				check(a <= prev + 1.0E-6F && a >= 0.0F, "kırık saydamlığı azalır i=" + i);
				prev = a;
				dist = Math.max(dist, (float) Math.hypot(dx, dy));
			}
			check(ChainHudMath.shardAlpha(1.0F) == 0.0F, "kırık sonda görünmez");
			check(dist > 10.0F, "kırık yeterince dağılır i=" + i);
			shardEnds.add(((long) Math.round(ChainHudMath.shardDx(i, 1.0F) * 100.0F) << 32) ^ Math.round(ChainHudMath.shardDy(i, 1.0F) * 100.0F));
		}
		check(shardEnds.size() == ChainHudMath.SHARDS, "her kırık farklı yöne gider");
		check(ChainHudMath.shardSize(-1) >= 2 && ChainHudMath.shardSize(-1) <= 4, "negatif indeks boyutu geçerli");

		// Renkler 0xRRGGBB
		for (int t = -2; t <= 7; t++) {
			check((ChainLogic.dustStart(t) & 0xFF000000) == 0 && (ChainLogic.dustEnd(t) & 0xFF000000) == 0, "renk alfa kanalsız t" + t);
		}
		check(ChainLogic.dustStart(2) != ChainLogic.dustStart(3), "kademeler farklı renkte");
		check(ChainLogic.damageBonus(99) == ChainConfig.DAMAGE_BONUS[4] && ChainLogic.damageBonus(-1) == 0.0, "bonus sorguları sınırlı");
		check(ChainLogic.speedBonus(99) == ChainConfig.SPEED_BONUS[4] && ChainLogic.speedBonus(-1) == 0.0, "hız sorguları sınırlı");

		// Kalan süre
		check(ChainLogic.remainingTicks(2, 1000L, 1000L) == 100 && ChainLogic.remainingTicks(2, 1000L, 1040L) == 60, "kalan süre");
		check(ChainLogic.remainingTicks(2, 1000L, 1100L) == 0 && ChainLogic.remainingTicks(2, 1000L, 1101L) == 0, "süre bitince 0");
		check(ChainLogic.remainingTicks(0, 1000L, 1000L) == 0 && ChainLogic.remainingTicks(5, -1L, 10L) == 0 && ChainLogic.remainingTicks(5, 1000L, 900L) == 0, "geçersiz zincir 0");
		check(ChainLogic.remainingTicks(15, 1000L, 1000L) == 180, "kademe 4 kalan süre 180");

		// Shunpo uzatması: pencereyi aşmaz, kopmuşu uzatmaz
		check(ChainLogic.extendedLastKill(1060L, 1000L, 100, 40) == 1040L, "kalan 40 + 40 = 80 (son öldürme 1040'a çekilir)");
		check(ChainLogic.remainingTicks(2, ChainLogic.extendedLastKill(1060L, 1000L, 100, 40), 1060L) == 80, "uzatınca kalan süre 80");
		check(ChainLogic.remainingTicks(2, ChainLogic.extendedLastKill(1010L, 1000L, 100, 40), 1010L) == 100, "pencere aşılmaz");
		check(ChainLogic.extendedLastKill(1000L, 1000L, 100, 40) == 1000L, "dolu zincir değişmez");
		check(ChainLogic.extendedLastKill(1101L, 1000L, 100, 40) == 1000L, "kopmuş zincir uzatılamaz");
		check(ChainLogic.extendedLastKill(900L, 1000L, 100, 40) == 1000L && ChainLogic.extendedLastKill(10L, -1L, 100, 40) == -1L, "geçersiz zaman uzatılmaz");
		check(ChainLogic.extendedLastKill(1060L, 1000L, 100, 0) == 1000L && ChainLogic.extendedLastKill(1060L, 1000L, 0, 40) == 1000L, "bonus/pencere 0 değişmez");
		check(ChainLogic.remainingTicks(2, ChainLogic.extendedLastKill(1100L, 1000L, 100, 40), 1100L) == 40, "son tickte bile uzatılabilir");

		// Hasar cezası: sınırlı, orantılı, güvenli
		check(ChainLogic.penaltyTicks(0.0F) == 0 && ChainLogic.penaltyTicks(-4.0F) == 0 && ChainLogic.penaltyTicks(Float.NaN) == 0, "geçersiz hasar ceza yok");
		check(ChainLogic.penaltyTicks(1.0F) == 8 && ChainLogic.penaltyTicks(3.0F) == 24, "hasar x 8 tick");
		check(ChainLogic.penaltyTicks(1000.0F) == ChainConfig.DAMAGE_PENALTY_MAX_TICKS && ChainLogic.penaltyTicks(Float.POSITIVE_INFINITY) == ChainConfig.DAMAGE_PENALTY_MAX_TICKS, "ceza üst sınırlı");
		check(ChainConfig.DAMAGE_PENALTY_MAX_TICKS < ChainConfig.BASE_WINDOW_TICKS, "tek vuruş zinciri en baştan bitiremez");
		check(ChainConfig.SHUNPO_EXTEND_TICKS > 0 && ChainConfig.SHUNPO_EXTEND_TICKS <= ChainConfig.BASE_WINDOW_TICKS, "uzatma makul");
		long pl = ChainLogic.penalizedLastKill(1000L, 24);
		check(pl == 976L && ChainLogic.remainingTicks(2, pl, 1040L) == 100 - 40 - 24, "ceza kalan süreyi kısaltır");
		check(ChainLogic.penalizedLastKill(5L, 80) == 0L && ChainLogic.penalizedLastKill(-1L, 80) == -1L && ChainLogic.penalizedLastKill(1000L, -9) == 1000L, "ceza zaman damgasını bozmaz");
		// Ceza + uzatma birlikte: rastgele dizilerde değişmezler
		Random rr = new Random(7);
		long nowF = 1_000L;
		int cntF = 8;
		long lastF = nowF;
		for (int i = 0; i < 20_000; i++) {
			nowF += rr.nextInt(12);
			if (!ChainLogic.alive(cntF, lastF, nowF)) {
				cntF = 8;
				lastF = nowF;
			}
			int before = ChainLogic.remainingTicks(cntF, lastF, nowF);
			int win = ChainLogic.windowFor(ChainLogic.tierOf(cntF));
			int action = rr.nextInt(3);
			if (action == 0) {
				lastF = ChainLogic.extendedLastKill(nowF, lastF, win, ChainConfig.SHUNPO_EXTEND_TICKS);
				int after = ChainLogic.remainingTicks(cntF, lastF, nowF);
				check(after >= before && after <= win, "uzatma kalan süreyi azaltmaz, pencereyi aşmaz");
			} else if (action == 1) {
				lastF = ChainLogic.penalizedLastKill(lastF, ChainLogic.penaltyTicks(rr.nextFloat() * 10.0F));
				int after = ChainLogic.remainingTicks(cntF, lastF, nowF);
				check(after <= before && lastF >= 0L, "ceza kalan süreyi artırmaz");
			}
		}

		// Deneme modu yayına kaçmamalı; kapalıyken katkı değişmez
		check(!ChainConfig.TEST_MODE, "TEST_MODE yayın sürümünde KAPALI olmalı");
		check(ChainLogic.effectiveWeight(1) == 1 && ChainLogic.effectiveWeight(3) == 3 && ChainLogic.effectiveWeight(0) == 1, "kapalıyken katkı aynı");
		check(ChainConfig.TEST_WEIGHT_FACTOR >= 1, "deneme çarpanı en az 1");
		// Deneme çarpanıyla (3) 5 öldürmede tüm kademeler tek tek görülür
		int tc = 0;
		long tl = -1L;
		int[] expectedTiers = {1, 2, 2, 3, 4};
		for (int k = 0; k < expectedTiers.length; k++) {
			long tn = 1000L + k * 20L;
			tc = ChainLogic.advance(tc, tl, tn, 3);
			tl = tn;
			check(ChainLogic.tierOf(tc) == expectedTiers[k], "çarpan 3 ile " + (k + 1) + ". öldürmede kademe " + expectedTiers[k]);
		}

		// Rastgele akış: değişmezler
		Random rnd = new Random(42);
		int count = 0;
		long last = -1L;
		long now = 0L;
		int ups = 0;
		for (int i = 0; i < 50_000; i++) {
			now += rnd.nextInt(20) == 0 ? 200 : rnd.nextInt(40); // arada zinciri koparan uzun boşluklar
			int before = ChainLogic.alive(count, last, now) ? count : 0;
			int after = ChainLogic.advance(count, last, now, 1 + rnd.nextInt(3));
			check(after >= 1 && after <= ChainConfig.MAX_COUNT, "sayaç 1..MAX");
			check(after >= before + 1 || after == ChainConfig.MAX_COUNT, "her öldürme en az +1");
			if (ChainLogic.isTierUp(before, after)) {
				ups++;
			}
			count = after;
			last = now;
		}
		check(ups > 100, "rastgele akışta kademe atlamaları görülür (" + ups + ")");

		if (failed == 0) {
			System.out.println("ChainLogicTest: tüm testler geçti.");
		} else {
			System.out.println("ChainLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
