import com.battleaxe.spirit.RuhYiyenConfig;
import com.battleaxe.spirit.SavrulmusConfig;
import com.battleaxe.spirit.SpiritConfig;
import com.battleaxe.spirit.SpiritLogic;
import com.battleaxe.spirit.ZincirliConfig;

/** Başıboş Ruhlar ortak saf mantık testleri: hasar ayarı, iyileşme sınırları, geometri. Çalıştırma: tools/test/run_tests.sh */
public final class SpiritLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static boolean near(double a, double b) {
		return Math.abs(a - b) < 1.0E-4;
	}

	public static void main(String[] args) {
		// ---- Gelen hasar
		check(near(SpiritLogic.incoming(10.0F, false, -1, false), 10.0), "normal silah: hasar aynen");
		check(near(SpiritLogic.incoming(10.0F, true, -1, false), 10.0 * (1.0 - SpiritConfig.PROJECTILE_RESISTANCE)), "ok/mermi: sınırlı direnç");
		check(SpiritLogic.incoming(10.0F, true, -1, false) > 5.0F, "mermi direnci normal silahları anlamsız yapmaz (>%50 geçer)");
		check(SpiritLogic.incoming(10.0F, false, 0, false) > 10.0F, "balta (rütbe 0) normal silahtan fazla keser");
		check(SpiritLogic.incoming(10.0F, true, 0, false) > 10.0F, "fırlatılan balta mermi direncine takılmaz");
		for (int r = 1; r <= 9; r++) {
			check(SpiritLogic.incoming(10.0F, false, r, false) > SpiritLogic.incoming(10.0F, false, r - 1, false), "rütbe artınca balta hasarı artar: " + r);
		}
		check(near(SpiritLogic.axeMultiplier(9), 1.0 + SpiritConfig.AXE_BONUS_BASE + 9 * SpiritConfig.AXE_BONUS_PER_RANK), "rütbe 9 çarpanı");
		check(near(SpiritLogic.axeMultiplier(99), SpiritLogic.axeMultiplier(9)), "rütbe 9'da sınırlanır");
		check(near(SpiritLogic.axeMultiplier(-1), 1.0), "balta değilse çarpan 1");
		check(near(SpiritLogic.incoming(10.0F, false, -1, true), 10.0 * (1.0 + SpiritConfig.EXPOSED_DAMAGE_BONUS)), "savunmasız: ek hasar");
		check(SpiritLogic.incoming(0.0F, true, 5, true) == 0.0F && SpiritLogic.incoming(-3.0F, false, -1, false) == 0.0F, "sıfır/negatif hasar güvenli");
		// Savunmasızlık + balta üst üste bile makul bir tavanda kalır (tek vuruşla oyun bozulmaz).
		check(SpiritLogic.incoming(16.0F, false, 9, true) < 16.0F * 1.6F, "balta + savunmasızlık makul sınırda");

		// ---- Ruh Emdirme iyileşmesi: sınırsız iyileşme yok
		float one = SpiritLogic.drainHeal(2.0F, false, 0.0F, 0.0F, 60.0F);
		check(near(one, 2.0 * RuhYiyenConfig.HEAL_FRACTION), "tek darbe: oranlı iyileşme");
		float hiddet = SpiritLogic.drainHeal(2.0F, true, 0.0F, 0.0F, 60.0F);
		check(near(hiddet, one * RuhYiyenConfig.HIDDET_HEAL_MULTIPLIER) && hiddet < one, "Hiddet'teki oyuncudan iyileşme azalır");
		float healedChannel = 0.0F;
		float healedTotal = 0.0F;
		int pulses = RuhYiyenConfig.DRAIN_CHANNEL_TICKS / RuhYiyenConfig.DRAIN_PULSE_INTERVAL_TICKS;
		for (int i = 0; i < pulses * 4; i++) { // bağ başına tavanı zorla
			float h = SpiritLogic.drainHeal(RuhYiyenConfig.DRAIN_PULSE_DAMAGE, false, healedChannel, healedTotal, 60.0F);
			healedChannel += h;
			healedTotal += h;
		}
		check(healedChannel <= RuhYiyenConfig.HEAL_CAP_PER_CHANNEL + 1.0E-4, "bağlantı başına iyileşme tavanı");
		float lifetime = 0.0F;
		for (int channel = 0; channel < 20; channel++) { // ömür boyu bütçeyi zorla
			float ch = 0.0F;
			for (int i = 0; i < pulses; i++) {
				float h = SpiritLogic.drainHeal(RuhYiyenConfig.DRAIN_PULSE_DAMAGE, false, ch, lifetime, 60.0F);
				ch += h;
				lifetime += h;
			}
		}
		check(lifetime <= 60.0 * RuhYiyenConfig.HEAL_BUDGET_RATIO + 1.0E-3, "ömür boyu iyileşme bütçesi (maks canın yarısı)");
		check(SpiritLogic.drainHeal(0.0F, false, 0.0F, 0.0F, 60.0F) == 0.0F && SpiritLogic.drainHeal(2.0F, false, 0.0F, 0.0F, 0.0F) == 0.0F, "geçersiz girdide iyileşme yok");
		// Bir bağlantının tam iyileşmesi ruhun canının küçük bir kesridir.
		check(RuhYiyenConfig.HEAL_CAP_PER_CHANNEL < RuhYiyenConfig.MAX_HEALTH * 0.25, "tek bağlantı canın %25'inden azını yeniler");
		// Bağlantı hasarı: tam bir bağ ancak makul miktarda hasar verir (acımasız ama adil)
		check(pulses * RuhYiyenConfig.DRAIN_PULSE_DAMAGE <= 16.0, "tam bağlantı toplam hasarı <= 16");
		check(RuhYiyenConfig.DRAIN_INTERRUPT_DAMAGE <= 16.0F, "tek balta vuruşu (16 hasar) bağı koparır");

		// ---- Geometri
		check(near(SpiritLogic.wrapAngle(Math.PI * 3), Math.PI), "wrapAngle 3PI -> PI");
		check(near(SpiritLogic.wrapAngle(-Math.PI * 2 - 0.5), -0.5), "wrapAngle -2PI-0.5");
		// Hedef güneye (yaw 0) bakıyorsa arkası -z yönündedir (atan2(z,x) = -PI/2).
		check(near(SpiritLogic.backAngle(0.0), -Math.PI / 2.0), "yaw 0 -> arka -z");
		check(near(SpiritLogic.backAngle(90.0), 0.0), "yaw 90 (batıya bakıyor) -> arka +x");
		check(SpiritLogic.shortestArcSign(0.0, 1.0) == 1 && SpiritLogic.shortestArcSign(0.0, -1.0) == -1, "en kısa yay yönü");
		check(SpiritLogic.shortestArcSign(3.0, -3.0) == 1, "en kısa yay sınırı aşar (3 -> -3 ileri)");
		double[] orbit = SpiritLogic.orbitPoint(5.0, 0.0, 0.0, 0.0, 3.0, 0.0);
		check(near(orbit[0], 3.0) && near(orbit[1], 0.0), "orbit: aynı açı, yarıçap 3");
		double[] orbit2 = SpiritLogic.orbitPoint(3.0, 0.0, 0.0, 0.0, 3.0, Math.PI / 2.0);
		check(near(orbit2[0], 0.0) && near(orbit2[1], 3.0), "orbit: çeyrek tur");
		double dist = Math.hypot(orbit2[0], orbit2[1]);
		check(near(dist, 3.0), "orbit yarıçapı korunur");
		check(near(SpiritLogic.angleAround(0.0, 2.0, 0.0, 0.0), Math.PI / 2.0), "angleAround");

		// Koni: yaw 0 -> ileri +z
		check(SpiritLogic.inCone(0.0, 3.0, 0.0, 75.0), "ileri koni içinde");
		check(!SpiritLogic.inCone(0.0, -3.0, 0.0, 75.0), "arka koni dışında");
		check(SpiritLogic.inCone(3.0, 3.0, 0.0, 75.0) && !SpiritLogic.inCone(3.0, -1.0, 0.0, 75.0), "açı sınırı");
		check(SpiritLogic.inCone(0.0, 0.0, 0.0, 75.0), "sıfır vektör içeride");
		check(SpiritLogic.inCone(-3.0, 0.0, 270.0, 10.0) || SpiritLogic.inCone(3.0, 0.0, 270.0, 10.0), "yaw 270 yatay yönü");

		// Şok halkası: adım kalınlıktan küçükse hiçbir mesafe atlanmaz (tünelleme yok)
		double step = ZincirliConfig.SLAM_RADIUS / ZincirliConfig.SLAM_STRIKE_TICKS;
		check(step < ZincirliConfig.SLAM_RING_THICKNESS, "halka adımı kalınlıktan küçük");
		for (double d = 0.0; d <= ZincirliConfig.SLAM_RADIUS; d += 0.05) {
			boolean reached = false;
			for (int t = 1; t <= ZincirliConfig.SLAM_STRIKE_TICKS; t++) {
				if (SpiritLogic.ringReaches(d, step * t, ZincirliConfig.SLAM_RING_THICKNESS)) {
					reached = true;
				}
			}
			check(reached, "halka mesafeye ulaşır: " + d);
			if (!reached) {
				break;
			}
		}

		// Sıçrayış hızı: sınırlı, mesafeyle artar; menzil sonunda aşırı hıza çıkmaz
		check(SpiritLogic.leapSpeed(0.5) == SavrulmusConfig.LEAP_MIN_SPEED, "sıçrayış hız alt sınırı");
		check(SpiritLogic.leapSpeed(100.0) == SavrulmusConfig.LEAP_MAX_SPEED, "sıçrayış hız üst sınırı");
		check(SpiritLogic.leapSpeed(8.0) > SpiritLogic.leapSpeed(5.0), "mesafe arttıkça hız artar");
		check(SpiritLogic.leapSpeed(SavrulmusConfig.LEAP_MAX_RANGE) <= SavrulmusConfig.LEAP_MAX_SPEED, "menzil sonunda hız sınırda");
		// Önden nişan: hız yoksa kayma yok; makul sınırlı
		check(SpiritLogic.leadTicks(10.0, RuhYiyenConfig.BOLT_SPEED, RuhYiyenConfig.BOLT_MAX_LEAD_TICKS, RuhYiyenConfig.BOLT_LEAD_FACTOR) > 0.0, "önden nişan > 0");
		check(SpiritLogic.leadTicks(100.0, 1.0, 18, 0.65) <= 18 * 0.65 + 1.0E-9, "önden nişan üst sınırı");
		check(SpiritLogic.leadTicks(10.0, 0.0, 18, 0.65) == 0.0, "hız 0 -> nişan kayması yok");
		check(RuhYiyenConfig.BOLT_LEAD_FACTOR < 1.0, "tahmin tam değil (kaçınılmaz olmasın)");

		if (failed == 0) {
			System.out.println("SpiritLogicTest: tüm testler geçti.");
		} else {
			System.out.println("SpiritLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
