package com.battleaxe.berserker;

/** Yalnızca test: ayarların histerezis kuralını denetler. Mod kaynağına dahil değildir. */
public final class BerserkerConfigProbe {
	public static boolean hysteresisOk() {
		return BerserkerConfig.DEACTIVATION_HEALTH_RATIO > BerserkerConfig.ACTIVATION_HEALTH_RATIO
				&& BerserkerConfig.ACTIVATION_HEALTH_RATIO == 0.50;
	}
}
