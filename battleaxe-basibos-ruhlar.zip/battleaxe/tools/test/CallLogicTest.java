import java.util.Random;

import com.battleaxe.call.CallConfig;
import com.battleaxe.call.CallLogic;
import com.battleaxe.call.CallMoon;

/** Minecraft gerektirmeyen Baltanın Çağrısı testleri. Çalıştırma: tools/test/run_tests.sh */
public final class CallLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static boolean near(double a, double b, double eps) {
		return Math.abs(a - b) <= eps;
	}

	public static void main(String[] args) {
		// ---- İlerleme ----
		check(CallLogic.progress(0) == 0, "ilerleme 0");
		check(CallLogic.progress(CallLogic.F_NETHER) == 1, "Nether = 1");
		check(CallLogic.progress(CallLogic.F_NETHER | CallLogic.F_WITHER_SEEN) == 2, "Wither görüldü = 2");
		check(CallLogic.progress(CallLogic.F_WITHER_DEFEATED) == 3, "Wither yenildi = 3");
		check(CallLogic.progress(CallLogic.F_STAR | CallLogic.F_NETHER) == 4, "Yıldız = 4");
		check(CallLogic.silenced(CallLogic.F_AXE) && !CallLogic.silenced(CallLogic.MILESTONE_MASK), "balta susturur");

		// ---- Dönüm noktaları ----
		check(CallLogic.pendingMilestone(0, 0) == 0, "bayrak yoksa dönüm noktası yok");
		check(CallLogic.pendingMilestone(CallLogic.F_NETHER, 0) == CallLogic.F_NETHER, "Nether dönüm noktası");
		int all = CallLogic.F_NETHER | CallLogic.F_WITHER_SEEN | CallLogic.F_WITHER_DEFEATED | CallLogic.F_STAR;
		check(CallLogic.pendingMilestone(all, 0) == CallLogic.F_STAR, "en yüksek aşama seçilir");
		int covered = CallLogic.milestonesCovered(CallLogic.F_STAR);
		check(covered == all, "yıldız mesajı alt aşamaları da kapsar");
		check(CallLogic.pendingMilestone(all, covered) == 0, "gösterilen dönüm noktası tekrar gelmez");
		check(CallLogic.milestonesCovered(CallLogic.F_WITHER_SEEN) == (CallLogic.F_NETHER | CallLogic.F_WITHER_SEEN), "Wither görüldü: Nether de kapsanır");
		check(CallLogic.milestoneNumber(CallLogic.F_NETHER) == 1 && CallLogic.milestoneNumber(CallLogic.F_STAR) == 4, "dönüm noktası numaraları 1..4");
		check(CallLogic.MILESTONE_COUNT == 4, "4 dönüm noktası");

		// ---- Tablo bütünlüğü ----
		check(CallLogic.TABLE.length <= 64, "tablo seenMask'a (64 bit) sığar");
		for (CallLogic.Entry e : CallLogic.TABLE) {
			check(e.minProgress() >= 0 && e.minProgress() <= 4, "minProgress aralığı: " + e.key());
			check(e.contexts() != 0, "bağlam boş değil: " + e.key());
		}

		// ---- Seçim ----
		Random rnd = new Random(42);
		// Fısıltılar ilerleme 0'da yalnızca fısıltı olmalı
		for (int i = 0; i < 500; i++) {
			int pick = CallLogic.choose(rnd, 0, CallLogic.C_ANY, 0L, -1, false);
			check(pick >= 0 && CallLogic.TABLE[pick].kind() == CallLogic.Kind.WHISPER, "ilerleme 0 yalnızca fısıltı");
		}
		// Bağlam: gece mesajı gündüz çıkmaz, Nether mesajı Overworld'de çıkmaz
		for (int i = 0; i < 800; i++) {
			int pick = CallLogic.choose(rnd, 0, CallLogic.C_ANY, 0L, -1, false);
			int ctx = CallLogic.TABLE[pick].contexts();
			check((ctx & CallLogic.C_ANY) != 0, "ANY bağlamında yalnızca ANY mesajlar");
		}
		// Gece bağlamı: gece mesajları gelebilir
		boolean sawNight = false;
		for (int i = 0; i < 800; i++) {
			int pick = CallLogic.choose(rnd, 0, CallLogic.context(false, false, true, false), 0L, -1, false);
			if ((CallLogic.TABLE[pick].contexts() & CallLogic.C_NIGHT) != 0) {
				sawNight = true;
			}
		}
		check(sawNight, "gece bağlamında gece mesajı çıkabilir");
		// Tanınma mesajları ilerleme yeterli olmadan çıkmaz
		for (int i = 0; i < 800; i++) {
			int pick = CallLogic.choose(rnd, 1, CallLogic.context(true, false, true, true), 0L, -1, false);
			check(CallLogic.TABLE[pick].minProgress() <= 1, "ilerleme 1'de ileri aşama mesajı çıkmaz");
		}
		// Yıldız aşamasında tanınma mesajları gelir
		boolean sawRecognition = false;
		for (int i = 0; i < 500; i++) {
			int pick = CallLogic.choose(rnd, 4, CallLogic.C_ANY, 0L, -1, false);
			if (CallLogic.TABLE[pick].kind() == CallLogic.Kind.RECOGNITION) {
				sawRecognition = true;
			}
		}
		check(sawRecognition, "ilerleme 4'te tanınma mesajı çıkar");
		// Aynı mesaj art arda gelmez
		for (int i = 0; i < 500; i++) {
			int pick = CallLogic.choose(rnd, 2, CallLogic.C_ANY, 0L, 3, false);
			check(pick != 3, "son mesaj tekrarlanmaz");
		}
		// Görülenler elenir; hepsi görüldüyse sessizlik (-1), tekrar izniyle tekrar
		long allSeen = 0L;
		for (int i = 0; i < CallLogic.TABLE.length; i++) {
			allSeen |= 1L << i;
		}
		check(CallLogic.choose(rnd, 4, CallLogic.context(true, true, true, true), allSeen, -1, false) == -1, "tümü görüldüyse sessizlik");
		check(CallLogic.choose(rnd, 4, CallLogic.context(true, true, true, true), allSeen, -1, true) >= 0, "tekrar izniyle seçilebilir");
		check(!CallLogic.hasUnseen(4, CallLogic.context(true, true, true, true), allSeen, -1), "hepsi görüldü: yeni mesaj yok");
		check(CallLogic.hasUnseen(0, CallLogic.C_ANY, 0L, -1), "hiçbiri görülmedi: yeni mesaj var");
		long reset = CallLogic.resetSeen(allSeen, 5);
		check(reset == (1L << 5), "tekrar sıfırlaması yalnızca seçilen mesajı bırakır");
		// Uygun mesaj kalmayınca bayrak dışı seçim hatasız: ilerleme 0, yalnızca DEEP, hepsi görülmüş
		check(CallLogic.choose(rnd, 0, CallLogic.C_UNDERGROUND | CallLogic.C_ANY, allSeen, -1, false) == -1, "görülmüşler elenir");

		// ---- Bekleme ----
		check(CallLogic.ready(100L, 0L, 1000L), "hiç olmadıysa hazır");
		check(!CallLogic.ready(1500L, 1000L, 1000L), "bekleme dolmadı");
		check(CallLogic.ready(2000L, 1000L, 1000L), "bekleme doldu (eşit)");
		check(CallLogic.ready(500L, 1000L, 1000L), "şimdi < son (veri taşınmış): takılmaz");
		check(CallLogic.messageChance(0) < CallLogic.messageChance(4), "ilerledikçe olasılık biraz artar");
		check(CallLogic.messageChance(99) == CallLogic.messageChance(4), "olasılık üst sınırı");
		check(CallLogic.moonDuration(4) > CallLogic.moonDuration(0), "silüet süresi ilerledikçe uzar");
		check(CallLogic.moonIntensity(0) == 0 && CallLogic.moonIntensity(2) == 1 && CallLogic.moonIntensity(3) == 2, "yoğunluk basamakları");

		// ---- Sessizlik oranı: 12 saatlik oyunda mesaj sayısı sınırlı ----
		// Her 200 tick'te bir denetim, 15 dk aralık, oturum sınırı 3: üst sınırı simüle et
		int shown = 0;
		long last = 0L;
		long now = CallConfig.INITIAL_QUIET_TICKS;
		Random sim = new Random(7);
		for (long t = now; t < 12L * 72000L; t += CallConfig.CHECK_INTERVAL_TICKS) {
			if (shown >= CallConfig.MESSAGES_PER_SESSION) {
				break;
			}
			if (CallLogic.ready(t, last, CallConfig.MESSAGE_MIN_GAP_TICKS) && sim.nextDouble() < CallLogic.messageChance(2)) {
				shown++;
				last = t;
			}
		}
		check(shown <= CallConfig.MESSAGES_PER_SESSION, "oturum sınırı aşılmaz");

		// ---- Ay geometrisi ----
		// Gün zamanı 6000 = öğlen: güneş tepede (ay tam altta), 18000 = gece yarısı: ay tepede
		check(near(CallMoon.celestialAngle(6000L), 0.0, 1e-9), "öğlen gök açısı 0");
		check(near(CallMoon.celestialAngle(18000L), 0.5, 1e-9), "gece yarısı gök açısı 0.5");
		check(near(CallMoon.moonElevationSin(CallMoon.celestialAngle(18000L)), 1.0, 1e-9), "gece yarısı ay tepede");
		check(CallMoon.moonElevationSin(CallMoon.celestialAngle(6000L)) < -0.99, "öğlen ay ufkun altında");
		check(CallMoon.moonElevationSin(CallMoon.celestialAngle(1000L)) < 0.0, "sabah ay yok");
		check(CallMoon.moonElevationSin(CallMoon.celestialAngle(15000L)) > CallConfig.MOON_MIN_ELEVATION_SIN, "gece 15000'de ay yeterince yüksek");
		check(CallMoon.moonElevationSin(CallMoon.celestialAngle(13000L)) < CallConfig.MOON_MIN_ELEVATION_SIN, "13000'de ay henüz alçak: işaret yok");
		// Ay doğudan doğar: gece başında +X
		double[] rising = CallMoon.moonDirection(CallMoon.celestialAngle(13500L));
		check(rising[0] > 0.0, "ay doğudan doğar (+X)");
		double[] setting = CallMoon.moonDirection(CallMoon.celestialAngle(22500L));
		check(setting[0] < 0.0, "ay batıdan batar (-X)");
		// Evreler
		check(CallMoon.moonPhase(0L) == 0 && CallMoon.moonPhase(24000L * 4) == 4 && CallMoon.moonPhase(24000L * 8) == 0, "ay evresi döngüsü");
		check(CallMoon.moonPhase(-24000L) == 7, "negatif gün zamanı güvenli");
		check(CallMoon.phaseVisible(0) && CallMoon.phaseVisible(7) && !CallMoon.phaseVisible(4) && !CallMoon.phaseVisible(3), "yeni ay/hilal görünmez sayılır");
		// Bakış ve izdüşüm: aya tam bakınca ekranın ortası
		double[] moon = CallMoon.moonDirection(CallMoon.celestialAngle(18000L)); // tepe
		double[] look = CallMoon.lookVector(0.0, -90.0); // yukarı bak
		check(near(CallMoon.angleBetweenDegrees(look, moon), 0.0, 0.01), "yukarı bakınca açı 0");
		double[] center = CallMoon.project(moon, 0.0, -90.0, 70.0, 800, 450);
		check(center != null && near(center[0], 400, 0.5) && near(center[1], 225, 0.5), "aya tam bakınca ekran ortası");
		// Doğuya bak (yaw 270 = -90), ay doğuda ufka yakın: merkeze yakın
		double[] eastDir = {1.0, 0.0, 0.0};
		double[] east = CallMoon.project(eastDir, -90.0, 0.0, 70.0, 800, 450);
		check(east != null && near(east[0], 400, 0.5) && near(east[1], 225, 0.5), "yaw -90 = doğu: doğu ekran ortasında");
		// Güneye bakarken (yaw 0) doğu SOLDA olmalı
		// Minecraft: yaw 0 = güney (+Z); güneye bakan oyuncunun SAĞI batıdır (-X), SOLU doğudur (+X).
		double[] towardEast = CallMoon.project(new double[] {Math.sin(0.3), 0.0, Math.cos(0.3)}, 0.0, 0.0, 70.0, 800, 450);
		check(towardEast != null && towardEast[0] < 400, "güneye bakarken doğuya (+X) kayan yön SOLDA");
		double[] towardWest = CallMoon.project(new double[] {Math.sin(-0.3), 0.0, Math.cos(-0.3)}, 0.0, 0.0, 70.0, 800, 450);
		check(towardWest != null && towardWest[0] > 400, "güneye bakarken batıya (-X) kayan yön SAĞDA");
		double[] westLook = CallMoon.lookVector(90.0, 0.0);
		check(near(westLook[0], -1.0, 1e-9), "yaw 90 = batı (-X)");
		// Yukarıdaki yön ekranın üstünde
		double[] above = CallMoon.project(new double[] {0.0, Math.sin(0.3), Math.cos(0.3)}, 0.0, 0.0, 70.0, 800, 450);
		check(above != null && above[1] < 225, "yukarı yön ekranın üstünde");
		// Arkadaki yön görünmez
		check(CallMoon.project(new double[] {0.0, 0.0, -1.0}, 0.0, 0.0, 70.0, 800, 450) == null, "arka yön null");
		// Yarıçap pikseli makul: 70 derece dikey FOV, 450 yükseklik -> ~ 0.09 * 321 ~ 29 px
		double r = CallMoon.MOON_RADIUS_TAN * center[2];
		check(r > 20 && r < 40, "ay yarıçapı piksel (" + r + ")");
		// Bakış açısı sınırı
		check(CallMoon.angleBetweenDegrees(CallMoon.lookVector(0.0, 0.0), CallMoon.lookVector(0.0, -30.0)) > CallConfig.MOON_GAZE_DEGREES, "30 derece sapma bakış sayılmaz");

		if (failed == 0) {
			System.out.println("CallLogicTest: tüm testler geçti.");
		} else {
			System.out.println("CallLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
