import com.battleaxe.nexus.*;
import java.util.*;

/** Minecraft gerektirmeyen Ruh Ağı çekirdek testleri. Çalıştırma: tools/test/run_tests.sh */
public class NexusLogicTest {
	static int fails = 0;
	static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("BAŞARISIZ: " + msg); } }

	public static void main(String[] a) {
		// Tablo
		check(NexusTree.all().size() == 100, "100 düğüm");
		check(NexusTree.validate().isEmpty(), "ağ geçerli: " + NexusTree.validate());
		Set<Stat> used = EnumSet.noneOf(Stat.class);
		for (NodeDef n : NexusTree.all()) for (Effect e : n.effects()) used.add(e.stat());
		check(used.equals(EnumSet.allOf(Stat.class)), "her Stat en az bir düğümde kullanılıyor, fark: " + diff(used));
		int pts = 0, xp = 0;
		for (NodeDef n : NexusTree.all()) { pts += n.type().points; xp += n.type().xpPoints(); }
		check(pts == 175 && pts == NexusConfig.MAX_POINTS, "toplam puan 175 = MAX_POINTS: " + pts);

		// Açıklamalar dürüst kalsın: tüm ağdaki HAM toplam hiçbir etkinin sınırını aşmasın (aşarsa metin fazla vaat eder).
		double[] raw = new double[Stat.values().length];
		for (NodeDef n : NexusTree.all()) for (Effect e : n.effects()) if (e.stat().kind == Stat.Kind.SUM) raw[e.stat().ordinal()] += e.value();
		for (Stat st : Stat.values()) if (st.kind == Stat.Kind.SUM && st.min >= 0) check(raw[st.ordinal()] <= st.max + 1e-9, "ham toplam sınırı aşıyor: " + st + " " + raw[st.ordinal()] + " > " + st.max);

		// Roller ve önkoşullar
		int synergy = 0;
		for (NodeDef n : NexusTree.all()) {
			if (n.role() == NodeRole.SYNERGY) { synergy++; check(n.requires().length == 1 && NexusTree.get(n.requires()[0]).branch() != n.branch(), "sinerji önkoşulu başka daldan: " + n.id()); }
			else check(n.requires().length == 0, "yalnızca sinerji önkoşul ister: " + n.id());
			check((n.role() == NodeRole.MAJOR) == (n.type() == NodeType.LARGE || n.type() == NodeType.CAPSTONE), "büyük rol = büyük/dal sonu tür: " + n.id());
		}
		check(synergy == 10, "10 sinerji düğümü (dal başına 2): " + synergy);

		// Ekonomi: puan başına ruh eşiği eskisinin ~%75'i; büyük düğümün ruh karşılığı eskisinden ucuz değil
		check(NexusMath.thresholdForPoint(1) == 15 && NexusMath.thresholdForPoint(100) == 15000, "yeni eşikler");
		for (int n = 1; n <= 175; n++) check(NexusMath.thresholdForPoint(n) <= Math.ceil(20.0 * Math.pow(n, 1.5)) * 0.76 + 1, "eşik ~%25 daha ucuz " + n);
		check(NexusConfig.COST_LARGE * 15.0 >= 3 * 20.0 * 0.98, "büyük düğüm ruh karşılığı korunur");

		// Tam ağ istatistikleri sınır içinde
		NexusStats all = NexusStats.compute(NexusTree.all());
		for (Stat s : Stat.values()) if (s.kind == Stat.Kind.SUM) check(all.get(s) >= s.min && all.get(s) <= s.max, "sınır " + s);
		System.out.printf("Tüm ağ: hasar%%=%.0f kritikŞans=%.0f kritikHasar=%.0f DR=%.0f bekleme=-%.0f ruh=+%.0f%n",
			all.get(Stat.DAMAGE_PCT), all.get(Stat.CRIT_CHANCE_PCT), all.get(Stat.CRIT_DAMAGE_PCT),
			all.get(Stat.DAMAGE_REDUCTION_PCT), all.get(Stat.CLEAVE_COOLDOWN_PCT), all.get(Stat.SOUL_GAIN_PCT));

		// XP matematiği (vanilla değerleri)
		check(NexusMath.levelsToPoints(5) == 55, "5 seviye=55");
		check(NexusMath.levelsToPoints(15) == 315, "15 seviye=315");
		check(NexusMath.levelsToPoints(30) == 1395, "30 seviye=1395");
		check(NexusMath.levelsToPoints(40) == 2920, "40 seviye=2920");
		for (int l = 0; l < 60; l++) {
			long sum = 0; for (int i = 0; i < l; i++) sum += NexusMath.xpNeededForNextLevel(i);
			check(sum == NexusMath.levelsToPoints(l), "seviye toplamı tutarlı " + l);
		}
		check(NexusMath.playerPoints(10, 0.5F) == 160 + 14, "playerPoints " + NexusMath.playerPoints(10, 0.5F));

		// Puan eşikleri: monoton, tekrar kazanılmaz
		int prev = 0;
		for (long s = 0; s <= 60000; s += 7) {
			int p = NexusMath.pointsForLifetime(s);
			check(p >= prev, "monoton"); prev = p;
			check(p == 0 || NexusMath.thresholdForPoint(p) <= s, "eşik altı değil");
			check(p >= NexusConfig.MAX_POINTS || NexusMath.thresholdForPoint(p + 1) > s, "sonraki eşik üstte");
		}
		check(NexusMath.pointsForLifetime(14) == 0 && NexusMath.pointsForLifetime(15) == 1, "ilk puan 15 ruhta");
		System.out.println("puan eşikleri: 1=" + NexusMath.thresholdForPoint(1) + " 10=" + NexusMath.thresholdForPoint(10)
			+ " 40=" + NexusMath.thresholdForPoint(40) + " 100=" + NexusMath.thresholdForPoint(100) + " 160=" + NexusMath.thresholdForPoint(160));

		// Satın alma
		NexusData d = new NexusData(List.of(), 0, 10, 0, 0);
		check(NexusRules.purchase(d, "soul_02", 0).result() == NexusRules.Result.NOT_REACHABLE, "kilitli düğüm alınamaz");
		NexusRules.Purchase p1 = NexusRules.purchase(d, "soul_01", 0);
		check(p1.ok() && p1.data().unlocked().equals(List.of("soul_01")), "geçit alınır");
		check(d.unlocked().isEmpty(), "girdi değişmedi");
		check(NexusRules.purchase(p1.data(), "soul_01", 0).result() == NexusRules.Result.ALREADY_OWNED, "ikinci kez alınamaz");
		NexusData cur = p1.data();
		for (String id : List.of("soul_02", "soul_03", "soul_04")) { var r = NexusRules.purchase(cur, id, 0); check(r.ok(), "al " + id + r.result()); cur = r.data(); }
		check(NexusRules.availablePoints(cur) == 10 - 1 - 1 - 1 - 2, "puan düştü " + NexusRules.availablePoints(cur));
		// büyük düğüm XP ister, yetersizse hiçbir şey değişmez
		NexusData big = new NexusData(allOfBranch(Branch.SOUL, 17), 0, 160, 0, 0);
		var nx = NexusRules.purchase(big, "soul_18", 54);
		check(nx.result() == NexusRules.Result.NOT_ENOUGH_XP && nx.data() == big, "XP yetersiz -> değişmez");
		var ok = NexusRules.purchase(big, "soul_18", 55);
		check(ok.ok() && ok.xpPointsCost() == 55, "büyük düğüm 55 xp puanı");
		// dal sonu ilerleme şartı
		NexusData few = new NexusData(List.of("exec_01", "exec_04"), 0, 160, 0, 0);
		check(NexusRules.purchase(few, "exec_20", 9999).result() == NexusRules.Result.NOT_REACHABLE, "dal sonu bağlantısız");
		NexusData mid = new NexusData(allOfBranch(Branch.EXECUTIONER, 10), 0, 160, 0, 0);
		check(!NexusRules.capstoneReady(mid.unlockedSet(), NexusTree.get("exec_20")), "10 düğümle dal sonu hazır değil");
		NexusData nearly = new NexusData(minus(allOfBranch(Branch.EXECUTIONER, 19), "exec_19"), 0, 160, 0, 0);
		var cap = NexusRules.purchase(nearly, "exec_20", 315);
		check(cap.ok() && cap.xpPointsCost() == 315, "dal sonu 315 xp: " + cap.result());
		NexusData noLarge = new NexusData(minus(minus(allOfBranch(Branch.EXECUTIONER, 17), "exec_18"), "exec_19"), 0, 160, 0, 0);
		check(!NexusRules.capstoneReady(noLarge.unlockedSet(), NexusTree.get("exec_20")), "büyük düğümsüz dal sonu olmaz");
		// dallar arası köprü
		NexusData hyb = new NexusData(List.of("soul_01", "soul_03", "soul_04", "soul_06", "soul_09"), 0, 20, 0, 0);
		check(NexusRules.purchase(hyb, "exec_08", 0).ok(), "köprü + önkoşul (soul_04) ile hibrit geçiş");
		NexusData noReq = new NexusData(List.of("soul_01", "soul_03", "soul_06", "soul_09"), 0, 20, 0, 0);
		var blocked = NexusRules.purchase(noReq, "exec_08", 0);
		check(blocked.result() == NexusRules.Result.REQUIREMENTS && blocked.data() == noReq, "önkoşul yoksa sinerji alınamaz ve veri değişmez: " + blocked.result());
		check(NexusRules.purchase(hyb, "exec_09", 0).result() == NexusRules.Result.NOT_REACHABLE, "yanlış uçtan geçilmez");

		// Sıfırlama
		NexusData owned = new NexusData(allOfBranch(Branch.SOUL, 12), 5000, 100, 0, 0);
		var plan = NexusRules.resetPlan(owned, 0);
		check(plan.nodes() == 12 && plan.souls() == 15 * 12 + 66 && plan.xpLevels() == 5, "plan " + plan);
		check(NexusMath.resetSouls(24, 0) > 2 * NexusMath.resetSouls(12, 0), "bedel düğüm sayısıyla artar");
		check(NexusMath.resetSouls(12, 10) < NexusMath.resetSouls(12, 0), "indirim");
		var bad = NexusRules.reset(owned, 0, 1000, 11);
		check(bad.result() == NexusRules.Result.COUNT_MISMATCH && bad.data() == owned, "sayı uyuşmazlığı reddedilir");
		check(NexusRules.reset(owned, 0, plan.xpPoints() - 1, 12).result() == NexusRules.Result.NOT_ENOUGH_XP, "xp yetersiz");
		check(NexusRules.reset(owned.withSpent(4990), 0, 1000, 12).result() == NexusRules.Result.NOT_ENOUGH_SOULS, "ruh yetersiz");
		var done = NexusRules.reset(owned, 0, 1000, 12);
		check(done.ok() && done.data().unlocked().isEmpty(), "sıfırlandı");
		check(done.data().lifetimeSouls() == 5000 && done.data().earnedPoints() == 100, "toplam ruh ve kazanılmış puan korunur");
		check(done.data().soulsSpent() == plan.souls() && done.data().soulBalance() == 5000 - plan.souls(), "yalnızca bakiye düşer");
		check(NexusRules.availablePoints(done.data()) == 100, "puanlar iade");
		check(NexusRules.reset(NexusData.EMPTY, 0, 99, 0).result() == NexusRules.Result.NOTHING_TO_RESET, "boş sıfırlama");

		// Sanitize
		var sane = NexusTree.sanitize(List.of("soul_05", "bilinmeyen", "exec_01", "exec_04", "soul_01"));
		check(sane.equals(List.of("exec_01", "exec_04", "soul_01")), "kopuk ve bilinmeyen atılır: " + sane);
		var noPrereq = NexusTree.sanitize(List.of("soul_01", "soul_03", "soul_06", "soul_09"));
		check(noPrereq.equals(List.of("soul_01", "soul_03", "soul_06")), "önkoşulu bozulan sinerji düğümü atılır (puan iade olur): " + noPrereq);
		var keepsPrereq = NexusTree.sanitize(List.of("guard_01", "guard_04", "soul_01", "soul_03", "soul_06", "soul_09"));
		check(keepsPrereq.contains("soul_09"), "önkoşulu sağlanan sinerji korunur: " + keepsPrereq);
		// Geçiş: eski kayıtlı ilerleme (sinerji öncesi) sanitize'dan sonra puan kaybettirmez: harcanan puan yalnızca açık düğümlerden
		NexusData legacy = new NexusData(List.of("soul_01", "soul_03", "soul_06", "soul_09"), 3000, 100, 0, 0);
		NexusData migrated = legacy.withUnlocked(NexusTree.sanitize(legacy.unlocked()));
		check(NexusRules.availablePoints(migrated) >= NexusRules.availablePoints(legacy), "geçişte kullanılabilir puan azalmaz");
		check(migrated.earnedPoints() == legacy.earnedPoints() && migrated.lifetimeSouls() == legacy.lifetimeSouls(), "kazanılmış puan ve ruh geçmişi korunur");

		System.out.println(fails == 0 ? "TÜM TESTLER GEÇTİ" : fails + " TEST BAŞARISIZ");
		System.exit(fails == 0 ? 0 : 1);
	}

	static List<String> allOfBranch(Branch b, int firstN) {
		List<String> l = new ArrayList<>();
		for (int i = 1; i <= firstN; i++) l.add(b.id + "_" + String.format("%02d", i));
		return l;
	}
	static List<String> minus(List<String> l, String x) { List<String> r = new ArrayList<>(l); r.remove(x); return r; }
	static String diff(Set<Stat> used) { Set<Stat> m = EnumSet.allOf(Stat.class); m.removeAll(used); return m.toString(); }
}
