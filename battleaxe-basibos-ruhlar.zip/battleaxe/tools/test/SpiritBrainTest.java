import com.battleaxe.spirit.RuhYiyenConfig;
import com.battleaxe.spirit.RuhYiyenLogic;
import com.battleaxe.spirit.SavrulmusConfig;
import com.battleaxe.spirit.SavrulmusLogic;
import com.battleaxe.spirit.ZincirliConfig;
import com.battleaxe.spirit.ZincirliLogic;

/** Başıboş Ruhların savaş durum makinesi testleri (saf mantık). Çalıştırma: tools/test/run_tests.sh */
public final class SpiritBrainTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	// ------------------------------------------------------------------ Savrulmuş
	static SavrulmusLogic.Inputs sIn(double dist, boolean los, boolean reach, boolean landed, double roll) {
		return new SavrulmusLogic.Inputs(true, dist, los, reach, landed, roll);
	}

	static void savrulmus() {
		// Pençe kombosu: yakın + erişim -> hazırlık -> vuruş -> (ikinci hazırlık -> vuruş) -> geri çekilme
		SavrulmusLogic.Brain b = new SavrulmusLogic.Brain();
		for (int i = 0; i < SavrulmusConfig.COMBO_COOLDOWN_TICKS; i++) {
			b.step(sIn(2.0, true, true, false, 0.99)); // bekleme süresi akar (kombo hazır olana dek)
			if (!b.isIdle()) {
				break;
			}
		}
		int hits = 0;
		int windups = 0;
		boolean retreat = false;
		for (int i = 0; i < 80 && !retreat; i++) {
			SavrulmusLogic.Event e = b.step(sIn(2.0, true, true, false, 0.99));
			if (e == SavrulmusLogic.Event.CLAW_HIT) {
				hits++;
			}
			if (e == SavrulmusLogic.Event.CLAW_WINDUP_START) {
				windups++;
			}
			if (e == SavrulmusLogic.Event.RETREAT_START) {
				retreat = true;
			}
		}
		check(hits == SavrulmusConfig.COMBO_HITS && retreat, "kombo: iki vuruş sonra geri çekilme (vuruş=" + hits + ")");
		check(windups >= 1, "kombo ikinci vuruş için yeniden hazırlanır");
		check(b.comboCooldown() > SavrulmusConfig.COMBO_COOLDOWN_TICKS / 2, "kombo sonrası bekleme kuruldu (spam yok)");

		// Menzil kaçarsa kombo ikinci vuruşa gitmez, geri çekilir
		b = new SavrulmusLogic.Brain();
		for (int i = 0; i < SavrulmusConfig.COMBO_COOLDOWN_TICKS && b.isIdle(); i++) {
			b.step(sIn(2.0, true, true, false, 0.99));
		}
		int hits2 = 0;
		for (int i = 0; i < 80; i++) {
			SavrulmusLogic.Event e = b.step(sIn(6.0, true, false, false, 0.99));
			if (e == SavrulmusLogic.Event.CLAW_HIT) {
				hits2++;
			}
		}
		check(hits2 == 1, "hedef menzilden çıkınca ikinci vuruş yapılmaz");

		// Sıçrayış: bekleme + mesafe + görüş hattı + şans
		b = new SavrulmusLogic.Brain();
		boolean windup = false;
		for (int i = 0; i < SavrulmusConfig.LEAP_INITIAL_COOLDOWN_TICKS + 5; i++) {
			SavrulmusLogic.Event e = b.step(sIn(8.0, true, false, false, 0.0));
			if (e == SavrulmusLogic.Event.LEAP_WINDUP_START) {
				windup = true;
				check(i >= SavrulmusConfig.LEAP_INITIAL_COOLDOWN_TICKS - 1, "ilk sıçrayış bekleme süresinden önce başlamaz");
				break;
			}
		}
		check(windup, "uzak mesafede sıçrayış hazırlığı başlar");
		check(b.attack() == SavrulmusLogic.Attack.LEAP_WINDUP && !b.exposed(), "hazırlıkta savunmasız değil");
		boolean launched = false;
		for (int i = 0; i < SavrulmusConfig.LEAP_WINDUP_TICKS + 2; i++) {
			if (b.step(sIn(8.0, true, false, false, 0.5)) == SavrulmusLogic.Event.LEAP_LAUNCH) {
				launched = true;
				break;
			}
		}
		check(launched && b.attack() == SavrulmusLogic.Attack.LEAP_AIR, "hazırlık sonrası fırlar");
		// Hemen "indi" demek erken inişi tetiklemez (min hava süresi); sonra iner ve SAVUNMASIZ kalır
		SavrulmusLogic.Event early = b.step(sIn(8.0, true, false, true, 0.5));
		check(early == SavrulmusLogic.Event.NONE && b.attack() == SavrulmusLogic.Attack.LEAP_AIR, "erken iniş sinyali yok sayılır");
		boolean landedEv = false;
		for (int i = 0; i < SavrulmusConfig.LEAP_MAX_AIR_TICKS && !landedEv; i++) {
			landedEv = b.step(sIn(8.0, true, false, true, 0.5)) == SavrulmusLogic.Event.LEAP_LANDED;
		}
		check(landedEv && b.exposed(), "iniş sonrası savunmasız");
		check(b.leapCooldown() >= SavrulmusConfig.LEAP_COOLDOWN_TICKS - 1, "iniş sonrası sıçrayış beklemesi");
		int recoverTicks = 0;
		while (b.exposed() && recoverTicks < 200) {
			b.step(sIn(8.0, true, false, false, 0.5));
			recoverTicks++;
		}
		check(recoverTicks == SavrulmusConfig.LEAP_RECOVER_TICKS - 1 || recoverTicks == SavrulmusConfig.LEAP_RECOVER_TICKS, "savunmasızlık süresi kadar sürer (" + recoverTicks + ")");

		// Hava süresi dolarsa iner (takılı kalmaz)
		b = new SavrulmusLogic.Brain();
		for (int i = 0; i < 400 && b.attack() != SavrulmusLogic.Attack.LEAP_AIR; i++) {
			b.step(sIn(8.0, true, false, false, 0.0));
		}
		int air = 0;
		while (b.attack() == SavrulmusLogic.Attack.LEAP_AIR && air < 100) {
			b.step(sIn(8.0, true, false, false, 0.5));
			air++;
		}
		check(air <= SavrulmusConfig.LEAP_MAX_AIR_TICKS, "havada en çok MAX_AIR tick");

		// Görüş hattı kaybolursa sıçrayış iptal olur, kısa bekleme kurulur
		b = new SavrulmusLogic.Brain();
		for (int i = 0; i < 400 && b.attack() != SavrulmusLogic.Attack.LEAP_WINDUP; i++) {
			b.step(sIn(8.0, true, false, false, 0.0));
		}
		boolean cancelled = false;
		for (int i = 0; i < SavrulmusConfig.LEAP_WINDUP_TICKS + 2; i++) {
			if (b.step(sIn(8.0, false, false, false, 0.5)) == SavrulmusLogic.Event.LEAP_CANCELLED) {
				cancelled = true;
				break;
			}
		}
		check(cancelled && b.isIdle() && b.leapCooldown() > 0, "görüş hattı yoksa sıçrayış iptal");

		// Görüş hattı yoksa sıçrayış başlamaz; hedef yoksa hiçbir şey olmaz
		b = new SavrulmusLogic.Brain();
		boolean any = false;
		for (int i = 0; i < 300; i++) {
			if (b.step(sIn(8.0, false, false, false, 0.0)) != SavrulmusLogic.Event.NONE) {
				any = true;
			}
		}
		check(!any, "görüş hattı olmadan saldırı başlamaz");
		b = new SavrulmusLogic.Brain();
		any = false;
		for (int i = 0; i < 300; i++) {
			if (b.step(new SavrulmusLogic.Inputs(false, 0.0, false, false, false, 0.0)) != SavrulmusLogic.Event.NONE) {
				any = true;
			}
		}
		check(!any, "hedef yokken olay yok");

		// abort bekleme sürelerini korur
		b = new SavrulmusLogic.Brain();
		int before = b.leapCooldown();
		b.abort();
		check(b.isIdle() && b.leapCooldown() == before, "abort bekleme sürelerini korur");
	}

	// ------------------------------------------------------------------ Ruh Yiyen
	static RuhYiyenLogic.Inputs rIn(double dist, boolean los, boolean claim, boolean interrupted, double health, double roll) {
		return new RuhYiyenLogic.Inputs(true, dist, los, claim, interrupted, health, roll);
	}

	static void ruhYiyen() {
		// Ruh Oku: bekleme sonrası hazırlık -> ateş
		RuhYiyenLogic.Brain b = new RuhYiyenLogic.Brain();
		boolean windup = false;
		boolean fired = false;
		int fireTick = -1;
		for (int i = 0; i < 200; i++) {
			RuhYiyenLogic.Event e = b.step(rIn(12.0, true, false, false, 1.0, 0.99));
			if (e == RuhYiyenLogic.Event.BOLT_WINDUP_START) {
				windup = true;
			}
			if (e == RuhYiyenLogic.Event.BOLT_FIRE) {
				fired = true;
				fireTick = i;
				break;
			}
		}
		check(windup && fired, "ruh oku: hazırlık sonra ateş");
		check(fireTick >= RuhYiyenConfig.BOLT_INITIAL_COOLDOWN_TICKS + RuhYiyenConfig.BOLT_WINDUP_TICKS - 2, "ruh oku hazırlıksız atılmaz");
		check(b.boltCooldown() >= RuhYiyenConfig.BOLT_COOLDOWN_TICKS - 1, "ateş sonrası bekleme");

		// Çok yakın/çok uzak mesafede ok atmaz
		b = new RuhYiyenLogic.Brain();
		boolean any = false;
		for (int i = 0; i < 300; i++) {
			if (b.step(rIn(1.0, true, false, false, 1.0, 0.99)) != RuhYiyenLogic.Event.NONE) {
				any = true;
			}
		}
		check(!any, "çok yakında ok yok");

		// Ruh Emdirme: tam yaşam döngüsü
		b = new RuhYiyenLogic.Brain();
		int linkTick = -1;
		int pulses = 0;
		boolean end = false;
		boolean sawWindup = false;
		for (int i = 0; i < 600 && !end; i++) {
			RuhYiyenLogic.Event e = b.step(rIn(9.0, true, true, false, 0.4, 0.0));
			switch (e) {
				case DRAIN_WINDUP_START -> sawWindup = true;
				case DRAIN_LINK -> linkTick = i;
				case DRAIN_PULSE -> pulses++;
				case DRAIN_END -> end = true;
				default -> {
				}
			}
		}
		check(sawWindup && linkTick > 0, "emme: önce hazırlık sonra bağ");
		check(end, "emme normal biter");
		check(pulses >= RuhYiyenConfig.DRAIN_CHANNEL_TICKS / RuhYiyenConfig.DRAIN_PULSE_INTERVAL_TICKS - 2, "bağ boyunca darbe (" + pulses + ")");
		check(pulses <= RuhYiyenConfig.DRAIN_CHANNEL_TICKS / RuhYiyenConfig.DRAIN_PULSE_INTERVAL_TICKS + 1, "darbe sayısı sınırlı");
		check(b.drainCooldown() >= RuhYiyenConfig.DRAIN_COOLDOWN_TICKS - 2, "emme sonrası uzun bekleme");

		// Bağı bozma yolları
		java.util.function.Function<String, RuhYiyenLogic.Event> breaker = mode -> {
			RuhYiyenLogic.Brain br = new RuhYiyenLogic.Brain();
			for (int i = 0; i < 600 && br.attack() != RuhYiyenLogic.Attack.DRAIN_CHANNEL; i++) {
				br.step(rIn(9.0, true, true, false, 0.4, 0.0));
			}
			if (br.attack() != RuhYiyenLogic.Attack.DRAIN_CHANNEL) {
				return RuhYiyenLogic.Event.NONE;
			}
			for (int i = 0; i < 20; i++) {
				RuhYiyenLogic.Inputs in = switch (mode) {
					case "los" -> rIn(9.0, false, true, false, 0.4, 0.5);
					case "range" -> rIn(RuhYiyenConfig.DRAIN_BREAK_RANGE + 2.0, true, true, false, 0.4, 0.5);
					case "damage" -> rIn(9.0, true, true, true, 0.4, 0.5);
					default -> new RuhYiyenLogic.Inputs(false, 0.0, false, false, false, 0.4, 0.5);
				};
				RuhYiyenLogic.Event e = br.step(in);
				if (e == RuhYiyenLogic.Event.DRAIN_BROKEN) {
					check(br.exposed(), "bağ kopunca ruh savunmasız (" + mode + ")");
					return e;
				}
			}
			return RuhYiyenLogic.Event.NONE;
		};
		check(breaker.apply("los") == RuhYiyenLogic.Event.DRAIN_BROKEN, "görüş hattını kesmek bağı koparır");
		check(breaker.apply("range") == RuhYiyenLogic.Event.DRAIN_BROKEN, "uzaklaşmak bağı koparır");
		check(breaker.apply("damage") == RuhYiyenLogic.Event.DRAIN_BROKEN, "yeterli hasar bağı koparır");
		check(breaker.apply("target") == RuhYiyenLogic.Event.DRAIN_BROKEN, "hedef kaybolunca bağ kopar");

		// Görüş hattı kısa süre kesilirse (köşe) bağ SÜRER; grace aşılınca kopar
		b = new RuhYiyenLogic.Brain();
		for (int i = 0; i < 600 && b.attack() != RuhYiyenLogic.Attack.DRAIN_CHANNEL; i++) {
			b.step(rIn(9.0, true, true, false, 0.4, 0.0));
		}
		boolean brokeEarly = false;
		for (int i = 0; i < RuhYiyenConfig.DRAIN_LOS_GRACE_TICKS - 1; i++) {
			if (b.step(rIn(9.0, false, true, false, 0.4, 0.5)) == RuhYiyenLogic.Event.DRAIN_BROKEN) {
				brokeEarly = true;
			}
		}
		check(!brokeEarly, "kısa görüş kesintisi bağı koparmaz (tolerans)");
		check(b.step(rIn(9.0, true, true, false, 0.4, 0.5)) != RuhYiyenLogic.Event.DRAIN_BROKEN, "görüş dönünce sayaç sıfırlanır");

		// Hazırlıkta hasar alırsa emme iptal; izin yoksa başlamaz
		b = new RuhYiyenLogic.Brain();
		for (int i = 0; i < 600 && b.attack() != RuhYiyenLogic.Attack.DRAIN_WINDUP; i++) {
			b.step(rIn(9.0, true, true, false, 0.4, 0.0));
		}
		check(b.step(rIn(9.0, true, true, true, 0.4, 0.5)) == RuhYiyenLogic.Event.DRAIN_CANCELLED && b.isIdle(), "hazırlıkta ağır hasar emmeyi iptal eder");
		b = new RuhYiyenLogic.Brain();
		boolean drain = false;
		for (int i = 0; i < 600; i++) {
			if (b.step(rIn(9.0, true, false, false, 0.4, 0.0)) == RuhYiyenLogic.Event.DRAIN_WINDUP_START) {
				drain = true;
			}
		}
		check(!drain, "koordinasyon izni yoksa emme başlamaz");

		// Yaralıyken emmeyi daha sık seçer (uygun fırsatta iyileşir)
		check(RuhYiyenConfig.DRAIN_CHANCE_WOUNDED_PER_TICK > RuhYiyenConfig.DRAIN_CHANCE_PER_TICK, "yaralı ruh emmeyi tercih eder");
		b = new RuhYiyenLogic.Brain();
		boolean healthyDrain = false;
		boolean woundedDrain = false;
		RuhYiyenLogic.Brain w = new RuhYiyenLogic.Brain();
		double roll = (RuhYiyenConfig.DRAIN_CHANCE_PER_TICK + RuhYiyenConfig.DRAIN_CHANCE_WOUNDED_PER_TICK) / 2.0;
		for (int i = 0; i < RuhYiyenConfig.DRAIN_INITIAL_COOLDOWN_TICKS + 20; i++) {
			if (b.step(rIn(9.0, true, true, false, 1.0, roll)) == RuhYiyenLogic.Event.DRAIN_WINDUP_START) {
				healthyDrain = true;
			}
			if (w.step(rIn(9.0, true, true, false, 0.3, roll)) == RuhYiyenLogic.Event.DRAIN_WINDUP_START) {
				woundedDrain = true;
			}
		}
		check(!healthyDrain && woundedDrain, "aynı zarda: sağlam ruh emmez, yaralı ruh emer");
	}

	// ------------------------------------------------------------------ Zincirli
	static ZincirliLogic.Inputs zIn(double dist, boolean los, boolean sealable, boolean claim, boolean chainDone, double roll) {
		return new ZincirliLogic.Inputs(true, dist, los, sealable, claim, chainDone, roll);
	}

	static void zincirli() {
		// Zincir Savurma: yakın + bekleme sonrası; hazırlık sonra vuruş sonra savunmasız
		ZincirliLogic.Brain b = new ZincirliLogic.Brain();
		int hitTick = -1;
		boolean windup = false;
		for (int i = 0; i < 300; i++) {
			ZincirliLogic.Event e = b.step(zIn(3.0, true, false, false, false, 0.1)); // roll < 0.5 -> savurma
			if (e == ZincirliLogic.Event.SWEEP_WINDUP_START) {
				windup = true;
			}
			if (e == ZincirliLogic.Event.SWEEP_HIT) {
				hitTick = i;
				break;
			}
		}
		check(windup && hitTick > 0, "savurma: hazırlık sonra vuruş");
		check(hitTick >= ZincirliConfig.SWEEP_INITIAL_COOLDOWN_TICKS + ZincirliConfig.SWEEP_WINDUP_TICKS - 2, "savurma hazırlıksız vurmaz");
		boolean exposed = false;
		for (int i = 0; i < ZincirliConfig.SWEEP_STRIKE_TICKS + 3; i++) {
			b.step(zIn(3.0, true, false, false, false, 0.1));
		}
		exposed = b.exposed() && b.attack() == ZincirliLogic.Attack.SWEEP_RECOVER;
		check(exposed, "savurma sonrası savunmasız");
		check(b.sweepCooldown() > 0, "savurma bekleme süresi kuruldu");

		// Ruhani Darbe: roll >= 0.5 -> darbe; şok dalgası süresince STRIKE
		b = new ZincirliLogic.Brain();
		boolean impact = false;
		int strike = 0;
		for (int i = 0; i < 400; i++) {
			ZincirliLogic.Event e = b.step(zIn(3.0, true, false, false, false, 0.9));
			if (e == ZincirliLogic.Event.SLAM_IMPACT) {
				impact = true;
			}
			if (b.attack() == ZincirliLogic.Attack.SLAM_STRIKE) {
				strike++;
			}
			if (impact && b.attack() == ZincirliLogic.Attack.SLAM_RECOVER) {
				break;
			}
		}
		check(impact, "ruhani darbe şok dalgası başlatır");
		check(strike == ZincirliConfig.SLAM_STRIKE_TICKS || strike == ZincirliConfig.SLAM_STRIKE_TICKS + 1, "şok dalgası süresi kadar STRIKE (" + strike + ")");
		check(b.exposed(), "darbe sonrası savunmasız");

		// Aynı anda tek ağır saldırı: bir saldırı sürerken yenisi seçilmez
		b = new ZincirliLogic.Brain();
		int starts = 0;
		for (int i = 0; i < 40; i++) {
			ZincirliLogic.Event e = b.step(zIn(2.0, true, true, true, false, 0.1));
			if (e == ZincirliLogic.Event.SWEEP_WINDUP_START || e == ZincirliLogic.Event.SLAM_WINDUP_START || e == ZincirliLogic.Event.CHAIN_WINDUP_START) {
				starts++;
			}
		}
		check(starts <= 1, "bir saldırı sürerken ikincisi başlamaz");

		// Zincirle Mühürleme: orta mesafe + mühürlenebilir + izin; yakında asla
		b = new ZincirliLogic.Brain();
		boolean launch = false;
		boolean end = false;
		boolean windupStart = false;
		for (int i = 0; i < 400 && !end; i++) {
			ZincirliLogic.Event e = b.step(zIn(9.0, true, true, true, false, 0.5));
			if (e == ZincirliLogic.Event.CHAIN_WINDUP_START) {
				windupStart = true;
			}
			if (e == ZincirliLogic.Event.CHAIN_LAUNCH) {
				launch = true;
			}
			if (launch && b.attack() == ZincirliLogic.Attack.CHAIN_THROW) {
				// zincir bir şeye çarptı
				if (b.step(zIn(9.0, true, true, true, true, 0.5)) == ZincirliLogic.Event.CHAIN_END) {
					end = true;
				}
			}
		}
		check(windupStart && launch && end, "mühür: hazırlık, fırlatma ve bitiş");
		check(b.exposed() && b.chainCooldown() >= ZincirliConfig.CHAIN_COOLDOWN_TICKS - 5, "mühür sonrası savunmasız ve uzun bekleme");

		// Mühürlenemez hedef veya izin yoksa zincir atılmaz
		for (int mode = 0; mode < 2; mode++) {
			b = new ZincirliLogic.Brain();
			boolean chain = false;
			for (int i = 0; i < 500; i++) {
				ZincirliLogic.Event e = b.step(zIn(9.0, true, mode != 0, mode != 1, false, 0.5));
				if (e == ZincirliLogic.Event.CHAIN_WINDUP_START) {
					chain = true;
				}
			}
			check(!chain, "mühür koşulu eksikse zincir atılmaz (mod " + mode + ")");
		}

		// Zincir süresi dolarsa takılı kalmaz
		b = new ZincirliLogic.Brain();
		for (int i = 0; i < 400 && b.attack() != ZincirliLogic.Attack.CHAIN_THROW; i++) {
			b.step(zIn(9.0, true, true, true, false, 0.5));
		}
		int throwTicks = 0;
		while (b.attack() == ZincirliLogic.Attack.CHAIN_THROW && throwTicks < 100) {
			b.step(zIn(9.0, true, true, true, false, 0.5));
			throwTicks++;
		}
		check(throwTicks <= ZincirliConfig.CHAIN_MAX_THROW_TICKS, "fırlatma süresi sınırlı");

		// Yakında bekleme sürerken uzaktan mühür seçilmez (alan daraltmaya devam)
		b = new ZincirliLogic.Brain();
		for (int i = 0; i < 400; i++) {
			b.step(zIn(3.0, true, true, true, false, 0.1));
		}
		// (savurma/darbe döngüsü sürerken zincir başlatılmamış olmalı: yakın mesafe)
		check(b.chainCooldown() == 0 || b.attack() != ZincirliLogic.Attack.CHAIN_WINDUP, "yakın mesafede mühür seçilmez");

		b = new ZincirliLogic.Brain();
		int before = b.slamCooldown();
		b.abort();
		check(b.isIdle() && b.slamCooldown() == before, "abort bekleme sürelerini korur");
	}

	public static void main(String[] args) {
		savrulmus();
		ruhYiyen();
		zincirli();
		if (failed == 0) {
			System.out.println("SpiritBrainTest: tüm testler geçti.");
		} else {
			System.out.println("SpiritBrainTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
