import com.battleaxe.evolution.*;
import com.battleaxe.evolution.EvolutionLogic.*;

/** Minecraft gerektirmeyen Berserker Evrimi çekirdek testleri. Çalıştırma: tools/test/run_tests.sh */
public class EvolutionLogicTest {
	static int fails = 0;
	static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("BAŞARISIZ: " + msg); } }
	static StageInputs in(boolean legacy, boolean combat, double essence) {
		return new StageInputs(true, true, true, legacy, combat, essence, Recovery.NONE, false);
	}

	public static void main(String[] a) {
		// ---- Aşama geçişleri ----
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 10)) == EvolutionStage.NONE, "öz düşükken aşama yok");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 20)) == EvolutionStage.SPARK, "öz 20 + savaş = Kıvılcım");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, false, 90)) == EvolutionStage.NONE, "savaş dışında kendiliğinden başlamaz");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(true, false, 0)) == EvolutionStage.SPARK, "eski Berserker = Kıvılcım");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 40)) == EvolutionStage.AWAKENING, "öz 40 = Uyanış");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 70)) == EvolutionStage.SURGE, "öz 70 = Taşkınlık");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 100)) != EvolutionStage.FINAL_THRESHOLD, "Son Eşik kendiliğinden açılmaz");
		// histerezis
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, in(false, true, 50)) == EvolutionStage.SURGE, "Taşkınlık 50'de sürer (çıkış 40)");
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, in(false, true, 50)) == EvolutionStage.AWAKENING, "ama 50'de girilmez (giriş 65)");
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, in(false, true, 39)) == EvolutionStage.AWAKENING, "Taşkınlık 39'da düşer");
		check(EvolutionLogic.nextStage(EvolutionStage.AWAKENING, in(false, false, 25)) == EvolutionStage.AWAKENING, "savaş bitse de eşik üstünde sürer");
		// yol seçilmemiş: yalnızca eski Berserker ile Kıvılcım
		StageInputs noPath = new StageInputs(true, true, false, true, true, 100, Recovery.NONE, false);
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, noPath) == EvolutionStage.SPARK, "dal yokken en çok Kıvılcım");
		StageInputs noPath2 = new StageInputs(true, true, false, false, true, 100, Recovery.NONE, false);
		check(EvolutionLogic.nextStage(EvolutionStage.NONE, noPath2) == EvolutionStage.NONE, "dal yok + eski Berserker yok = aşama yok");
		// ölüm / balta yok
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, new StageInputs(false, true, true, true, true, 100, Recovery.NONE, false)) == EvolutionStage.NONE, "ölünce sıfır");
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, new StageInputs(true, false, true, true, true, 100, Recovery.NONE, false)) == EvolutionStage.NONE, "balta elde değilse sıfır");
		// toparlanma sınırları
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, new StageInputs(true, true, true, false, true, 100, Recovery.OVERLOAD, false)) == EvolutionStage.SPARK, "aşırı yük: en çok Kıvılcım");
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, new StageInputs(true, true, true, true, true, 100, Recovery.BURNOUT, false)) == EvolutionStage.NONE, "tükenme: evrim aşaması yok");
		check(EvolutionLogic.nextStage(EvolutionStage.SURGE, new StageInputs(true, true, true, true, true, 100, Recovery.NONE, true)) == EvolutionStage.FINAL_THRESHOLD, "açık eylemle Son Eşik");
		check(EvolutionLogic.nextStage(EvolutionStage.FINAL_THRESHOLD, in(false, true, 100)) == EvolutionStage.SURGE, "Son Eşik bitince Taşkınlığa düşer, kilitlenmez");

		// ---- Savaş Özü: sınırlar ----
		double e = 100;
		for (int i = 0; i < 100000; i++) { e = EvolutionLogic.essenceAfterTick(e, 3, false, 99999); check(e >= 0 && e <= 100, "öz sınır dışı " + e); }
		check(e == 0.0, "öz sürekli tüketimle 0'da durur, negatif olmaz");
		check(EvolutionLogic.essenceAfterTick(50, 0, true, 0) == 50, "savaşta aşamasızken öz sabit");
		check(EvolutionLogic.essenceAfterTick(50, 0, false, 300) < 50, "savaş dışında azalır");
		check(EvolutionLogic.essenceAfterTick(50, 0, false, 100) == 50, "gecikmeden önce azalmaz");
		// zayıf vuruş spam'i
		check(EvolutionLogic.meleeGain(0.2, 20, 0, 1, 1) == 0.0, "zayıf vuruş öz vermez");
		check(EvolutionLogic.meleeGain(1.0, 20, 0, 1, 1) == 3.0, "tam vuruş temel kazanım: " + EvolutionLogic.meleeGain(1.0, 20, 0, 1, 1));
		// aynı hedefe tekrar
		double first = EvolutionLogic.meleeGain(1.0, 20, 0, 1, 1), fifth = EvolutionLogic.meleeGain(1.0, 20, 4, 1, 1), hundredth = EvolutionLogic.meleeGain(1.0, 20, 99, 1, 1);
		check(fifth < first && hundredth >= first * 0.25 - 1e-9 && hundredth <= fifth, "aynı hedef kazanımı düşürür, tabanı var");
		check(EvolutionLogic.meleeGain(1.0, 200, 0, 1, 1) <= 3.0 * 2.5 + 1e-9, "hedef ağırlığı sınırlı");
		// pencere sınırlayıcı: saniyede en çok 14, 1000 vuruş spam'inde bile
		WindowLimiter limiter = new WindowLimiter(20, 14);
		double total = 0; for (long t = 0; t < 200; t++) { total += limiter.limit(100, t); }
		check(Math.abs(total - 14.0 * 10) < 1e-9, "10 saniyede en çok 140 öz: " + total);
		check(new WindowLimiter(20, 14).limit(5, 0) == 5.0, "limit altında tam geçer");
		// tehlike çarpanları üst üste binmez
		check(EvolutionLogic.dangerMultiplier(EvolutionPath.LAST_BREATH, 0.2) == 1.5 && EvolutionLogic.dangerMultiplier(EvolutionPath.BLOOD_WHIRL, 0.2) == 1.4, "tehlike çarpanı");
		check(EvolutionLogic.dangerMultiplier(EvolutionPath.LAST_BREATH, 0.9) == 1.0, "sağlıklıyken tehlike çarpanı yok");
		check(EvolutionLogic.killGain(20) == 4 && EvolutionLogic.killGain(300) == 10, "öldürme kazanımı");

		// ---- Aşırı yüklenme ----
		double o = 0; int ticks = 0; while (o < 100 && ticks < 100000) { o = EvolutionLogic.overloadAfterTick(o, 3); ticks++; }
		check(ticks == 400, "Taşkınlık 20 saniyede aşırı yüklenir: " + ticks);
		double cool = 100; for (int i = 0; i < 20 * 10; i++) cool = EvolutionLogic.overloadAfterTick(cool, 0);
		check(cool == 0.0, "boştayken 10 saniyede soğur");
		check(EvolutionLogic.overloadAfterTick(40, 4) == 40, "Son Eşik'te sabit");
		check(EvolutionLogic.abilityOverload(3, 12) == 12 && EvolutionLogic.abilityOverload(2, 12) == 0, "yetenek bedeli yalnız Taşkınlıkta");

		// ---- Ustalık ----
		check(EvolutionLogic.masteryLevel(0) == 1 && EvolutionLogic.masteryLevel(149) == 1 && EvolutionLogic.masteryLevel(150) == 2
			&& EvolutionLogic.masteryLevel(2500) == 5 && EvolutionLogic.masteryLevel(999999) == 5, "ustalık seviyeleri");
		check(EvolutionLogic.masteryScale(1) == 0.8 && EvolutionLogic.masteryScale(5) == 1.2 && EvolutionLogic.masteryScale(99) == 1.2, "ustalık ölçeği");
		check(EvolutionLogic.masteryProgress(75) == 0.5 && EvolutionLogic.masteryProgress(9999) == 1.0, "ustalık ilerlemesi");
		check(EvolutionLogic.nextMasteryThreshold(0) == 150 && EvolutionLogic.nextMasteryThreshold(2500) == -1, "sonraki eşik");
		check(EvolutionLogic.masteryGain(EvolutionPath.BLOOD_WHIRL, MasteryEvent.MELEE_HIT, 6, 1, 1) == 1, "kan ustalığı");
		check(EvolutionLogic.masteryGain(EvolutionPath.BLOOD_WHIRL, MasteryEvent.MELEE_HIT, 2, 1, 1) == 0, "düşük ivmede ustalık yok");
		check(EvolutionLogic.masteryGain(EvolutionPath.BLOOD_WHIRL, MasteryEvent.MELEE_HIT, 9, 1, 0) == 0, "aşama yokken ustalık yok");
		check(EvolutionLogic.masteryGain(EvolutionPath.LAST_BREATH, MasteryEvent.DAMAGED, 0, 0.9, 1) == 0, "sağlıklıyken hasar ustalık vermez");
		check(EvolutionLogic.masteryGain(EvolutionPath.SOUL_RENDER, MasteryEvent.THROW_HIT, 0, 1, 2) == 2, "ruh ustalığı");

		// ---- Hasar sınırları ----
		DamageContext maxBlood = new DamageContext(false, false, 1.0, 10, true, Recovery.NONE);
		double worstBlood = EvolutionLogic.outgoingPct(EvolutionPath.BLOOD_WHIRL, 4, 5, maxBlood);
		check(worstBlood <= 45 + 1e-9, "kan hasarı sınırlı: " + worstBlood);
		for (EvolutionPath p : EvolutionPath.values()) for (int st = 0; st <= 4; st++) for (int ml = 1; ml <= 5; ml++) for (int m = 0; m <= 10; m += 5) for (double hr : new double[]{0.05, 0.5, 1.0}) {
			for (boolean cl : new boolean[]{false, true}) for (boolean fin : new boolean[]{false, true}) {
				double d = EvolutionLogic.outgoingPct(p, st, ml, new DamageContext(cl, !cl, hr, m, fin, Recovery.NONE));
				check(d >= -20 && d <= 45, "hasar aralık dışı");
				double r = EvolutionLogic.incomingReductionPct(p, st, ml, hr, fin, true);
				check(r >= 0 && r <= 60 + 1e-9, "azaltma %60'ı aşmaz: " + r);
				double rs = EvolutionLogic.attackSpeedPct(p, st, ml, m, Recovery.NONE, false);
				check(rs >= -15 && rs <= 30, "saldırı hızı aralık dışı: " + rs);
			}
		}
		check(EvolutionLogic.incomingReductionPct(EvolutionPath.LAST_BREATH, 3, 5, 0.01, true, true) == 60.0, "azaltma tavanı tam %60 (ölümsüzlük yok)");
		check(EvolutionLogic.incomingReductionPct(EvolutionPath.BLOOD_WHIRL, 3, 5, 0.01, true, false) == 0.0, "kan dalı azaltma vermez");
		check(EvolutionLogic.incomingReductionPct(EvolutionPath.LAST_BREATH, 2, 3, 0.95, false, false) < 3, "sağlıklıyken Son Nefes azaltması ihmal edilebilir");
		check(EvolutionLogic.incomingExtraPct(EvolutionPath.BLOOD_WHIRL, 4, 5, Recovery.NONE) <= 12, "kan savunmasızlığı sınırlı");
		check(EvolutionLogic.incomingExtraPct(EvolutionPath.SOUL_RENDER, 3, 3, Recovery.OVERLOAD) == 10, "toparlanma ek hasar");
		check(EvolutionLogic.outgoingPct(EvolutionPath.SOUL_RENDER, 0, 1, new DamageContext(true, false, 1, 0, false, Recovery.OVERLOAD)) == -10, "toparlanma hasar cezası");
		double soulCleave = EvolutionLogic.outgoingPct(EvolutionPath.SOUL_RENDER, 3, 3, new DamageContext(true, false, 1, 0, false, Recovery.NONE));
		double soulMelee = EvolutionLogic.outgoingPct(EvolutionPath.SOUL_RENDER, 3, 3, new DamageContext(false, false, 1, 0, false, Recovery.NONE));
		check(soulCleave > soulMelee, "Ruh Yırtıcısı Yar Geç'te güçlü, sıradan vuruşta zayıf");
		// Son Nefes: düşük canda daha güçlü
		check(EvolutionLogic.outgoingPct(EvolutionPath.LAST_BREATH, 2, 3, new DamageContext(false, false, 0.2, 0, false, Recovery.NONE))
			> EvolutionLogic.outgoingPct(EvolutionPath.LAST_BREATH, 2, 3, new DamageContext(false, false, 1.0, 0, false, Recovery.NONE)), "Son Nefes düşük canda güçlenir");
		// Evrimsiz oyuncu: sıfır
		check(EvolutionLogic.outgoingPct(null, 4, 5, maxBlood) == 0.0 && EvolutionLogic.attackSpeedPct(null, 4, 5, 10, Recovery.NONE, false) == 0.0, "dal yoksa bonus yok");
		// eski Berserker hız çakışması
		check(EvolutionLogic.attackSpeedPct(EvolutionPath.BLOOD_WHIRL, 3, 3, 5, Recovery.NONE, true) < EvolutionLogic.attackSpeedPct(EvolutionPath.BLOOD_WHIRL, 3, 3, 5, Recovery.NONE, false), "eski Berserker açıkken hız bonusu azalır");
		check(EvolutionLogic.movementPct(Recovery.BURNOUT) == -10 && EvolutionLogic.movementPct(Recovery.NONE) == 0, "hareket cezası");

		// ---- Ruh Yırtıcısı sinerjileri ----
		check(EvolutionLogic.soulBonus(EvolutionPath.SOUL_RENDER, 3, 5) == 2 && EvolutionLogic.soulBonus(EvolutionPath.SOUL_RENDER, 2, 5) == 1 && EvolutionLogic.soulBonus(EvolutionPath.SOUL_RENDER, 1, 5) == 0, "ruh bonusu aşamaya göre");
		check(EvolutionLogic.soulBonus(EvolutionPath.SOUL_RENDER, 3, 1) == 0 && EvolutionLogic.soulBonus(EvolutionPath.BLOOD_WHIRL, 3, 9) == 0, "zayıf düşman ve başka dalda bonus yok");
		check(EvolutionLogic.cleaveCooldownTicks(30, EvolutionPath.SOUL_RENDER, true, 12) == 18, "Son Eşik'te bekleme %40 kısalır");
		check(EvolutionLogic.cleaveCooldownTicks(12, EvolutionPath.SOUL_RENDER, true, 12) == 12 && EvolutionLogic.cleaveCooldownTicks(20, EvolutionPath.SOUL_RENDER, true, 12) >= 12, "bekleme asla 12 altına inmez");
		check(EvolutionLogic.cleaveCooldownTicks(30, EvolutionPath.SOUL_RENDER, false, 12) == 30 && EvolutionLogic.cleaveCooldownTicks(30, EvolutionPath.BLOOD_WHIRL, true, 12) == 30, "yalnız Ruh dalı + Son Eşik");

		// ---- İvme ----
		int m = 0; for (int i = 0; i < 50; i++) m = EvolutionLogic.momentumAfterHit(m, 1.0);
		check(m == 10, "ivme 10'da durur");
		check(EvolutionLogic.momentumAfterHit(5, 0.3) == 4 && EvolutionLogic.momentumAfterHit(0, 0.3) == 0, "zayıf vuruş ivmeyi azaltır, negatif olmaz");
		int d = 10; long lastHit = 0; for (long t = 1; t < 400; t++) d = EvolutionLogic.momentumAfterTick(d, t, lastHit, false);
		check(d == 0, "ivme boşta tamamen çözülür: " + d);
		int f = 10; for (long t = 1; t < 400; t++) f = EvolutionLogic.momentumAfterTick(f, t, 0, true);
		check(f == 6, "Son Eşik'te ivme tabanı: " + f);
		check(EvolutionLogic.momentumAfterTick(5, 30, 0, false) == 5, "gecikme bitmeden çözülmez");

		// ---- Son Eşik koşulları ----
		var ok = EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 80, 1000, 0, Recovery.NONE, 30, false);
		check(ok == FinalCheck.OK, "Son Eşik uygun: " + ok);
		check(EvolutionLogic.canStartFinal(false, true, EvolutionStage.SURGE, 80, 1000, 0, Recovery.NONE, 30, false) == FinalCheck.NO_PATH, "dalsız olmaz");
		check(EvolutionLogic.canStartFinal(true, false, EvolutionStage.SURGE, 80, 1000, 0, Recovery.NONE, 30, false) == FinalCheck.NOT_HOLDING, "baltasız olmaz");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.AWAKENING, 80, 1000, 0, Recovery.NONE, 30, false) == FinalCheck.STAGE_TOO_LOW, "Taşkınlık gerekli");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 49, 1000, 0, Recovery.NONE, 30, false) == FinalCheck.NOT_ENOUGH_ESSENCE, "öz gerekli");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 80, 1000, 1001, Recovery.NONE, 30, false) == FinalCheck.COOLDOWN, "bekleme");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 80, 1000, 0, Recovery.BURNOUT, 30, false) == FinalCheck.RECOVERING, "toparlanırken olmaz");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 80, 1000, 0, Recovery.NONE, 90, false) == FinalCheck.OVERLOADED, "aşırı yüklüyken olmaz");
		check(EvolutionLogic.canStartFinal(true, true, EvolutionStage.SURGE, 80, 1000, 0, Recovery.NONE, 30, true) == FinalCheck.ALREADY_ACTIVE, "zaten aktifken olmaz");

		// ---- Dal değişikliği ----
		check(EvolutionLogic.canChangePath(-1, 0, EvolutionStage.NONE, false, 0, 0) == PathChange.OK, "ilk seçim serbest");
		check(EvolutionLogic.canChangePath(-1, 0, EvolutionStage.SURGE, true, 0, 99999) == PathChange.OK, "ilk seçim her durumda");
		check(EvolutionLogic.canChangePath(0, 0, EvolutionStage.NONE, false, 0, 0) == PathChange.SAME, "aynı dal");
		check(EvolutionLogic.canChangePath(0, 1, EvolutionStage.SPARK, false, 99999, 0) == PathChange.IN_USE, "aşamadayken değişmez");
		check(EvolutionLogic.canChangePath(0, 1, EvolutionStage.NONE, true, 99999, 0) == PathChange.COMBAT, "savaşta değişmez");
		check(EvolutionLogic.canChangePath(0, 1, EvolutionStage.NONE, false, 100, 6000) == PathChange.COOLDOWN, "bekleme");
		check(EvolutionLogic.canChangePath(0, 1, EvolutionStage.NONE, false, 6000, 6000) == PathChange.OK, "bekleme sonrası");
		check(EvolutionLogic.canChangePath(0, 7, EvolutionStage.NONE, false, 6000, 0) == PathChange.INVALID && EvolutionLogic.canChangePath(0, -1, EvolutionStage.NONE, false, 6000, 0) == PathChange.INVALID, "geçersiz dal");

		// ---- Ölümden kurtulma ----
		check(EvolutionLogic.canDefy(EvolutionPath.LAST_BREATH, 1, 20, 100, 0), "kurtulma uygun");
		check(!EvolutionLogic.canDefy(EvolutionPath.LAST_BREATH, 0, 20, 100, 0), "aşamasız olmaz");
		check(!EvolutionLogic.canDefy(EvolutionPath.LAST_BREATH, 1, 10, 100, 0), "öz yetersiz");
		check(!EvolutionLogic.canDefy(EvolutionPath.LAST_BREATH, 1, 20, 100, 101), "bekleme");
		check(!EvolutionLogic.canDefy(EvolutionPath.BLOOD_WHIRL, 3, 90, 100, 0), "yalnız Son Nefes dalı");

		// ---- Kalıcı veri ----
		var data = new EvolutionData(5, 500.0, java.util.List.of(5, -3), -1, -1, -1);
		check(data.path() == -1 && data.essence() == 100.0 && data.mastery().size() == 3 && data.mastery().get(1) == 0 && data.finalReadyTick() == 0, "veri doğrulaması: " + data);
		var d2 = EvolutionData.EMPTY.withPath(1).withMastery(EvolutionPath.SOUL_RENDER, 77).withEssence(-5);
		check(d2.path() == 1 && d2.masteryPoints(EvolutionPath.SOUL_RENDER) == 77 && d2.essence() == 0, "veri güncellemeleri");

		// ---- Karma simülasyon: 60 sn spam (zayıf vuruş + aynı hedef) toplam öz sınırı ----
		WindowLimiter lim = new WindowLimiter(20, 14); double essence = 0; long hits = 0;
		for (long t = 0; t < 1200; t++) { // her tick bir vuruş (imkânsız hız), tam şarj, aynı hedef
			double g = EvolutionLogic.meleeGain(1.0, 20, (int) Math.min(hits, 99), 1.4, 1.0);
			essence = Math.min(100, essence + lim.limit(g, t)); hits++;
		}
		check(essence == 100, "spam öz tavanında kalır (aşılamaz): " + essence);

		System.out.println(fails == 0 ? "EVRİM TESTLERİ GEÇTİ" : fails + " EVRİM TESTİ BAŞARISIZ");
		System.exit(fails == 0 ? 0 : 1);
	}
}
