import java.util.Random;

import com.battleaxe.execution.ExecutionConfig;
import com.battleaxe.execution.ExecutionLogic;
import com.battleaxe.execution.ExecutionTiming;

/** Minecraft gerektirmeyen Execution testleri. Çalıştırma: tools/test/run_tests.sh */
public final class ExecutionLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) {
		float r = ExecutionConfig.HEALTH_RATIO;
		check(r == 0.30F, "eşik %30");
		// Can eşiği (20 azami can: 6 HP ve altı)
		check(ExecutionLogic.healthQualifies(6.0F, 20.0F, r), "6/20 tam %30 uygun");
		check(ExecutionLogic.healthQualifies(4.0F, 20.0F, r), "4/20 uygun");
		check(ExecutionLogic.healthQualifies(0.5F, 20.0F, r), "0.5/20 uygun");
		check(!ExecutionLogic.healthQualifies(6.5F, 20.0F, r), "6.5/20 uygun değil");
		check(!ExecutionLogic.healthQualifies(20.0F, 20.0F, r), "tam can uygun değil");
		check(!ExecutionLogic.healthQualifies(10.0F, 20.0F, r), "yarı can uygun değil");
		// Farklı azami can
		check(ExecutionLogic.healthQualifies(12.0F, 40.0F, r), "12/40 uygun");
		check(!ExecutionLogic.healthQualifies(13.0F, 40.0F, r), "13/40 uygun değil");
		// Geçersiz değerler asla uygun sayılmaz
		check(!ExecutionLogic.healthQualifies(0.0F, 20.0F, r), "ölü (0 can) uygun değil");
		check(!ExecutionLogic.healthQualifies(-1.0F, 20.0F, r), "negatif can uygun değil");
		check(!ExecutionLogic.healthQualifies(5.0F, 0.0F, r), "azami can 0 uygun değil");
		check(!ExecutionLogic.healthQualifies(Float.NaN, 20.0F, r), "NaN can uygun değil");
		check(!ExecutionLogic.healthQualifies(5.0F, Float.NaN, r), "NaN azami can uygun değil");

		// Şarj
		check(ExecutionLogic.strongEnough(1.0F, ExecutionConfig.MIN_ATTACK_STRENGTH), "tam şarj yeterli");
		check(ExecutionLogic.strongEnough(0.9F, ExecutionConfig.MIN_ATTACK_STRENGTH), "0.9 şarj yeterli");
		check(!ExecutionLogic.strongEnough(0.5F, ExecutionConfig.MIN_ATTACK_STRENGTH), "yarım şarj yetersiz (kol sallama spam'i)");

		// Bekleme süresi
		check(ExecutionLogic.cooldownReady(100L, 0L), "hiç olmadıysa hazır");
		check(!ExecutionLogic.cooldownReady(100L, 160L), "bekleme sürüyor");
		check(ExecutionLogic.cooldownReady(160L, 160L), "bekleme doldu (eşit)");
		check(ExecutionLogic.cooldownReady(160L, 100L), "bekleme geçti");
		check(ExecutionLogic.cooldownReady(10L, 10L + 24L * 60L * 60L * 20L + 5L), "saçma uzak gelecek zamanı takılı bırakmaz");

		// Olasılık
		Random rnd = new Random(1234);
		int hits = 0;
		int n = 100_000;
		for (int i = 0; i < n; i++) {
			if (ExecutionLogic.roll(rnd, ExecutionConfig.CHANCE)) {
				hits++;
			}
		}
		double rate = hits / (double) n;
		check(Math.abs(rate - 0.25) < 0.01, "olasılık ~%25 (ölçülen " + rate + ")");
		check(!ExecutionLogic.roll(rnd, 0.0) && !ExecutionLogic.roll(rnd, -1.0), "olasılık 0 asla başarmaz");
		check(ExecutionLogic.roll(rnd, 1.0), "olasılık 1 her zaman başarır");
		check(ExecutionConfig.CHANCE == 0.25, "başlangıç olasılığı %25");

		// Yön (yaw)
		check(Math.abs(ExecutionLogic.yawToward(0.0, 1.0) - 0.0F) < 1e-3, "+Z = yaw 0 (güney)");
		check(Math.abs(ExecutionLogic.yawToward(-1.0, 0.0) - 90.0F) < 1e-3, "-X = yaw 90 (batı)");
		check(Math.abs(ExecutionLogic.yawToward(1.0, 0.0) + 90.0F) < 1e-3, "+X = yaw -90 (doğu)");
		check(Math.abs(Math.abs(ExecutionLogic.yawToward(0.0, -1.0)) - 180.0F) < 1e-3, "-Z = yaw 180 (kuzey)");

		// Mesafe
		check(ExecutionLogic.within(3.0, 0.0, 4.0, 5.0), "3-4-5 tam sınırda içeride");
		check(!ExecutionLogic.within(3.0, 0.1, 4.0, 5.0), "sınırın dışında");

		// Zaman çizelgesi
		ExecutionTiming zombie = new ExecutionTiming(new int[] {11}, 16, 3);
		ExecutionTiming skeleton = new ExecutionTiming(new int[] {7, 12}, 15, 2);
		check(zombie.swingAt(11) && !zombie.swingAt(10) && !zombie.swingAt(16), "zombi tek savurma 11");
		check(skeleton.swingAt(7) && skeleton.swingAt(12) && !skeleton.swingAt(15), "iskelet çift savurma 7 ve 12");
		check(zombie.windupEffectAt(0) && zombie.windupEffectAt(3) && !zombie.windupEffectAt(4), "zombi hazırlık efekti 3 tickte bir");
		check(!zombie.windupEffectAt(16) && !skeleton.windupEffectAt(16), "darbe anından sonra hazırlık efekti yok");
		check(zombie.secondsToImpact() >= 0.7 && zombie.secondsToImpact() <= 1.5, "zombi süresi hedef aralıkta");
		check(skeleton.secondsToImpact() >= 0.7 && skeleton.secondsToImpact() <= 1.5, "iskelet süresi hedef aralıkta");
		check(zombie.impactTick() != skeleton.impactTick() && zombie.swingTicks().length != skeleton.swingTicks().length, "iki animasyon farklı ritimde");

		// Geçersiz zaman çizelgeleri reddedilir
		check(throwsOnBuild(new int[] {16}, 16), "savurma = darbe geçersiz");
		check(throwsOnBuild(new int[] {12, 8}, 16), "azalan savurma geçersiz");
		check(throwsOnBuild(new int[0], 16), "savurmasız geçersiz");
		check(throwsOnBuild(new int[] {0}, 16), "0. tick savurma geçersiz");

		// Güvenlik sabitleri
		check(ExecutionConfig.FINISH_DAMAGE > 100.0F, "son darbe kesin öldürücü");
		check(ExecutionConfig.ABORT_DISTANCE > ExecutionConfig.MAX_START_DISTANCE, "iptal mesafesi başlangıç mesafesinden büyük");
		check(ExecutionConfig.PLAYER_COOLDOWN_TICKS >= 20, "oyuncu beklemesi >= 1 sn");

		if (failed == 0) {
			System.out.println("ExecutionLogicTest: tüm testler geçti.");
		} else {
			System.out.println("ExecutionLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}

	static boolean throwsOnBuild(int[] swings, int impact) {
		try {
			new ExecutionTiming(swings, impact, 3);
			return false;
		} catch (IllegalArgumentException e) {
			return true;
		}
	}
}
