import com.battleaxe.boss.KaraKorukConfig;
import com.battleaxe.boss.KaraKorukLogic;
import com.battleaxe.boss.KaraKorukLogic.*;
import java.util.*;

/** Kara Körük savaş durum makinesi testleri (Minecraft gerektirmez). */
public class KaraKorukBrainTest {
	static int fails = 0;
	static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("BAŞARISIZ: " + msg); } }
	static Inputs in(double dist, boolean los, boolean charge, double hp) { return new Inputs(true, dist, los, charge, false, hp, 0.99); }

	public static void main(String[] a) {
		// Yakın: Dövme Darbesi; ilk bekleme bitmeden başlamaz
		Brain b = new Brain();
		int started = -1;
		for (int t = 0; t < 200; t++) { if (b.step(in(3, true, true, 1.0)) == Event.SLAM_WINDUP_START) { started = t; break; } }
		check(started == KaraKorukConfig.SLAM_INITIAL_COOLDOWN_TICKS - 1, "ilk darbe başlangıç beklemesinden sonra: " + started);
		// hazırlık tam süre sürer ve darbe VURUR (hedef uzaklaşsa bile)
		int ticks = 0; Event e = Event.NONE;
		while (e != Event.SLAM_STRIKE && ticks < 100) { e = b.step(new Inputs(false, 99, false, false, false, 1.0, 0.5)); ticks++; }
		check(e == Event.SLAM_STRIKE && ticks == KaraKorukConfig.SLAM_WINDUP_TICKS - 0, "hedef kaçsa da darbe vurur, hazırlık süresi " + ticks);
		check(b.slamCooldown() == KaraKorukConfig.SLAM_COOLDOWN_TICKS, "bekleme darbede kurulur");

		// Menzil seçimi
		b = freshReady();
		check(b.step(in(15, true, false, 1.0)) == Event.EMBER_WINDUP_START, "orta mesafe: Kor Mermisi");
		b = freshReady();
		check(b.step(in(15, false, false, 1.0)) == Event.NONE, "görüş yoksa mermi yok");
		b = freshReady();
		check(b.step(in(6, true, true, 1.0)) == Event.NONE, "çok yakın değil/uzak değil: ne mermi ne hücum");
		b = freshReady();
		check(b.step(in(30, true, true, 1.0)) == Event.NONE, "çok uzakta saldırı yok (menzil dışı)");
		b = freshReady();
		check(b.step(in(20, true, true, 1.0)) == Event.CHARGE_WINDUP_START, "uzak (>=16) ve yol varsa hücum");
		b = freshReady();
		check(b.step(in(20, true, false, 1.0)) == Event.EMBER_WINDUP_START, "yol yoksa uzakta mermi");
		b = freshReady();
		check(b.step(new Inputs(true, 12, true, true, false, 1.0, 0.1)) == Event.CHARGE_WINDUP_START, "orta mesafe, düşük zar: hücum");
		b = freshReady();
		check(b.step(new Inputs(true, 12, true, true, false, 1.0, 0.9)) == Event.EMBER_WINDUP_START, "orta mesafe, yüksek zar: mermi");
		b = freshReady();
		check(b.step(in(3, true, true, 1.0)) == Event.SLAM_WINDUP_START, "yakında darbe önceliklidir");

		// Mermi: hazırlık -> savurma -> TAM BİR fırlatma
		b = freshReady(); b.step(in(15, true, false, 1.0));
		int launches = 0, guard = 0;
		while (!(b.isIdle()) && guard++ < 200) { if (b.step(in(15, true, false, 1.0)) == Event.EMBER_LAUNCH) launches++; }
		check(launches == 1, "mermi saldırısı tam bir kez fırlatır: " + launches);
		check(b.emberCooldown() > 0 && b.globalGap() > 0, "bitişte bekleme ve nefes boşluğu");

		// Hücum: zaman aşımı ve erken bitiş
		b = freshReady(); b.step(in(20, true, true, 1.0));
		int begins = 0, ends = 0; guard = 0;
		while (guard++ < 300) { Event ev = b.step(in(20, true, true, 1.0)); if (ev == Event.CHARGE_BEGIN) begins++; if (ev == Event.CHARGE_END) ends++; if (b.isIdle()) break; }
		check(begins == 1 && ends == 1, "hücum bir kez başlar bir kez biter");
		check(guard <= KaraKorukConfig.CHARGE_WINDUP_TICKS + KaraKorukConfig.CHARGE_MAX_TICKS + KaraKorukConfig.CHARGE_RECOVER_TICKS + 3, "hücum zaman aşımıyla biter: " + guard);
		b = freshReady(); b.step(in(20, true, true, 1.0));
		for (int i = 0; i < KaraKorukConfig.CHARGE_WINDUP_TICKS; i++) b.step(in(20, true, true, 1.0));
		check(b.attack() == Attack.CHARGING, "hücum başladı");
		check(b.step(new Inputs(true, 2, true, true, true, 1.0, 0.5)) == Event.CHARGE_END, "hedefe ulaşınca hücum biter");
		b = freshReady(); b.step(in(20, true, true, 1.0));
		for (int i = 0; i < KaraKorukConfig.CHARGE_WINDUP_TICKS; i++) b.step(in(20, true, true, 1.0));
		check(b.step(new Inputs(false, 0, false, false, false, 1.0, 0.5)) == Event.CHARGE_END, "hedef kaybolunca hücum biter");

		// Aynı tick'te ikinci ağır saldırı yok, aralarında boşluk var: 10.000 tick karışık simülasyon
		b = new Brain(); Random r = new Random(7);
		int heavy = 0; int lastHeavyStart = -1000; boolean ok = true; int minGapSeen = 9999;
		for (int t = 0; t < 10000; t++) {
			double hp = Math.max(0.05, 1.0 - t / 12000.0);
			Event ev = b.step(new Inputs(r.nextInt(10) != 0, 2 + r.nextDouble() * 30, r.nextBoolean(), r.nextBoolean(), r.nextInt(30) == 0, hp, r.nextDouble()));
			if (ev == Event.SLAM_WINDUP_START || ev == Event.EMBER_WINDUP_START || ev == Event.CHARGE_WINDUP_START) {
				if (b.attack() == Attack.IDLE) ok = false;
				heavy++; minGapSeen = Math.min(minGapSeen, t - lastHeavyStart); lastHeavyStart = t;
			}
			if (b.slamCooldown() < 0 || b.emberCooldown() < 0 || b.chargeCooldown() < 0 || b.globalGap() < 0) ok = false;
		}
		check(ok && heavy > 20, "karışık simülasyon tutarlı, saldırı sayısı: " + heavy);
		check(minGapSeen > KaraKorukConfig.PHASE2_GLOBAL_GAP_TICKS, "saldırı başlangıçları arası boşluk: " + minGapSeen);

		// Bekleme süreleri saldırı sırasında SIFIRLANMAZ (abort bile): kalan süre korunur
		b = freshReady(); b.step(in(15, true, false, 1.0));
		while (!b.isIdle()) b.step(in(15, true, false, 1.0));
		int cd = b.emberCooldown();
		b.abort();
		check(b.emberCooldown() == cd && b.isIdle(), "abort bekleme süresini korur");
		check(b.step(in(15, true, false, 1.0)) == Event.NONE, "bekleme sürerken yeni mermi yok");

		// İkinci aşama: tek yönlü mandal
		b = new Brain();
		b.step(in(40, true, false, 0.49));
		check(b.phaseTwo(), "can %50 altında ikinci aşama");
		for (int i = 0; i < 100; i++) b.step(in(40, true, false, 1.0));
		check(b.phaseTwo(), "can iyileşse bile ikinci aşama geri dönmez");
		Brain p1 = new Brain(); Brain p2 = new Brain(); p2.step(in(40, true, false, 0.3));
		check(cooldownAfterEmber(p2) < cooldownAfterEmber(p1), "ikinci aşamada bekleme kısalır");
		check(windupOfSlam(p2) >= KaraKorukConfig.PHASE2_MIN_SLAM_WINDUP_TICKS && windupOfSlam(p2) < windupOfSlam(p1), "ikinci aşama hazırlık kısalır ama kaçılabilir kalır: " + windupOfSlam(p2));
		check(windupOfSlam(p1) == KaraKorukConfig.SLAM_WINDUP_TICKS, "birinci aşamada tam hazırlık");
		Brain restored = new Brain(); restored.restorePhaseTwo(true);
		check(restored.phaseTwo(), "yüklemede ikinci aşama geri yüklenir");

		// İlerleme 0-1
		b = freshReady(); b.step(in(3, true, false, 1.0));
		float prev = -1; boolean mono = true;
		while (b.attack() == Attack.SLAM_WINDUP) { float p = b.progress(); if (p < prev) mono = false; prev = p; b.step(in(3, true, false, 1.0)); }
		check(mono && prev > 0.9f, "hazırlık ilerlemesi artar: " + prev);
		check(new Brain().progress() == 0.0f, "boşta ilerleme 0");

		// Sayısal tutarlılık (kaçılabilirlik): hazırlık en az ~1 sn, mermi hazırlığı en az ~0.8 sn
		check(KaraKorukConfig.SLAM_WINDUP_TICKS >= 20 && KaraKorukConfig.EMBER_WINDUP_TICKS >= 16, "hazırlıklar kaçmaya yeterli");
		check(KaraKorukConfig.EMBER_SPEED * 20 < 30, "mermi hızı makul");

		System.out.println(fails == 0 ? "KARA KÖRÜK TESTLERİ GEÇTİ" : fails + " KARA KÖRÜK TESTİ BAŞARISIZ");
		System.exit(fails == 0 ? 0 : 1);
	}

	/** Tüm bekleme süreleri dolmuş, boşta bir beyin. */
	static Brain freshReady() {
		Brain b = new Brain();
		for (int i = 0; i < 400; i++) b.step(new Inputs(false, 99, false, false, false, 1.0, 0.5));
		return b;
	}
	static int cooldownAfterEmber(Brain b) {
		Brain c = b;
		for (int i = 0; i < 400; i++) c.step(new Inputs(false, 99, false, false, false, b.phaseTwo() ? 0.3 : 1.0, 0.5));
		c.step(in(15, true, false, b.phaseTwo() ? 0.3 : 1.0));
		while (!c.isIdle()) c.step(in(15, true, false, b.phaseTwo() ? 0.3 : 1.0));
		return c.emberCooldown();
	}
	static int windupOfSlam(Brain b) {
		Brain c = b;
		for (int i = 0; i < 400; i++) c.step(new Inputs(false, 99, false, false, false, b.phaseTwo() ? 0.3 : 1.0, 0.5));
		c.step(in(3, true, false, b.phaseTwo() ? 0.3 : 1.0));
		int n = 0;
		while (c.attack() == Attack.SLAM_WINDUP) { c.step(in(3, true, false, 1.0)); n++; }
		return n;
	}
}
