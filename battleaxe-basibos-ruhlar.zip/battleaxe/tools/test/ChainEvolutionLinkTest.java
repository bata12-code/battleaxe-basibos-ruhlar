import com.battleaxe.chain.ChainLogic;
import com.battleaxe.evolution.EvolutionConfig;
import com.battleaxe.evolution.EvolutionLogic;

/** Kıyım Zinciri - Evrim (Savaş Özü) bağlantısı testleri. Minecraft gerektirmez. */
public final class ChainEvolutionLinkTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	public static void main(String[] args) {
		check(EvolutionLogic.chainEssence(0) == 0.0 && EvolutionLogic.chainEssence(-3) == 0.0, "kademe 0 ve negatif öz vermez");
		double previous = 0.0;
		for (int tier = 1; tier <= ChainLogic.MAX_TIER; tier++) {
			double gain = EvolutionLogic.chainEssence(tier);
			check(gain > previous, "yüksek kademe daha çok öz verir t" + tier);
			check(gain <= EvolutionConfig.GAIN_WINDOW_CAP, "tek ödül kazanım penceresini aşmaz t" + tier + " (" + gain + ")");
			previous = gain;
		}
		check(EvolutionLogic.chainEssence(99) == EvolutionLogic.chainEssence(4), "4. kademenin üstü sayılmaz");
		check(EvolutionLogic.chainEssence(ChainLogic.MAX_TIER) < EvolutionConfig.MAX_ESSENCE * 0.1, "en büyük ödül azami özün %10'undan az");
		check(EvolutionLogic.chainEssence(1) == EvolutionConfig.CHAIN_TIER_ESSENCE, "kademe 1 = temel miktar");

		// Kötüye kullanım koruması: ödül sınırlayıcıdan geçer; art arda kademe atlamalar pencere sınırını aşamaz.
		EvolutionLogic.WindowLimiter limiter = new EvolutionLogic.WindowLimiter(EvolutionConfig.GAIN_WINDOW_TICKS, EvolutionConfig.GAIN_WINDOW_CAP);
		double total = 0.0;
		for (int i = 0; i < 10; i++) {
			total += limiter.limit(EvolutionLogic.chainEssence(4), 100L);
		}
		check(total <= EvolutionConfig.GAIN_WINDOW_CAP + 1.0E-9, "aynı pencerede en çok sınır kadar öz");
		double later = limiter.limit(EvolutionLogic.chainEssence(4), 100L + EvolutionConfig.GAIN_WINDOW_TICKS);
		check(later == EvolutionLogic.chainEssence(4), "yeni pencerede ödül tam alınır");

		if (failed == 0) {
			System.out.println("ChainEvolutionLinkTest: tüm testler geçti.");
		} else {
			System.out.println("ChainEvolutionLinkTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}
}
