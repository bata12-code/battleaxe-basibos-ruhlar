import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.SplittableRandom;

import com.battleaxe.call.AllWatchingLogic;
import com.battleaxe.call.AnomalyWhisperLogic;
import com.battleaxe.call.AllWatchingLogic.Phase;
import com.battleaxe.call.CallMoon;
import com.battleaxe.call.OmenCategory;
import com.battleaxe.call.OmenConfig;
import com.battleaxe.call.OmenGeometry;
import com.battleaxe.call.OmenKind;
import com.battleaxe.call.OmenLogic;
import com.battleaxe.call.OmenShapes;
import com.battleaxe.call.SunAnomalyLogic;
import com.battleaxe.call.SunAnomalyShapes;

/** Kozmik Anomaliler saf mantık testleri (Minecraft gerektirmez). Çalıştırma: tools/test/run_tests.sh */
public final class AnomalyLogicTest {
	static int failed = 0;

	static void check(boolean ok, String name) {
		if (!ok) {
			failed++;
			System.out.println("BAŞARISIZ: " + name);
		}
	}

	static boolean near(double a, double b, double eps) {
		return Math.abs(a - b) <= eps;
	}

	public static void main(String[] args) {
		kinds();
		masks();
		scheduling();
		placement();
		sunCalendar();
		sunGeometry();
		sunShapes();
		allWatching();
		whispers();
		ringsGeometry();
		if (failed == 0) {
			System.out.println("AnomalyLogicTest: tüm testler geçti.");
		} else {
			System.out.println("AnomalyLogicTest: " + failed + " test başarısız.");
			System.exit(1);
		}
	}

	// ------------------------------------------------------------------

	static void kinds() {
		Set<Integer> ids = new HashSet<>();
		EnumSet<OmenCategory> categories = EnumSet.noneOf(OmenCategory.class);
		for (OmenKind k : OmenKind.values()) {
			check(ids.add(k.id()), "kimlik benzersiz " + k);
			check(k.id() >= 0 && k.id() < OmenKind.COUNT, "kimlik aralıkta " + k);
			check(k.bit() == (1 << k.id()), "bit doğru " + k);
			check(OmenKind.byId(k.id()) == k, "gidiş-dönüş " + k);
			check(k.legacy() == (k.id() < OmenKind.LEGACY_COUNT), "legacy tanımı " + k);
			categories.add(k.category());
		}
		check(OmenKind.byId(-1) == null && OmenKind.byId(OmenKind.COUNT) == null && OmenKind.byId(99) == null, "geçersiz kimlik null");
		check(categories.size() == OmenCategory.values().length, "her kategori en az bir türde temsil edilir");
		// Eski dört belirtinin kimlikleri DEĞİŞMEDİ (kayıtlı 'görüldü' maskesi bozulmasın)
		check(OmenKind.SKY_AXE.id() == 0 && OmenKind.WATCHER_EYE.id() == 1 && OmenKind.HORIZON_COLOSSUS.id() == 2 && OmenKind.IMPOSSIBLE_STRUCTURE.id() == 3, "eski kimlikler sabit");
		check(OmenKind.LEGACY_MASK == 0b1111, "eski maske");
		check(OmenKind.COUNT == OmenKind.values().length && OmenKind.COUNT <= 16, "COUNT doğru ve maske 16 bite sığar");
		// Anlam: büyük/küçük, görüntülü/görüntüsüz, çizelgeli/günlük
		check(OmenKind.ALL_WATCHING.category() == OmenCategory.OBSERVER && !OmenKind.ALL_WATCHING.visual() && !OmenKind.ALL_WATCHING.major(), "bütün canlılar: gözlemci, görüntüsüz, küçük");
		check(OmenKind.FRACTURED_SUN.category() == OmenCategory.WORLD && !OmenKind.FRACTURED_SUN.scheduled() && !OmenKind.FRACTURED_SUN.major(), "parçalanmış güneş: dünya, günlük, çizelgesiz");
		check(OmenKind.SECOND_MOON.category() == OmenCategory.CELESTIAL && OmenKind.MONOLITH.category() == OmenKind.HORIZON_COLOSSUS.category(), "kategoriler");
		check(OmenKind.IMPOSSIBLE_RINGS.major() && OmenKind.MONOLITH.major() && OmenKind.SECOND_MOON.major(), "büyük olaylar");
		for (OmenKind k : OmenKind.values()) {
			if (k.legacy()) {
				check(k.scheduled() && k.major() && k.visual(), "eski türler çizelgeli, büyük, görüntülü " + k);
			}
		}
	}

	static void masks() {
		// Ortam: (ana dünya, açık gökyüzü, yağış, ton, yolculuk)
		OmenLogic.Env night = new OmenLogic.Env(true, true, false, OmenLogic.TONE_NIGHT, 0.0);
		OmenLogic.Env dusk = new OmenLogic.Env(true, true, false, OmenLogic.TONE_TWILIGHT, 0.0);
		OmenLogic.Env day = new OmenLogic.Env(true, true, false, OmenLogic.TONE_DAY, 0.0);
		OmenLogic.Env unknownTone = new OmenLogic.Env(true, true, false, OmenLogic.TONE_UNKNOWN, 0.0);
		int nm = OmenLogic.anomalyMask(night);
		check((nm & OmenKind.SECOND_MOON.bit()) != 0 && (nm & OmenKind.IMPOSSIBLE_RINGS.bit()) != 0 && (nm & OmenKind.MONOLITH.bit()) != 0 && (nm & OmenKind.ALL_WATCHING.bit()) != 0, "gece: dört anomali de uygun");
		int dm = OmenLogic.anomalyMask(dusk);
		check((dm & OmenKind.SECOND_MOON.bit()) == 0 && (dm & OmenKind.IMPOSSIBLE_RINGS.bit()) != 0, "alacakaranlık: halkalar evet, ikinci ay hayır");
		int gm = OmenLogic.anomalyMask(day);
		check((gm & OmenKind.MONOLITH.bit()) != 0, "gündüz: monolith uygun (gündüz de tetiklenebilir)");
		check((gm & OmenKind.SECOND_MOON.bit()) == 0 && (gm & OmenKind.IMPOSSIBLE_RINGS.bit()) == 0, "gündüz: ay ve halkalar uygun değil");
		check((OmenLogic.anomalyMask(unknownTone) & OmenKind.MONOLITH.bit()) != 0, "zaman bilinmiyor: monolith yine uygun");
		// Gökyüzü kapalı / yağış: görsel anomaliler kapanır; Bütün Canlılar mağarada da olur
		OmenLogic.Env cave = new OmenLogic.Env(true, false, false, OmenLogic.TONE_NIGHT, 0.0);
		int cm = OmenLogic.anomalyMask(cave);
		check(cm == OmenKind.ALL_WATCHING.bit(), "kapalı gökyüzü: yalnızca bütün canlılar");
		OmenLogic.Env rain = new OmenLogic.Env(true, true, true, OmenLogic.TONE_NIGHT, 0.0);
		check(OmenLogic.anomalyMask(rain) == OmenKind.ALL_WATCHING.bit(), "yağmur: yalnızca bütün canlılar");
		check(OmenLogic.anomalyMask(new OmenLogic.Env(false, true, false, OmenLogic.TONE_NIGHT, 0.0)) == 0, "başka boyut: hiçbiri");
		check(OmenLogic.anomalyMask(null) == 0, "null ortam: hiçbiri");
		// Eski maske anlamı değişmedi: yeni türleri HİÇ içermez
		for (OmenLogic.Env e : new OmenLogic.Env[] {night, dusk, day, unknownTone, cave, rain}) {
			check((OmenLogic.eligibleMask(e) & ~OmenKind.LEGACY_MASK) == 0, "eligibleMask yalnızca eski türleri kapsar");
			check((OmenLogic.anomalyMask(e) & OmenKind.LEGACY_MASK) == 0, "anomalyMask yalnızca yeni türleri kapsar");
			check((OmenLogic.anomalyMask(e) & OmenKind.FRACTURED_SUN.bit()) == 0, "parçalanmış güneş çizelgeye girmez");
		}
	}

	static void scheduling() {
		// Bekleme
		for (OmenKind k : OmenKind.values()) {
			long cd = OmenLogic.kindCooldown(k);
			check(cd >= 0, "bekleme negatif değil " + k);
			check(OmenLogic.kindReady(k, 0L, 5L), "hiç gösterilmediyse hazır " + k);
			if (cd > 0) {
				check(!OmenLogic.kindReady(k, 100_000L, 100_000L + cd - 1), "bekleme dolmadan hazır değil " + k);
				check(OmenLogic.kindReady(k, 100_000L, 100_000L + cd), "bekleme dolunca hazır " + k);
				check(OmenLogic.kindReady(k, 100_000L, 50L), "zaman geri giderse takılı kalmaz " + k);
			}
		}
		check(OmenLogic.kindCooldown(OmenKind.SKY_AXE) == 0 && OmenLogic.kindCooldown(OmenKind.FRACTURED_SUN) == 0, "eski türler ve güneşte tür beklemesi yok");
		check(OmenLogic.kindCooldown(OmenKind.ALL_WATCHING) >= OmenLogic.kindCooldown(OmenKind.MONOLITH), "bütün canlılar en seyrek olaylardan");
		// Hafıza çarpanı: sınırlı, kendine ve geçersize 1; yalnızca ihtimali artırır
		for (OmenKind last : OmenKind.values()) {
			for (OmenKind k : OmenKind.values()) {
				double m = OmenLogic.memoryBoost(last.id(), k);
				check(m >= 1.0 && m <= 3.0, "hafıza çarpanı 1..3 " + last + "->" + k);
				if (last == k) {
					check(m == 1.0, "aynı tür kendini çağırmaz " + k);
				}
			}
		}
		check(OmenLogic.memoryBoost(-1, OmenKind.MONOLITH) == 1.0 && OmenLogic.memoryBoost(99, OmenKind.MONOLITH) == 1.0, "geçersiz son tür: etki yok");
		check(OmenLogic.memoryBoost(OmenKind.SECOND_MOON.id(), OmenKind.IMPOSSIBLE_RINGS) > 1.0, "ikinci aydan sonra halkalar biraz daha olası");
		check(OmenLogic.memoryBoost(OmenKind.IMPOSSIBLE_RINGS.id(), OmenKind.WATCHER_EYE) > 1.0, "halkalardan sonra göz biraz daha olası");
		check(OmenLogic.memoryBoost(OmenKind.MONOLITH.id(), OmenKind.SECOND_MOON) > 1.0, "monolith'ten sonra ikinci ay biraz daha olası");
		// Zorunlu zincir YOK: hafızayla bile hiçbir tür %100 değildir; her uygun tür hâlâ seçilebilir
		OmenLogic.Env night = new OmenLogic.Env(true, true, false, OmenLogic.TONE_NIGHT, 0.0);
		int mask = OmenLogic.anomalyMask(night);
		SplittableRandom r = new SplittableRandom(11);
		int[] counts = new int[OmenKind.COUNT];
		for (int i = 0; i < 40_000; i++) {
			OmenKind pick = OmenLogic.choose(r, mask, 3, 0, OmenKind.SECOND_MOON.id());
			counts[pick.id()]++;
		}
		check(counts[OmenKind.SECOND_MOON.id()] == 0, "aynı tür art arda seçilmez");
		check(counts[OmenKind.IMPOSSIBLE_RINGS.id()] > 0 && counts[OmenKind.MONOLITH.id()] > 0 && counts[OmenKind.ALL_WATCHING.id()] > 0, "hafızaya rağmen diğer türler de seçilir (zorunlu zincir yok)");
		check(counts[OmenKind.IMPOSSIBLE_RINGS.id()] < 40_000 * 0.8, "hiçbir tür baskın değil (halkalar " + counts[OmenKind.IMPOSSIBLE_RINGS.id()] + ")");
		// Sıklık farkı: Monolith ve Bütün Canlılar, İkinci Ay ve Halkalardan erişilebilir (varsayılan ağırlıklar)
		int[] fresh = new int[OmenKind.COUNT];
		for (int i = 0; i < 40_000; i++) {
			fresh[OmenLogic.choose(r, mask, 3, 0, -1).id()]++;
		}
		check(fresh[OmenKind.MONOLITH.id()] > fresh[OmenKind.IMPOSSIBLE_RINGS.id()], "monolith halkalardan sık");
		check(fresh[OmenKind.ALL_WATCHING.id()] > fresh[OmenKind.IMPOSSIBLE_RINGS.id()], "bütün canlılar halkalardan sık");
		check(fresh[OmenKind.IMPOSSIBLE_RINGS.id()] > 0 && fresh[OmenKind.SECOND_MOON.id()] > 0, "nadir olaylar yine de olur");
		for (OmenKind k : OmenKind.values()) {
			if (k.scheduled()) {
				check(OmenLogic.weight(k, 5, 0) > 0.0, "çizelgeli türün ağırlığı pozitif " + k);
			}
		}
		check(OmenLogic.weight(OmenKind.FRACTURED_SUN, 5, 0) == 0.0, "güneşin çizelge ağırlığı 0");
		// Süreler aralıkta ve varyantlar 11 bite sığar
		for (OmenKind k : OmenKind.values()) {
			for (int i = 0; i < 500; i++) {
				int v = OmenLogic.makeVariant(r, k);
				check((v & ~OmenLogic.VARIANT_MASK) == 0, "varyant maskeye sığar " + k);
				int d = OmenLogic.duration(r, k);
				check(d >= 20 && d <= 8000, "süre makul " + k + " " + d);
			}
		}
		check(OmenConfig.MONOLITH_WARP_APPROACH_BLOCKS < OmenConfig.MONOLITH_VANISH_APPROACH_BLOCKS, "perspektif bozulması, sönmeden önce başlar");
		check(OmenConfig.MONOLITH_VANISH_TRAVEL_BLOCKS > OmenConfig.MONOLITH_VANISH_APPROACH_BLOCKS, "yürüyüş sınırı yaklaşma sınırından büyük");
		check(OmenConfig.MONOLITH_VANISH_TRAVEL_BLOCKS <= 400.0, "oyuncu sonsuza dek yürümek zorunda kalmaz");
		check(OmenConfig.POST_AXE_CHANCE_MULTIPLIER > 0.0 && OmenConfig.POST_AXE_CHANCE_MULTIPLIER <= 1.0, "balta sonrası çarpan makul");
		check(!OmenConfig.TEST_MODE, "TEST_MODE yayın sürümünde KAPALI olmalı");
	}

	static void placement() {
		SplittableRandom r = new SplittableRandom(5);
		double[] moon = CallMoon.moonDirection(0.5);
		for (int i = 0; i < 4000; i++) {
			double yaw = r.nextDouble() * 360.0 - 180.0;
			double pitch = -r.nextDouble() * 50.0;
			OmenLogic.Placement sm = OmenLogic.place(r, OmenKind.SECOND_MOON, yaw, pitch, i % 2 == 0 ? moon : null);
			check(sm.elevation() >= 18.0 && sm.elevation() <= 62.0, "ikinci ay yüksekliği aralıkta " + sm.elevation());
			check(Double.isFinite(sm.azimuth()), "ikinci ay yönü sonlu");
			OmenLogic.Placement rg = OmenLogic.place(r, OmenKind.IMPOSSIBLE_RINGS, yaw, pitch, i % 2 == 0 ? moon : null);
			check(rg.elevation() >= 30.0 && rg.elevation() <= 62.0, "halka yüksekliği aralıkta " + rg.elevation());
			OmenLogic.Placement mn = OmenLogic.place(r, OmenKind.MONOLITH, yaw, 3.0, null);
			check(mn.elevation() == OmenLogic.MONOLITH_BASE_ELEVATION, "monolith tabanı ufukta");
			check(Math.abs(OmenGeometry.wrap180(mn.azimuth() - yaw)) <= 55.0 + 1e-6, "monolith bakışın yakınında");
			OmenLogic.Placement co = OmenLogic.place(r, OmenKind.HORIZON_COLOSSUS, yaw, 3.0, null);
			check(co.elevation() == OmenLogic.COLOSSUS_BASE_ELEVATION, "dev tabanı ufukta");
		}
		// Taban ufuk çizgisine çok yakın: düz bir ovada gerçek ufuk ~ -0.5 derece
		check(OmenLogic.MONOLITH_BASE_ELEVATION >= -1.0 && OmenLogic.MONOLITH_BASE_ELEVATION <= 0.0, "monolith tabanı gerçek ufka yakın");
		check(OmenLogic.COLOSSUS_BASE_ELEVATION >= -1.0 && OmenLogic.COLOSSUS_BASE_ELEVATION <= 0.0, "dev tabanı gerçek ufka yakın");
		// Bazen gerçek ayın yakınında (her iki yer de gerçekleşir)
		int near = 0;
		int far = 0;
		for (int i = 0; i < 4000; i++) {
			OmenLogic.Placement sm = OmenLogic.place(r, OmenKind.SECOND_MOON, 0.0, -30.0, moon);
			double moonAz = Math.toDegrees(Math.atan2(-moon[0], moon[2]));
			double moonEl = Math.toDegrees(Math.asin(moon[1]));
			double ang = OmenGeometry.angleDegrees(OmenGeometry.direction(sm.azimuth(), sm.elevation()), OmenGeometry.direction(moonAz, moonEl));
			if (ang < 40.0) {
				near++;
			} else {
				far++;
			}
		}
		check(near > 400 && far > 400, "ikinci ay hem ayın yakınında hem başka yerde doğar (" + near + "/" + far + ")");
		// Bakış koşulları
		check(OmenLogic.lookAllows(OmenKind.ALL_WATCHING, 80.0) && OmenLogic.lookAllows(OmenKind.FRACTURED_SUN, -80.0), "görüntüsüz/günlük türler bakışa bağlı değil");
		check(OmenLogic.lookAllows(OmenKind.SECOND_MOON, -20.0) && !OmenLogic.lookAllows(OmenKind.SECOND_MOON, 20.0), "ikinci ay: bakış yukarıda olmalı");
		check(OmenLogic.lookAllows(OmenKind.MONOLITH, 0.0), "monolith: ufka bakarken");
	}

	// ------------------------------------------------------------------

	static void sunCalendar() {
		long seed = 123456789L;
		double chance = 0.045;
		int spacing = 6;
		int minDay = 3;
		// Determinizm
		for (long day = 0; day < 2000; day++) {
			check(SunAnomalyLogic.stateForDay(true, seed, day, chance, spacing, minDay) == SunAnomalyLogic.stateForDay(true, seed, day, chance, spacing, minDay), "deterministik gün " + day);
			double h = SunAnomalyLogic.hash(seed, day, 1);
			check(h >= 0.0 && h < 1.0, "karma 0-1");
		}
		check(SunAnomalyLogic.hash(seed, 10, 1) != SunAnomalyLogic.hash(seed + 1, 10, 1), "farklı dünya farklı takvim");
		// Uzun dönem: sıklık, aralık, ilk sakin günler, iz yalnızca ertesi gün
		int events = 0;
		long lastEvent = -1000;
		int[] variants = new int[5];
		int scars = 0;
		long days = 60_000;
		for (long day = 0; day < days; day++) {
			boolean event = SunAnomalyLogic.isEventDay(seed, day, chance, spacing, minDay);
			int state = SunAnomalyLogic.stateForDay(true, seed, day, chance, spacing, minDay);
			if (event) {
				events++;
				check(day >= minDay, "ilk sakin günlerde olay yok");
				check(day - lastEvent >= spacing, "iki olay arası en az " + spacing + " gün (" + lastEvent + "," + day + ")");
				check(state >= SunAnomalyLogic.PARTIAL && state <= SunAnomalyLogic.SHATTERED, "olay günü 1-3 varyasyon");
				variants[state]++;
				lastEvent = day;
			} else if (state == SunAnomalyLogic.SCAR) {
				scars++;
				check(SunAnomalyLogic.isEventDay(seed, day - 1, chance, spacing, minDay), "iz yalnızca olay gününden SONRAKİ gün");
			} else {
				check(state == SunAnomalyLogic.NONE, "diğer günler normal");
			}
		}
		double rate = events / (double) days;
		check(rate > 0.012 && rate < chance, "olay sıklığı çok nadir ama sıfır değil: " + rate);
		check(variants[SunAnomalyLogic.PARTIAL] > variants[SunAnomalyLogic.CRACKED] && variants[SunAnomalyLogic.CRACKED] > variants[SunAnomalyLogic.SHATTERED] && variants[SunAnomalyLogic.SHATTERED] > 0, "A > B > C ve hepsi görülür " + java.util.Arrays.toString(variants));
		check(scars > 0 && scars < events, "iz bazen olur, her olayı izlemez (" + scars + "/" + events + ")");
		// Kapalıyken hiçbir gün
		for (long day = 0; day < 5000; day++) {
			check(SunAnomalyLogic.stateForDay(false, seed, day, chance, spacing, minDay) == SunAnomalyLogic.NONE, "kapalıyken olay yok");
		}
		check(!SunAnomalyLogic.isEventDay(seed, 100, 0.0, spacing, minDay) && !SunAnomalyLogic.isEventDay(seed, 100, -1.0, spacing, minDay), "olasılık 0: olay yok");
		check(!SunAnomalyLogic.isEventDay(seed, 2, 1.0, spacing, 3), "minDay öncesi hiç olay yok (olasılık 1 bile olsa)");
		// Gün hesabı: negatif zaman sarılır; gün içi zaman 0..23999
		check(SunAnomalyLogic.dayOf(0) == 0 && SunAnomalyLogic.dayOf(23_999) == 0 && SunAnomalyLogic.dayOf(24_000) == 1, "gün sayısı");
		check(SunAnomalyLogic.dayOf(-1) == -1 && SunAnomalyLogic.timeOfDay(-1) == 23_999 && SunAnomalyLogic.timeOfDay(24_000) == 0, "negatif zaman sarılır");
		for (long t = -50_000; t < 100_000; t += 777) {
			long tod = SunAnomalyLogic.timeOfDay(t);
			check(tod >= 0 && tod < 24_000 && SunAnomalyLogic.dayOf(t) * 24_000L + tod == t, "gün ve zaman birleşir t=" + t);
		}
		// Görsel tohum: negatif değil ve aynı gün için kararlı
		for (long day = 0; day < 500; day++) {
			check(SunAnomalyLogic.visualSeed(seed, day) >= 0 && SunAnomalyLogic.visualSeed(seed, day) == SunAnomalyLogic.visualSeed(seed, day), "görsel tohum geçerli");
		}
		// Çok oyunculu tutarlılık: aynı (tohum, gün) -> aynı durum; hesap yalnızca bu girdilere bağlı
		for (long day = 0; day < 3000; day++) {
			int a = SunAnomalyLogic.stateForDay(true, seed, day, chance, spacing, minDay);
			int b = SunAnomalyLogic.stateForDay(true, seed, day, chance, spacing, minDay);
			check(a == b, "iki oyuncu aynı güneşi görür");
		}
		// Ayarlar: TEST_MODE kapalıyken yayın değerleri nadir
		check(OmenConfig.FRACTURED_SUN_DAY_CHANCE <= 0.1 && OmenConfig.FRACTURED_SUN_SPACING_DAYS >= 4, "yayında güneş olayı çok nadir ve aralıklı");
	}

	static void sunGeometry() {
		for (double celestial = 0.0; celestial < 1.0; celestial += 0.01) {
			double[] sun = SunAnomalyLogic.sunDirection(celestial);
			double[] moon = CallMoon.moonDirection(celestial);
			check(near(sun[0], -moon[0], 1e-12) && near(sun[1], -moon[1], 1e-12) && near(sun[2], -moon[2], 1e-12), "güneş ayın tam karşısında c=" + celestial);
			check(near(Math.sqrt(sun[0] * sun[0] + sun[1] * sun[1] + sun[2] * sun[2]), 1.0, 1e-9), "güneş yönü birim vektör");
			double el = SunAnomalyLogic.sunElevationDegrees(celestial);
			check(near(el, Math.toDegrees(Math.asin(sun[1])), 1e-6), "yükseklik yön vektörüyle tutarlı");
			check(el >= -90.0 && el <= 90.0, "yükseklik aralıkta");
		}
		// Öğle (celestial 0.0) güneş tepede; gece yarısı (0.5) ufkun altında
		check(SunAnomalyLogic.sunElevationDegrees(0.0) > 80.0, "öğlen güneş tepede");
		check(SunAnomalyLogic.sunElevationDegrees(0.5) < -80.0, "gece yarısı güneş ufkun altında");
	}


	static void sunShapes() {
		check(SunAnomalyShapes.build(SunAnomalyLogic.NONE, 1).length == 0 && SunAnomalyShapes.build(99, 1).length == 0 && SunAnomalyShapes.build(-1, 1).length == 0, "olay yoksa/geçersizse parça yok");
		check(SunAnomalyShapes.SUN_HALF_TAN > 0.08 && SunAnomalyShapes.SUN_HALF_TAN < 0.2, "güneş karesinin boyutu makul");
		double[] avg = new double[5];
		int seeds = 300;
		for (int variant = SunAnomalyLogic.PARTIAL; variant <= SunAnomalyLogic.SCAR; variant++) {
			for (long seed = 0; seed < seeds; seed++) {
				SunAnomalyShapes.Piece[] pieces = SunAnomalyShapes.build(variant, seed);
				check(pieces.length >= 1 && pieces.length <= SunAnomalyShapes.MAX_PIECES, "parça sayısı sınırlı v" + variant + " s" + seed + " n=" + pieces.length);
				boolean anyInside = false;
				double area = 0.0;
				for (SunAnomalyShapes.Piece p : pieces) {
					check(p.xy().length % 2 == 0 && p.xy().length / 2 >= 3 && p.xy().length / 2 <= SunAnomalyShapes.MAX_POINTS, "köşe sayısı sınırlı v" + variant);
					check(p.alpha() > 0.0F && p.alpha() <= 1.0F, "saydamlık geçerli");
					boolean inside = true;
					for (float c : p.xy()) {
						check(Float.isFinite(c) && Math.abs(c) <= SunAnomalyShapes.FRAGMENT_LIMIT + 1e-4F, "koordinat sonlu ve sınırlı v" + variant + " " + c);
						if (Math.abs(c) > SunAnomalyShapes.BODY_LIMIT + 1e-4F) {
							inside = false;
						}
					}
					if (inside) {
						anyInside = true;
						if (!p.dim()) {
							area += polygonAreaXY(p.xy());
						}
					}
				}
				check(anyInside, "güneşin gövdesinde en az bir parça v" + variant);
				avg[variant] += area / seeds;
				check(java.util.Arrays.equals(flatten(pieces), flatten(SunAnomalyShapes.build(variant, seed))), "deterministik v" + variant);
			}
			check(!java.util.Arrays.equals(flatten(SunAnomalyShapes.build(variant, 1)), flatten(SunAnomalyShapes.build(variant, 2))), "tohum şekli değiştirir v" + variant);
		}
		check(avg[SunAnomalyLogic.SHATTERED] > avg[SunAnomalyLogic.PARTIAL] * 1.4, "ağır parçalanma kısmiden belirgin daha çok kaplar " + java.util.Arrays.toString(avg));
		check(avg[SunAnomalyLogic.PARTIAL] > avg[SunAnomalyLogic.SCAR] * 3.0, "iz neredeyse hiçbir şey kaplamaz " + java.util.Arrays.toString(avg));
		check(avg[SunAnomalyLogic.SHATTERED] > avg[SunAnomalyLogic.CRACKED], "ağır parçalanma çatlaktan daha çok kaplar");
		check(avg[SunAnomalyLogic.SHATTERED] > 0.45 * 4.0 * 0.5 * 0.4, "ağır parçalanma karenin önemli bir bölümü (alan " + avg[SunAnomalyLogic.SHATTERED] + ")");
		// Kısmi parçalanma bir KÖŞEYE oturur: köşelerden birinde kenara taşan köşe vardır
		int corners = 0;
		for (long seed = 0; seed < 100; seed++) {
			boolean atCorner = false;
			for (SunAnomalyShapes.Piece p : SunAnomalyShapes.build(SunAnomalyLogic.PARTIAL, seed)) {
				for (int i = 0; i < p.xy().length; i += 2) {
					if (Math.abs(p.xy()[i]) >= SunAnomalyShapes.BODY_LIMIT - 1e-4F && Math.abs(p.xy()[i + 1]) >= SunAnomalyShapes.BODY_LIMIT - 1e-4F) {
						atCorner = true;
					}
				}
			}
			if (atCorner) {
				corners++;
			}
		}
		check(corners == 100, "kısmi parçalanmada her zaman bir köşe kopar (" + corners + ")");
		// Güneş karesinin yerel eksenleri: dik ve birim; e2 güneşin yolu boyunca; e1 sabit
		for (double c = 0.0; c < 1.0; c += 0.013) {
			double[] f = SunAnomalyShapes.frame(c);
			double[] s = SunAnomalyLogic.sunDirection(c);
			check(near(f[0], s[0], 1e-9) && near(f[1], s[1], 1e-9) && near(f[2], s[2], 1e-9), "çerçevenin güneş yönü = güneş yönü c=" + c);
			double[] e1 = {f[3], f[4], f[5]};
			double[] e2 = {f[6], f[7], f[8]};
			check(near(dot(e1, e1), 1.0, 1e-9) && near(dot(e2, e2), 1.0, 1e-9), "eksenler birim");
			check(near(dot(e1, e2), 0.0, 1e-9) && near(dot(e1, s), 0.0, 1e-9) && near(dot(e2, s), 0.0, 1e-9), "eksenler birbirine ve güneş yönüne dik c=" + c);
			// e2, güneşin hareket yönüdür: küçük bir ilerlemede güneş e2 yönünde yer değiştirir
			double[] s2 = SunAnomalyLogic.sunDirection(c + 1e-6);
			double[] d = {s2[0] - s[0], s2[1] - s[1], s2[2] - s[2]};
			double len = Math.sqrt(dot(d, d));
			check(dot(d, e2) / len > 0.999999, "e2 güneşin yolu boyunca c=" + c);
		}
	}

	static double dot(double[] a, double[] b) {
		return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
	}

	static double polygonAreaXY(float[] xy) {
		double a = 0.0;
		int n = xy.length / 2;
		for (int i = 0; i < n; i++) {
			int j = (i + 1) % n;
			a += (double) xy[i * 2] * xy[j * 2 + 1] - (double) xy[j * 2] * xy[i * 2 + 1];
		}
		return Math.abs(a) / 2.0;
	}

	static float[] flatten(SunAnomalyShapes.Piece[] pieces) {
		int n = 0;
		for (SunAnomalyShapes.Piece p : pieces) {
			n += p.xy().length + 1;
		}
		float[] out = new float[n];
		int k = 0;
		for (SunAnomalyShapes.Piece p : pieces) {
			out[k++] = p.alpha();
			System.arraycopy(p.xy(), 0, out, k, p.xy().length);
			k += p.xy().length;
		}
		return out;
	}

	// ------------------------------------------------------------------

	static void allWatching() {
		// Tür süzgeci: yalnızca vanilla; boss/özel ve mod mobları hariç
		check(AllWatchingLogic.eligibleType("minecraft:zombie") && AllWatchingLogic.eligibleType("minecraft:cow") && AllWatchingLogic.eligibleType("minecraft:villager") && AllWatchingLogic.eligibleType("minecraft:skeleton"), "sıradan moblar uygun");
		for (String banned : new String[] {"minecraft:ender_dragon", "minecraft:wither", "minecraft:warden", "minecraft:elder_guardian", "minecraft:creaking", "minecraft:player", "minecraft:armor_stand"}) {
			check(!AllWatchingLogic.eligibleType(banned), "boss/özel hariç " + banned);
		}
		check(!AllWatchingLogic.eligibleType("battleaxe:kara_koruk") && !AllWatchingLogic.eligibleType("othermod:thing"), "mod mobları hariç (Kara Körük dâhil)");
		check(!AllWatchingLogic.eligibleType(null) && !AllWatchingLogic.eligibleType("") && !AllWatchingLogic.eligibleType("minecraft:") && !AllWatchingLogic.eligibleType("zombie"), "geçersiz kimlikler hariç");
		check(AllWatchingLogic.TAG.startsWith("battleaxe_") && !AllWatchingLogic.TAG.equals("battleaxe_execution"), "etiket kendine özgü (Execution'la karışmaz)");
		check(AllWatchingLogic.enoughMobs(OmenConfig.ALL_WATCHING_MIN_MOBS) && !AllWatchingLogic.enoughMobs(OmenConfig.ALL_WATCHING_MIN_MOBS - 1), "yeterli mob eşiği");
		// Gecikmeler sınırlı, kusursuz senkron değil
		Set<Integer> delays = new HashSet<>();
		Set<Integer> jitters = new HashSet<>();
		for (int i = 0; i <= 1000; i++) {
			double roll = i / 1000.0;
			int d = AllWatchingLogic.startDelay(roll);
			int j = AllWatchingLogic.releaseJitter(roll);
			check(d >= 0 && d < OmenConfig.ALL_WATCHING_STAGGER_TICKS, "başlama gecikmesi sınırlı");
			check(j >= 0 && j < AllWatchingLogic.RELEASE_JITTER_TICKS, "serbest kalma farkı sınırlı");
			delays.add(d);
			jitters.add(j);
		}
		check(delays.size() > 10 && jitters.size() > 5, "moblar kusursuz senkron değil (gecikmeler çeşitli)");
		check(AllWatchingLogic.startDelay(Double.NaN) == 0 && AllWatchingLogic.startDelay(-5.0) == 0 && AllWatchingLogic.startDelay(9.0) < OmenConfig.ALL_WATCHING_STAGGER_TICKS, "uç zarlar güvenli");
		// Aşamalar: önce normal, sonra bakar, sonra serbest; asla geriye dönmez
		for (int delay = 0; delay < OmenConfig.ALL_WATCHING_STAGGER_TICKS; delay += 5) {
			for (int duration : new int[] {OmenConfig.ALL_WATCHING_MIN_TICKS, OmenConfig.ALL_WATCHING_MAX_TICKS}) {
				for (int jitter : new int[] {0, 7, AllWatchingLogic.RELEASE_JITTER_TICKS - 1}) {
					Phase prev = Phase.WAIT;
					boolean sawWatch = false;
					for (int t = 0; t < duration + 80; t++) {
						Phase p = AllWatchingLogic.phase(t, delay, duration, jitter);
						check(p.ordinal() >= prev.ordinal(), "aşama geriye dönmez t=" + t);
						if (p == Phase.WATCH) {
							sawWatch = true;
						}
						prev = p;
					}
					check(sawWatch && prev == Phase.DONE, "her mob bakar ve sonunda serbest kalır");
					check(AllWatchingLogic.phase(0, delay + 1, duration, jitter) == Phase.WAIT, "sırası gelmeden normal davranır");
					check(AllWatchingLogic.phase(duration + 100, delay, duration, jitter) == Phase.DONE, "olay bitince serbest");
				}
			}
		}
		check(AllWatchingLogic.messageDue(OmenConfig.ALL_WATCHING_MESSAGE_DELAY_TICKS, false) && !AllWatchingLogic.messageDue(0, false) && !AllWatchingLogic.messageDue(500, true), "mesaj bir kez, moblar döndükten sonra");
		check(OmenConfig.ALL_WATCHING_MESSAGE_DELAY_TICKS < OmenConfig.ALL_WATCHING_MIN_TICKS, "mesaj olay bitmeden gelir");
		check(OmenConfig.ALL_WATCHING_MAX_TICKS <= 200, "olay çok kısa (en çok 10 sn)");
		check(OmenConfig.ALL_WATCHING_MAX_MOBS <= 40 && OmenConfig.ALL_WATCHING_RADIUS <= 32.0, "olay sınırlı yarıçap ve mob sayısı (performans)");
		// Açı matematiği
		check(near(AllWatchingLogic.wrapDegrees(190), -170, 1e-4) && near(AllWatchingLogic.wrapDegrees(-190), 170, 1e-4) && near(AllWatchingLogic.wrapDegrees(540), 180, 1e-4) && near(AllWatchingLogic.wrapDegrees(0), 0, 1e-9), "wrapDegrees");
		check(AllWatchingLogic.wrapDegrees(Float.NaN) == 0.0F && AllWatchingLogic.wrapDegrees(Float.POSITIVE_INFINITY) == 0.0F, "wrapDegrees sonsuz/NaN güvenli");
		SplittableRandom r = new SplittableRandom(9);
		for (int i = 0; i < 5000; i++) {
			float cur = (float) (r.nextDouble() * 720.0 - 360.0);
			float target = (float) (r.nextDouble() * 720.0 - 360.0);
			float step = 22.0F;
			float next = AllWatchingLogic.turnToward(cur, target, step);
			float before = Math.abs(AllWatchingLogic.wrapDegrees(target - cur));
			float after = Math.abs(AllWatchingLogic.wrapDegrees(target - next));
			check(Math.abs(next - cur) <= step + 1e-3F, "tick başına dönüş sınırlı");
			check(after <= before + 1e-3F, "hedefe yaklaşır, uzaklaşmaz");
			// Birkaç tikte hedefe kilitlenir (en kısa yoldan)
			float x = cur;
			for (int k = 0; k < 10; k++) {
				x = AllWatchingLogic.turnToward(x, target, step);
			}
			check(Math.abs(AllWatchingLogic.wrapDegrees(target - x)) < 1e-2F, "en çok 9 tikte hedefe varır");
		}
		check(AllWatchingLogic.turnToward(10.0F, 50.0F, 0.0F) == 10.0F && AllWatchingLogic.turnToward(10.0F, 50.0F, -5.0F) == 10.0F, "adım 0/negatifse dönmez");
		// Bakış yönleri (Minecraft kuralı: +Z = 0, +X = -90, -X = +90, -Z = 180)
		check(near(AllWatchingLogic.yawTo(0, 1), 0, 1e-4) && near(AllWatchingLogic.yawTo(1, 0), -90, 1e-4) && near(AllWatchingLogic.yawTo(-1, 0), 90, 1e-4) && near(Math.abs(AllWatchingLogic.yawTo(0, -1)), 180, 1e-4), "yatay bakış yönleri");
		check(near(AllWatchingLogic.pitchTo(0, 5), 0, 1e-4) && AllWatchingLogic.pitchTo(5, 5) < 0 && AllWatchingLogic.pitchTo(-5, 5) > 0 && near(AllWatchingLogic.pitchTo(5, 5), -45, 1e-3), "dikey bakış: yukarı negatif");
		check(Float.isFinite(AllWatchingLogic.pitchTo(3, 0)) && Float.isFinite(AllWatchingLogic.yawTo(0, 0)), "sıfır mesafe güvenli");
	}


	static void whispers() {
		check(AnomalyWhisperLogic.hasLine(OmenKind.SECOND_MOON) && AnomalyWhisperLogic.hasLine(OmenKind.IMPOSSIBLE_RINGS) && AnomalyWhisperLogic.hasLine(OmenKind.MONOLITH), "gökyüzü/ufuk anomalilerinin sözü var");
		check(!AnomalyWhisperLogic.hasLine(OmenKind.ALL_WATCHING) && !AnomalyWhisperLogic.hasLine(OmenKind.FRACTURED_SUN) && !AnomalyWhisperLogic.hasLine(OmenKind.SKY_AXE), "diğerlerinin balta sözü yok");
		check(AnomalyWhisperLogic.key(OmenKind.ALL_WATCHING, 0) == null, "sözü olmayan tür null");
		check(AnomalyWhisperLogic.allKeys().size() == 9 && new HashSet<>(AnomalyWhisperLogic.allKeys()).size() == 9, "9 söz, benzersiz");
		check(AnomalyWhisperLogic.key(OmenKind.MONOLITH, 99).equals(AnomalyWhisperLogic.key(OmenKind.MONOLITH, 2)) && AnomalyWhisperLogic.key(OmenKind.MONOLITH, -3).equals(AnomalyWhisperLogic.key(OmenKind.MONOLITH, 0)), "bant sınırlanır");
		check(AnomalyWhisperLogic.CHANCE > 0.0 && AnomalyWhisperLogic.CHANCE < 1.0, "bazen konuşur, her zaman değil");
		check(AnomalyWhisperLogic.shouldSpeak(OmenKind.MONOLITH, 0.0) && !AnomalyWhisperLogic.shouldSpeak(OmenKind.MONOLITH, 0.99) && !AnomalyWhisperLogic.shouldSpeak(OmenKind.ALL_WATCHING, 0.0), "konuşma kararı");
		for (int i = 0; i <= 200; i++) {
			int d = AnomalyWhisperLogic.delay(i / 200.0);
			check(d >= AnomalyWhisperLogic.MIN_DELAY_TICKS && d <= AnomalyWhisperLogic.MAX_DELAY_TICKS, "gecikme aralıkta");
		}
		check(AnomalyWhisperLogic.delay(Double.NaN) == AnomalyWhisperLogic.MIN_DELAY_TICKS && AnomalyWhisperLogic.delay(5.0) == AnomalyWhisperLogic.MAX_DELAY_TICKS, "uç zarlar güvenli");
		check(AnomalyWhisperLogic.MIN_DELAY_TICKS >= 100, "oyuncu önce anomaliyi görsün (en az 5 sn)");
		// Çeviri bütünlüğü: her anahtar iki dil dosyasında da var ve boş değil; tüm yeni anahtarlar
		java.util.List<String> keys = new java.util.ArrayList<>(AnomalyWhisperLogic.allKeys());
		keys.add("message.battleaxe.anomaly.all_watching");
		for (String lang : new String[] {"tr_tr", "en_us"}) {
			String json;
			try {
				json = java.nio.file.Files.readString(java.nio.file.Path.of("src/main/resources/assets/battleaxe/lang/" + lang + ".json"), java.nio.charset.StandardCharsets.UTF_8);
			} catch (java.io.IOException e) {
				check(false, "dil dosyası okunamadı " + lang);
				continue;
			}
			for (String key : keys) {
				int at = json.indexOf("\"" + key + "\"");
				check(at >= 0, lang + " dosyasında eksik: " + key);
				if (at >= 0) {
					int open = json.indexOf('"', json.indexOf(':', at));
					int close = json.indexOf('"', open + 1);
					check(close - open > 8, lang + " metni çok kısa: " + key);
				}
			}
		}
	}

	// ------------------------------------------------------------------

	static void ringsGeometry() {
		// Halkalar: her tohumda çok sayıda ayrı halka gövdesi ve (kesişimler varsa) döngüsel üst-alt düzeltme yamaları bulunur.
		int withPatches = 0;
		int total = 0;
		for (long seed = 0; seed < 400; seed++) {
			for (int count = 0; count < 2; count++) {
				int variant = (count << 3) | 1;
				OmenShapes.Scene s = OmenShapes.build(OmenKind.IMPOSSIBLE_RINGS, variant, seed);
				int bodies = 0;
				int patches = 0;
				for (OmenShapes.Poly p : s.polys()) {
					boolean ring = p.outline() && (p.style() == OmenShapes.S_BODY || p.style() == OmenShapes.S_MID);
					if (ring && p.x().length > 40) {
						bodies++;
					} else if (ring) {
						patches++;
					}
				}
				check(bodies == 3 + count, "halka sayısı varyanta uyar " + bodies);
				total++;
				if (patches >= 2) {
					withPatches++;
				}
				check(patches <= 12, "yama sayısı sınırlı " + patches);
			}
		}
		check(withPatches > total * 0.8, "halkaların çoğunda kesişim yamaları (döngüsel üst-alt) var (" + withPatches + "/" + total + ")");
		// Göz ve yok: bit 2 gözü ekler
		boolean eyeSeen = false;
		OmenShapes.Scene withEye = OmenShapes.build(OmenKind.IMPOSSIBLE_RINGS, 4, 7);
		OmenShapes.Scene noEye = OmenShapes.build(OmenKind.IMPOSSIBLE_RINGS, 0, 7);
		for (OmenShapes.Poly p : withEye.polys()) {
			if (p.group() == 1) {
				eyeSeen = true;
			}
		}
		check(eyeSeen && withEye.polys().length > noEye.polys().length, "hafıza: halkaların merkezinde göz belirir");
		for (OmenShapes.Poly p : noEye.polys()) {
			check(p.group() == 0, "göz yoksa bebek grubu yok");
		}
		// İkinci ay varyasyonları gerçekten farklı görünür
		for (int a = 0; a < 4; a++) {
			for (int b = a + 1; b < 4; b++) {
				check(!sameScene(OmenShapes.build(OmenKind.SECOND_MOON, a, 9), OmenShapes.build(OmenKind.SECOND_MOON, b, 9)), "ikinci ay görünümleri farklı " + a + b);
			}
		}
		// Boyut: gerçek aydan (yaklaşık 5 derece yarıçap) çok daha büyük
		for (int size = 0; size < 3; size++) {
			OmenShapes.Scene s = OmenShapes.build(OmenKind.SECOND_MOON, size << 2, 3);
			check(s.halfWidth() >= 10.0F, "ikinci ay gerçek aydan çok büyük (boyut " + size + "): " + s.halfWidth());
		}
		check(OmenShapes.build(OmenKind.SECOND_MOON, 2 << 2, 3).halfWidth() > OmenShapes.build(OmenKind.SECOND_MOON, 0, 3).halfWidth(), "boyutlar farklı");
		// Yıldızsız boşluk: bit 4 karanlık kütleler ekler
		boolean hasVoid = false;
		for (OmenShapes.Poly p : OmenShapes.build(OmenKind.SECOND_MOON, 16, 3).polys()) {
			if (p.style() == OmenShapes.S_VOID) {
				hasVoid = true;
			}
		}
		boolean noVoid = true;
		for (OmenShapes.Poly p : OmenShapes.build(OmenKind.SECOND_MOON, 0, 3).polys()) {
			if (p.style() == OmenShapes.S_VOID) {
				noVoid = false;
			}
		}
		check(hasVoid && noVoid, "yıldızsız boşluk yalnızca ilgili varyantta");
		// Hilal: gövde gerçekten yalnızca bir bölüm (tam diskten küçük alan)
		check(polygonArea(mainDisc(OmenShapes.build(OmenKind.SECOND_MOON, 2, 5))) < polygonArea(mainDisc(OmenShapes.build(OmenKind.SECOND_MOON, 0, 5))) * 0.95, "kısmi görünüm tam diskten belirgin küçük");
		// Göz boyutları: büyük göz gerçekten büyük, gölgeli göz ek karanlık kütle içerir
		check(OmenShapes.build(OmenKind.WATCHER_EYE, 3 << 2, 4).halfWidth() > OmenShapes.build(OmenKind.WATCHER_EYE, 0, 4).halfWidth() * 1.4, "göz boyutu çeşitlenir");
		int voidSmall = countStyle(OmenShapes.build(OmenKind.WATCHER_EYE, 0, 4), OmenShapes.S_VOID);
		int voidShroud = countStyle(OmenShapes.build(OmenKind.WATCHER_EYE, 16, 4), OmenShapes.S_VOID);
		int voidHidden = countStyle(OmenShapes.build(OmenKind.WATCHER_EYE, 32, 4), OmenShapes.S_VOID);
		check(voidSmall == 0 && voidShroud > 0 && voidHidden > 0, "karanlık kısmen yutar: gölge ve yarı gizli varyantları");
	}

	static int countStyle(OmenShapes.Scene s, int style) {
		int n = 0;
		for (OmenShapes.Poly p : s.polys()) {
			if (p.style() == style) {
				n++;
			}
		}
		return n;
	}

	/** İkinci Ay'ın ana gövdesi (S_DEEP stili, en büyük alan). */
	static OmenShapes.Poly mainDisc(OmenShapes.Scene s) {
		OmenShapes.Poly best = null;
		double bestArea = -1;
		for (OmenShapes.Poly p : s.polys()) {
			if (p.style() == OmenShapes.S_DEEP) {
				double a = polygonArea(p);
				if (a > bestArea) {
					bestArea = a;
					best = p;
				}
			}
		}
		return best;
	}

	static double polygonArea(OmenShapes.Poly p) {
		if (p == null) {
			return 0.0;
		}
		double a = 0.0;
		int n = p.x().length;
		for (int i = 0; i < n; i++) {
			int j = (i + 1) % n;
			a += (double) p.x()[i] * p.y()[j] - (double) p.x()[j] * p.y()[i];
		}
		return Math.abs(a) / 2.0;
	}

	static boolean sameScene(OmenShapes.Scene a, OmenShapes.Scene b) {
		if (a.polys().length != b.polys().length) {
			return false;
		}
		for (int i = 0; i < a.polys().length; i++) {
			OmenShapes.Poly p = a.polys()[i];
			OmenShapes.Poly q = b.polys()[i];
			if (p.style() != q.style() || !java.util.Arrays.equals(p.x(), q.x()) || !java.util.Arrays.equals(p.y(), q.y())) {
				return false;
			}
		}
		return true;
	}
}
