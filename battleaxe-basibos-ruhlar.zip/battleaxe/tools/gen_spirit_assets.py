#!/usr/bin/env python3
"""Başıboş Ruhlar: model parçaları (Java) ve dokular TEK KAYNAKTAN üretilir.

Çıktılar:
  src/client/java/com/battleaxe/client/spirit/{Savrulmus,RuhYiyen,Zincirli}Parts.java
  src/main/resources/assets/battleaxe/textures/entity/{savrulmus_ruh,ruh_yiyen,zincirli_ruh}.png

Parça tablosu (SPEC) hem Java gövde katmanını hem de doku düzenini belirler; UV'ler otomatik yerleştirilir,
bu yüzden model ile doku asla birbirinden ayrışmaz. Aynı biçimli kutular (ör. zincir halkaları) aynı UV bölgesini paylaşır.
Çalıştırma: python3 tools/gen_spirit_assets.py   (yalnızca Pillow gerekir; oyun derlemesi bu aracı çalıştırmaz)
"""
import os
import random

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
JAVA_OUT = os.path.join(ROOT, "src", "client", "java", "com", "battleaxe", "client", "spirit")
TEX_OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "battleaxe", "textures", "entity")

# ---- Palet: siyah, soluk beyaz, mor, gerektiğinde koyu kırmızı
VOID = (10, 7, 16)
DEEP = (26, 14, 44)
VIOLET = (62, 34, 104)
LIGHT_VIOLET = (122, 78, 180)
PALE = (216, 208, 232)
BONE = (190, 182, 196)
BONE_DARK = (96, 88, 108)
RED = (110, 16, 34)
CORE_A = (178, 120, 244)
CORE_B = (252, 244, 255)
IRON = (46, 46, 60)
IRON_LIGHT = (104, 104, 126)


class P:
    """Bir model parçası: tek kutu + dönme noktası. box = (x, y, z, w, h, d); pivot = (px, py, pz)."""

    def __init__(self, name, parent, box, pivot, style):
        self.name = name
        self.parent = parent
        self.box = box
        self.pivot = pivot
        self.style = style
        self.uv = None


def chain(prefix, parent, pivot, links, style="chain"):
    """İç içe zincir halkaları: her halka bir öncekinin çocuğudur (sarkaç gibi sallanır)."""
    out = []
    for i in range(links):
        if i % 2 == 0:
            box = (-1.0, 0.0, -0.5, 2, 3, 1)
        else:
            box = (-0.5, 0.0, -1.0, 1, 3, 2)
        piv = pivot if i == 0 else (0.0, 3.0, 0.0)
        par = parent if i == 0 else "%s_%d" % (prefix, i - 1)
        out.append(P("%s_%d" % (prefix, i), par, box, piv, style))
    return out


SPEC = {}

# ---------------------------------------------------------------- Savrulmuş Ruh (64x64)
SPEC["savrulmus"] = (64, 64, [
    P("rig", None, None, (0, 0, 0), None),
    P("torso", "rig", (-3.0, -11.0, -2.0, 6, 11, 4), (0.0, 11.0, 0.0), "spirit"),
    P("head", "torso", (-3.0, -7.0, -3.0, 6, 7, 6), (0.0, -11.0, 0.0), "void"),
    P("splinter_r", "head", (-3.0, -10.0, -1.0, 1, 4, 1), (0.0, 0.0, 0.0), "bone"),
    P("splinter_l", "head", (2.0, -9.0, 0.0, 1, 3, 1), (0.0, 0.0, 0.0), "bone"),
    P("spine_0", "torso", (-0.5, -9.0, 2.0, 1, 3, 2), (0.0, 0.0, 0.0), "bone"),
    P("spine_1", "torso", (-0.5, -5.0, 2.0, 1, 3, 2), (0.0, 0.0, 0.0), "bone"),
    P("arm_r", "torso", (-1.5, 0.0, -1.5, 3, 16, 3), (-4.5, -9.5, 0.0), "spirit"),
    P("hand_r", "arm_r", (-2.0, 0.0, -2.0, 4, 3, 4), (0.0, 16.0, 0.0), "spirit"),
    P("claw_r_0", "hand_r", (-0.5, 0.0, -0.5, 1, 5, 1), (-1.5, 3.0, 0.0), "claw"),
    P("claw_r_1", "hand_r", (-0.5, 0.0, -0.5, 1, 5, 1), (0.0, 3.0, 0.0), "claw"),
    P("claw_r_2", "hand_r", (-0.5, 0.0, -0.5, 1, 5, 1), (1.5, 3.0, 0.0), "claw"),
    P("arm_l", "torso", (-1.5, 0.0, -1.5, 3, 16, 3), (4.5, -9.5, 0.0), "spirit"),
    P("hand_l", "arm_l", (-2.0, 0.0, -2.0, 4, 3, 4), (0.0, 16.0, 0.0), "spirit"),
    P("claw_l_0", "hand_l", (-0.5, 0.0, -0.5, 1, 5, 1), (-1.5, 3.0, 0.0), "claw"),
    P("claw_l_1", "hand_l", (-0.5, 0.0, -0.5, 1, 5, 1), (0.0, 3.0, 0.0), "claw"),
    P("claw_l_2", "hand_l", (-0.5, 0.0, -0.5, 1, 5, 1), (1.5, 3.0, 0.0), "claw"),
    P("wisp_a", "rig", (-2.5, 0.0, -2.0, 5, 4, 4), (0.0, 11.0, 0.0), "wisp"),
    P("wisp_b", "wisp_a", (-2.0, 0.0, -1.5, 4, 4, 3), (0.0, 4.0, 0.0), "wisp"),
    P("wisp_c", "wisp_b", (-1.0, 0.0, -1.0, 2, 3, 2), (0.0, 4.0, 0.0), "wisp"),
])

# ---------------------------------------------------------------- Ruh Yiyen (64x64)
SPEC["ruh_yiyen"] = (64, 64, [
    P("rig", None, None, (0, 0, 0), None),
    P("torso", "rig", (-3.0, -16.0, -2.0, 6, 16, 4), (0.0, 9.0, 0.0), "spirit"),
    P("core", "torso", (-2.0, -12.0, -2.6, 4, 5, 1), (0.0, 0.0, 0.0), "core"),
    P("rib_0", "torso", (-3.5, -6.0, -2.4, 7, 1, 1), (0.0, 0.0, 0.0), "rib"),
    P("rib_1", "torso", (-3.5, -4.0, -2.4, 7, 1, 1), (0.0, 0.0, 0.0), "rib"),
    P("rib_2", "torso", (-3.5, -2.0, -2.4, 7, 1, 1), (0.0, 0.0, 0.0), "rib"),
    P("head", "torso", (-2.5, -7.0, -2.5, 5, 7, 5), (0.0, -16.0, 0.0), "void"),
    P("hood", "head", (-3.0, -8.0, -3.0, 6, 3, 6), (0.0, 0.0, 0.0), "hood"),
    P("hood_point", "hood", (-1.0, -4.0, 0.0, 2, 4, 2), (0.0, -8.0, 1.0), "hood"),
    P("arm_r", "torso", (-1.0, 0.0, -1.0, 2, 18, 2), (-4.0, -14.0, 0.0), "spirit"),
    P("finger_r_0", "arm_r", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, -1.0), "claw"),
    P("finger_r_1", "arm_r", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, 0.0), "claw"),
    P("finger_r_2", "arm_r", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, 1.0), "claw"),
    P("arm_l", "torso", (-1.0, 0.0, -1.0, 2, 18, 2), (4.0, -14.0, 0.0), "spirit"),
    P("finger_l_0", "arm_l", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, -1.0), "claw"),
    P("finger_l_1", "arm_l", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, 0.0), "claw"),
    P("finger_l_2", "arm_l", (-0.5, 0.0, -0.5, 1, 6, 1), (0.0, 18.0, 1.0), "claw"),
    P("rag_r", "torso", (-1.0, 0.0, -2.0, 1, 10, 4), (-3.0, -14.0, 0.0), "wisp"),
    P("rag_l", "torso", (0.0, 0.0, -2.0, 1, 10, 4), (3.0, -14.0, 0.0), "wisp"),
    P("tail_a", "rig", (-2.0, 0.0, -1.5, 4, 5, 3), (0.0, 9.0, 0.0), "wisp"),
    P("tail_b", "tail_a", (-1.5, 0.0, -1.0, 3, 4, 2), (0.0, 5.0, 0.0), "wisp"),
    P("tail_c", "tail_b", (-1.0, 0.0, -0.5, 2, 3, 1), (0.0, 4.0, 0.0), "wisp"),
])

# ---------------------------------------------------------------- Zincirli Ruh (128x128)
_z = [
    P("rig", None, None, (0, 0, 0), None),
    P("leg_r", "rig", (-3.0, 0.0, -3.0, 6, 12, 6), (-4.0, 12.0, 0.0), "plate"),
    P("leg_l", "rig", (-3.0, 0.0, -3.0, 6, 12, 6), (4.0, 12.0, 0.0), "plate"),
    P("torso", "rig", (-7.0, -18.0, -4.0, 14, 18, 8), (0.0, 12.0, 0.0), "spirit"),
    P("chest_plate", "torso", (-6.0, -16.0, -4.8, 12, 9, 1), (0.0, 0.0, 0.0), "plate"),
    P("core", "torso", (-2.0, -11.0, -5.6, 4, 4, 1), (0.0, 0.0, 0.0), "core"),
    P("pauldron_r", "torso", (-7.0, -4.0, -5.0, 8, 6, 10), (-7.0, -16.0, 0.0), "plate"),
    P("pauldron_l", "torso", (-1.0, -4.0, -5.0, 8, 6, 10), (7.0, -16.0, 0.0), "plate"),
    P("head", "torso", (-4.0, -9.0, -4.0, 8, 9, 8), (0.0, -16.0, -1.0), "void"),
    P("horn_r", "head", (-6.0, -12.0, -1.0, 2, 7, 2), (0.0, 0.0, 0.0), "bone"),
    P("horn_l", "head", (4.0, -10.0, 1.0, 2, 5, 2), (0.0, 0.0, 0.0), "bone"),
    P("spike_0", "torso", (-1.0, -5.0, 0.0, 2, 5, 2), (0.0, -14.0, 4.0), "bone"),
    P("spike_1", "torso", (-1.0, -5.0, 0.0, 2, 5, 2), (0.0, -9.0, 4.0), "bone"),
    P("spike_2", "torso", (-1.0, -5.0, 0.0, 2, 5, 2), (0.0, -4.0, 4.0), "bone"),
    P("arm_r", "torso", (-3.0, 0.0, -3.0, 6, 18, 6), (-10.0, -14.0, 0.0), "spirit"),
    P("fist_r", "arm_r", (-4.0, 0.0, -4.0, 8, 7, 8), (0.0, 18.0, 0.0), "plate"),
    P("arm_l", "torso", (-3.0, 0.0, -3.0, 6, 18, 6), (10.0, -14.0, 0.0), "spirit"),
    P("fist_l", "arm_l", (-4.0, 0.0, -4.0, 8, 7, 8), (0.0, 18.0, 0.0), "plate"),
]
_z += chain("chain_r", "pauldron_r", (-3.0, 5.0, -3.0), 5)
_z += chain("chain_l", "pauldron_l", (3.0, 5.0, -3.0), 5)
_z += chain("chain_wr", "torso", (-6.0, -1.0, -4.0), 4)
_z += chain("chain_wl", "torso", (6.0, -1.0, -4.0), 4)
_z += chain("chain_fr", "fist_r", (0.0, 6.0, 0.0), 6)
_z += chain("chain_fl", "fist_l", (0.0, 6.0, 0.0), 5)
SPEC["zincirli"] = (128, 128, _z)

CLASS_NAMES = {"savrulmus": "Savrulmus", "ruh_yiyen": "RuhYiyen", "zincirli": "Zincirli"}
TEX_NAMES = {"savrulmus": "savrulmus_ruh", "ruh_yiyen": "ruh_yiyen", "zincirli": "zincirli_ruh"}


# ------------------------------------------------------------------ UV yerleştirme (raf paketleme)
def region_size(w, h, d):
    return (2 * d + 2 * w, d + h)


def pack(tw, th, parts):
    keys = {}
    for p in parts:
        if p.box is None:
            continue
        w, h, d = p.box[3], p.box[4], p.box[5]
        keys.setdefault((p.style, w, h, d), []).append(p)
    order = sorted(keys.keys(), key=lambda k: (-(region_size(k[1], k[2], k[3])[1]), -(region_size(k[1], k[2], k[3])[0])))
    x = y = row_h = 0
    placed = {}
    for key in order:
        rw, rh = region_size(key[1], key[2], key[3])
        if x + rw > tw:
            x = 0
            y += row_h
            row_h = 0
        if y + rh > th:
            raise SystemExit("Doku yetmedi: %s" % (key,))
        placed[key] = (x, y)
        x += rw
        row_h = max(row_h, rh)
    for key, plist in keys.items():
        for p in plist:
            p.uv = placed[key]
    return placed


# ------------------------------------------------------------------ Boyama
def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def clampf(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))


def face_pixels(style, fw, fh, rng, face):
    """Bir yüzün RGBA piksellerini (fh satır x fw sütun) üretir. gy: 0 üst, 1 alt."""
    rows = []
    streak_cols = {c: rng.random() for c in range(fw)}
    for r in range(fh):
        gy = r / max(1, fh - 1)
        row = []
        for c in range(fw):
            gx = c / max(1, fw - 1)
            n = rng.random()
            a = 255
            if style == "spirit":
                col = lerp(VOID, DEEP, 0.25 + 0.5 * n + 0.2 * gy)
                if streak_cols[c] > 0.78:
                    col = lerp(col, VIOLET, 0.55 + 0.3 * n)
                if streak_cols[c] > 0.93 and n > 0.5:
                    col = lerp(col, PALE, 0.35)
                if n > 0.985:
                    col = lerp(col, RED, 0.9)
                if gy > 0.88 and rng.random() < (gy - 0.88) * 5.0:
                    a = 0
            elif style == "wisp":
                col = lerp(DEEP, VIOLET, 0.2 + 0.5 * n)
                if n > 0.9:
                    col = lerp(col, PALE, 0.5)
                hole = 0.06 + 0.5 * gy
                if rng.random() < hole:
                    a = 0
            elif style == "void":
                col = lerp(VOID, DEEP, 0.1 + 0.25 * n + 0.2 * gy)
                if face == "front" and gy > 0.85 and 0.2 < gx < 0.8 and n > 0.6:
                    col = lerp(col, VIOLET, 0.5)
            elif style == "bone":
                col = lerp(BONE_DARK, BONE, 0.2 + 0.7 * gy)
                col = lerp(col, (0, 0, 0), 0.25 * n)
            elif style == "claw":
                col = lerp(BONE_DARK, PALE, 0.15 + 0.85 * gy)
                if gy > 0.8:
                    col = lerp(col, (255, 255, 255), 0.25)
            elif style == "core":
                dx = (gx - 0.5) * 2.0
                dy = (gy - 0.5) * 2.0
                rad = clampf((dx * dx + dy * dy) ** 0.5)
                col = lerp(CORE_B, CORE_A, rad)
                col = lerp(col, VIOLET, clampf((rad - 0.6) * 1.4))
                if n > 0.92:
                    col = lerp(col, CORE_B, 0.6)
            elif style == "rib":
                col = lerp(BONE_DARK, PALE, 0.25 + 0.5 * (1.0 - gy))
            elif style == "hood":
                col = lerp(VOID, DEEP, 0.3 + 0.4 * n)
                if gy < 0.2:
                    col = lerp(col, PALE, 0.45)
                if gx < 0.1 or gx > 0.9:
                    col = lerp(col, VIOLET, 0.4)
            elif style == "plate":
                col = lerp(IRON, IRON_LIGHT, 0.1 + 0.25 * n)
                edge = (r == 0 or c == 0 or r == fh - 1 or c == fw - 1)
                if edge:
                    col = lerp(col, VIOLET, 0.7)
                elif (r % 4 == 2 and c % 4 == 2) and fw > 5 and fh > 5:
                    col = lerp(col, PALE, 0.5)  # perçin
                if n > 0.975:
                    col = lerp(col, RED, 0.8)
            elif style == "chain":
                stripe = 0.5 + 0.5 * ((r + c) % 2)
                col = lerp(IRON, IRON_LIGHT, 0.2 + 0.5 * stripe * (0.6 + 0.4 * n))
                if n > 0.94:
                    col = lerp(col, LIGHT_VIOLET, 0.7)
            else:
                col = (255, 0, 255)
            row.append((col[0], col[1], col[2], a))
        rows.append(row)
    return rows


def paint_box(img, uv, w, h, d, style, rng):
    u, v = uv
    faces = {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }
    for name, (fx, fy, fw, fh) in faces.items():
        px = face_pixels(style, fw, fh, rng, name)
        for r in range(fh):
            for c in range(fw):
                img.putpixel((fx + c, fy + r), px[r][c])


# ------------------------------------------------------------------ Java üretimi
def fmt(v):
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s + "F"


def var(name):
    return "p_" + name


def emit_java(key, tw, th, parts):
    cls = CLASS_NAMES[key] + "Parts"
    lines = []
    lines.append("package com.battleaxe.client.spirit;")
    lines.append("")
    lines.append("import net.minecraft.client.model.geom.builders.CubeListBuilder;")
    lines.append("import net.minecraft.client.model.geom.builders.LayerDefinition;")
    lines.append("import net.minecraft.client.model.geom.builders.MeshDefinition;")
    lines.append("import net.minecraft.client.model.geom.builders.PartDefinition;")
    lines.append("import net.minecraft.client.model.geom.PartPose;")
    lines.append("")
    lines.append("/**")
    lines.append(" * ÜRETİLDİ: tools/gen_spirit_assets.py. Elle düzenleme; model parçaları ve doku düzeni o araçta tek kaynaktır.")
    lines.append(" * Tüm parçalar \"rig\" altındadır (süzülme/dağılma animasyonu tek noktadan sürülür). Doku %dx%d." % (tw, th))
    lines.append(" */")
    lines.append("final class %s {" % cls)
    lines.append("\tprivate %s() {" % cls)
    lines.append("\t}")
    lines.append("")
    lines.append("\tstatic final int TEX_W = %d;" % tw)
    lines.append("\tstatic final int TEX_H = %d;" % th)
    lines.append("")
    lines.append("\tstatic LayerDefinition create() {")
    lines.append("\t\tMeshDefinition mesh = new MeshDefinition();")
    lines.append("\t\tPartDefinition root = mesh.getRoot();")
    for p in parts:
        parent = "root" if p.parent is None else var(p.parent)
        pose = "PartPose.offset(%s, %s, %s)" % (fmt(p.pivot[0]), fmt(p.pivot[1]), fmt(p.pivot[2]))
        if p.box is None:
            cubes = "CubeListBuilder.create()"
        else:
            b = p.box
            cubes = "CubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s)" % (
                p.uv[0], p.uv[1], fmt(b[0]), fmt(b[1]), fmt(b[2]), fmt(float(b[3])), fmt(float(b[4])), fmt(float(b[5])))
        lines.append("\t\tPartDefinition %s = %s.addOrReplaceChild(\"%s\", %s, %s);" % (var(p.name), parent, p.name, cubes, pose))
    lines.append("\t\treturn LayerDefinition.create(mesh, TEX_W, TEX_H);")
    lines.append("\t}")
    lines.append("}")
    lines.append("")
    return "\n".join(lines)


def main():
    os.makedirs(JAVA_OUT, exist_ok=True)
    os.makedirs(TEX_OUT, exist_ok=True)
    for key, (tw, th, parts) in SPEC.items():
        pack(tw, th, parts)
        img = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        painted = {}
        for p in parts:
            if p.box is None:
                continue
            k = (p.style, p.box[3], p.box[4], p.box[5])
            if k in painted:
                continue
            painted[k] = True
            rng = random.Random("%s|%s|%d|%d|%d" % (key, p.style, p.box[3], p.box[4], p.box[5]))
            paint_box(img, p.uv, p.box[3], p.box[4], p.box[5], p.style, rng)
        img.save(os.path.join(TEX_OUT, TEX_NAMES[key] + ".png"))
        with open(os.path.join(JAVA_OUT, CLASS_NAMES[key] + "Parts.java"), "w", encoding="utf-8") as f:
            f.write(emit_java(key, tw, th, parts))
        print("%s: %d parça, doku %dx%d" % (key, len(parts), tw, th))


if __name__ == "__main__":
    main()
