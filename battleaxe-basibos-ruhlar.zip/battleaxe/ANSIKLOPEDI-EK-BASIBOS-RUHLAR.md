# ANSİKLOPEDİ EKİ — Başıboş Ruhlar (ilk üç tür)

(Proje ansiklopedisine yeni bir bölüm olarak eklenebilir. Ayrıntılı kurallar ve sayılar için README'deki "Başıboş Ruhlar" bölümüne bakın.)

## Lore ve kimlik

Başıboş Ruhlar, kendi boyutlarını terk edip bizim dünyamıza ulaşmış varlıklardır. Boyutlar arası geçiş onlara pahalıya mal olmuştur: güçlerinin önemli bir kısmını yitirmişlerdir.
Burada karşılaştığımız Savrulmuş Ruh, Ruh Yiyen ve Zincirli Ruh, kendi dünyalarında güçlü varlıklar DEĞİLDİR; o dünyada çok daha korkunç, gelişmiş ve tehlikeli ruh türleri vardır.
İleride o boyuta geçildiğinde karşılaşılacak düşmanlar bu üçünün çok üzerinde bir tehdit olacaktır. (Bu güncellemede o türler yoktur; yalnızca genişletilebilir ruh ailesi altyapısı vardır.)

Bunlar yaşayan canlılar değil; amacını ve kimliğini kaybetmiş düşmanca ruhsal varlıklardır. Görünüm: yarı maddesel, yarı ruhani; anatomisi hafifçe bozulmuş; koyu siyah, soluk beyaz, mor
ve gerektiğinde koyu kırmızı. Üç silüet uzaktan bile ayırt edilir: eğri ve uzun kollu Savrulmuş, uzun ince kukuletalı Ruh Yiyen, geniş omuzlu zincirli Zincirli Ruh.

Baltanın bu ruhlara tepkisi bir açıklama değildir; bir ipucudur ("Bunlar buraya ait değil", "Yurtlarında bundan çok daha aç olanlar var", "Kapının öbür yanı bundan da karanlık olmalı").
Balta bu ruhların nereden geldiğini bilip bilmediğini söylemez.

## Savaş ilkeleri

Zorluk acımasız, tutum tamamen düşmancadır; ama hilesiz: her saldırının hazırlığı, uyarısı ve karşılığı vardır. Roller: Savrulmuş hareket ettirir, Ruh Yiyen uzaktan baskı kurar ve fırsatta iyileşir,
Zincirli alanı daraltır ve ağır vurur. Aynı hedefe aynı anda yalnızca tek kontrol yeteneği uygulanır. Ruhsal doğaları gereği mermilere dirençlidirler; Savaş Baltası bedeni keser (rütbesi arttıkça daha çok).

## Sistemler arası bağlantılar

- Ruh rütbesi: baltanın rütbesi arttıkça ruhlara karşı hasarı artar; ruh ödülü sabit ve küçüktür (baltanın ruh dengesi korunur).
- Hiddet: Hiddet'teki oyuncunun kanı Ruh Yiyen için acıdır (iyileşme yarıya iner).
- Shunpo: Zincirli Ruh'un mührünü kırar (kısa bir kaçış bağışıklığıyla).
- Yar Geç ve balta vuruşları: Ruh Yiyen'in emme bağını tek vuruşta koparır; mühürleyen Zincirli Ruh'a 12+ hasar mührü koparır.
- Kıyım Zinciri: ruhlar düşman sayılır. Execution: ruhlar bitirici kataloğunda yoktur.
- Baltanın fısıltıları: bir ruhu devirince ilk kez tür başına, sonra nadiren rütbesine göre.

## Gelecek

Anormal Biyom, Ruhlar Boyutu, portallar, özel bloklar, çok daha güçlü ruhlar ve boss'lar ayrı güncellemelerdir. Altyapı hazırdır: `SpiritKind`, `SpiritEntity` tabanı, `SpiritEncounter` düzenleri ve
`SpiritSpawner` (henüz hiçbir biyom/boyuta bağlı değildir).
