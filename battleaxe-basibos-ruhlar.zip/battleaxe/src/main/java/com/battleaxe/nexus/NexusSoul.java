package com.battleaxe.nexus;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.component.ModComponents;

/**
 * Ruh Ağı ile MEVCUT ruh sisteminin (SoulManager) köprüsü.
 *
 * <p>Tek öldürme olayı, SoulManager'ın AFTER_DEATH işleyicisinde TEK SEFER işlenir: buradaki bonus hesabı
 * aynı değeri hem baltanın ruh sayacına (rütbe) hem oyuncunun ağ defterine (yetenek puanı) yazdırır.
 * Yani ikinci bir ruh ödülü ya da ikinci bir para birimi yoktur; defter yalnızca aynı olayın oyuncu tarafı
 * kaydıdır ve harcanabilir (sıfırlama) olduğu için baltanın rütbesinden ayrı tutulur.
 */
public final class NexusSoul {
	private NexusSoul() {
	}

	/**
	 * SoulManager, baltanın ruhunu artırmadan ÖNCE çağırır.
	 *
	 * @param axe baltanın (üzerinde değişiklik yapılabilen) eşyası
	 * @return baltaya yazılacak nihai ruh miktarı (bonuslu)
	 */
	public static int onKill(ServerPlayer player, LivingEntity victim, ItemStack axe, int baseValue) {
		return onKill(player, victim, axe, baseValue, 0);
	}

	/**
	 * @param extraFlat başka bir sistemin (Berserker Evrimi) AYNI öldürme olayının ödülüne eklediği düz miktar;
	 *                  ayrı bir ödül değildir, aynı değer hem baltaya hem deftere yazılır
	 */
	public static int onKill(ServerPlayer player, LivingEntity victim, ItemStack axe, int baseValue, int extraFlat) {
		NexusState state = NexusManager.state(player);
		claimLegacy(player, state, axe);

		// Aynı varlığın ölümü ikinci kez işlenmez (deftere iki kez yazılmaz).
		if (!state.markKill(victim.getUUID())) {
			return baseValue;
		}

		NexusStats stats = state.stats;
		NexusData data = state.data;

		double percent = stats.get(Stat.SOUL_GAIN_PCT);
		if (baseValue >= NexusConfig.ELITE_VALUE) {
			percent += stats.get(Stat.SOUL_ELITE_PCT);
		}
		double value = baseValue * (1.0 + percent / 100.0);
		if (baseValue >= NexusConfig.STRONG_VALUE) {
			value += stats.get(Stat.SOUL_STRONG_FLAT);
		}
		value += Math.max(0, extraFlat);

		// Bitirici öldürüş (Execution / kombo bitirici): aynı öldürme olayına eklenen düz ruh. İşaret tek kullanımlıktır.
		if (victim.getUUID().equals(state.finisherVictim) && player.level().getGameTime() <= state.finisherExpiry) {
			value += stats.get(Stat.FINISHER_KILL_SOULS);
		}
		state.finisherVictim = null;

		// Kesirli kısım kaybolmaz: bir sonraki öldürmeye taşınır (düşük değerli canlılarda da bonus işler).
		double total = value + data.soulRemainder();
		int whole = (int) Math.floor(total);
		double remainder = total - whole;
		whole = Math.max(baseValue, Math.min(whole, NexusConfig.MAX_FINAL_SOULS_PER_KILL));

		credit(player, state, whole, remainder);
		return whole;
	}

	/** Eski (güncellemeden önceki) ruhları, balta başına yalnızca BİR KEZ deftere işler. */
	public static void claimLegacy(ServerPlayer player, ItemStack axe) {
		claimLegacy(player, NexusManager.state(player), axe);
	}

	private static void claimLegacy(ServerPlayer player, NexusState state, ItemStack axe) {
		if (axe.getOrDefault(ModComponents.NEXUS_CLAIMED, Boolean.FALSE)) {
			return;
		}
		int souls = axe.getOrDefault(ModComponents.SOULS, 0);
		axe.set(ModComponents.NEXUS_CLAIMED, Boolean.TRUE);
		if (souls > 0) {
			credit(player, state, souls, state.data.soulRemainder());
		}
	}

	/** Deftere ruh ekler, yeni eşiklerden puan kazandırır, verileri yazar. Defter hiçbir zaman azalmaz. */
	private static void credit(ServerPlayer player, NexusState state, long souls, double remainder) {
		NexusData data = state.data;
		long lifetime = data.lifetimeSouls() + souls;
		int earned = Math.max(data.earnedPoints(), NexusMath.pointsForLifetime(lifetime));
		int gained = earned - data.earnedPoints();
		NexusManager.commit(player, state, data.withSouls(lifetime, earned, remainder));

		if (gained > 0) {
			player.sendSystemMessage(Component.translatable("nexus.msg.points_gained", gained), true);
			if (player.level() instanceof ServerLevel level) {
				level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_LEVELUP,
						SoundSource.PLAYERS, 0.5F, 1.4F);
			}
			NexusWhispers.onMilestone(player, state);
		}
	}

	/** Baltanın ruhu artırıldıktan SONRA çağrılır: öldürmeye bağlı ağ etkileri. */
	public static void afterKill(ServerLevel level, ServerPlayer player, LivingEntity victim, int baseValue, int finalValue) {
		NexusState state = NexusManager.state(player);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return;
		}
		long now = level.getGameTime();

		int xp = (int) stats.get(Stat.XP_ON_KILL);
		if (xp > 0) {
			player.giveExperiencePoints(xp);
		}

		// Seri: süre dolduysa sıfırlanır; üst sınır düğümlerle genişler.
		if (now > state.streakExpiry) {
			state.streak = 0;
		}
		int maxStacks = NexusConfig.STREAK_BASE_STACKS + (int) stats.get(Stat.STREAK_MAX_STACKS);
		state.streak = Math.min(state.streak + 1, maxStacks);
		state.streakExpiry = now + NexusConfig.STREAK_BASE_WINDOW_TICKS + (long) stats.get(Stat.STREAK_WINDOW_TICKS);

		double haste = stats.get(Stat.KILL_HASTE_PCT);
		if (haste > 0.0) {
			state.activate(Buff.HASTE, haste, NexusConfig.HASTE_TICKS, now);
		}

		double heal = Math.min(NexusConfig.MAX_KILL_HEAL,
				stats.get(Stat.HEAL_ON_KILL) + stats.get(Stat.HEAL_PER_SOUL) * finalValue);
		if (heal > 0.0 && player.isAlive()) {
			player.heal((float) heal);
		}

		if (stats.has(Stat.VISUAL_KILL_WISP)) {
			level.sendParticles(ParticleTypes.SOUL, victim.getX(), victim.getY(0.5), victim.getZ(),
					6 + Math.min(finalValue, 12), 0.3, 0.4, 0.3, 0.06);
		}

		NexusWhispers.onKill(level, player, state, victim);
	}
}
