package com.battleaxe.nexus;

/**
 * Düğüm türü. Maliyetler {@link NexusConfig} içinden gelir:
 * küçük 1 puan, orta 2 puan, büyük 4 puan + 5 XP seviyesi, dal sonu 5 puan + 15 XP seviyesi.
 */
public enum NodeType {
	SMALL("small", NexusConfig.COST_SMALL, 0),
	MEDIUM("medium", NexusConfig.COST_MEDIUM, 0),
	LARGE("large", NexusConfig.COST_LARGE, NexusConfig.XP_LEVELS_LARGE),
	CAPSTONE("capstone", NexusConfig.COST_CAPSTONE, NexusConfig.XP_LEVELS_CAPSTONE);

	public final String id;
	/** Yetenek puanı maliyeti. */
	public final int points;
	/** XP maliyeti, "seviye" cinsinden (gerçek deneyim puanına NexusMath çevirir). */
	public final int xpLevels;

	NodeType(String id, int points, int xpLevels) {
		this.id = id;
		this.points = points;
		this.xpLevels = xpLevels;
	}

	/** Bu türün gerçek deneyim PUANI maliyeti (0'dan o seviyeye ulaşmak için gereken toplam puan). */
	public int xpPoints() {
		return NexusMath.levelsToPoints(xpLevels);
	}

	public String langKey() {
		return "nexus.type." + id;
	}
}
