package com.battleaxe.nexus;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.item.ModItems;
import com.battleaxe.soul.SoulManager;

/**
 * Ruh Ağı'nın sunucu tarafı merkezi: oyuncu durumları, ağ paketleri, otoriter satın alma/sıfırlama ve tick.
 * İstemci yalnızca istek gönderir; kaynak düşümü, bağlantı ve şart denetimi BURADA yapılır.
 */
public final class NexusManager {
	private NexusManager() {
	}

	private static final Map<UUID, NexusState> STATES = new HashMap<>();

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(NexusSyncPayload.TYPE, NexusSyncPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(NexusResultPayload.TYPE, NexusResultPayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(NexusActionPayload.TYPE, NexusActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(NexusActionPayload.TYPE,
				(payload, context) -> handleAction(context.player(), payload));

		// Yeniden doğan oyuncu yeni bir varlıktır; durum tembelce (kalıcı veriden) yeniden kurulur.
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> STATES.remove(newPlayer.getUUID()));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> STATES.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tick(player);
			}
		});

		NexusDamage.initialize();
	}

	// ------------------------------------------------------------------
	// Durum
	// ------------------------------------------------------------------

	static NexusState state(ServerPlayer player) {
		NexusState state = STATES.get(player.getUUID());
		if (state == null) {
			state = load(player);
			STATES.put(player.getUUID(), state);
		}
		return state;
	}

	private static NexusState load(ServerPlayer player) {
		NexusState state = new NexusState();
		NexusData raw = player.getAttachedOrElse(NexusAttachments.DATA, NexusData.EMPTY);
		NexusData clean = sanitize(raw);
		if (!clean.equals(raw)) {
			player.setAttached(NexusAttachments.DATA, clean);
		}
		// Yeniden tasarım geçişi: tablodan kalkan/önkoşulu bozulan düğümler atılır; puanları otomatik iade olur
		// (harcanan puan yalnızca açık düğümlerden hesaplanır). Oyuncu bir kez bilgilendirilir.
		state.migrationRemoved = Math.max(0, raw.unlocked().size() - clean.unlocked().size());
		state.data = clean;
		state.refreshStats();
		return state;
	}

	/** Kayıtlı veriyi tabloyla uyumlu hale getirir: bilinmeyen/kopuk düğümler atılır, puanlar geriye gitmez. */
	static NexusData sanitize(NexusData raw) {
		var unlocked = NexusTree.sanitize(raw.unlocked());
		int earned = Math.max(raw.earnedPoints(), NexusMath.pointsForLifetime(raw.lifetimeSouls()));
		return new NexusData(unlocked, raw.lifetimeSouls(), earned, raw.soulsSpent(), raw.soulRemainder());
	}

	/** Veriyi kalıcı olarak yazar ve önbellekleri/istemciyi güncellemeye işaretler. */
	static void commit(ServerPlayer player, NexusState state, NexusData next) {
		boolean nodesChanged = !next.unlocked().equals(state.data.unlocked());
		player.setAttached(NexusAttachments.DATA, next);
		state.data = next;
		if (nodesChanged) {
			state.refreshStats();
		}
		state.dirty = true;
		state.syncPending = true;
	}

	static boolean holdingAxe(ServerPlayer player) {
		return player.getMainHandItem().is(ModItems.BATTLE_AXE) || player.getOffhandItem().is(ModItems.BATTLE_AXE);
	}

	// ------------------------------------------------------------------
	// Tick
	// ------------------------------------------------------------------

	private static void tick(ServerPlayer player) {
		NexusState state = state(player);
		ServerLevel level = player.level() instanceof ServerLevel serverLevel ? serverLevel : null;
		if (level == null) {
			return;
		}
		long now = level.getGameTime();

		ItemStack main = player.getMainHandItem();
		boolean holding = main.is(ModItems.BATTLE_AXE);
		int rank = holding ? SoulManager.rankOf(main) : 0;

		boolean expired = state.expire(now);
		if (state.dirty || expired || holding != state.holding || rank != state.rank) {
			state.holding = holding;
			state.rank = rank;
			state.dirty = false;
			NexusAttributes.apply(player, state, now);
		}

		if (state.syncPending && now - state.lastSyncTick >= NexusConfig.SYNC_MIN_INTERVAL_TICKS) {
			sync(player, state, now);
		}
		if (state.migrationRemoved > 0) {
			player.sendSystemMessage(Component.translatable("nexus.msg.migrated", state.migrationRemoved), false);
			state.migrationRemoved = 0;
		}

		if (holding && state.stats.nodeCount() > 0) {
			NexusWhispers.tick(level, player, state, now);
		}
	}

	// ------------------------------------------------------------------
	// Ağ
	// ------------------------------------------------------------------

	static void sync(ServerPlayer player, NexusState state, long now) {
		NexusData data = state.data;
		ServerPlayNetworking.send(player,
				new NexusSyncPayload(data.unlocked(), data.lifetimeSouls(), data.soulsSpent(), data.earnedPoints()));
		state.syncPending = false;
		state.lastSyncTick = now;
	}

	static void result(ServerPlayer player, boolean ok, String key, String nodeId) {
		ServerPlayNetworking.send(player, new NexusResultPayload(ok, key, nodeId));
	}

	private static void handleAction(ServerPlayer player, NexusActionPayload payload) {
		int action = payload.action();
		if (action < NexusActionPayload.SYNC || action > NexusActionPayload.RESET || payload.nodeId().length() > 64
				|| payload.expectedCount() < 0 || payload.expectedCount() > 100_000) {
			return; // geçersiz paket: sessizce yoksay
		}

		NexusState state = state(player);
		long now = player.level().getGameTime();
		if (now - state.lastActionTick < NexusConfig.ACTION_MIN_INTERVAL_TICKS) {
			result(player, false, NexusRules.Result.TOO_FAST.langKey(), "");
			return;
		}
		state.lastActionTick = now;

		if (action == NexusActionPayload.SYNC) {
			sync(player, state, now);
			return;
		}
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		if (!holdingAxe(player)) {
			result(player, false, NexusRules.Result.NEED_AXE.langKey(), "");
			return;
		}

		if (action == NexusActionPayload.PURCHASE) {
			purchase(player, state, payload.nodeId(), now);
		} else {
			reset(player, state, payload.expectedCount(), now);
		}
	}

	/** Atomik satın alma: önce TÜM şartlar doğrulanır, sonra XP düşer, sonra veri yazılır; hata olursa XP iade edilir. */
	private static void purchase(ServerPlayer player, NexusState state, String nodeId, long now) {
		NexusRules.Purchase attempt = NexusRules.purchase(state.data, nodeId, NexusXp.points(player));
		if (!attempt.ok()) {
			result(player, false, attempt.result().langKey(), nodeId);
			sync(player, state, now);
			return;
		}
		if (!NexusXp.deduct(player, attempt.xpPointsCost())) {
			result(player, false, NexusRules.Result.NOT_ENOUGH_XP.langKey(), nodeId);
			return;
		}
		try {
			commit(player, state, attempt.data());
		} catch (RuntimeException e) {
			NexusXp.refund(player, attempt.xpPointsCost());
			throw e;
		}
		sync(player, state, now);
		result(player, true, "nexus.msg.purchased", nodeId);
		NexusWhispers.onNodeUnlocked(player, state, nodeId);
	}

	/** Atomik sıfırlama: ruh bakiyesi + XP yeterliyse hepsi birlikte düşer, düğümler kapanır. */
	private static void reset(ServerPlayer player, NexusState state, int expectedCount, long now) {
		NexusRules.ResetOutcome outcome = NexusRules.reset(state.data, state.stats.get(Stat.RESET_DISCOUNT_PCT),
				NexusXp.points(player), expectedCount);
		if (!outcome.ok()) {
			result(player, false, outcome.result().langKey(), "");
			sync(player, state, now);
			return;
		}
		if (!NexusXp.deduct(player, outcome.plan().xpPoints())) {
			result(player, false, NexusRules.Result.NOT_ENOUGH_XP.langKey(), "");
			return;
		}
		try {
			commit(player, state, outcome.data());
			state.clearTransient();
		} catch (RuntimeException e) {
			NexusXp.refund(player, outcome.plan().xpPoints());
			throw e;
		}
		sync(player, state, now);
		result(player, true, "nexus.msg.reset_done", "");
	}
}
