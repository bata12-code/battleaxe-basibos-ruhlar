package com.battleaxe.nexus;

/**
 * Bir düğümün tek bir etkisi: hangi {@link Stat}, ne kadar ({@code value}) ve gerekiyorsa koşul/anahtar
 * parametresi ({@code param}: rütbe eşiği, ruh eşiği, can yüzdesi eşiği, fısıltı olayı numarası...).
 */
public record Effect(Stat stat, double value, int param) {
}
