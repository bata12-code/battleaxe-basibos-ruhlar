package com.battleaxe.nexus;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

import com.battleaxe.boss.KaraKorukEntity;

/**
 * Lanetli Bilinç: baltanın gerçek oyun olaylarına bağlı yeni replikleri, rütbe tepkileri, görsel geri bildirimleri
 * ve Kara Körük sezgisi. Mevcut Whispers sistemi olduğu gibi çalışmaya devam eder; bunlar düğümlerle AÇILAN ek
 * sözlerdir ve kendi bekleme süreleri vardır (ekranı fısıltıyla doldurmaz).
 */
public final class NexusWhispers {
	private NexusWhispers() {
	}

	// ------------------------------------------------------------------
	// Olay girişleri
	// ------------------------------------------------------------------

	static void onKill(ServerLevel level, ServerPlayer player, NexusState state, LivingEntity victim) {
		if (!state.stats.hasAnyWhisper()) {
			return;
		}
		if (victim instanceof KaraKorukEntity) {
			fire(level, player, state, NexusEvent.BOSS, 1.0, true);
		} else if (isBigGame(victim)) {
			fire(level, player, state, NexusEvent.BIG, 1.0, true);
		} else {
			fire(level, player, state, NexusEvent.KILL, NexusConfig.WHISPER_CHANCE_KILL, false);
		}
	}

	/** Wither, Warden ve Ejderha: sabit adlara değil kayıt kimliğine bakılır (sürümler arası kırılmaz). */
	private static boolean isBigGame(LivingEntity victim) {
		String id = BuiltInRegistries.ENTITY_TYPE.getKey(victim.getType()).toString();
		return id.equals("minecraft:wither") || id.equals("minecraft:warden") || id.equals("minecraft:ender_dragon");
	}

	static void onCleave(ServerLevel level, ServerPlayer player, NexusState state) {
		fire(level, player, state, NexusEvent.CLEAVE, NexusConfig.WHISPER_CHANCE_CLEAVE, false);
	}

	public static void onBerserk(ServerLevel level, ServerPlayer player) {
		NexusState state = NexusManager.state(player);
		fire(level, player, state, NexusEvent.BERSERK, NexusConfig.WHISPER_CHANCE_BERSERK, false);
	}

	public static void onThrow(ServerLevel level, ServerPlayer player) {
		NexusState state = NexusManager.state(player);
		fire(level, player, state, NexusEvent.THROW, NexusConfig.WHISPER_CHANCE_THROW, false);
	}

	/** Rütbe atlandığında (SoulManager çağırır): görsel yankı ve o rütbeye özel tepki. */
	public static void onRankUp(ServerLevel level, ServerPlayer player, int rank) {
		NexusState state = NexusManager.state(player);
		NexusStats stats = state.stats;
		if (stats.has(Stat.VISUAL_RANKUP)) {
			level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, player.getX(), player.getY(0.6), player.getZ(),
					20 + rank * 6, 0.6, 0.9, 0.6, 0.05);
			level.sendParticles(ParticleTypes.SOUL, player.getX(), player.getY(0.6), player.getZ(),
					10 + rank * 3, 0.5, 0.8, 0.5, 0.1);
		}
		if (stats.hasRankReact(rank)) {
			speak(level, player, state, "nexus.rank_react." + rank, true);
		}
	}

	static void onNodeUnlocked(ServerPlayer player, NexusState state, String nodeId) {
		if (player.level() instanceof ServerLevel level) {
			fire(level, player, state, NexusEvent.NODE, 1.0, true);
		}
	}

	static void onMilestone(ServerPlayer player, NexusState state) {
		if (player.level() instanceof ServerLevel level) {
			fire(level, player, state, NexusEvent.MILESTONE, 1.0, true);
		}
	}

	// ------------------------------------------------------------------
	// Periyodik (yalnızca baltayı tutarken ve ilgili düğüm açıkken iş yapar)
	// ------------------------------------------------------------------

	static void tick(ServerLevel level, ServerPlayer player, NexusState state, long now) {
		NexusStats stats = state.stats;

		// Düşük can: tek seferlik (can toparlanınca yeniden kurulur).
		if (stats.hasWhisper(NexusEvent.LOW_HEALTH)) {
			float ratio = player.getHealth() / Math.max(1.0F, player.getMaxHealth());
			if (ratio >= 0.5F) {
				state.lowHealthLatched = false;
			} else if (ratio < NexusConfig.LOW_HEALTH_RATIO && !state.lowHealthLatched && player.isAlive()
					&& now - state.lastLowHealthTick >= NexusConfig.LOW_HEALTH_WHISPER_COOLDOWN_TICKS) {
				state.lowHealthLatched = true;
				state.lastLowHealthTick = now;
				fire(level, player, state, NexusEvent.LOW_HEALTH, 1.0, true);
			}
		}

		if (stats.has(Stat.VISUAL_AURA) && now % NexusConfig.AURA_INTERVAL_TICKS == 0) {
			level.sendParticles(ParticleTypes.SOUL, player.getX(), player.getY(0.5), player.getZ(),
					2 + state.rank / 3, 0.45, 0.7, 0.45, 0.01);
		}

		if (stats.has(Stat.BOSS_SENSE) && now % NexusConfig.BOSS_SENSE_INTERVAL_TICKS == 0
				&& now - state.lastSenseTick >= NexusConfig.BOSS_SENSE_COOLDOWN_TICKS) {
			senseBoss(level, player, state, now);
		}

		if (stats.has(Stat.SENTIENT)) {
			if (state.lastSentientTick == 0L) {
				state.lastSentientTick = now;
			} else if (now - state.lastSentientTick >= NexusConfig.SENTIENT_INTERVAL_TICKS) {
				state.lastSentientTick = now;
				fire(level, player, state, NexusEvent.SENTIENT, 1.0, true);
			}
		}
	}

	private static void senseBoss(ServerLevel level, ServerPlayer player, NexusState state, long now) {
		var box = player.getBoundingBox().inflate(NexusConfig.BOSS_SENSE_RANGE);
		List<KaraKorukEntity> bosses = level.getEntitiesOfClass(KaraKorukEntity.class, box, entity -> entity.isAlive());
		if (bosses.isEmpty()) {
			return;
		}
		KaraKorukEntity nearest = bosses.get(0);
		for (KaraKorukEntity boss : bosses) {
			if (player.distanceToSqr(boss) < player.distanceToSqr(nearest)) {
				nearest = boss;
			}
		}
		state.lastSenseTick = now;
		int distance = (int) Math.round(Math.sqrt(player.distanceToSqr(nearest)));
		player.sendSystemMessage(Component.translatable("nexus.whisper.sense", distance)
				.withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));
	}

	// ------------------------------------------------------------------
	// Konuşma
	// ------------------------------------------------------------------

	private static boolean fire(ServerLevel level, ServerPlayer player, NexusState state, NexusEvent event, double chance,
			boolean force) {
		NexusStats stats = state.stats;
		if (!stats.hasWhisper(event)) {
			return false;
		}
		long now = level.getGameTime();
		int cooldown = (int) Math.round(NexusConfig.WHISPER_COOLDOWN_TICKS
				* (1.0 - stats.get(Stat.WHISPER_COOLDOWN_PCT) / 100.0));
		long needed = force ? NexusConfig.WHISPER_MIN_GAP_TICKS : cooldown;
		if (now - state.lastWhisperTick < needed) {
			return false;
		}
		if (!force && chance < 1.0 && player.getRandom().nextDouble() >= chance) {
			return false;
		}
		int line = 1 + player.getRandom().nextInt(3);
		if (line == state.lastLine) {
			line = line % 3 + 1;
		}
		state.lastLine = line;
		return speak(level, player, state, "nexus.whisper." + event.key() + "." + line, force);
	}

	private static boolean speak(ServerLevel level, ServerPlayer player, NexusState state, String key, boolean force) {
		long now = level.getGameTime();
		if (!force && now - state.lastWhisperTick < NexusConfig.WHISPER_MIN_GAP_TICKS) {
			return false;
		}
		state.lastWhisperTick = now;
		player.sendSystemMessage(Component.translatable(key, player.getName().getString())
				.withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC));

		NexusStats stats = state.stats;
		double heal = stats.get(Stat.WHISPER_HEAL);
		if (heal > 0.0 && player.isAlive()) {
			player.heal((float) heal);
		}
		double speed = stats.get(Stat.WHISPER_BUFF_PCT);
		if (speed > 0.0) {
			state.activate(Buff.WHISPER_SPEED, speed, NexusConfig.WHISPER_BUFF_TICKS, now);
		}
		return true;
	}
}
