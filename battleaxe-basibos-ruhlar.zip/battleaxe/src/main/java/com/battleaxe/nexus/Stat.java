package com.battleaxe.nexus;

/**
 * Düğüm etkilerinin türleri. Her düğüm bir veya birkaç (Stat, değer, param) çiftinden oluşur;
 * oyun mantığı düğümlere değil bu etkilere bağlanır. Toplamlar {@code [min, max]} aralığına sıkıştırılır,
 * böylece pasifler üst üste binse bile sınırsız güç üretmez.
 */
public enum Stat {
	// ---- Ruh Hâkimiyeti ----
	SOUL_GAIN_PCT(0, 60),
	SOUL_STRONG_FLAT(0, 4),
	SOUL_ELITE_PCT(0, 100),
	XP_ON_KILL(0, 12),
	HEAL_PER_SOUL(0, 1),
	RESET_DISCOUNT_PCT(0, 35),
	RANK_ARMOR(Kind.GATED, Gate.AT_LEAST, 4),
	RANK_DAMAGE_PCT(Kind.GATED, Gate.AT_LEAST, 20),
	RANK_SPEED_PCT(Kind.GATED, Gate.AT_LEAST, 10),
	LEDGER_DAMAGE_PCT(Kind.GATED, Gate.AT_LEAST, 20),

	// ---- Cellat Yolu ----
	DAMAGE_PCT(-40, 60),
	CRIT_CHANCE_PCT(0, 25),
	CRIT_DAMAGE_PCT(0, 60),
	HEAVY_DAMAGE_PCT(0, 25),
	LOW_TARGET_DAMAGE_PCT(Kind.GATED, Gate.AT_MOST, 30),
	STREAK_DAMAGE_PCT(0, 5),
	STREAK_MAX_STACKS(0, 4),
	STREAK_WINDOW_TICKS(0, 120),
	STRONG_TARGET_DAMAGE_PCT(0, 20),
	FULL_HEALTH_TARGET_DAMAGE_PCT(0, 20),
	ARMORED_TARGET_DAMAGE_PCT(0, 20),
	KILL_HASTE_PCT(0, 30),
	BERSERK_DAMAGE_PCT(0, 25),
	THROW_DAMAGE_PCT(0, 40),
	MAX_HEALTH_PCT(-40, 20),
	EXECUTE_THRESHOLD_PCT(0, 15),

	// ---- Yarık Gezgini ----
	CLEAVE_COOLDOWN_PCT(0, 40),
	CLEAVE_DAMAGE_PCT(0, 60),
	CLEAVE_REACH_PCT(0, 40),
	CLEAVE_ANGLE_DEG(0, 30),
	CLEAVE_TARGETS(0, 5),
	CLEAVE_KNOCKBACK_PCT(0, 60),
	CLEAVE_DURABILITY_SAVE_PCT(0, 60),
	POST_CLEAVE_SPEED_PCT(0, 35),
	POST_CLEAVE_DAMAGE_PCT(0, 30),
	CLEAVE_HEAL_PER_HIT(0, 1),
	CLEAVE_TIER3_DAMAGE_PCT(0, 60),
	CLEAVE_RHYTHM(0, 50),

	// ---- Ruh Muhafızı ----
	ARMOR_FLAT(0, 8),
	TOUGHNESS_FLAT(0, 6),
	KNOCKBACK_RESIST(0, 0.6),
	MAX_HEALTH_FLAT(0, 12),
	HEAL_ON_KILL(0, 3),
	ON_HIT_ARMOR(0, 8),
	POST_CLEAVE_ARMOR(0, 8),
	LIFESTEAL_PCT(0, 10),
	DAMAGE_REDUCTION_PCT(0, 30),
	DR_PROJECTILE_PCT(0, 20),
	DR_FIRE_PCT(0, 20),
	DR_EXPLOSION_PCT(0, 20),
	DR_FALL_PCT(0, 30),
	DR_LOW_HEALTH_PCT(0, 20),
	DR_MELEE_PCT(0, 20),
	BERSERK_DR_PCT(0, 15),
	/** Değer: bekleme süresi (saniye). */
	LAST_STAND(0, 600),

	// ---- Yarık Gezgini: Shunpo ve kombo ----
	/** Shunpo'nun ikinci tuş penceresi bu kadar tick uzar (temel 80). */
	SHUNPO_WINDOW_TICKS(0, 80),
	/** Shunpo sonrası 3 saniye saldırı hızı yüzdesi. */
	SHUNPO_HASTE_PCT(0, 30),
	/** Kombonun tüm vuruşlarının hasarı yüzdesi. */
	COMBO_DAMAGE_PCT(0, 40),
	/** Kombonun bitirici (3.) vuruşunun ek hasarı yüzdesi. */
	COMBO_FINISH_PCT(0, 40),
	/** 1 ise ana hedef ikinci vuruştan önce ölürse kombo yakındaki geçerli bir hedefe geçebilir. */
	COMBO_RETARGET(0, 1),
	/** Hedef değiştirme yarıçapına eklenen blok (temel 4). */
	COMBO_RETARGET_RADIUS(0, 4),
	/** Bitirici vuruş, ana hedefin yanındaki bu kadar ek düşmana da hasarın bir kısmını verir. */
	COMBO_SWEEP_TARGETS(0, 3),

	// ---- Cellat Yolu: Execution sinerjisi ----
	/** Normal Execution bitirici olasılığına eklenen yüzde puan (temel 25). */
	EXEC_CHANCE_PCT(0, 25),
	/** Execution için gereken hedef can oranına eklenen yüzde puan (temel 30). */
	EXEC_HEALTH_RATIO_PCT(0, 10),

	// ---- Ruh Hâkimiyeti: bitirici öldürüşler ----
	/** Bitirici (Execution veya kombo bitirici) öldürüşlerinden ek ruh. */
	FINISHER_KILL_SOULS(0, 2),

	// ---- Ruh Muhafızı: Shunpo/Execution sonrası hayatta kalma ----
	/** Shunpo sonrası 4 saniye zırh. */
	SHUNPO_ARMOR(0, 8),
	/** Canın yarının altındayken Shunpo can yeniler. */
	SHUNPO_HEAL(0, 4),
	/** Bitirici (Execution) tamamlanınca can yeniler. */
	EXEC_FINISH_HEAL(0, 4),

	// ---- Lanetli Bilinç: Hiddet etkileşimleri ----
	/** Hiddet aktifken kombo vuruşları hasarı yüzdesi. */
	HIDDET_COMBO_PCT(0, 30),
	/** Hiddet aktifken her kombo başlangıcında harcanan can (asla öldürmez). BEDEL. */
	HIDDET_COMBO_COST(0, 2),
	/** Hiddet aktifken kritik öldürüş kükremesi can yeniler. */
	HIDDET_ROAR_HEAL(0, 4),

	// ---- Lanetli Bilinç ----
	/** param: {@link NexusEvent} numarası. */
	WHISPER_UNLOCK(Kind.SET, Gate.NONE, 0),
	/** param: balta rütbesi; o rütbeye yükselince balta özel konuşur. */
	RANK_REACT(Kind.SET, Gate.NONE, 0),
	WHISPER_COOLDOWN_PCT(0, 60),
	WHISPER_HEAL(0, 4),
	WHISPER_BUFF_PCT(0, 25),
	KARA_DAMAGE_PCT(0, 30),
	KARA_DR_PCT(0, 30),
	VISUAL_KILL_WISP(0, 1),
	VISUAL_AURA(0, 1),
	VISUAL_RANKUP(0, 1),
	VISUAL_CLEAVE(0, 1),
	BOSS_SENSE(0, 1),
	SENTIENT(0, 1);

	/** Etkinin toplanma biçimi. */
	public enum Kind {
		/** Değerler toplanır ve [min, max] aralığına sıkıştırılır. */
		SUM,
		/** Değerler (param, değer) çiftleri olarak tutulur; koşul sağlanan çiftler toplanır. */
		GATED,
		/** param'lar bir kümede toplanır (fısıltı olayları, rütbe tepkileri). */
		SET
	}

	/** GATED etkilerde koşul: gerçek değer eşiğe göre. */
	public enum Gate {
		NONE, AT_LEAST, AT_MOST
	}

	public final Kind kind;
	public final Gate gate;
	public final double min;
	public final double max;

	Stat(double min, double max) {
		this(Kind.SUM, Gate.NONE, min, max);
	}

	Stat(Kind kind, Gate gate, double max) {
		this(kind, gate, 0.0, max);
	}

	Stat(Kind kind, Gate gate, double min, double max) {
		this.kind = kind;
		this.gate = gate;
		this.min = min;
		this.max = max;
	}

	public String langKey() {
		return "nexus.stat." + name();
	}
}
