package com.battleaxe.nexus;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Satın alma ve sıfırlama kuralları (saf mantık). Sunucu bunu otoriter olarak çalıştırır, istemci yalnızca
 * düğümlerin görsel durumunu (açılabilir / yetersiz kaynak / kilitli) göstermek için aynı fonksiyonu kullanır.
 * Fonksiyonlar girdiyi DEĞİŞTİRMEZ; yeni değişmez veri döndürür. Böylece işlem ya tamamen uygulanır ya hiç.
 */
public final class NexusRules {
	private NexusRules() {
	}

	public enum Result {
		OK, UNKNOWN_NODE, ALREADY_OWNED, NOT_REACHABLE, REQUIREMENTS, CAPSTONE_PROGRESS, NOT_ENOUGH_POINTS, NOT_ENOUGH_XP,
		NOT_ENOUGH_SOULS, NOTHING_TO_RESET, COUNT_MISMATCH, NEED_AXE, TOO_FAST, BAD_REQUEST;

		public String langKey() {
			return "nexus.msg." + name().toLowerCase(java.util.Locale.ROOT);
		}
	}

	public record Purchase(Result result, NexusData data, long xpPointsCost) {
		public boolean ok() {
			return result == Result.OK;
		}
	}

	public record ResetPlan(int nodes, long souls, int xpPoints, int xpLevels) {
	}

	public record ResetOutcome(Result result, NexusData data, ResetPlan plan) {
		public boolean ok() {
			return result == Result.OK;
		}
	}

	/** Açık düğümlerin toplam puan maliyeti (yalnızca tanınan düğümler). */
	public static int spentPoints(Set<String> owned) {
		int total = 0;
		for (String id : owned) {
			NodeDef node = NexusTree.get(id);
			if (node != null) {
				total += node.type().points;
			}
		}
		return total;
	}

	public static int availablePoints(NexusData data) {
		return Math.max(0, data.earnedPoints() - spentPoints(data.unlockedSet()));
	}

	/** Dal sonu için gerekli dal ilerlemesi sağlanıyor mu? */
	public static boolean capstoneReady(Set<String> owned, NodeDef capstone) {
		int inBranch = 0;
		int large = 0;
		for (String id : owned) {
			NodeDef node = NexusTree.get(id);
			if (node != null && node.branch() == capstone.branch()) {
				inBranch++;
				if (node.type() == NodeType.LARGE) {
					large++;
				}
			}
		}
		return inBranch >= NexusConfig.CAPSTONE_MIN_BRANCH_NODES && large >= NexusConfig.CAPSTONE_MIN_LARGE_NODES;
	}

	/** Satın alma denemesi. {@code xpPointsHeld}: oyuncunun sahip olduğu toplam deneyim puanı. */
	public static Purchase purchase(NexusData data, String nodeId, long xpPointsHeld) {
		NodeDef node = NexusTree.get(nodeId);
		if (node == null) {
			return new Purchase(Result.UNKNOWN_NODE, data, 0L);
		}
		Set<String> owned = data.unlockedSet();
		if (owned.contains(nodeId)) {
			return new Purchase(Result.ALREADY_OWNED, data, 0L);
		}
		if (!NexusTree.isReachable(owned, node)) {
			return new Purchase(Result.NOT_REACHABLE, data, 0L);
		}
		if (!NexusTree.requirementsMet(owned, node)) {
			return new Purchase(Result.REQUIREMENTS, data, 0L);
		}
		if (node.type() == NodeType.CAPSTONE && !capstoneReady(owned, node)) {
			return new Purchase(Result.CAPSTONE_PROGRESS, data, 0L);
		}
		if (availablePoints(data) < node.type().points) {
			return new Purchase(Result.NOT_ENOUGH_POINTS, data, 0L);
		}
		long xpCost = node.type().xpPoints();
		if (xpPointsHeld < xpCost) {
			return new Purchase(Result.NOT_ENOUGH_XP, data, xpCost);
		}
		List<String> next = new ArrayList<>(data.unlocked());
		next.add(nodeId);
		return new Purchase(Result.OK, data.withUnlocked(next), xpCost);
	}

	public static ResetPlan resetPlan(NexusData data, double discountPct) {
		int count = data.unlocked().size();
		return new ResetPlan(count, NexusMath.resetSouls(count, discountPct), NexusMath.resetXpPoints(count),
				NexusMath.resetXpLevels(count));
	}

	/**
	 * Tüm düğümleri sıfırlar. Harcanan ruh yalnızca {@code soulsSpent}'e eklenir: toplam ruh ilerlemesi,
	 * kazanılmış puanlar ve balta rütbesi etkilenmez. Puanlar, düğümler kapandığı için otomatik iade olur.
	 */
	public static ResetOutcome reset(NexusData data, double discountPct, long xpPointsHeld, int expectedCount) {
		ResetPlan plan = resetPlan(data, discountPct);
		if (plan.nodes() == 0) {
			return new ResetOutcome(Result.NOTHING_TO_RESET, data, plan);
		}
		if (plan.nodes() != expectedCount) {
			return new ResetOutcome(Result.COUNT_MISMATCH, data, plan);
		}
		if (data.soulBalance() < plan.souls()) {
			return new ResetOutcome(Result.NOT_ENOUGH_SOULS, data, plan);
		}
		if (xpPointsHeld < plan.xpPoints()) {
			return new ResetOutcome(Result.NOT_ENOUGH_XP, data, plan);
		}
		NexusData next = data.withUnlocked(List.of()).withSpent(data.soulsSpent() + plan.souls());
		return new ResetOutcome(Result.OK, next, plan);
	}
}
