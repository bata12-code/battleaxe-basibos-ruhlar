package com.battleaxe.nexus;

import java.util.ArrayDeque;
import java.util.UUID;

/**
 * Bir oyuncunun SUNUCU tarafındaki geçici (kaydedilmeyen) Ruh Ağı durumu: hazır hesaplanmış etkiler,
 * kısa süreli bonuslar, öldürme serisi, saldırı bağlamı ve fısıltı bekleme süreleri.
 * Yalnızca sunucu iş parçacığından kullanılır.
 */
final class NexusState {
	NexusData data = NexusData.EMPTY;
	NexusStats stats = NexusStats.EMPTY;

	boolean dirty = true;
	boolean holding;
	int rank;
	boolean syncPending = true;
	long lastSyncTick = -1000;
	long lastActionTick = -1000;

	// Kısa süreli bonuslar
	private final long[] buffExpiry = new long[Buff.values().length];
	private final double[] buffValue = new double[Buff.values().length];
	private long nextExpiry = Long.MAX_VALUE;

	// Öldürme serisi
	int streak;
	long streakExpiry;

	// Son normal saldırının bağlamı (PlayerMixin#attack içinde kaydedilir)
	long attackTick = -1;
	float attackStrength;
	boolean attackCritHint;
	int attackTargetId = -1;
	/** Yar Geç saldırısı sürerken true: normal vuruşa özgü bonuslar (ağır/kritik) uygulanmaz. */
	boolean cleaveActive;
	/** Son vuruşta fiilen verilen (ağ bonuslarıyla birlikte) ham hasar; yalnızca bilgi içindir. */
	float lastDealt;

	/** Shunpo kombo/Execution bitiricisiyle öldürülecek varlık (ek ruh için) ve işaretin bitiş zamanı. */
	UUID finisherVictim;
	long finisherExpiry;
	/** Cellat darbesi (kritik) en son hangi tick'te tetiklendi? */
	long critProcTick = -1;
	/** Yükleme sırasında tablodan atılan düğüm sayısı (yeniden tasarım geçişi); oyuncuya bir kez bildirilir. */
	int migrationRemoved;

	boolean rhythmReady;
	long lastStandReadyTick;
	long lastExecuteTick = -1000;

	// Fısıltılar
	long lastWhisperTick = -100000;
	long lastLowHealthTick = -100000;
	long lastSentientTick;
	long lastSenseTick = -100000;
	boolean lowHealthLatched;
	int lastLine = -1;

	final ArrayDeque<UUID> recentKills = new ArrayDeque<>();

	void refreshStats() {
		stats = NexusStats.compute(NexusTree.resolve(data.unlocked()));
		dirty = true;
	}

	void activate(Buff buff, double value, int ticks, long now) {
		if (value <= 0.0) {
			return;
		}
		int i = buff.ordinal();
		buffValue[i] = value;
		buffExpiry[i] = now + ticks;
		nextExpiry = Math.min(nextExpiry, buffExpiry[i]);
		dirty = true;
	}

	double active(Buff buff, long now) {
		int i = buff.ordinal();
		return buffExpiry[i] > now ? buffValue[i] : 0.0;
	}

	/** Süresi dolan bonus varsa true döner (öznitelikler yeniden eşitlenmeli). */
	boolean expire(long now) {
		if (now < nextExpiry) {
			return false;
		}
		long next = Long.MAX_VALUE;
		boolean any = false;
		for (int i = 0; i < buffExpiry.length; i++) {
			if (buffExpiry[i] > 0) {
				if (buffExpiry[i] <= now) {
					buffExpiry[i] = 0;
					buffValue[i] = 0.0;
					any = true;
				} else {
					next = Math.min(next, buffExpiry[i]);
				}
			}
		}
		nextExpiry = next;
		return any;
	}

	void clearTransient() {
		for (int i = 0; i < buffExpiry.length; i++) {
			buffExpiry[i] = 0;
			buffValue[i] = 0.0;
		}
		nextExpiry = Long.MAX_VALUE;
		streak = 0;
		rhythmReady = false;
		finisherVictim = null;
		dirty = true;
	}

	/** Aynı öldürme olayını (varlık kimliği) ikinci kez işlememek için. */
	boolean markKill(UUID victim) {
		if (recentKills.contains(victim)) {
			return false;
		}
		recentKills.addLast(victim);
		while (recentKills.size() > 16) {
			recentKills.removeFirst();
		}
		return true;
	}
}
