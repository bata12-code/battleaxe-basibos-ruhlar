package com.battleaxe.nexus;

import java.util.Arrays;

/**
 * Bir düğümün veri tanımı. Tablo {@link NexusNodes} içindedir; mantık buraya değil
 * {@link Effect}/{@link Stat} sistemine yazılır, böylece yeni düğüm eklemek sadece veri eklemektir.
 *
 * @param id      benzersiz kimlik ("soul_01" ... "mind_20")
 * @param branch  ait olduğu dal
 * @param type    küçük / orta / büyük / dal sonu (maliyet)
 * @param role    temel / mekanik / uzmanlık / sinerji / büyük (anlam)
 * @param x       ağ koordinatı (birim; ekranda ölçeklenir)
 * @param y       ağ koordinatı
 * @param links   doğrudan komşu düğüm kimlikleri (çift yönlü tutarlıdır; doğrulama bunu denetler)
 * @param requires ek önkoşul düğümleri (tümü açık olmalı); boş olabilir
 * @param effects uygulanan etkiler
 */
public record NodeDef(String id, Branch branch, NodeType type, NodeRole role, float x, float y, String[] links,
		String[] requires, Effect[] effects) {
	public NodeDef {
		links = links.clone();
		requires = requires.clone();
		effects = effects.clone();
	}

	/** Bağlantıya ek olarak AÇIK olması gereken düğümler (çoğunlukla başka daldan; yalnızca sinerji düğümlerinde). */
	@Override
	public String[] requires() {
		return requires.clone();
	}

	@Override
	public String[] links() {
		return links.clone();
	}

	@Override
	public Effect[] effects() {
		return effects.clone();
	}

	/** Dalın çekirdeğe bağlanan ilk düğümü mü? (Çekirdek her zaman "açık" sayılır.) */
	public boolean isGate() {
		return id.endsWith("_01");
	}

	public String nameKey() {
		return "nexus.node." + id;
	}

	@Override
	public boolean equals(Object other) {
		return other instanceof NodeDef node && node.id.equals(id);
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public String toString() {
		return "NodeDef[" + id + ", " + type + ", " + Arrays.toString(effects) + "]";
	}
}
