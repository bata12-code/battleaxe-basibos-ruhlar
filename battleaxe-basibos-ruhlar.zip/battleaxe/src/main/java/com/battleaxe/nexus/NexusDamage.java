package com.battleaxe.nexus;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.boss.KaraKorukEntity;
import com.battleaxe.effect.CritEffects;
import com.battleaxe.item.ModItems;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * Hasar kancaları. Giden hasar (saldırgan oyuncunun Ruh Ağı'na göre) ve gelen hasar (savunan oyuncunun
 * Ruh Ağı'na göre) LivingEntity#hurtServer başında, ZIRH VE KORUMA hesaplarından ÖNCE ham miktar üzerinde
 * ölçeklenir; böylece vanilla zırh/büyü/direnç hesabı olduğu gibi çalışır.
 *
 * <p>Sınırlar: toplam hasar bonusu [{@link NexusConfig#DAMAGE_PCT_MIN}, {@link NexusConfig#DAMAGE_PCT_MAX}] %,
 * toplam hasar azaltma en çok {@link NexusConfig#DAMAGE_REDUCTION_MAX} %. Oyuncu hiçbir zaman hasar almaz hale gelmez.
 */
public final class NexusDamage {
	private NexusDamage() {
	}

	/** hurtServer'ın yeniden çağrısında (ölçeklenmiş miktarla) kancanın ikinci kez çalışmasını önler. */
	private static boolean busy;

	static void initialize() {
		ServerLivingEntityEvents.AFTER_DAMAGE.register(NexusDamage::afterDamage);
		ServerLivingEntityEvents.ALLOW_DEATH.register(NexusDamage::allowDeath);
	}

	public static boolean isBusy() {
		return busy;
	}

	public static void enter() {
		busy = true;
	}

	public static void exit() {
		busy = false;
	}

	/** Ölçeklenmiş hasar miktarı; değişiklik yoksa aynı değeri döndürür. */
	public static float modify(LivingEntity victim, DamageSource source, float amount) {
		if (amount <= 0.0F || !(victim.level() instanceof ServerLevel level)) {
			return amount;
		}
		float result = amount;
		if (source.getEntity() instanceof ServerPlayer attacker && attacker != victim) {
			result = outgoing(level, attacker, victim, source, result);
		}
		if (victim instanceof ServerPlayer defender) {
			result = incoming(defender, source, result);
		}
		return result;
	}

	// ------------------------------------------------------------------
	// Giden hasar
	// ------------------------------------------------------------------

	private static float outgoing(ServerLevel level, ServerPlayer attacker, LivingEntity victim, DamageSource source, float amount) {
		NexusState state = NexusManager.state(attacker);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return amount;
		}

		ThrownBattleAxe hit = ThrownBattleAxe.activeHit();
		boolean viaThrow = hit != null && source.is(DamageTypes.THROWN) && attacker.getUUID().equals(hit.getOwnerUuid());
		boolean melee = source.is(DamageTypes.PLAYER_ATTACK) && attacker.getMainHandItem().is(ModItems.BATTLE_AXE);
		if (!melee && !viaThrow) {
			return amount;
		}

		long now = level.getGameTime();
		int rank = viaThrow ? SoulManager.rankOf(hit.getItem()) : SoulManager.rankOf(attacker.getMainHandItem());
		boolean swing = melee && !state.cleaveActive && state.attackTick == now;

		float maxHealth = victim.getMaxHealth();
		float health = victim.getHealth();
		double healthPct = maxHealth > 0.0F ? health / maxHealth * 100.0 : 100.0;

		double pct = stats.get(Stat.DAMAGE_PCT);
		pct += stats.gated(Stat.RANK_DAMAGE_PCT, rank);
		pct += stats.gated(Stat.LEDGER_DAMAGE_PCT, state.data.lifetimeSouls());
		pct += state.active(Buff.CLEAVE_DAMAGE, now);
		if (BerserkerManager.isActive(attacker)) {
			pct += stats.get(Stat.BERSERK_DAMAGE_PCT);
		}
		if (viaThrow) {
			pct += stats.get(Stat.THROW_DAMAGE_PCT);
		}
		if (victim instanceof KaraKorukEntity) {
			pct += stats.get(Stat.KARA_DAMAGE_PCT);
		}
		pct += stats.gated(Stat.LOW_TARGET_DAMAGE_PCT, healthPct);
		if (health >= maxHealth - 0.01F) {
			pct += stats.get(Stat.FULL_HEALTH_TARGET_DAMAGE_PCT);
		}
		if (maxHealth >= 100.0F) {
			pct += stats.get(Stat.STRONG_TARGET_DAMAGE_PCT);
		}
		if (victim.getArmorValue() >= 8) {
			pct += stats.get(Stat.ARMORED_TARGET_DAMAGE_PCT);
		}
		if (state.streak > 0 && now <= state.streakExpiry) {
			pct += stats.get(Stat.STREAK_DAMAGE_PCT) * state.streak;
		}
		boolean heavy = swing && state.attackStrength >= NexusConfig.HEAVY_STRENGTH;
		if (heavy) {
			pct += stats.get(Stat.HEAVY_DAMAGE_PCT);
		}
		pct = Math.max(NexusConfig.DAMAGE_PCT_MIN, Math.min(NexusConfig.DAMAGE_PCT_MAX, pct));
		double multiplier = 1.0 + pct / 100.0;

		// Kritik: vanilla kritikse üstüne "kritik hasar" yüzdesi; değilse tam şarjlı vuruşta "kritik şansı" ile
		// Cellat darbesi (1.5x). İkisi de yalnızca asıl hedefe ve normal vuruşa uygulanır.
		if (heavy && victim.getId() == state.attackTargetId) {
			double critBonus = 1.0 + stats.get(Stat.CRIT_DAMAGE_PCT) / 100.0;
			if (state.attackCritHint) {
				multiplier *= critBonus;
			} else {
				double chance = stats.get(Stat.CRIT_CHANCE_PCT);
				if (chance > 0.0 && attacker.getRandom().nextDouble() * 100.0 < chance) {
					multiplier *= NexusConfig.CRIT_PROC_MULTIPLIER * critBonus;
					CritEffects.play(level, attacker, victim, false);
					state.critProcTick = now;
				}
			}
		}

		float result = (float) (amount * multiplier);

		// İnfaz (Cellat dal sonu): vuruş hedefi eşiğin altına indirecekse infaz eder. Boss ve oyuncularda çalışmaz.
		double executePct = stats.get(Stat.EXECUTE_THRESHOLD_PCT);
		if (executePct > 0.0 && !(victim instanceof Player) && maxHealth < NexusConfig.EXECUTE_MAX_TARGET_HEALTH
				&& health > 0.0F && now - state.lastExecuteTick >= NexusConfig.EXECUTE_COOLDOWN_TICKS
				&& health - result <= maxHealth * executePct / 100.0) {
			result = Math.max(result, health * 5.0F + 10.0F);
			state.lastExecuteTick = now;
			level.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY(0.5), victim.getZ(), 14, 0.3, 0.4, 0.3, 0.25);
		}

		state.lastDealt = result;
		return result;
	}

	// ------------------------------------------------------------------
	// Gelen hasar
	// ------------------------------------------------------------------

	private static float incoming(ServerPlayer defender, DamageSource source, float amount) {
		if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || !defender.getMainHandItem().is(ModItems.BATTLE_AXE)) {
			return amount;
		}
		NexusState state = NexusManager.state(defender);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return amount;
		}

		long now = defender.level().getGameTime();
		double reduction = stats.get(Stat.DAMAGE_REDUCTION_PCT);
		if (defender.getHealth() < defender.getMaxHealth() * 0.5F) {
			reduction += stats.get(Stat.DR_LOW_HEALTH_PCT);
		}
		Entity direct = source.getDirectEntity();
		if (source.is(DamageTypeTags.IS_PROJECTILE)) {
			reduction += stats.get(Stat.DR_PROJECTILE_PCT);
		} else if (direct instanceof LivingEntity) {
			reduction += stats.get(Stat.DR_MELEE_PCT);
		}
		if (source.is(DamageTypeTags.IS_EXPLOSION)) {
			reduction += stats.get(Stat.DR_EXPLOSION_PCT);
		}
		if (source.is(DamageTypeTags.IS_FIRE)) {
			reduction += stats.get(Stat.DR_FIRE_PCT);
		}
		if (source.is(DamageTypeTags.IS_FALL)) {
			reduction += stats.get(Stat.DR_FALL_PCT);
		}
		if (BerserkerManager.isActive(defender)) {
			reduction += stats.get(Stat.BERSERK_DR_PCT);
		}
		if (source.getEntity() instanceof KaraKorukEntity) {
			reduction += stats.get(Stat.KARA_DR_PCT);
		}

		double cap = NexusConfig.DAMAGE_REDUCTION_MAX;
		double grace = state.active(Buff.GRACE, now);
		if (grace > cap) {
			cap = grace; // Son Direniş'in kısa süreli koruması normal sınırı aşabilir ama yine de %100 değildir
		}
		reduction = Math.min(reduction + grace, cap);
		if (reduction <= 0.0) {
			return amount;
		}
		return (float) (amount * (1.0 - reduction / 100.0));
	}

	// ------------------------------------------------------------------
	// Olay işleyicileri
	// ------------------------------------------------------------------

	/** Başarılı bir vuruştan sonra (vanilla saldırı efekti veya Yar Geç isabeti) kısa süreli savunma. */
	public static void onSuccessfulHit(ServerPlayer player) {
		NexusState state = NexusManager.state(player);
		double armor = state.stats.get(Stat.ON_HIT_ARMOR);
		if (armor > 0.0) {
			state.activate(Buff.HIT_ARMOR, armor, NexusConfig.HIT_ARMOR_TICKS, player.level().getGameTime());
		}
	}

	private static void afterDamage(LivingEntity entity, DamageSource source, float baseDamageTaken, float damageTaken, boolean blocked) {
		if (blocked || damageTaken <= 0.0F || !(source.getEntity() instanceof ServerPlayer player) || player == entity
				|| !source.is(DamageTypes.PLAYER_ATTACK) || !player.getMainHandItem().is(ModItems.BATTLE_AXE)) {
			return;
		}
		double lifesteal = NexusManager.state(player).stats.get(Stat.LIFESTEAL_PCT);
		if (lifesteal > 0.0 && player.isAlive()) {
			player.heal((float) Math.min(4.0, damageTaken * lifesteal / 100.0));
		}
	}

	/** Son Direniş (Muhafız dal sonu): ölümcül vuruşta bir kez hayatta kalır; uzun bekleme süresi vardır. */
	private static boolean allowDeath(LivingEntity entity, DamageSource source, float amount) {
		if (!(entity instanceof ServerPlayer player) || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
				|| !player.getMainHandItem().is(ModItems.BATTLE_AXE) || !(player.level() instanceof ServerLevel level)) {
			return true;
		}
		NexusState state = NexusManager.state(player);
		double cooldownSeconds = state.stats.get(Stat.LAST_STAND);
		long now = level.getGameTime();
		if (cooldownSeconds <= 0.0 || now < state.lastStandReadyTick) {
			return true;
		}

		state.lastStandReadyTick = now + (long) (cooldownSeconds * 20.0);
		player.setHealth(Math.max(1.0F, player.getMaxHealth() * NexusConfig.LAST_STAND_HEALTH_RATIO));
		state.activate(Buff.GRACE, NexusConfig.LAST_STAND_GRACE_DR, NexusConfig.LAST_STAND_GRACE_TICKS, now);
		player.sendSystemMessage(Component.translatable("nexus.msg.last_stand"), true);
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.0F, 0.5F);
		level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, player.getX(), player.getY(0.5), player.getZ(), 40, 0.5, 0.8, 0.5, 0.08);
		return false;
	}
}
