package com.battleaxe.nexus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Açılmış düğümlerin toplanmış etkisi. Düğüm kümesi değiştiğinde BİR KEZ hesaplanır ve önbellekte tutulur;
 * savaş/tick kodu yalnızca bu hazır değerleri okur (her tick'te yeniden hesaplama yok).
 */
public final class NexusStats {
	public static final NexusStats EMPTY = compute(List.of());

	private final double[] sums = new double[Stat.values().length];
	private final Map<Stat, List<double[]>> gated = new EnumMap<>(Stat.class);
	private final Set<Integer> whisperEvents = new HashSet<>();
	private final Set<Integer> rankReacts = new HashSet<>();
	private final int nodeCount;

	private NexusStats(int nodeCount) {
		this.nodeCount = nodeCount;
	}

	public static NexusStats compute(Collection<NodeDef> unlocked) {
		NexusStats stats = new NexusStats(unlocked.size());
		for (NodeDef node : unlocked) {
			for (Effect effect : node.effects()) {
				switch (effect.stat().kind) {
					case SUM -> stats.sums[effect.stat().ordinal()] += effect.value();
					case GATED -> stats.gated.computeIfAbsent(effect.stat(), key -> new ArrayList<>())
							.add(new double[] {effect.param(), effect.value()});
					case SET -> {
						if (effect.stat() == Stat.WHISPER_UNLOCK) {
							stats.whisperEvents.add(effect.param());
						} else {
							stats.rankReacts.add(effect.param());
						}
					}
				}
			}
		}
		return stats;
	}

	/** Toplam (sıkıştırılmış) değer. */
	public double get(Stat stat) {
		return Math.max(stat.min, Math.min(stat.max, sums[stat.ordinal()]));
	}

	public boolean has(Stat stat) {
		return get(stat) > 0.0;
	}

	/** Koşullu etkilerin, verilen gerçek değer için geçerli olanlarının (sıkıştırılmış) toplamı. */
	public double gated(Stat stat, double actual) {
		List<double[]> list = gated.get(stat);
		if (list == null) {
			return 0.0;
		}
		double total = 0.0;
		for (double[] pair : list) {
			boolean ok = stat.gate == Stat.Gate.AT_MOST ? actual <= pair[0] : actual >= pair[0];
			if (ok) {
				total += pair[1];
			}
		}
		return Math.min(stat.max, total);
	}

	public boolean hasWhisper(NexusEvent event) {
		return whisperEvents.contains(event.id);
	}

	public boolean hasAnyWhisper() {
		return !whisperEvents.isEmpty();
	}

	public boolean hasRankReact(int rank) {
		return rankReacts.contains(rank);
	}

	public int nodeCount() {
		return nodeCount;
	}
}
