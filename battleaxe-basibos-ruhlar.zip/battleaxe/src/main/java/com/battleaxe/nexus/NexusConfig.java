package com.battleaxe.nexus;

/**
 * Ruh Ağı dengeleme ayarları. Dengelemek için yalnızca bu dosyayı değiştirmen yeterlidir.
 * Süreler tick cinsindendir (20 tick = 1 saniye).
 */
public final class NexusConfig {
	private NexusConfig() {
	}

	// ------------------------------------------------------------------
	// Düğüm maliyetleri
	// ------------------------------------------------------------------
	// Yeniden tasarım: yetenek puanı artık ~%25 daha ucuz kazanılıyor (POINT_BASE 20 -> 15); küçük/orta düğümler
	// bu yüzden ruh olarak ~%25 ucuzlar. Büyük ve dal sonu düğümlerin PUAN bedeli, ucuzlamayı dengeleyecek kadar
	// artırıldı (3 -> 4, 4 -> 5): ruh karşılıkları büyük düğümde değişmedi, dal sonunda ~%6 azaldı.
	public static final int COST_SMALL = 1;
	public static final int COST_MEDIUM = 2;
	public static final int COST_LARGE = 4;
	public static final int COST_CAPSTONE = 5;
	/** Büyük düğüm ek maliyeti: 5 XP SEVİYESİ değerinde deneyim puanı (0 -> 5. seviye = 55 puan). */
	public static final int XP_LEVELS_LARGE = 5;
	/** Dal sonu ek maliyeti: 15 XP seviyesi değerinde deneyim puanı (0 -> 15. seviye = 315 puan). */
	public static final int XP_LEVELS_CAPSTONE = 15;

	/** Dal sonu düğümü için dalda açılmış olması gereken en az düğüm sayısı (dal sonunun kendisi hariç). */
	public static final int CAPSTONE_MIN_BRANCH_NODES = 12;
	/** Dal sonu düğümü için dalda açılmış olması gereken en az büyük düğüm sayısı. */
	public static final int CAPSTONE_MIN_LARGE_NODES = 1;

	// ------------------------------------------------------------------
	// Yetenek puanı kazanımı: kalıcı "toplam ruh ilerlemesi"ne göre.
	// n. puan için eşik = ceil(POINT_BASE * n ^ POINT_EXPONENT) toplam ruh.
	// Örn (POINT_BASE 15): 1. puan 15, 10. puan 475, 40. puan 3.795, 100. puan 15.000, 175. puan 34.725 ruh.
	// (Eski değer 20'ydi; kazanılmış puanlar hiç azalmadığı için mevcut oyuncular puan kaybetmez, daha fazlasını kazanır.)
	// Ruh HARCAMAK (sıfırlama) bu toplamı ve kazanılmış puanları asla azaltmaz.
	// ------------------------------------------------------------------
	public static final double POINT_BASE = 15.0;
	public static final double POINT_EXPONENT = 1.5;
	/** Kazanılabilecek en çok puan (ağacın tamamının maliyeti: 5 x (12x1 + 5x2 + 2x4 + 1x5) = 175). */
	public static final int MAX_POINTS = 175;

	// ------------------------------------------------------------------
	// Sıfırlama: sıfırlanan düğüm sayısına (n) göre artan bedel.
	// ruh = (RESET_SOULS_BASE * n + RESET_SOULS_GROWTH * n(n-1)/2) * (1 - indirim)
	// xp seviyesi = min(RESET_XP_MAX_LEVELS, RESET_XP_BASE_LEVELS + n / RESET_XP_NODES_PER_LEVEL)
	// ------------------------------------------------------------------
	public static final double RESET_SOULS_BASE = 15.0;
	public static final double RESET_SOULS_GROWTH = 1.0;
	public static final int RESET_XP_BASE_LEVELS = 2;
	public static final int RESET_XP_NODES_PER_LEVEL = 4;
	public static final int RESET_XP_MAX_LEVELS = 40;

	// ------------------------------------------------------------------
	// Ruh kazanımı
	// ------------------------------------------------------------------
	/** Bir öldürmeden (bonuslarla) alınabilecek mutlak üst sınır. */
	public static final int MAX_FINAL_SOULS_PER_KILL = 40;
	/** Temel ruh değeri bu kadar veya fazlaysa "güçlü düşman" (>= 60 can). */
	public static final int STRONG_VALUE = 3;
	/** Temel ruh değeri bu kadar veya fazlaysa "elit/boss" (>= 160 can). */
	public static final int ELITE_VALUE = 8;
	/** Öldürme başına geri kazanılabilecek en çok can (ruh başına şifa dahil). */
	public static final double MAX_KILL_HEAL = 4.0;

	// ------------------------------------------------------------------
	// Hasar çarpanı sınırları (üst üste binen pasifler aşırı hasar üretmesin)
	// ------------------------------------------------------------------
	public static final double DAMAGE_PCT_MIN = -40.0;
	public static final double DAMAGE_PCT_MAX = 75.0;
	/** Toplam hasar azaltma üst sınırı (%). Oyuncu hiçbir zaman hasar almaz hale gelmez. */
	public static final double DAMAGE_REDUCTION_MAX = 40.0;
	/** Tam şarjlı vuruş eşiği (saldırı gücü 0-1). */
	public static final float HEAVY_STRENGTH = 0.9F;
	/** Cellat kritik darbesi (vanilla kritik olmayan tam şarjlı vuruşta) çarpanı. */
	public static final double CRIT_PROC_MULTIPLIER = 1.5;
	/** İnfaz, bundan fazla azami cana sahip hedeflerde (boss) çalışmaz. */
	public static final float EXECUTE_MAX_TARGET_HEALTH = 150.0F;
	/** İnfaz için art arda iki tetik arasındaki asgari süre. */
	public static final int EXECUTE_COOLDOWN_TICKS = 20;

	// Öldürme serisi
	public static final int STREAK_BASE_STACKS = 3;
	public static final int STREAK_BASE_WINDOW_TICKS = 160;

	// Kısa süreli bonuslar (aynı tetik süreyi yeniler, değeri BİRİKTİRMEZ)
	public static final int HASTE_TICKS = 60;
	public static final int HIT_ARMOR_TICKS = 60;
	public static final int CLEAVE_SPEED_TICKS = 60;
	public static final int CLEAVE_DAMAGE_TICKS = 100;
	public static final int CLEAVE_ARMOR_TICKS = 80;
	public static final int WHISPER_BUFF_TICKS = 80;

	// Yar Geç
	/** Yar Geç bekleme süresi hiçbir zaman bunun altına inmez (asla sıfırlanmaz). */
	public static final int CLEAVE_MIN_COOLDOWN_TICKS = 12;
	/** Bekleme süresindeki toplam azalma üst sınırı (%), ritim dahil. */
	public static final double CLEAVE_MAX_COOLDOWN_REDUCTION = 60.0;
	/** Ritim tetiği için tek Yar Geç'te vurulması gereken en az düşman. */
	public static final int CLEAVE_RHYTHM_MIN_HITS = 3;
	public static final int CLEAVE_HEAL_MAX_TARGETS = 3;

	// Son Direniş
	public static final float LAST_STAND_HEALTH_RATIO = 0.30F;
	public static final int LAST_STAND_GRACE_TICKS = 80;
	public static final double LAST_STAND_GRACE_DR = 35.0;

	// Shunpo / kombo kaynaklı kısa süreli bonuslar
	public static final int SHUNPO_BUFF_TICKS = 60;
	public static final int SHUNPO_ARMOR_TICKS = 80;

	// Ağ / sunucu
	public static final int ACTION_MIN_INTERVAL_TICKS = 2;
	public static final int SYNC_MIN_INTERVAL_TICKS = 20;

	// Fısıltılar
	public static final int WHISPER_COOLDOWN_TICKS = 300;
	public static final int WHISPER_MIN_GAP_TICKS = 60;
	public static final double WHISPER_CHANCE_KILL = 0.12;
	public static final double WHISPER_CHANCE_BERSERK = 0.6;
	public static final double WHISPER_CHANCE_CLEAVE = 0.15;
	public static final double WHISPER_CHANCE_THROW = 0.3;
	public static final int LOW_HEALTH_WHISPER_COOLDOWN_TICKS = 2400;
	public static final float LOW_HEALTH_RATIO = 0.30F;
	public static final int SENTIENT_INTERVAL_TICKS = 3600;
	public static final int BOSS_SENSE_INTERVAL_TICKS = 100;
	public static final int BOSS_SENSE_COOLDOWN_TICKS = 3000;
	public static final double BOSS_SENSE_RANGE = 48.0;
	public static final int AURA_INTERVAL_TICKS = 20;
}
