package com.battleaxe.nexus;

import java.util.List;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan oyuncunun KENDİ istemcisine: ağacın görüntülenmesi için gereken özet.
 * İstemci bu veriyi yalnızca gösterir; hiçbir karar buna dayanmaz (otorite sunucudadır).
 */
public record NexusSyncPayload(List<String> unlocked, long lifetimeSouls, long soulsSpent, int earnedPoints)
		implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<NexusSyncPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("nexus_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, NexusSyncPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.stringUtf8(64).apply(ByteBufCodecs.list(256)),
			NexusSyncPayload::unlocked,
			ByteBufCodecs.VAR_LONG,
			NexusSyncPayload::lifetimeSouls,
			ByteBufCodecs.VAR_LONG,
			NexusSyncPayload::soulsSpent,
			ByteBufCodecs.VAR_INT,
			NexusSyncPayload::earnedPoints,
			NexusSyncPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
