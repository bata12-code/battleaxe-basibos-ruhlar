package com.battleaxe.nexus;

/** Lanetli Bilinç'in konuşabildiği olaylar. {@code id}, WHISPER_UNLOCK düğümlerinin param değeridir. */
public enum NexusEvent {
	KILL(1, true), BOSS(2, true), BIG(3, true), BERSERK(5, false), CLEAVE(6, false), THROW(7, false),
	LOW_HEALTH(8, false), NODE(9, false), MILESTONE(10, false), SENTIENT(11, false);

	public final int id;
	/** true ise olay, çoğu zaman kendi şansından bağımsız (boss/öldürme) olarak değerlendirilir. */
	public final boolean kill;

	NexusEvent(int id, boolean kill) {
		this.id = id;
		this.kill = kill;
	}

	public String key() {
		return name().toLowerCase(java.util.Locale.ROOT);
	}

	public static NexusEvent byId(int id) {
		for (NexusEvent event : values()) {
			if (event.id == id) {
				return event;
			}
		}
		return null;
	}
}
