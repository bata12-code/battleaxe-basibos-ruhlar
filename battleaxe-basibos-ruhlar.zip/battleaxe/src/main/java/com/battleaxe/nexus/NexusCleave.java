package com.battleaxe.nexus;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Yarık Gezgini'nin mevcut Yar Geç büyüsüne bağlandığı yer. Yeni bir büyü yoktur: YarGecAttack aynı akışta
 * çalışır, burası yalnızca değerleri (hasar, menzil, açı, hedef sayısı...) ve sonrasındaki kısa süreli
 * bonusları sağlar.
 *
 * <p>Bekleme süresi asla sıfırlanmaz: toplam azalma {@link NexusConfig#CLEAVE_MAX_COOLDOWN_REDUCTION} %
 * ile ve en az {@link NexusConfig#CLEAVE_MIN_COOLDOWN_TICKS} tick ile sınırlıdır. Kısa süreli bonuslar
 * aynı değerle süre yeniler, birikmez.
 */
public final class NexusCleave {
	private NexusCleave() {
	}

	/** Bir Yar Geç için ölçekler. */
	public record Mods(double damageMultiplier, double reachMultiplier, double extraAngleDegrees, int extraTargets,
			double knockbackMultiplier) {
		public static final Mods NONE = new Mods(1.0, 1.0, 0.0, 0, 1.0);
	}

	public static Mods mods(ServerPlayer player, int tier) {
		NexusStats stats = NexusManager.state(player).stats;
		if (stats.nodeCount() == 0) {
			return Mods.NONE;
		}
		double damage = 1.0 + stats.get(Stat.CLEAVE_DAMAGE_PCT) / 100.0;
		if (tier >= 3) {
			damage *= 1.0 + stats.get(Stat.CLEAVE_TIER3_DAMAGE_PCT) / 100.0;
		}
		return new Mods(
				damage,
				1.0 + stats.get(Stat.CLEAVE_REACH_PCT) / 100.0,
				stats.get(Stat.CLEAVE_ANGLE_DEG),
				(int) stats.get(Stat.CLEAVE_TARGETS),
				1.0 + stats.get(Stat.CLEAVE_KNOCKBACK_PCT) / 100.0);
	}

	/** Oyuncu şu an Yar Geç saldırısının içinde mi? (Evrim hasar kancası bunu okur.) */
	public static boolean isCleaving(ServerPlayer player) {
		return NexusManager.state(player).cleaveActive;
	}

	/** Yar Geç saldırısı sırasında normal vuruşa özgü bonusların (ağır/kritik) uygulanmasını kapatır. */
	public static void begin(ServerPlayer player) {
		NexusManager.state(player).cleaveActive = true;
	}

	public static void end(ServerPlayer player) {
		NexusManager.state(player).cleaveActive = false;
	}

	/**
	 * Yeni bekleme süresi (tick). Azalma sınırlıdır ve süre asla {@link NexusConfig#CLEAVE_MIN_COOLDOWN_TICKS}
	 * altına inmez. Ritim bonusu bir sonraki Yar Geç'e BİR KEZ uygulanır ve tüketilir.
	 */
	public static int cooldownTicks(ServerPlayer player, int baseTicks) {
		NexusState state = NexusManager.state(player);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return baseTicks;
		}
		double reduction = stats.get(Stat.CLEAVE_COOLDOWN_PCT);
		if (state.rhythmReady) {
			reduction += stats.get(Stat.CLEAVE_RHYTHM);
			state.rhythmReady = false;
		}
		reduction = Math.min(reduction, NexusConfig.CLEAVE_MAX_COOLDOWN_REDUCTION);
		int ticks = (int) Math.round(baseTicks * (1.0 - reduction / 100.0));
		return Math.max(Math.min(baseTicks, NexusConfig.CLEAVE_MIN_COOLDOWN_TICKS), ticks);
	}

	/** Dayanıklılık tasarrufu (Kara Çubuklu balta zaten kırılmaz; diğerlerinde işler). */
	public static boolean skipDurability(ServerPlayer player) {
		double save = NexusManager.state(player).stats.get(Stat.CLEAVE_DURABILITY_SAVE_PCT);
		return save > 0.0 && player.getRandom().nextDouble() * 100.0 < save;
	}

	/** Her isabette: sınırlı sayıda hedef için küçük şifa. */
	public static void onTargetHit(ServerPlayer player, int hitIndex) {
		double heal = NexusManager.state(player).stats.get(Stat.CLEAVE_HEAL_PER_HIT);
		if (heal > 0.0 && hitIndex <= NexusConfig.CLEAVE_HEAL_MAX_TARGETS && player.isAlive()) {
			player.heal((float) heal);
		}
	}

	/** Yar Geç bittiğinde: kısa süreli bonuslar, ritim, görsel/fısıltı geri bildirimi. */
	public static void afterCleave(ServerLevel level, ServerPlayer player, int hits, int tier, double reach) {
		NexusState state = NexusManager.state(player);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return;
		}
		long now = level.getGameTime();

		// Kısa süreli bonuslar yalnızca gerçekten bir şeye vurulduysa ("başarılı Yar Geç") tetiklenir.
		if (hits > 0) {
			state.activate(Buff.CLEAVE_SPEED, stats.get(Stat.POST_CLEAVE_SPEED_PCT), NexusConfig.CLEAVE_SPEED_TICKS, now);
			state.activate(Buff.CLEAVE_DAMAGE, stats.get(Stat.POST_CLEAVE_DAMAGE_PCT), NexusConfig.CLEAVE_DAMAGE_TICKS, now);
			state.activate(Buff.CLEAVE_ARMOR, stats.get(Stat.POST_CLEAVE_ARMOR), NexusConfig.CLEAVE_ARMOR_TICKS, now);
			NexusDamage.onSuccessfulHit(player);
			if (stats.has(Stat.CLEAVE_RHYTHM) && hits >= NexusConfig.CLEAVE_RHYTHM_MIN_HITS) {
				state.rhythmReady = true;
			}
		}

		if (stats.has(Stat.VISUAL_CLEAVE)) {
			double step = Math.max(1.0, reach / 4.0);
			double yaw = Math.toRadians(player.getYRot());
			double fx = -Math.sin(yaw);
			double fz = Math.cos(yaw);
			for (double d = step; d <= reach; d += step) {
				level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, player.getX() + fx * d, player.getY(0.5),
						player.getZ() + fz * d, 3, 0.25, 0.2, 0.25, 0.01);
			}
		}

		NexusWhispers.onCleave(level, player, state);
	}
}
