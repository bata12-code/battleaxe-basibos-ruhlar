package com.battleaxe.nexus;

import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

import com.battleaxe.BattleAxeMod;

/**
 * Ruh Ağı ilerlemesi OYUNCUYA bağlı kalıcı veridir (dünya kaydıyla saklanır, ölünce kopyalanır).
 * Baltaya yazılmaz: balta kopyalansa, sandığa konsa, yere atılsa ya da devredilse ilerleme çoğalmaz.
 */
public final class NexusAttachments {
	private NexusAttachments() {
	}

	public static final Codec<NexusData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.STRING.listOf().optionalFieldOf("unlocked", List.of()).forGetter(NexusData::unlocked),
			Codec.LONG.optionalFieldOf("lifetime_souls", 0L).forGetter(NexusData::lifetimeSouls),
			Codec.INT.optionalFieldOf("earned_points", 0).forGetter(NexusData::earnedPoints),
			Codec.LONG.optionalFieldOf("souls_spent", 0L).forGetter(NexusData::soulsSpent),
			Codec.DOUBLE.optionalFieldOf("soul_remainder", 0.0).forGetter(NexusData::soulRemainder)
	).apply(instance, NexusData::new));

	public static final AttachmentType<NexusData> DATA = AttachmentRegistry.create(
			BattleAxeMod.id("nexus"),
			builder -> builder.persistent(CODEC).copyOnDeath()
	);
}
