package com.battleaxe.nexus;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import com.battleaxe.BattleAxeMod;

/**
 * Ruh Ağı'nın öznitelik tabanlı etkileri (zırh, can, hız...). Yalnızca durum değiştiğinde çağrılır
 * (düğüm/tutma/rütbe/bonus süresi); aynı değer tekrar yazılmaz. Modifier'lar geçicidir (kaydedilmez),
 * bu yüzden sunucudan çıkıp girince sıkışıp kalmazlar. Değerler sabit KİMLİKLE yazılır: birikmez.
 */
final class NexusAttributes {
	private NexusAttributes() {
	}

	private static final Identifier ARMOR = BattleAxeMod.id("nexus_armor");
	private static final Identifier TOUGHNESS = BattleAxeMod.id("nexus_toughness");
	private static final Identifier KNOCKBACK = BattleAxeMod.id("nexus_knockback");
	private static final Identifier HEALTH_FLAT = BattleAxeMod.id("nexus_health_flat");
	private static final Identifier HEALTH_PCT = BattleAxeMod.id("nexus_health_pct");
	private static final Identifier SPEED = BattleAxeMod.id("nexus_speed");
	private static final Identifier ATTACK_SPEED = BattleAxeMod.id("nexus_attack_speed");

	/** Ağdan gelen toplam ek zırh üst sınırı. */
	private static final double MAX_ARMOR = 12.0;

	static void apply(ServerPlayer player, NexusState state, long now) {
		NexusStats stats = state.stats;
		double armor = 0.0;
		double toughness = 0.0;
		double knockback = 0.0;
		double healthFlat = 0.0;
		double healthPct = 0.0;
		double speed = 0.0;
		double attackSpeed = 0.0;

		// Ağ etkileri yalnızca baltayı ana elde tutarken geçerlidir (Berserker ve rütbe bonuslarıyla aynı kural).
		if (state.holding && stats.nodeCount() > 0) {
			armor = stats.get(Stat.ARMOR_FLAT) + stats.gated(Stat.RANK_ARMOR, state.rank)
					+ state.active(Buff.HIT_ARMOR, now) + state.active(Buff.CLEAVE_ARMOR, now)
					+ state.active(Buff.SHUNPO_ARMOR, now);
			toughness = stats.get(Stat.TOUGHNESS_FLAT);
			knockback = stats.get(Stat.KNOCKBACK_RESIST);
			healthFlat = stats.get(Stat.MAX_HEALTH_FLAT);
			healthPct = stats.get(Stat.MAX_HEALTH_PCT) / 100.0;
			speed = (stats.gated(Stat.RANK_SPEED_PCT, state.rank) + state.active(Buff.CLEAVE_SPEED, now)
					+ state.active(Buff.WHISPER_SPEED, now)) / 100.0;
			attackSpeed = (state.active(Buff.HASTE, now) + state.active(Buff.SHUNPO_HASTE, now)) / 100.0;
			armor = Math.min(armor, MAX_ARMOR);
		}

		set(player.getAttribute(Attributes.ARMOR), ARMOR, armor, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.ARMOR_TOUGHNESS), TOUGHNESS, toughness, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.KNOCKBACK_RESISTANCE), KNOCKBACK, knockback, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.MAX_HEALTH), HEALTH_FLAT, healthFlat, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.MAX_HEALTH), HEALTH_PCT, healthPct, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		set(player.getAttribute(Attributes.MOVEMENT_SPEED), SPEED, speed, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
		set(player.getAttribute(Attributes.ATTACK_SPEED), ATTACK_SPEED, attackSpeed, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);

		// Azami can düştüyse mevcut can onu aşmasın.
		if (player.getHealth() > player.getMaxHealth()) {
			player.setHealth(player.getMaxHealth());
		}
	}

	/** Oyuncu çıkarken/yeniden doğarken tüm Ruh Ağı modifier'larını temizler. */
	static void clear(ServerPlayer player) {
		set(player.getAttribute(Attributes.ARMOR), ARMOR, 0.0, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.ARMOR_TOUGHNESS), TOUGHNESS, 0.0, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.KNOCKBACK_RESISTANCE), KNOCKBACK, 0.0, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.MAX_HEALTH), HEALTH_FLAT, 0.0, AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.MAX_HEALTH), HEALTH_PCT, 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
		set(player.getAttribute(Attributes.MOVEMENT_SPEED), SPEED, 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
		set(player.getAttribute(Attributes.ATTACK_SPEED), ATTACK_SPEED, 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
	}

	private static void set(AttributeInstance attribute, Identifier id, double amount, AttributeModifier.Operation operation) {
		if (attribute == null) {
			return;
		}
		AttributeModifier existing = attribute.getModifier(id);
		if (Math.abs(amount) < 1.0E-9) {
			if (existing != null) {
				attribute.removeModifier(id);
			}
			return;
		}
		if (existing != null) {
			if (Math.abs(existing.amount() - amount) < 1.0E-9) {
				return;
			}
			attribute.removeModifier(id);
		}
		attribute.addTransientModifier(new AttributeModifier(id, amount, operation));
	}
}
