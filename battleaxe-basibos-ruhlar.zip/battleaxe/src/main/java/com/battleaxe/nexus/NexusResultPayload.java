package com.battleaxe.nexus;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/** Sunucudan istemciye: son işlemin sonucu (ekranda kısa bildirim olarak gösterilir). */
public record NexusResultPayload(boolean ok, String messageKey, String nodeId) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<NexusResultPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("nexus_result"));

	public static final StreamCodec<RegistryFriendlyByteBuf, NexusResultPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL,
			NexusResultPayload::ok,
			ByteBufCodecs.stringUtf8(64),
			NexusResultPayload::messageKey,
			ByteBufCodecs.stringUtf8(64),
			NexusResultPayload::nodeId,
			NexusResultPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
