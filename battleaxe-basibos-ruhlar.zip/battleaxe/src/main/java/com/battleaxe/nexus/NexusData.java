package com.battleaxe.nexus;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Bir OYUNCUNUN Ruh Ağı ilerlemesi (değişmez kayıt). İlerleme baltaya değil oyuncuya bağlıdır:
 * balta kopyalanabilir, sandığa konabilir, devredilebilir; düğümler ve puanlar oyuncuda kalır.
 *
 * @param unlocked       açılmış düğüm kimlikleri
 * @param lifetimeSouls  oyuncunun Ruh Bağı öldürme olaylarından biriktirdiği TOPLAM ruh (hiç azalmaz)
 * @param earnedPoints   şimdiye dek kazanılmış yetenek puanı (hiç azalmaz)
 * @param soulsSpent     sıfırlamalara harcanan toplam ruh
 * @param soulRemainder  yüzdesel ruh bonusunun taşıyan kesir kısmı (0 <= x < 1)
 */
public record NexusData(List<String> unlocked, long lifetimeSouls, int earnedPoints, long soulsSpent, double soulRemainder) {
	public static final NexusData EMPTY = new NexusData(List.of(), 0L, 0, 0L, 0.0);

	public NexusData {
		unlocked = List.copyOf(unlocked);
		lifetimeSouls = Math.max(0L, lifetimeSouls);
		earnedPoints = Math.max(0, Math.min(NexusConfig.MAX_POINTS, earnedPoints));
		soulsSpent = Math.max(0L, soulsSpent);
		soulRemainder = Double.isFinite(soulRemainder) ? Math.max(0.0, Math.min(0.999999, soulRemainder)) : 0.0;
	}

	public Set<String> unlockedSet() {
		return new LinkedHashSet<>(unlocked);
	}

	/** Harcanabilir ruh bakiyesi: toplam ruh - sıfırlamalara harcananlar. */
	public long soulBalance() {
		return Math.max(0L, lifetimeSouls - soulsSpent);
	}

	public NexusData withUnlocked(List<String> ids) {
		return new NexusData(ids, lifetimeSouls, earnedPoints, soulsSpent, soulRemainder);
	}

	public NexusData withSouls(long lifetime, int earned, double remainder) {
		return new NexusData(unlocked, lifetime, earned, soulsSpent, remainder);
	}

	public NexusData withSpent(long spent) {
		return new NexusData(unlocked, lifetimeSouls, earnedPoints, spent, soulRemainder);
	}
}
