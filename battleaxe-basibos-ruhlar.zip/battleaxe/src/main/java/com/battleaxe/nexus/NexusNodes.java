package com.battleaxe.nexus;

import static com.battleaxe.nexus.Branch.*;
import static com.battleaxe.nexus.NodeType.*;
import static com.battleaxe.nexus.Stat.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Ruh Ağı'nın 100 düğümlük TANIM TABLOSU (rol + önkoşul + etki). BU DOSYA tools/gen_nexus.py TARAFINDAN ÜRETİLİR;
 * elle düzenlemek yerine betiği düzenleyip yeniden çalıştır (betik ağı da doğrular).
 * Elle düzenlersen: NexusTree'nin açılışta çalıştırdığı doğrulama (sayılar, bağlantılar,
 * erişilebilirlik) hatalı bir tabloyu reddeder.
 *
 * <p>Her satır: kimlik, dal, tür, x, y (ağ koordinatı), bağlantılar, etkiler. Ad ve açıklamalar
 * dil dosyasından gelir (nexus.node.&lt;kimlik&gt;); açıklama etkilerden otomatik kurulur.
 */
final class NexusNodes {
	private NexusNodes() {
	}

	/** Bu dallar tabloda dönüşümlü olarak 20'şer düğüm içerir. */
	static List<NodeDef> create() {
		List<NodeDef> n = new ArrayList<>(100);

		// ---- Ruh Hâkimiyeti ----
		n.add(new NodeDef("soul_01", SOUL, SMALL, NodeRole.BASE, 0.000f, -1.000f,
				new String[] {"soul_02", "soul_03", "soul_04"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 3D)}));
		n.add(new NodeDef("soul_02", SOUL, SMALL, NodeRole.BASE, -1.050f, -1.950f,
				new String[] {"soul_01", "soul_04", "soul_05"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 3D)}));
		n.add(new NodeDef("soul_03", SOUL, SMALL, NodeRole.BASE, 1.050f, -1.950f,
				new String[] {"soul_01", "soul_04", "soul_06"},
				new String[] {},
				new Effect[] {fx(XP_ON_KILL, 1D)}));
		n.add(new NodeDef("soul_04", SOUL, MEDIUM, NodeRole.MECHANIC, 0.000f, -2.300f,
				new String[] {"soul_01", "soul_02", "soul_03", "soul_07"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 6D), fx(SOUL_STRONG_FLAT, 1D)}));
		n.add(new NodeDef("soul_05", SOUL, SMALL, NodeRole.SPECIALTY, -1.700f, -3.000f,
				new String[] {"soul_02", "soul_08", "soul_10"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 4D)}));
		n.add(new NodeDef("soul_06", SOUL, SMALL, NodeRole.SPECIALTY, 1.700f, -3.000f,
				new String[] {"soul_03", "soul_09", "soul_11"},
				new String[] {},
				new Effect[] {fx(HEAL_PER_SOUL, 0.1D)}));
		n.add(new NodeDef("soul_07", SOUL, SMALL, NodeRole.SPECIALTY, 0.000f, -3.300f,
				new String[] {"soul_04", "soul_10", "soul_11", "soul_12"},
				new String[] {},
				new Effect[] {fx(RANK_ARMOR, 1D, 3)}));
		n.add(new NodeDef("soul_08", SOUL, MEDIUM, NodeRole.SYNERGY, -2.150f, -4.200f,
				new String[] {"mind_09", "soul_05", "soul_13"},
				new String[] {"exec_04"},
				new Effect[] {fx(RANK_DAMAGE_PCT, 4D, 4), fx(FINISHER_KILL_SOULS, 1D)}));
		n.add(new NodeDef("soul_09", SOUL, MEDIUM, NodeRole.SYNERGY, 2.150f, -4.200f,
				new String[] {"exec_08", "soul_06", "soul_14"},
				new String[] {"guard_04"},
				new Effect[] {fx(RESET_DISCOUNT_PCT, 10D), fx(SOUL_GAIN_PCT, 3D), fx(HEAL_ON_KILL, 0.5D)}));
		n.add(new NodeDef("soul_10", SOUL, SMALL, NodeRole.SPECIALTY, -0.950f, -4.450f,
				new String[] {"soul_05", "soul_07", "soul_12", "soul_13"},
				new String[] {},
				new Effect[] {fx(LEDGER_DAMAGE_PCT, 2D, 500)}));
		n.add(new NodeDef("soul_11", SOUL, SMALL, NodeRole.SPECIALTY, 0.950f, -4.450f,
				new String[] {"soul_06", "soul_07", "soul_12", "soul_14"},
				new String[] {},
				new Effect[] {fx(HEAL_PER_SOUL, 0.15D)}));
		n.add(new NodeDef("soul_12", SOUL, MEDIUM, NodeRole.MECHANIC, 0.000f, -4.700f,
				new String[] {"soul_07", "soul_10", "soul_11", "soul_15"},
				new String[] {},
				new Effect[] {fx(SOUL_STRONG_FLAT, 1D), fx(SOUL_ELITE_PCT, 15D)}));
		n.add(new NodeDef("soul_13", SOUL, SMALL, NodeRole.SPECIALTY, -1.850f, -5.500f,
				new String[] {"soul_08", "soul_10", "soul_17", "soul_19"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 4D)}));
		n.add(new NodeDef("soul_14", SOUL, SMALL, NodeRole.SPECIALTY, 1.850f, -5.500f,
				new String[] {"soul_09", "soul_11", "soul_16"},
				new String[] {},
				new Effect[] {fx(RANK_SPEED_PCT, 3D, 5)}));
		n.add(new NodeDef("soul_15", SOUL, SMALL, NodeRole.SPECIALTY, 0.000f, -5.750f,
				new String[] {"soul_12", "soul_16", "soul_17", "soul_18"},
				new String[] {},
				new Effect[] {fx(LEDGER_DAMAGE_PCT, 2D, 2000)}));
		n.add(new NodeDef("soul_16", SOUL, SMALL, NodeRole.SPECIALTY, 1.050f, -6.400f,
				new String[] {"soul_14", "soul_15", "soul_18"},
				new String[] {},
				new Effect[] {fx(RESET_DISCOUNT_PCT, 8D)}));
		n.add(new NodeDef("soul_17", SOUL, MEDIUM, NodeRole.MECHANIC, -1.050f, -6.400f,
				new String[] {"soul_13", "soul_15", "soul_18", "soul_19"},
				new String[] {},
				new Effect[] {fx(XP_ON_KILL, 2D), fx(SOUL_GAIN_PCT, 5D)}));
		n.add(new NodeDef("soul_18", SOUL, LARGE, NodeRole.MAJOR, 0.000f, -7.150f,
				new String[] {"soul_15", "soul_16", "soul_17", "soul_20"},
				new String[] {},
				new Effect[] {fx(SOUL_ELITE_PCT, 40D), fx(SOUL_STRONG_FLAT, 1D)}));
		n.add(new NodeDef("soul_19", SOUL, LARGE, NodeRole.MAJOR, -2.300f, -7.200f,
				new String[] {"soul_13", "soul_17", "soul_20"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 12D), fx(HEAL_PER_SOUL, 0.15D)}));
		n.add(new NodeDef("soul_20", SOUL, CAPSTONE, NodeRole.MAJOR, -0.800f, -8.400f,
				new String[] {"soul_18", "soul_19"},
				new String[] {},
				new Effect[] {fx(SOUL_GAIN_PCT, 10D), fx(SOUL_ELITE_PCT, 30D), fx(LEDGER_DAMAGE_PCT, 6D, 5000), fx(FINISHER_KILL_SOULS, 1D)}));

		// ---- Cellat Yolu ----
		n.add(new NodeDef("exec_01", EXECUTIONER, SMALL, NodeRole.BASE, 0.951f, -0.309f,
				new String[] {"exec_02", "exec_03", "exec_04"},
				new String[] {},
				new Effect[] {fx(DAMAGE_PCT, 2D)}));
		n.add(new NodeDef("exec_02", EXECUTIONER, SMALL, NodeRole.BASE, 1.530f, -1.601f,
				new String[] {"exec_01", "exec_04", "exec_05"},
				new String[] {},
				new Effect[] {fx(CRIT_CHANCE_PCT, 3D)}));
		n.add(new NodeDef("exec_03", EXECUTIONER, SMALL, NodeRole.BASE, 2.179f, 0.396f,
				new String[] {"exec_01", "exec_04", "exec_06"},
				new String[] {},
				new Effect[] {fx(HEAVY_DAMAGE_PCT, 3D)}));
		n.add(new NodeDef("exec_04", EXECUTIONER, MEDIUM, NodeRole.MECHANIC, 2.187f, -0.711f,
				new String[] {"exec_01", "exec_02", "exec_03", "exec_07"},
				new String[] {},
				new Effect[] {fx(DAMAGE_PCT, 3D), fx(CRIT_DAMAGE_PCT, 5D)}));
		n.add(new NodeDef("exec_05", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 2.328f, -2.544f,
				new String[] {"exec_02", "exec_08", "exec_10"},
				new String[] {},
				new Effect[] {fx(LOW_TARGET_DAMAGE_PCT, 4D, 35)}));
		n.add(new NodeDef("exec_06", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 3.378f, 0.690f,
				new String[] {"exec_03", "exec_09", "exec_11"},
				new String[] {},
				new Effect[] {fx(STREAK_DAMAGE_PCT, 1D)}));
		n.add(new NodeDef("exec_07", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 3.138f, -1.020f,
				new String[] {"exec_04", "exec_10", "exec_11", "exec_12"},
				new String[] {},
				new Effect[] {fx(CRIT_DAMAGE_PCT, 5D)}));
		n.add(new NodeDef("exec_08", EXECUTIONER, MEDIUM, NodeRole.SYNERGY, 3.330f, -3.343f,
				new String[] {"exec_05", "exec_13", "soul_09"},
				new String[] {"soul_04"},
				new Effect[] {fx(STREAK_MAX_STACKS, 2D), fx(STREAK_DAMAGE_PCT, 1D), fx(SOUL_GAIN_PCT, 3D)}));
		n.add(new NodeDef("exec_09", EXECUTIONER, MEDIUM, NodeRole.SYNERGY, 4.659f, 0.747f,
				new String[] {"exec_06", "exec_14", "rift_08"},
				new String[] {"rift_04"},
				new Effect[] {fx(HEAVY_DAMAGE_PCT, 5D), fx(STRONG_TARGET_DAMAGE_PCT, 4D), fx(EXEC_CHANCE_PCT, 5D)}));
		n.add(new NodeDef("exec_10", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 3.939f, -2.279f,
				new String[] {"exec_05", "exec_07", "exec_12", "exec_13"},
				new String[] {},
				new Effect[] {fx(FULL_HEALTH_TARGET_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("exec_11", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 4.526f, -0.472f,
				new String[] {"exec_06", "exec_07", "exec_12", "exec_14"},
				new String[] {},
				new Effect[] {fx(ARMORED_TARGET_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("exec_12", EXECUTIONER, MEDIUM, NodeRole.MECHANIC, 4.470f, -1.452f,
				new String[] {"exec_07", "exec_10", "exec_11", "exec_15"},
				new String[] {},
				new Effect[] {fx(KILL_HASTE_PCT, 10D)}));
		n.add(new NodeDef("exec_13", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 4.659f, -3.459f,
				new String[] {"exec_08", "exec_10", "exec_17", "exec_19"},
				new String[] {},
				new Effect[] {fx(CRIT_CHANCE_PCT, 3D)}));
		n.add(new NodeDef("exec_14", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 5.802f, 0.060f,
				new String[] {"exec_09", "exec_11", "exec_16"},
				new String[] {},
				new Effect[] {fx(STREAK_WINDOW_TICKS, 40D)}));
		n.add(new NodeDef("exec_15", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 5.469f, -1.777f,
				new String[] {"exec_12", "exec_16", "exec_17", "exec_18"},
				new String[] {},
				new Effect[] {fx(BERSERK_DAMAGE_PCT, 6D)}));
		n.add(new NodeDef("exec_16", EXECUTIONER, SMALL, NodeRole.SPECIALTY, 6.411f, -0.979f,
				new String[] {"exec_14", "exec_15", "exec_18"},
				new String[] {},
				new Effect[] {fx(THROW_DAMAGE_PCT, 8D)}));
		n.add(new NodeDef("exec_17", EXECUTIONER, MEDIUM, NodeRole.MECHANIC, 5.762f, -2.976f,
				new String[] {"exec_13", "exec_15", "exec_18", "exec_19"},
				new String[] {},
				new Effect[] {fx(LOW_TARGET_DAMAGE_PCT, 8D, 25), fx(CRIT_CHANCE_PCT, 2D), fx(EXEC_HEALTH_RATIO_PCT, 5D)}));
		n.add(new NodeDef("exec_18", EXECUTIONER, LARGE, NodeRole.MAJOR, 6.800f, -2.209f,
				new String[] {"exec_15", "exec_16", "exec_17", "exec_20"},
				new String[] {},
				new Effect[] {fx(DAMAGE_PCT, 25D), fx(MAX_HEALTH_PCT, -20D)}));
		n.add(new NodeDef("exec_19", EXECUTIONER, LARGE, NodeRole.MAJOR, 6.137f, -4.412f,
				new String[] {"exec_13", "exec_17", "exec_20"},
				new String[] {},
				new Effect[] {fx(CRIT_CHANCE_PCT, 8D), fx(CRIT_DAMAGE_PCT, 15D)}));
		n.add(new NodeDef("exec_20", EXECUTIONER, CAPSTONE, NodeRole.MAJOR, 7.742f, -3.357f,
				new String[] {"exec_18", "exec_19"},
				new String[] {},
				new Effect[] {fx(EXECUTE_THRESHOLD_PCT, 12D), fx(DAMAGE_PCT, 5D), fx(KILL_HASTE_PCT, 10D), fx(EXEC_CHANCE_PCT, 15D), fx(EXEC_HEALTH_RATIO_PCT, 5D)}));

		// ---- Yarık Gezgini ----
		n.add(new NodeDef("rift_01", RIFT, SMALL, NodeRole.BASE, 0.588f, 0.809f,
				new String[] {"rift_02", "rift_03", "rift_04"},
				new String[] {},
				new Effect[] {fx(CLEAVE_COOLDOWN_PCT, 3D)}));
		n.add(new NodeDef("rift_02", RIFT, SMALL, NodeRole.BASE, 1.996f, 0.960f,
				new String[] {"rift_01", "rift_04", "rift_05"},
				new String[] {},
				new Effect[] {fx(CLEAVE_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("rift_03", RIFT, SMALL, NodeRole.BASE, 0.297f, 2.195f,
				new String[] {"rift_01", "rift_04", "rift_06"},
				new String[] {},
				new Effect[] {fx(CLEAVE_ANGLE_DEG, 5D)}));
		n.add(new NodeDef("rift_04", RIFT, MEDIUM, NodeRole.MECHANIC, 1.352f, 1.861f,
				new String[] {"rift_01", "rift_02", "rift_03", "rift_07"},
				new String[] {},
				new Effect[] {fx(SHUNPO_WINDOW_TICKS, 20D), fx(POST_CLEAVE_SPEED_PCT, 12D)}));
		n.add(new NodeDef("rift_05", RIFT, SMALL, NodeRole.SPECIALTY, 3.139f, 1.428f,
				new String[] {"rift_02", "rift_08", "rift_10"},
				new String[] {},
				new Effect[] {fx(CLEAVE_REACH_PCT, 4D)}));
		n.add(new NodeDef("rift_06", RIFT, SMALL, NodeRole.SPECIALTY, 0.388f, 3.426f,
				new String[] {"rift_03", "rift_09", "rift_11"},
				new String[] {},
				new Effect[] {fx(CLEAVE_COOLDOWN_PCT, 4D)}));
		n.add(new NodeDef("rift_07", RIFT, SMALL, NodeRole.SPECIALTY, 1.940f, 2.670f,
				new String[] {"rift_04", "rift_10", "rift_11", "rift_12"},
				new String[] {},
				new Effect[] {fx(CLEAVE_KNOCKBACK_PCT, 10D)}));
		n.add(new NodeDef("rift_08", RIFT, MEDIUM, NodeRole.SYNERGY, 4.208f, 2.134f,
				new String[] {"exec_09", "rift_05", "rift_13"},
				new String[] {"exec_04"},
				new Effect[] {fx(CLEAVE_DAMAGE_PCT, 6D), fx(CLEAVE_DURABILITY_SAVE_PCT, 30D), fx(COMBO_FINISH_PCT, 12D)}));
		n.add(new NodeDef("rift_09", RIFT, MEDIUM, NodeRole.SYNERGY, 0.729f, 4.662f,
				new String[] {"guard_08", "rift_06", "rift_14"},
				new String[] {"mind_03"},
				new Effect[] {fx(POST_CLEAVE_DAMAGE_PCT, 8D), fx(HIDDET_COMBO_PCT, 10D)}));
		n.add(new NodeDef("rift_10", RIFT, SMALL, NodeRole.SPECIALTY, 3.384f, 3.042f,
				new String[] {"rift_05", "rift_07", "rift_12", "rift_13"},
				new String[] {},
				new Effect[] {fx(CLEAVE_TARGETS, 1D)}));
		n.add(new NodeDef("rift_11", RIFT, SMALL, NodeRole.SPECIALTY, 1.847f, 4.159f,
				new String[] {"rift_06", "rift_07", "rift_12", "rift_14"},
				new String[] {},
				new Effect[] {fx(POST_CLEAVE_SPEED_PCT, 8D), fx(SHUNPO_HASTE_PCT, 8D)}));
		n.add(new NodeDef("rift_12", RIFT, MEDIUM, NodeRole.MECHANIC, 2.763f, 3.802f,
				new String[] {"rift_07", "rift_10", "rift_11", "rift_15"},
				new String[] {},
				new Effect[] {fx(COMBO_RETARGET, 1D), fx(CLEAVE_TIER3_DAMAGE_PCT, 12D), fx(CLEAVE_REACH_PCT, 4D)}));
		n.add(new NodeDef("rift_13", RIFT, SMALL, NodeRole.SPECIALTY, 4.730f, 3.362f,
				new String[] {"rift_08", "rift_10", "rift_17", "rift_19"},
				new String[] {},
				new Effect[] {fx(CLEAVE_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("rift_14", RIFT, SMALL, NodeRole.SPECIALTY, 1.736f, 5.537f,
				new String[] {"rift_09", "rift_11", "rift_16"},
				new String[] {},
				new Effect[] {fx(CLEAVE_HEAL_PER_HIT, 0.3D)}));
		n.add(new NodeDef("rift_15", RIFT, SMALL, NodeRole.SPECIALTY, 3.380f, 4.652f,
				new String[] {"rift_12", "rift_16", "rift_17", "rift_18"},
				new String[] {},
				new Effect[] {fx(CLEAVE_COOLDOWN_PCT, 4D), fx(COMBO_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("rift_16", RIFT, SMALL, NodeRole.SPECIALTY, 2.912f, 5.795f,
				new String[] {"rift_14", "rift_15", "rift_18"},
				new String[] {},
				new Effect[] {fx(CLEAVE_ANGLE_DEG, 5D), fx(COMBO_DAMAGE_PCT, 4D)}));
		n.add(new NodeDef("rift_17", RIFT, MEDIUM, NodeRole.MECHANIC, 4.611f, 4.561f,
				new String[] {"rift_13", "rift_15", "rift_18", "rift_19"},
				new String[] {},
				new Effect[] {fx(COMBO_SWEEP_TARGETS, 1D), fx(CLEAVE_TARGETS, 1D), fx(CLEAVE_COOLDOWN_PCT, 5D)}));
		n.add(new NodeDef("rift_18", RIFT, LARGE, NodeRole.MAJOR, 4.203f, 5.784f,
				new String[] {"rift_15", "rift_16", "rift_17", "rift_20"},
				new String[] {},
				new Effect[] {fx(COMBO_RETARGET_RADIUS, 2D), fx(COMBO_FINISH_PCT, 10D), fx(CLEAVE_REACH_PCT, 15D), fx(CLEAVE_TARGETS, 2D), fx(CLEAVE_ANGLE_DEG, 10D)}));
		n.add(new NodeDef("rift_19", RIFT, LARGE, NodeRole.MAJOR, 6.093f, 4.473f,
				new String[] {"rift_13", "rift_17", "rift_20"},
				new String[] {},
				new Effect[] {fx(COMBO_SWEEP_TARGETS, 1D), fx(COMBO_FINISH_PCT, 12D), fx(CLEAVE_TIER3_DAMAGE_PCT, 25D), fx(CLEAVE_KNOCKBACK_PCT, 20D), fx(POST_CLEAVE_DAMAGE_PCT, 8D)}));
		n.add(new NodeDef("rift_20", RIFT, CAPSTONE, NodeRole.MAJOR, 5.585f, 6.326f,
				new String[] {"rift_18", "rift_19"},
				new String[] {},
				new Effect[] {fx(COMBO_DAMAGE_PCT, 10D), fx(SHUNPO_WINDOW_TICKS, 20D), fx(SHUNPO_HASTE_PCT, 15D), fx(CLEAVE_RHYTHM, 35D), fx(CLEAVE_DAMAGE_PCT, 8D), fx(CLEAVE_COOLDOWN_PCT, 5D)}));

		// ---- Ruh Muhafızı ----
		n.add(new NodeDef("guard_01", GUARD, SMALL, NodeRole.BASE, -0.588f, 0.809f,
				new String[] {"guard_02", "guard_03", "guard_04"},
				new String[] {},
				new Effect[] {fx(ARMOR_FLAT, 1D)}));
		n.add(new NodeDef("guard_02", GUARD, SMALL, NodeRole.BASE, -0.297f, 2.195f,
				new String[] {"guard_01", "guard_04", "guard_05"},
				new String[] {},
				new Effect[] {fx(KNOCKBACK_RESIST, 0.1D)}));
		n.add(new NodeDef("guard_03", GUARD, SMALL, NodeRole.BASE, -1.996f, 0.960f,
				new String[] {"guard_01", "guard_04", "guard_06"},
				new String[] {},
				new Effect[] {fx(DAMAGE_REDUCTION_PCT, 2D)}));
		n.add(new NodeDef("guard_04", GUARD, MEDIUM, NodeRole.MECHANIC, -1.352f, 1.861f,
				new String[] {"guard_01", "guard_02", "guard_03", "guard_07"},
				new String[] {},
				new Effect[] {fx(ARMOR_FLAT, 1D), fx(ON_HIT_ARMOR, 2D)}));
		n.add(new NodeDef("guard_05", GUARD, SMALL, NodeRole.SPECIALTY, -0.388f, 3.426f,
				new String[] {"guard_02", "guard_08", "guard_10"},
				new String[] {},
				new Effect[] {fx(MAX_HEALTH_FLAT, 2D)}));
		n.add(new NodeDef("guard_06", GUARD, SMALL, NodeRole.SPECIALTY, -3.139f, 1.428f,
				new String[] {"guard_03", "guard_09", "guard_11"},
				new String[] {},
				new Effect[] {fx(DR_PROJECTILE_PCT, 5D)}));
		n.add(new NodeDef("guard_07", GUARD, SMALL, NodeRole.SPECIALTY, -1.940f, 2.670f,
				new String[] {"guard_04", "guard_10", "guard_11", "guard_12"},
				new String[] {},
				new Effect[] {fx(DR_FIRE_PCT, 6D)}));
		n.add(new NodeDef("guard_08", GUARD, MEDIUM, NodeRole.SYNERGY, -0.729f, 4.662f,
				new String[] {"guard_05", "guard_13", "rift_09"},
				new String[] {"rift_04"},
				new Effect[] {fx(DR_LOW_HEALTH_PCT, 8D), fx(SHUNPO_ARMOR, 3D), fx(SHUNPO_HEAL, 1D)}));
		n.add(new NodeDef("guard_09", GUARD, MEDIUM, NodeRole.SYNERGY, -4.208f, 2.134f,
				new String[] {"guard_06", "guard_14", "mind_08"},
				new String[] {"mind_03"},
				new Effect[] {fx(POST_CLEAVE_ARMOR, 3D), fx(BERSERK_DR_PCT, 3D)}));
		n.add(new NodeDef("guard_10", GUARD, SMALL, NodeRole.SPECIALTY, -1.847f, 4.159f,
				new String[] {"guard_05", "guard_07", "guard_12", "guard_13"},
				new String[] {},
				new Effect[] {fx(DR_EXPLOSION_PCT, 6D)}));
		n.add(new NodeDef("guard_11", GUARD, SMALL, NodeRole.SPECIALTY, -3.384f, 3.042f,
				new String[] {"guard_06", "guard_07", "guard_12", "guard_14"},
				new String[] {},
				new Effect[] {fx(DR_FALL_PCT, 8D)}));
		n.add(new NodeDef("guard_12", GUARD, MEDIUM, NodeRole.MECHANIC, -2.763f, 3.802f,
				new String[] {"guard_07", "guard_10", "guard_11", "guard_15"},
				new String[] {},
				new Effect[] {fx(TOUGHNESS_FLAT, 2D), fx(MAX_HEALTH_FLAT, 2D)}));
		n.add(new NodeDef("guard_13", GUARD, SMALL, NodeRole.SPECIALTY, -1.736f, 5.537f,
				new String[] {"guard_08", "guard_10", "guard_17", "guard_19"},
				new String[] {},
				new Effect[] {fx(HEAL_ON_KILL, 0.5D)}));
		n.add(new NodeDef("guard_14", GUARD, SMALL, NodeRole.SPECIALTY, -4.730f, 3.362f,
				new String[] {"guard_09", "guard_11", "guard_16"},
				new String[] {},
				new Effect[] {fx(DR_MELEE_PCT, 3D)}));
		n.add(new NodeDef("guard_15", GUARD, SMALL, NodeRole.SPECIALTY, -3.380f, 4.652f,
				new String[] {"guard_12", "guard_16", "guard_17", "guard_18"},
				new String[] {},
				new Effect[] {fx(BERSERK_DR_PCT, 5D)}));
		n.add(new NodeDef("guard_16", GUARD, SMALL, NodeRole.SPECIALTY, -4.611f, 4.561f,
				new String[] {"guard_14", "guard_15", "guard_18"},
				new String[] {},
				new Effect[] {fx(LIFESTEAL_PCT, 2D), fx(EXEC_FINISH_HEAL, 1D)}));
		n.add(new NodeDef("guard_17", GUARD, MEDIUM, NodeRole.MECHANIC, -2.912f, 5.795f,
				new String[] {"guard_13", "guard_15", "guard_18", "guard_19"},
				new String[] {},
				new Effect[] {fx(DR_MELEE_PCT, 4D), fx(KNOCKBACK_RESIST, 0.1D)}));
		n.add(new NodeDef("guard_18", GUARD, LARGE, NodeRole.MAJOR, -4.203f, 5.784f,
				new String[] {"guard_15", "guard_16", "guard_17", "guard_20"},
				new String[] {},
				new Effect[] {fx(MAX_HEALTH_FLAT, 6D), fx(ARMOR_FLAT, 3D), fx(TOUGHNESS_FLAT, 1D), fx(DAMAGE_PCT, -15D)}));
		n.add(new NodeDef("guard_19", GUARD, LARGE, NodeRole.MAJOR, -2.371f, 7.177f,
				new String[] {"guard_13", "guard_17", "guard_20"},
				new String[] {},
				new Effect[] {fx(DAMAGE_REDUCTION_PCT, 7D), fx(ON_HIT_ARMOR, 3D), fx(SHUNPO_ARMOR, 3D), fx(DAMAGE_PCT, -10D)}));
		n.add(new NodeDef("guard_20", GUARD, CAPSTONE, NodeRole.MAJOR, -4.290f, 7.266f,
				new String[] {"guard_18", "guard_19"},
				new String[] {},
				new Effect[] {fx(LAST_STAND, 300D), fx(HEAL_ON_KILL, 0.5D), fx(DAMAGE_REDUCTION_PCT, 3D), fx(SHUNPO_HEAL, 2D), fx(EXEC_FINISH_HEAL, 1D)}));

		// ---- Lanetli Bilinç ----
		n.add(new NodeDef("mind_01", MIND, SMALL, NodeRole.BASE, -0.951f, -0.309f,
				new String[] {"mind_02", "mind_03", "mind_04"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 1)}));
		n.add(new NodeDef("mind_02", MIND, SMALL, NodeRole.BASE, -2.179f, 0.396f,
				new String[] {"mind_01", "mind_04", "mind_05"},
				new String[] {},
				new Effect[] {fx(RANK_REACT, 1D, 2)}));
		n.add(new NodeDef("mind_03", MIND, SMALL, NodeRole.BASE, -1.530f, -1.601f,
				new String[] {"mind_01", "mind_04", "mind_06"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 5)}));
		n.add(new NodeDef("mind_04", MIND, MEDIUM, NodeRole.MECHANIC, -2.187f, -0.711f,
				new String[] {"mind_01", "mind_02", "mind_03", "mind_07"},
				new String[] {},
				new Effect[] {fx(WHISPER_COOLDOWN_PCT, 15D), fx(VISUAL_KILL_WISP, 1D)}));
		n.add(new NodeDef("mind_05", MIND, SMALL, NodeRole.SPECIALTY, -3.378f, 0.690f,
				new String[] {"mind_02", "mind_08", "mind_10"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 6)}));
		n.add(new NodeDef("mind_06", MIND, SMALL, NodeRole.SPECIALTY, -2.328f, -2.544f,
				new String[] {"mind_03", "mind_09", "mind_11"},
				new String[] {},
				new Effect[] {fx(RANK_REACT, 1D, 4)}));
		n.add(new NodeDef("mind_07", MIND, SMALL, NodeRole.SPECIALTY, -3.138f, -1.020f,
				new String[] {"mind_04", "mind_10", "mind_11", "mind_12"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 7)}));
		n.add(new NodeDef("mind_08", MIND, MEDIUM, NodeRole.SYNERGY, -4.659f, 0.747f,
				new String[] {"guard_09", "mind_05", "mind_13"},
				new String[] {"exec_04"},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 8), fx(WHISPER_HEAL, 1D), fx(HIDDET_ROAR_HEAL, 1D)}));
		n.add(new NodeDef("mind_09", MIND, MEDIUM, NodeRole.SYNERGY, -3.330f, -3.343f,
				new String[] {"mind_06", "mind_14", "soul_08"},
				new String[] {"soul_04"},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 2), fx(KARA_DAMAGE_PCT, 5D), fx(SOUL_ELITE_PCT, 10D)}));
		n.add(new NodeDef("mind_10", MIND, SMALL, NodeRole.SPECIALTY, -4.526f, -0.472f,
				new String[] {"mind_05", "mind_07", "mind_12", "mind_13"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 9)}));
		n.add(new NodeDef("mind_11", MIND, SMALL, NodeRole.SPECIALTY, -3.939f, -2.279f,
				new String[] {"mind_06", "mind_07", "mind_12", "mind_14"},
				new String[] {},
				new Effect[] {fx(RANK_REACT, 1D, 6)}));
		n.add(new NodeDef("mind_12", MIND, MEDIUM, NodeRole.MECHANIC, -4.470f, -1.452f,
				new String[] {"mind_07", "mind_10", "mind_11", "mind_15"},
				new String[] {},
				new Effect[] {fx(VISUAL_AURA, 1D), fx(WHISPER_BUFF_PCT, 6D)}));
		n.add(new NodeDef("mind_13", MIND, SMALL, NodeRole.SPECIALTY, -5.802f, 0.060f,
				new String[] {"mind_08", "mind_10", "mind_17", "mind_19"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 3)}));
		n.add(new NodeDef("mind_14", MIND, SMALL, NodeRole.SPECIALTY, -4.659f, -3.459f,
				new String[] {"mind_09", "mind_11", "mind_16"},
				new String[] {},
				new Effect[] {fx(WHISPER_UNLOCK, 1D, 10)}));
		n.add(new NodeDef("mind_15", MIND, SMALL, NodeRole.SPECIALTY, -5.469f, -1.777f,
				new String[] {"mind_12", "mind_16", "mind_17", "mind_18"},
				new String[] {},
				new Effect[] {fx(RANK_REACT, 1D, 8)}));
		n.add(new NodeDef("mind_16", MIND, SMALL, NodeRole.SPECIALTY, -5.762f, -2.976f,
				new String[] {"mind_14", "mind_15", "mind_18"},
				new String[] {},
				new Effect[] {fx(VISUAL_RANKUP, 1D)}));
		n.add(new NodeDef("mind_17", MIND, MEDIUM, NodeRole.MECHANIC, -6.411f, -0.979f,
				new String[] {"mind_13", "mind_15", "mind_18", "mind_19"},
				new String[] {},
				new Effect[] {fx(BOSS_SENSE, 1D), fx(KARA_DR_PCT, 8D)}));
		n.add(new NodeDef("mind_18", MIND, LARGE, NodeRole.MAJOR, -6.800f, -2.209f,
				new String[] {"mind_15", "mind_16", "mind_17", "mind_20"},
				new String[] {},
				new Effect[] {fx(HIDDET_COMBO_PCT, 5D), fx(WHISPER_COOLDOWN_PCT, 25D), fx(WHISPER_HEAL, 2D), fx(WHISPER_BUFF_PCT, 6D)}));
		n.add(new NodeDef("mind_19", MIND, LARGE, NodeRole.MAJOR, -7.558f, -0.037f,
				new String[] {"mind_13", "mind_17", "mind_20"},
				new String[] {},
				new Effect[] {fx(HIDDET_COMBO_PCT, 15D), fx(HIDDET_COMBO_COST, 1D), fx(HIDDET_ROAR_HEAL, 1D), fx(KARA_DAMAGE_PCT, 10D), fx(KARA_DR_PCT, 8D), fx(VISUAL_CLEAVE, 1D)}));
		n.add(new NodeDef("mind_20", MIND, CAPSTONE, NodeRole.MAJOR, -8.236f, -1.835f,
				new String[] {"mind_18", "mind_19"},
				new String[] {},
				new Effect[] {fx(HIDDET_ROAR_HEAL, 2D), fx(SENTIENT, 1D), fx(WHISPER_UNLOCK, 1D, 11), fx(WHISPER_BUFF_PCT, 8D), fx(RANK_REACT, 1D, 9)}));

		return n;
	}

	private static Effect fx(Stat stat, double value) {
		return new Effect(stat, value, 0);
	}

	private static Effect fx(Stat stat, double value, int param) {
		return new Effect(stat, value, param);
	}
}
