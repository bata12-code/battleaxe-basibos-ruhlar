package com.battleaxe.nexus;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Ruh Ağı'nın sabit düğüm grafiği. Hem sunucu hem istemci aynı tabloyu (mod jar'ı) kullanır.
 * Açılışta tablo doğrulanır: tam 100 düğüm, dal başına 12/5/2/1, tüm bağlantılar çift yönlü,
 * her düğüm çekirdekten ulaşılabilir, her dal diğer dallara ihtiyaç duymadan tamamlanabilir.
 */
public final class NexusTree {
	private static final List<NodeDef> NODES;
	private static final Map<String, NodeDef> BY_ID = new HashMap<>();
	private static final Map<String, Integer> INDEX = new HashMap<>();
	private static final Map<Branch, List<NodeDef>> BY_BRANCH = new EnumMap<>(Branch.class);

	static {
		NODES = Collections.unmodifiableList(NexusNodes.create());
		for (int i = 0; i < NODES.size(); i++) {
			NodeDef node = NODES.get(i);
			BY_ID.put(node.id(), node);
			INDEX.put(node.id(), i);
			BY_BRANCH.computeIfAbsent(node.branch(), key -> new ArrayList<>()).add(node);
		}
		List<String> errors = validate();
		if (!errors.isEmpty()) {
			throw new IllegalStateException("Ruh Ağı tablosu geçersiz: " + errors);
		}
	}

	private NexusTree() {
	}

	public static List<NodeDef> all() {
		return NODES;
	}

	public static NodeDef get(String id) {
		return BY_ID.get(id);
	}

	public static int indexOf(String id) {
		return INDEX.getOrDefault(id, -1);
	}

	public static List<NodeDef> branch(Branch branch) {
		return BY_BRANCH.getOrDefault(branch, List.of());
	}

	/** Düğümün ek önkoşullarının (başka daldan olabilir) TÜMÜ açık mı? Önkoşulsuz düğüm için her zaman true. */
	public static boolean requirementsMet(Set<String> owned, NodeDef node) {
		for (String required : node.requires()) {
			if (!owned.contains(required)) {
				return false;
			}
		}
		return true;
	}

	/** Çekirdekten (her zaman açık) veya açık bir komşudan ulaşılıyor mu? */
	public static boolean isReachable(Set<String> owned, NodeDef node) {
		if (node.isGate()) {
			return true;
		}
		for (String link : node.links()) {
			if (owned.contains(link)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Verilen kimliklerden bilinmeyenleri ve çekirdekle bağlantısı kopanları atar; sıralamayı korur.
	 * Tablo sürümler arası değişirse kayıtlı ilerleme güvenle düzelir (puanlar otomatik iade olur).
	 */
	public static List<String> sanitize(Collection<String> ids) {
		Set<String> known = new LinkedHashSet<>();
		for (String id : ids) {
			if (BY_ID.containsKey(id)) {
				known.add(id);
			}
		}
		Set<String> connected = new HashSet<>();
		ArrayDeque<String> queue = new ArrayDeque<>();
		for (String id : known) {
			if (BY_ID.get(id).isGate()) {
				connected.add(id);
				queue.add(id);
			}
		}
		while (!queue.isEmpty()) {
			NodeDef current = BY_ID.get(queue.poll());
			for (String link : current.links()) {
				if (known.contains(link) && connected.add(link)) {
					queue.add(link);
				}
			}
		}
		// Önkoşulu (requires) sağlanmayan düğümler de atılır; bu bir düğümün atılmasının başkasını düşürebileceği
		// anlamına geldiğinden değişiklik kalmayana dek tekrarlanır (sonlanır: her turda en az bir düğüm azalır).
		Set<String> kept = new LinkedHashSet<>();
		for (String id : known) {
			if (connected.contains(id)) {
				kept.add(id);
			}
		}
		boolean changed = true;
		while (changed) {
			changed = false;
			for (String id : new ArrayList<>(kept)) {
				if (!requirementsMet(kept, BY_ID.get(id))) {
					kept.remove(id);
					changed = true;
				}
			}
		}
		return new ArrayList<>(kept);
	}

	public static List<NodeDef> resolve(Collection<String> ids) {
		List<NodeDef> list = new ArrayList<>(ids.size());
		for (String id : ids) {
			NodeDef node = BY_ID.get(id);
			if (node != null) {
				list.add(node);
			}
		}
		return list;
	}

	/** Tablo tutarlılık denetimi; boş liste = geçerli. */
	public static List<String> validate() {
		List<String> errors = new ArrayList<>();
		if (NODES.size() != 100) {
			errors.add("düğüm sayısı 100 değil: " + NODES.size());
		}
		if (BY_ID.size() != NODES.size()) {
			errors.add("kimlik çakışması");
		}
		for (Branch branch : Branch.values()) {
			int small = 0;
			int medium = 0;
			int large = 0;
			int capstone = 0;
			for (NodeDef node : branch(branch)) {
				switch (node.type()) {
					case SMALL -> small++;
					case MEDIUM -> medium++;
					case LARGE -> large++;
					case CAPSTONE -> capstone++;
				}
			}
			if (small != 12 || medium != 5 || large != 2 || capstone != 1) {
				errors.add("dal dağılımı hatalı: " + branch + " " + small + "/" + medium + "/" + large + "/" + capstone);
			}
		}
		for (NodeDef node : NODES) {
			if (node.effects().length == 0) {
				errors.add("etkisiz düğüm: " + node.id());
			}
			for (Effect effect : node.effects()) {
				if (effect.stat().kind == Stat.Kind.SUM && effect.stat().max < Math.abs(effect.value())
						&& effect.stat().min >= 0.0) {
					errors.add("etki sınırın üstünde: " + node.id());
				}
			}
			for (String link : node.links()) {
				NodeDef other = BY_ID.get(link);
				if (other == null) {
					errors.add("bilinmeyen bağlantı: " + node.id() + " -> " + link);
				} else if (!List.of(other.links()).contains(node.id())) {
					errors.add("tek yönlü bağlantı: " + node.id() + " -> " + link);
				}
			}
		}
		// Önkoşullar: yalnızca başka daldaki ERKEN (no <= 7) düğümlere işaret edebilir. Böylece döngü olamaz ve
		// bir dalı tamamlamak için başka dalın ileri düğümlerini açmak gerekmez.
		for (NodeDef node : NODES) {
			for (String required : node.requires()) {
				NodeDef req = BY_ID.get(required);
				if (req == null) {
					errors.add("bilinmeyen önkoşul: " + node.id() + " -> " + required);
				} else if (req.branch() == node.branch()) {
					errors.add("önkoşul başka daldan olmalı: " + node.id());
				} else if (Integer.parseInt(required.substring(required.indexOf('_') + 1)) > 7) {
					errors.add("önkoşul erken düğüm olmalı: " + node.id() + " -> " + required);
				}
			}
			if ((node.role() == NodeRole.SYNERGY) != (node.requires().length > 0)) {
				errors.add("yalnızca sinerji düğümlerinin önkoşulu olmalı (ve hepsinin olmalı): " + node.id());
			}
		}
		// Çekirdekten (tüm geçitlerden) erişilebilirlik
		Set<String> seen = new HashSet<>();
		ArrayDeque<String> queue = new ArrayDeque<>();
		for (NodeDef node : NODES) {
			if (node.isGate()) {
				seen.add(node.id());
				queue.add(node.id());
			}
		}
		while (!queue.isEmpty()) {
			for (String link : BY_ID.get(queue.poll()).links()) {
				if (BY_ID.containsKey(link) && seen.add(link)) {
					queue.add(link);
				}
			}
		}
		if (seen.size() != NODES.size()) {
			errors.add("ulaşılamayan düğüm var: " + (NODES.size() - seen.size()));
		}
		// Her dal kendi içinde tam bağlı olmalı (başka dalları tamamlamaya zorlanmasın)
		for (Branch branch : Branch.values()) {
			Set<String> inBranch = new HashSet<>();
			ArrayDeque<String> q = new ArrayDeque<>();
			for (NodeDef node : branch(branch)) {
				if (node.isGate()) {
					inBranch.add(node.id());
					q.add(node.id());
				}
			}
			while (!q.isEmpty()) {
				for (String link : BY_ID.get(q.poll()).links()) {
					NodeDef other = BY_ID.get(link);
					if (other != null && other.branch() == branch && inBranch.add(link)) {
						q.add(link);
					}
				}
			}
			if (inBranch.size() != branch(branch).size()) {
				errors.add("dal kendi içinde bağlı değil: " + branch);
			}
		}
		return errors;
	}
}
