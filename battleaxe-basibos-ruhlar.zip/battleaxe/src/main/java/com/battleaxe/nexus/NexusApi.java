package com.battleaxe.nexus;

import java.util.UUID;

import net.minecraft.server.level.ServerPlayer;

/**
 * Ruh Ağı'nın DIŞ DÜNYAYA açtığı küçük ve kararlı arayüz. Shunpo kombosu, Execution ve Hiddet gibi sistemler ağın
 * iç sınıflarına (NexusState, NexusManager) dokunmaz; yalnızca buradaki fonksiyonları çağırır. Yeni bir düğüm etkisi
 * eklemek bu sistemleri yeniden yazmayı gerektirmez: {@link Stat} eklenir, ilgili sistem {@link #stats} üzerinden okur.
 *
 * <p>Hepsi yalnızca SUNUCU iş parçacığından çağrılır.
 */
public final class NexusApi {
	private NexusApi() {
	}

	/** Oyuncunun açık düğümlerinden hesaplanmış (önbellekli, sıkıştırılmış) etkileri. Düğüm yoksa boştur. */
	public static NexusStats stats(ServerPlayer player) {
		return NexusManager.state(player).stats;
	}

	/** Shunpo ışınlanması başarıyla bittiğinde: kısa süreli hız/zırh ve (can yarının altındaysa) şifa. */
	public static void onShunpo(ServerPlayer player, long now) {
		NexusState state = NexusManager.state(player);
		NexusStats stats = state.stats;
		if (stats.nodeCount() == 0) {
			return;
		}
		state.activate(Buff.SHUNPO_HASTE, stats.get(Stat.SHUNPO_HASTE_PCT), NexusConfig.SHUNPO_BUFF_TICKS, now);
		state.activate(Buff.SHUNPO_ARMOR, stats.get(Stat.SHUNPO_ARMOR), NexusConfig.SHUNPO_ARMOR_TICKS, now);
		double heal = stats.get(Stat.SHUNPO_HEAL);
		if (heal > 0.0 && player.isAlive() && player.getHealth() < player.getMaxHealth() * 0.5F) {
			player.heal((float) heal);
		}
	}

	/** Normal Execution bitirici olasılığına eklenecek oran (0.05 = 5 puan). */
	public static double executionChanceBonus(ServerPlayer player) {
		return stats(player).get(Stat.EXEC_CHANCE_PCT) / 100.0;
	}

	/** Execution için gereken hedef can oranına eklenecek oran (0.05 = 5 puan). */
	public static float executionHealthRatioBonus(ServerPlayer player) {
		return (float) (stats(player).get(Stat.EXEC_HEALTH_RATIO_PCT) / 100.0);
	}

	/** Bitirici (Execution) tamamlandığında: can yenileme. */
	public static void onExecutionFinish(ServerPlayer player) {
		double heal = stats(player).get(Stat.EXEC_FINISH_HEAL);
		if (heal > 0.0 && player.isAlive()) {
			player.heal((float) heal);
		}
	}

	/**
	 * Bu varlığın yakın zamandaki ölümü bir BİTİRİCİ öldürüş sayılır (Execution veya kombo bitirici). Ruh ödülü hesabı
	 * ({@link NexusSoul}) bunu okuyup ek ruh verir; aynı öldürme olayına tek ödül yazılır, ikinci bir ödül yoktur.
	 *
	 * @param expiresAt bu oyun zamanından sonra işaret geçersizdir
	 */
	public static void markFinisherKill(ServerPlayer player, UUID victim, long expiresAt) {
		NexusState state = NexusManager.state(player);
		state.finisherVictim = victim;
		state.finisherExpiry = expiresAt;
	}

	/** Bu tick'te Cellat darbesi (düğümden gelen kritik) tetiklendi mi? Hiddet kükremesi için "kritik" bilgisi. */
	public static boolean critProcThisTick(ServerPlayer player, long now) {
		return NexusManager.state(player).critProcTick == now;
	}
}
