package com.battleaxe.nexus;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * İstemciden sunucuya: ağ isteği. Sunucu her alanı doğrular; istemciye güvenilmez.
 *
 * @param action        0 = durum iste, 1 = düğüm satın al, 2 = sıfırla
 * @param nodeId        satın alınacak düğüm (yalnızca action 1)
 * @param expectedCount sıfırlamada oyuncunun onayladığı düğüm sayısı (sunucudakiyle eşleşmezse reddedilir)
 */
public record NexusActionPayload(int action, String nodeId, int expectedCount) implements CustomPacketPayload {
	public static final int SYNC = 0;
	public static final int PURCHASE = 1;
	public static final int RESET = 2;

	public static final CustomPacketPayload.Type<NexusActionPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("nexus_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, NexusActionPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT,
			NexusActionPayload::action,
			ByteBufCodecs.stringUtf8(64),
			NexusActionPayload::nodeId,
			ByteBufCodecs.VAR_INT,
			NexusActionPayload::expectedCount,
			NexusActionPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
