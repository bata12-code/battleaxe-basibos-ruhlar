package com.battleaxe.nexus;

/** Saf matematik: deneyim puanı dönüşümleri, puan eşikleri, sıfırlama bedeli. Minecraft'a bağımlı değildir. */
public final class NexusMath {
	private NexusMath() {
	}

	// ----------------------------- Deneyim -----------------------------

	/** Vanilla: bir sonraki seviye için o seviyede gereken deneyim puanı. */
	public static int xpNeededForNextLevel(int level) {
		if (level >= 30) {
			return 112 + (level - 30) * 9;
		}
		if (level >= 15) {
			return 37 + (level - 15) * 5;
		}
		return 7 + level * 2;
	}

	/** Vanilla: 0. seviyeden verilen seviyeye ulaşmak için gereken TOPLAM deneyim puanı. */
	public static int levelsToPoints(int level) {
		if (level <= 0) {
			return 0;
		}
		if (level <= 16) {
			return level * level + 6 * level;
		}
		if (level <= 31) {
			return (int) Math.round(2.5 * level * level - 40.5 * level + 360.0);
		}
		return (int) Math.round(4.5 * level * level - 162.5 * level + 2220.0);
	}

	/** Oyuncunun sahip olduğu toplam deneyim puanı (seviye + seviye içi ilerleme). */
	public static long playerPoints(int level, float progress) {
		int lvl = Math.max(0, level);
		float p = Math.max(0.0F, Math.min(1.0F, progress));
		return (long) levelsToPoints(lvl) + Math.round(p * xpNeededForNextLevel(lvl));
	}

	/** Toplam deneyim puanını (seviye, ilerleme) karşılığına çevirir. */
	public static int levelFromPoints(long points) {
		int level = 0;
		while (level < 100_000 && levelsToPoints(level + 1) <= points) {
			level++;
		}
		return level;
	}

	// ----------------------------- Yetenek puanı -----------------------------

	/** n. yetenek puanının (n >= 1) kazanılması için gereken toplam ruh. */
	public static long thresholdForPoint(int n) {
		if (n <= 0) {
			return 0L;
		}
		return (long) Math.ceil(NexusConfig.POINT_BASE * StrictMath.pow(n, NexusConfig.POINT_EXPONENT));
	}

	/** Toplam ruh ilerlemesiyle kazanılmış olması gereken puan sayısı (MAX_POINTS ile sınırlı). */
	public static int pointsForLifetime(long lifetimeSouls) {
		if (lifetimeSouls <= 0) {
			return 0;
		}
		int n = (int) Math.min(NexusConfig.MAX_POINTS,
				StrictMath.pow(lifetimeSouls / NexusConfig.POINT_BASE, 1.0 / NexusConfig.POINT_EXPONENT));
		while (n < NexusConfig.MAX_POINTS && thresholdForPoint(n + 1) <= lifetimeSouls) {
			n++;
		}
		while (n > 0 && thresholdForPoint(n) > lifetimeSouls) {
			n--;
		}
		return n;
	}

	// ----------------------------- Sıfırlama bedeli -----------------------------

	/** n düğümü sıfırlamanın ruh bedeli; {@code discountPct} 0-100 arası indirimdir. Düğüm sayısıyla artar. */
	public static long resetSouls(int nodeCount, double discountPct) {
		if (nodeCount <= 0) {
			return 0L;
		}
		double n = nodeCount;
		double raw = NexusConfig.RESET_SOULS_BASE * n + NexusConfig.RESET_SOULS_GROWTH * n * (n - 1.0) / 2.0;
		double discount = Math.max(0.0, Math.min(90.0, discountPct));
		return Math.max(1L, Math.round(raw * (1.0 - discount / 100.0)));
	}

	/** n düğümü sıfırlamanın XP bedeli, seviye cinsinden. */
	public static int resetXpLevels(int nodeCount) {
		if (nodeCount <= 0) {
			return 0;
		}
		return Math.min(NexusConfig.RESET_XP_MAX_LEVELS,
				NexusConfig.RESET_XP_BASE_LEVELS + nodeCount / NexusConfig.RESET_XP_NODES_PER_LEVEL);
	}

	/** n düğümü sıfırlamanın XP bedeli, gerçek deneyim PUANI cinsinden. */
	public static int resetXpPoints(int nodeCount) {
		return levelsToPoints(resetXpLevels(nodeCount));
	}
}
