package com.battleaxe.nexus;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * Normal (vanilla) saldırının bağlamını kaydeder: tam şarjlı mı (ağır vuruş), kritik koşulları var mı.
 * PlayerMixin#attack başında çağrılır; hasar kancası (NexusDamage) aynı tick içinde bunu okur.
 */
public final class NexusCombat {
	private NexusCombat() {
	}

	public static void beginAttack(ServerPlayer player, Entity target) {
		NexusState state = NexusManager.state(player);
		if (state.stats.nodeCount() == 0) {
			return;
		}
		state.attackTick = player.level().getGameTime();
		state.attackTargetId = target.getId();
		float strength = player.getAttackStrengthScale(0.5F);
		state.attackStrength = strength;

		// Vanilla kritik koşullarının yansıması: yalnızca "kritik şansı" düğümleri için ipucu olarak kullanılır
		// (vanilla zaten kritik hasarı kendi uygular; ağ yalnızca üstüne yüzde ekler).
		state.attackCritHint = strength >= NexusConfig.HEAVY_STRENGTH
				&& target instanceof LivingEntity
				&& player.fallDistance > 0.0
				&& !player.onGround()
				&& !player.onClimbable()
				&& !player.isInWater()
				&& !player.isPassenger()
				&& !player.isSprinting();
	}
}
