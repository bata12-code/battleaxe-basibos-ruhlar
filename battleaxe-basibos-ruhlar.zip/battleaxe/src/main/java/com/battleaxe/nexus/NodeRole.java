package com.battleaxe.nexus;

/**
 * Düğümün ağdaki ROLÜ (boyut/maliyet {@link NodeType}'tan ayrıdır). Rol, oyuncuya düğümün ne işe yaradığını anlatır
 * ve arayüzde gösterilir; oyun mantığı yine yalnızca etkilere ({@link Stat}) bağlıdır.
 */
public enum NodeRole {
	/** Uzmanlık alanının giriş noktası: o dalın temel gücü. */
	BASE("base"),
	/** Yeni bir davranış veya kullanım biçimi açar. */
	MECHANIC("mechanic"),
	/** Var olan bir sistemin belirli bir yönünü geliştirir. */
	SPECIALTY("specialty"),
	/** İki dalı ya da iki mekanik sistemi birbirine bağlar; başka daldan önkoşul ister. */
	SYNERGY("synergy"),
	/** Savaş biçimini belirgin değiştiren, yüksek maliyetli seçim. */
	MAJOR("major");

	public final String id;

	NodeRole(String id) {
		this.id = id;
	}

	public String langKey() {
		return "nexus.role." + id;
	}
}
