package com.battleaxe.nexus;

import net.minecraft.server.level.ServerPlayer;

/**
 * Vanilla deneyim sistemiyle uyumlu XP işlemleri. Bedel GERÇEK deneyim PUANI olarak hesaplanır
 * (seviye + seviye içi ilerleme); düşüş vanilla'nın kendi mantığıyla (giveExperiencePoints negatif)
 * seviye ve ilerleme çubuğuna doğru yansır.
 */
final class NexusXp {
	private NexusXp() {
	}

	static long points(ServerPlayer player) {
		return NexusMath.playerPoints(player.experienceLevel, player.experienceProgress);
	}

	/** Yeterli XP varsa düşer ve true döner; yetersizse hiçbir şey değiştirmez. */
	static boolean deduct(ServerPlayer player, long cost) {
		if (cost <= 0L) {
			return true;
		}
		if (cost > Integer.MAX_VALUE || points(player) < cost) {
			return false;
		}
		player.giveExperiencePoints(-(int) cost);
		return true;
	}

	/** Geri ödeme (yalnızca beklenmedik bir hatada, işlemi geri almak için). */
	static void refund(ServerPlayer player, long cost) {
		if (cost > 0L && cost <= Integer.MAX_VALUE) {
			player.giveExperiencePoints((int) cost);
		}
	}
}
