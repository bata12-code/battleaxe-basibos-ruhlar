package com.battleaxe.nexus;

/** Ruh Ağı'nın beş ana dalı. Kimlik, dil anahtarlarında ve düğüm kimliklerinin önekinde kullanılır. */
public enum Branch {
	SOUL("soul", 0x4FD8FF),
	EXECUTIONER("exec", 0xFF5A4A),
	RIFT("rift", 0xC780FF),
	GUARD("guard", 0xFFC84A),
	MIND("mind", 0x7DFF9A);

	/** Kısa kimlik: düğüm kimliği "<id>_<no>" biçimindedir. */
	public final String id;
	/** Dalın ağdaki rengi (RGB). */
	public final int rgb;

	Branch(String id, int rgb) {
		this.id = id;
		this.rgb = rgb;
	}

	public String langKey() {
		return "nexus.branch." + id;
	}

	public static Branch byId(String id) {
		for (Branch branch : values()) {
			if (branch.id.equals(id)) {
				return branch;
			}
		}
		return null;
	}
}
