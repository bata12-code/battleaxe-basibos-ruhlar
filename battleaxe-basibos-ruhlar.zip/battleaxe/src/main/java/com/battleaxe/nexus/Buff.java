package com.battleaxe.nexus;

/** Kısa süreli Ruh Ağı bonusları. Aynı tetik bonusu BİRİKTİRMEZ: değer sabittir, yalnızca süre yenilenir. */
enum Buff {
	HASTE, CLEAVE_DAMAGE, CLEAVE_SPEED, CLEAVE_ARMOR, HIT_ARMOR, WHISPER_SPEED, GRACE, SHUNPO_HASTE, SHUNPO_ARMOR
}
