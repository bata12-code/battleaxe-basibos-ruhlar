package com.battleaxe.chain;

import java.util.ArrayList;
import java.util.List;

/**
 * <b>Gözün Yankısı</b>'nın SAF karar mantığı (test: tools/test/ChainWhisperTest.java).
 *
 * <p>Lore: Öncü Belirtiler baltayı edinince kalıcı olarak susar; oyuncu "çağıran şey baltaydı" sanır. Ama zincir en üst kademeye
 * (Ragnarök) ulaştığında, açık gökyüzünün altında gece, susan şey bir an geri döner: Sana Bakan Şey (mevcut göz tezahürü) belirir
 * ve birkaç saniye sonra balta rütbesine göre bir söz söyler ("Seni ben çağırmadım."). Hiçbir şey açıklanmaz; soru yalnızca derinleşir.
 *
 * <p>Nadirdir: ilk uygun Ragnarök'te kesin gerçekleşir (oyuncu başına KALICI sayaç), sonrakilerde giderek azalan olasılıkla ve uzun
 * bir beklemeyle. Gerçek bir varlık, blok, hasar ya da ödül yoktur; yalnızca mevcut {@code OmenPayload} görüntüsüdür.
 */
public final class ChainEchoLogic {
	private ChainEchoLogic() {
	}

	/** Yankı yalnızca bu kademede (Ragnarök) tetiklenir. */
	public static final int TRIGGER_TIER = ChainLogic.MAX_TIER;
	/** İki yankı arası en kısa süre (tick): 20 dakika. */
	public static final long COOLDOWN_TICKS = 24_000L;
	/** İkinci yankının olasılığı; sonrakiler bunun sayıya bölümüdür. */
	public static final double REPEAT_BASE_CHANCE = 0.30;
	/** En düşük olasılık: yankı hiçbir zaman tamamen imkânsız olmaz. */
	public static final double MIN_CHANCE = 0.06;
	/** Kalıcı sayaç üst sınırı. */
	public static final int MAX_SEEN = 99;
	/** Sözün gözden ne kadar sonra söyleneceği (tick) üst sınırı: oyuncu önce gözü fark etsin. */
	public static final int WHISPER_DELAY_TICKS = 70;

	private static final String PREFIX = "message.battleaxe.chain.eye.";

	/** Bu kademe yankıyı tetikler mi? */
	public static boolean triggers(int tier) {
		return tier >= TRIGGER_TIER;
	}

	/** Şimdiye dek görülen yankı sayısına göre olasılık: ilk kez 1, sonra 0.30, 0.15, 0.10 ... (en az {@link #MIN_CHANCE}). */
	public static double chance(int seen) {
		if (seen <= 0) {
			return 1.0;
		}
		return Math.max(MIN_CHANCE, REPEAT_BASE_CHANCE / seen);
	}

	/**
	 * Yankı gerçekleşmeli mi? {@code roll}: 0-1 rastgele; {@code lastEchoTick}: bu oturumdaki son yankı (yoksa negatif).
	 * İlk yankıda bekleme uygulanmaz (oturum başında bir kez). Zaman geriye giderse takılı kalmaz.
	 */
	public static boolean shouldEcho(int seen, double roll, long now, long lastEchoTick) {
		if (!(roll < chance(seen))) {
			return false;
		}
		return lastEchoTick < 0L || now < lastEchoTick || now - lastEchoTick >= COOLDOWN_TICKS;
	}

	/** Söz gözden kaç tick sonra söylenir: göz süresinden kısa kalır, ama oyuncunun fark etmesine yetecek kadar sonra. */
	public static int whisperDelay(int eyeTicks) {
		return Math.max(20, Math.min(WHISPER_DELAY_TICKS, eyeTicks - 40));
	}

	/** Kalıcı sayaç artışı (üst sınırlı). */
	public static int nextSeen(int seen) {
		return Math.min(MAX_SEEN, Math.max(0, seen) + 1);
	}

	/** Dil anahtarı: bant 0-2 ({@link ChainWhisperLogic#band}), {@code first}: bu oyuncunun ilk yankısı. */
	public static String key(int band, boolean first) {
		return PREFIX + Math.max(0, Math.min(ChainWhisperLogic.BANDS - 1, band)) + (first ? ".first" : ".later");
	}

	/** Tüm dil anahtarları (çeviri bütünlüğü testi için). */
	public static List<String> allKeys() {
		List<String> keys = new ArrayList<>();
		for (int band = 0; band < ChainWhisperLogic.BANDS; band++) {
			keys.add(key(band, true));
			keys.add(key(band, false));
		}
		return keys;
	}
}
