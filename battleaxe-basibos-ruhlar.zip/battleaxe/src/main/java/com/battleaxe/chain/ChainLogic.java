package com.battleaxe.chain;

/**
 * Kıyım Zinciri'nin SAF mantığı (Minecraft'a bağımlı değildir; test: tools/test/ChainLogicTest.java).
 * Oyun nesnelerini okuyup bu fonksiyonlara sayı olarak verir; kararlar burada alınır.
 */
public final class ChainLogic {
	private ChainLogic() {
	}

	/** Kademe sayısı (0 = zincir henüz eşikte değil). */
	public static final int MAX_TIER = ChainConfig.TIER_THRESHOLDS.length;

	private static final int[] DUST_START = {0xFF9A2E, 0xFF9A2E, 0xFF2B2B, 0xB04CFF, 0xFFF2B0};
	private static final int[] DUST_END = {0xB02A00, 0xB02A00, 0x600000, 0x3A0070, 0xFFB000};

	/** Bir düşmanın zincire katkısı: büyük/boss daha çok sayılır. Geçersiz can en küçük katkıdır. */
	public static int weight(float maxHealth) {
		if (!(maxHealth > 0.0F)) {
			return 1;
		}
		if (maxHealth >= ChainConfig.BIG_MOB_HEALTH) {
			return 3;
		}
		return maxHealth >= ChainConfig.MEDIUM_MOB_HEALTH ? 2 : 1;
	}

	/** Zincire gerçekten eklenecek katkı: normalde {@link #weight}; deneme modunda çarpanla büyütülür. */
	public static int effectiveWeight(int weight) {
		int base = Math.max(1, weight);
		return ChainConfig.TEST_MODE ? base * Math.max(1, ChainConfig.TEST_WEIGHT_FACTOR) : base;
	}

	/** Sayaçtan kademe (0..MAX_TIER). */
	public static int tierOf(int count) {
		int tier = 0;
		for (int i = 0; i < ChainConfig.TIER_THRESHOLDS.length; i++) {
			if (count >= ChainConfig.TIER_THRESHOLDS[i]) {
				tier = i + 1;
			}
		}
		return tier;
	}

	/** Bu kademedeki iki öldürme arası en uzun süre. Aralık dışı kademe sınırlanır. */
	public static int windowFor(int tier) {
		int t = Math.max(0, Math.min(MAX_TIER, tier));
		return ChainConfig.BASE_WINDOW_TICKS + t * ChainConfig.WINDOW_BONUS_PER_TIER;
	}

	/** Zincir hâlâ canlı mı? Zaman geriye giderse (veri bozulması) canlı sayılmaz; takılı kalmaz. */
	public static boolean alive(int count, long lastKillTick, long now) {
		if (count <= 0 || lastKillTick < 0L || now < lastKillTick) {
			return false;
		}
		return now - lastKillTick <= windowFor(tierOf(count));
	}

	public static boolean alive(ChainState state, long now) {
		return alive(state.count(), state.lastKillTick(), now);
	}

	/** Bir öldürmeden sonraki sayaç: canlı zincire eklenir, kopmuşsa yeniden başlar. Üst sınır uygulanır. */
	public static int advance(int count, long lastKillTick, long now, int weight) {
		int base = alive(count, lastKillTick, now) ? count : 0;
		long sum = (long) base + Math.max(1, weight);
		return (int) Math.min(ChainConfig.MAX_COUNT, sum);
	}

	/** Bir sonraki kademenin eşiği; en üst kademedeyse 0. */
	public static int nextThreshold(int count) {
		int tier = tierOf(count);
		return tier >= MAX_TIER ? 0 : ChainConfig.TIER_THRESHOLDS[tier];
	}

	/** Bir sonraki kademeye ilerleme (0-1); en üst kademede 1. HUD'daki ince ilerleme çizgisi içindir. */
	public static float tierProgress(int count) {
		int tier = tierOf(count);
		if (tier >= MAX_TIER) {
			return 1.0F;
		}
		int low = tier == 0 ? 0 : ChainConfig.TIER_THRESHOLDS[tier - 1];
		int high = ChainConfig.TIER_THRESHOLDS[tier];
		float progress = (count - low) / (float) (high - low);
		return Math.max(0.0F, Math.min(1.0F, progress));
	}

	/** Bu öldürme kademe atlattı mı? */
	public static boolean isTierUp(int before, int after) {
		return tierOf(after) > tierOf(before);
	}

	public static double damageBonus(int tier) {
		return ChainConfig.DAMAGE_BONUS[Math.max(0, Math.min(MAX_TIER, tier))];
	}

	public static double speedBonus(int tier) {
		return ChainConfig.SPEED_BONUS[Math.max(0, Math.min(MAX_TIER, tier))];
	}

	/** Zincirin kalan süresi (tick): 0..pencere; canlı değilse 0. HUD'a bildirilen değer budur. */
	public static int remainingTicks(int count, long lastKillTick, long now) {
		if (!alive(count, lastKillTick, now)) {
			return 0;
		}
		int window = windowFor(tierOf(count));
		return (int) Math.max(0L, Math.min(window, window - (now - lastKillTick)));
	}

	/**
	 * Süreyi {@code bonusTicks} uzatan yeni "son öldürme" zamanı: kalan süre en çok pencereye çıkar (dolu zincirde değişmez). Kopmuş
	 * ya da geçersiz zincir uzatılamaz (aynı zaman döner).
	 */
	public static long extendedLastKill(long now, long lastKillTick, int window, int bonusTicks) {
		if (window <= 0 || bonusTicks <= 0 || lastKillTick < 0L || now < lastKillTick) {
			return lastKillTick;
		}
		long remaining = window - (now - lastKillTick);
		if (remaining < 0L) {
			return lastKillTick;
		}
		long newRemaining = Math.min((long) window, remaining + bonusTicks);
		return now - (window - newRemaining);
	}

	/** Alınan hasarın zincirden götürdüğü süre (tick): hasar x tick/can, üst sınırlı. Geçersiz/negatif hasar 0. */
	public static int penaltyTicks(float damage) {
		if (!(damage > 0.0F)) {
			return 0;
		}
		double raw = Math.min((double) ChainConfig.DAMAGE_PENALTY_MAX_TICKS, damage * ChainConfig.DAMAGE_PENALTY_TICKS_PER_HP);
		return (int) Math.round(raw);
	}

	/** Cezalı "son öldürme" zamanı: kalan süre ceza kadar kısalır. Zaman damgası asla negatife düşmez (negatif "zincir yok" demektir). */
	public static long penalizedLastKill(long lastKillTick, int penaltyTicks) {
		if (lastKillTick < 0L) {
			return lastKillTick;
		}
		return Math.max(0L, lastKillTick - Math.max(0, penaltyTicks));
	}

	/** Süre çubuğunda dolu hücre sayısı (0..cells): kalan süreyle orantılı, canlıyken en az 1. */
	public static int barCells(long now, long lastKillTick, int window, int cells) {
		if (window <= 0 || cells <= 0 || lastKillTick < 0L || now < lastKillTick) {
			return 0;
		}
		long remaining = window - (now - lastKillTick);
		if (remaining < 0L) {
			return 0; // süre bitti (alive ile aynı sınır: pencerenin son tickinde zincir hâlâ canlıdır, çubuk 1 hücre)
		}
		long filled = (remaining * cells + window - 1) / window; // yukarı yuvarla
		return (int) Math.max(1L, Math.min(cells, filled));
	}

	/** Çubuğu metne çevirir: dolu hücreler "|", boşlar ".". */
	public static String barText(int filled, int cells) {
		int f = Math.max(0, Math.min(cells, filled));
		return "|".repeat(f) + ".".repeat(cells - f);
	}

	/** Aura parçacık sayısı: kademe 0'da yok, sonra kademe + 1. */
	public static int orbiterCount(int tier) {
		return tier <= 0 ? 0 : Math.min(MAX_TIER, tier) + 1;
	}

	/** Aura yarıçapı (kademeyle büyür). */
	public static double orbitRadius(int tier) {
		return ChainConfig.ORBIT_RADIUS + ChainConfig.ORBIT_RADIUS_PER_TIER * Math.max(0, Math.min(MAX_TIER, tier));
	}

	/** {@code index}. dönen noktanın açısı (radyan): kademe yükseldikçe daha hızlı döner; noktalar eşit aralıklıdır. */
	public static double orbitAngle(long tick, int tier, int index, int total) {
		double speed = 0.18 + 0.05 * Math.max(0, Math.min(MAX_TIER, tier));
		double offset = total <= 0 ? 0.0 : (2.0 * Math.PI * index) / total;
		return tick * speed + offset;
	}

	public static double orbitX(double angle, double radius) {
		return Math.cos(angle) * radius;
	}

	public static double orbitZ(double angle, double radius) {
		return Math.sin(angle) * radius;
	}

	/** Dönen noktanın dikey sallanması (0..0.5 blok): canlı, dalgalı bir halka. */
	public static double orbitLift(long tick, int index) {
		return 0.25 + 0.25 * Math.sin(tick * 0.2 + index * 1.7);
	}

	public static int dustStart(int tier) {
		return DUST_START[Math.max(0, Math.min(MAX_TIER, tier))];
	}

	public static int dustEnd(int tier) {
		return DUST_END[Math.max(0, Math.min(MAX_TIER, tier))];
	}
}
