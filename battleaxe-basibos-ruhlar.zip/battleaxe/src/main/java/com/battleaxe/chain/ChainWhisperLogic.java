package com.battleaxe.chain;

import java.util.ArrayList;
import java.util.List;

/**
 * Baltanın Kıyım Zinciri'ne tepkisi: kademe atlayınca balta rütbesine göre konuşur (SAF mantık; test:
 * tools/test/ChainWhisperTest.java). Üç ton vardır (bant): tanımayan/mesafeli (rütbe 0-2), susamış ve kanlı (3-6), sadık ve
 * kadim (7-9). Her kademe x bant için {@link #VARIANTS} söz vardır; art arda aynı söz seçilmez. Metinler dil dosyalarındadır:
 * {@code message.battleaxe.chain.whisper.<kademe>.<bant>.<söz>}.
 */
public final class ChainWhisperLogic {
	private ChainWhisperLogic() {
	}

	public static final int BANDS = 3;
	public static final int VARIANTS = 2;
	/** İki fısıltı arası en kısa süre (tick): zincir kopup hızla yeniden kurulsa da balta susmadan konuşmaz. */
	public static final int COOLDOWN_TICKS = 400;

	private static final double[] CHANCE_BY_TIER = {0.0, 0.50, 0.65, 0.85, 1.0};
	private static final String PREFIX = "message.battleaxe.chain.whisper.";

	/** Rütbe 0-2 -> 0 (yabancı), 3-6 -> 1 (susamış), 7+ -> 2 (sadık). Negatif rütbe 0 sayılır. */
	public static int band(int rank) {
		if (rank >= 7) {
			return 2;
		}
		return rank >= 3 ? 1 : 0;
	}

	/** Bu kademe atlayışında konuşma olasılığı (0-1). Geçersiz kademe konuşmaz. */
	public static double chance(int tier) {
		if (tier < 1) {
			return 0.0;
		}
		return CHANCE_BY_TIER[Math.min(tier, ChainLogic.MAX_TIER)];
	}

	/** Konuşmalı mı? {@code roll}: 0-1 rastgele; {@code lastTick}: son fısıltı (yoksa negatif). Zaman geriye giderse serbest bırakır. */
	public static boolean shouldWhisper(int tier, double roll, long now, long lastTick) {
		if (!(roll < chance(tier))) {
			return false;
		}
		return lastTick < 0L || now < lastTick || now - lastTick >= COOLDOWN_TICKS;
	}

	/** 1..VARIANTS arası söz; {@code last} (0 = yok) ile aynı olmaz. {@code roll01}: 0-1 rastgele. */
	public static int pickVariant(double roll01, int last) {
		double clamped = Double.isNaN(roll01) ? 0.0 : Math.max(0.0, Math.min(0.999999, roll01));
		int pick = (int) (clamped * VARIANTS) + 1;
		if (VARIANTS > 1 && pick == last) {
			pick = pick % VARIANTS + 1;
		}
		return pick;
	}

	/** Dil anahtarı. */
	public static String key(int tier, int band, int variant) {
		return PREFIX + Math.max(1, Math.min(ChainLogic.MAX_TIER, tier)) + "." + Math.max(0, Math.min(BANDS - 1, band)) + "."
				+ Math.max(1, Math.min(VARIANTS, variant));
	}

	/** Tüm dil anahtarları (çeviri bütünlüğü testi için). */
	public static List<String> allKeys() {
		List<String> keys = new ArrayList<>();
		for (int tier = 1; tier <= ChainLogic.MAX_TIER; tier++) {
			for (int band = 0; band < BANDS; band++) {
				for (int variant = 1; variant <= VARIANTS; variant++) {
					keys.add(key(tier, band, variant));
				}
			}
		}
		return keys;
	}
}
