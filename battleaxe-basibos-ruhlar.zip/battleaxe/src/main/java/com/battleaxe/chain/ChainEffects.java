package com.battleaxe.chain;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;

/**
 * Kıyım Zinciri'nin görsel ve işitsel efektleri. Tümü SUNUCUDA üretilir (parçacık/ses paketleri yalnızca yakındaki
 * oyunculara gider); hiçbir hasar/ölüm/dünya değişikliği yapmaz. Yalnızca mevcut efekt sınıflarında zaten kullanılan
 * ses ve parçacık türlerini kullanır.
 */
final class ChainEffects {
	private ChainEffects() {
	}

	/** Kademe 0..4 için dust: renk geçişi {@link ChainLogic}'te (saf, test edilir). */
	private static final DustColorTransitionOptions[] DUST = new DustColorTransitionOptions[ChainLogic.MAX_TIER + 1];

	static {
		for (int tier = 0; tier <= ChainLogic.MAX_TIER; tier++) {
			DUST[tier] = new DustColorTransitionOptions(ChainLogic.dustStart(tier), ChainLogic.dustEnd(tier), 0.9F + 0.1F * tier);
		}
	}

	private static DustColorTransitionOptions dust(int tier) {
		return DUST[Math.max(0, Math.min(ChainLogic.MAX_TIER, tier))];
	}

	/** Zincirin kademesine göre yazı rengi. */
	static ChatFormatting color(int tier) {
		return switch (Math.max(0, Math.min(ChainLogic.MAX_TIER, tier))) {
			case 1 -> ChatFormatting.GOLD;
			case 2 -> ChatFormatting.RED;
			case 3 -> ChatFormatting.LIGHT_PURPLE;
			case 4 -> ChatFormatting.YELLOW;
			default -> ChatFormatting.GRAY;
		};
	}

	/** Zincirdeki her öldürmede kurbanın üzerinde kısa bir kesik/kıvılcım patlaması. */
	static void flourish(ServerLevel level, LivingEntity victim, int tier) {
		double x = victim.getX();
		double y = victim.getY(0.5);
		double z = victim.getZ();
		level.sendParticles(dust(tier), x, y, z, 6 + tier * 3, 0.3, 0.4, 0.3, 0.0);
		level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
		if (tier >= 2) {
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 4 + tier, 0.3, 0.4, 0.3, 0.25);
		}
		if (tier >= 3) {
			level.sendParticles(ParticleTypes.SOUL, x, y, z, 3, 0.25, 0.4, 0.25, 0.04);
		}
	}

	/** Oyuncunun etrafında dönen halka: kademeyle daha çok nokta, daha geniş ve daha hızlı. */
	static void aura(ServerLevel level, ServerPlayer player, int tier, long now) {
		int total = ChainLogic.orbiterCount(tier);
		double radius = ChainLogic.orbitRadius(tier);
		double baseY = player.getY(0.0);
		for (int i = 0; i < total; i++) {
			double angle = ChainLogic.orbitAngle(now, tier, i, total);
			double x = player.getX() + ChainLogic.orbitX(angle, radius);
			double z = player.getZ() + ChainLogic.orbitZ(angle, radius);
			double y = baseY + ChainLogic.orbitLift(now, i);
			level.sendParticles(dust(tier), x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
			if (i == 0) {
				if (tier == 2) {
					level.sendParticles(ParticleTypes.FLAME, x, y, z, 1, 0.0, 0.02, 0.0, 0.0);
				} else if (tier == 3) {
					level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 1, 0.0, 0.02, 0.0, 0.0);
				} else if (tier >= 4) {
					level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.0, 0.03, 0.0, 0.0);
				}
			}
		}
	}

	/**
	 * Kademe atlama töreni: sesler, yere yayılan halka; yüksek kademelerde ışık sütunu ve patlama.
	 * {@code announce}: yazıyı aksiyon çubuğunda göster (yalnızca HUD'u olmayan istemciler için; HUD'u olanlar başlığı kendi çizer).
	 */
	static void tierUp(ServerLevel level, ServerPlayer player, int tier, int count, boolean announce) {
		double x = player.getX();
		double y = player.getY(0.1);
		double z = player.getZ();

		if (announce) {
			player.sendSystemMessage(Component.translatable("message.battleaxe.chain.tier." + tier, count)
					.withStyle(color(tier)).withStyle(ChatFormatting.BOLD), true);
		}

		level.playSound(null, x, y, z, SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 0.6F + 0.2F * tier);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.7F, 0.5F);
		if (tier >= 3) {
			level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 0.5F, 1.0F + 0.1F * (tier - 3));
		}

		// Yere yayılan halka (24 nokta); kademeyle genişler.
		double radius = 1.2 + 0.35 * tier;
		int points = 24;
		for (int i = 0; i < points; i++) {
			double angle = (2.0 * Math.PI * i) / points;
			level.sendParticles(dust(tier), x + ChainLogic.orbitX(angle, radius), y, z + ChainLogic.orbitZ(angle, radius),
					2, 0.0, 0.05, 0.0, 0.0);
		}
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, player.getY(0.6), z, 8 + tier * 4, 0.6, 0.7, 0.6, 0.3);
		if (tier >= 3) {
			level.sendParticles(ParticleTypes.END_ROD, x, y, z, 12, 0.2, 1.2, 0.2, 0.06);
		}
		if (tier >= 4) {
			level.sendParticles(ParticleTypes.EXPLOSION, x, player.getY(0.5), z, 2, 0.5, 0.4, 0.5, 0.0);
			level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 8, 0.5, 0.2, 0.5, 0.03);
		}
	}

	/** Shunpo zinciri taşıdı: oyuncunun varış noktasında kısa, ince bir kıvılcım (zincir renginde). */
	static void extended(ServerLevel level, ServerPlayer player, int tier) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();
		level.sendParticles(dust(tier), x, y, z, 10, 0.35, 0.5, 0.35, 0.0);
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 6, 0.3, 0.5, 0.3, 0.2);
	}

	/** Zincir koptu: alçak bir çınlama ve dağılan duman. {@code announce}: yazıyı aksiyon çubuğunda göster (HUD'suz istemciler). */
	static void broken(ServerLevel level, ServerPlayer player, int count, boolean announce) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F, 0.45F);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 8, 0.4, 0.5, 0.4, 0.02);
		if (announce) {
			player.sendSystemMessage(Component.translatable("message.battleaxe.chain.broken", count).withStyle(ChatFormatting.GRAY), true);
		}
	}

	/** Zincir süre çubuğu (aksiyon çubuğu): sayaç ve kalan süre. */
	static void bar(ServerPlayer player, int count, int tier, long now, long lastKillTick) {
		int window = ChainLogic.windowFor(tier);
		String bar = ChainLogic.barText(ChainLogic.barCells(now, lastKillTick, window, ChainConfig.BAR_CELLS), ChainConfig.BAR_CELLS);
		player.sendSystemMessage(Component.translatable("message.battleaxe.chain.bar", count, bar).withStyle(color(tier)), true);
	}
}
