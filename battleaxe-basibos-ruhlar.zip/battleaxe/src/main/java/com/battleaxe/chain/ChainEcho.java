package com.battleaxe.chain;

import java.util.concurrent.ThreadLocalRandom;

import com.mojang.serialization.Codec;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.call.OmenEcho;
import com.battleaxe.soul.SoulManager;

/**
 * <b>Gözün Yankısı</b> (sunucu tarafı glue; karar mantığı {@link ChainEchoLogic}'te): Kıyım Zinciri Ragnarök'e ulaşınca, uygun koşulda
 * (gece, açık gökyüzü) Öncü Belirtiler'in göz tezahürü bir an geri döner; birkaç saniye sonra balta rütbesine göre kısa bir söz söyler.
 *
 * <p>Güvenlik: yalnızca mevcut görsel paketi gönderir (hasar, varlık, blok, ödül yok). Koşullar uygun değilse HİÇBİR ŞEY tüketilmez;
 * kalıcı sayaç yalnızca gerçekten gönderilen yankıyla artar. Sayaç oyuncuya bağlı ve kalıcıdır (ölünce korunur); diğer durum oturumluktur.
 */
final class ChainEcho {
	private ChainEcho() {
	}

	/** Bu oyuncunun şimdiye dek gördüğü yankı sayısı (KALICI). */
	private static final AttachmentType<Integer> SEEN = AttachmentRegistry.create(
			BattleAxeMod.id("chain_eye_seen"),
			builder -> builder.persistent(Codec.INT).copyOnDeath());
	/** Son yankının oyun zamanı (oturumluk). */
	private static final AttachmentType<Long> LAST = AttachmentRegistry.create(BattleAxeMod.id("chain_eye_last"));
	/** Bekleyen sözün zamanı; negatif = yok (oturumluk). */
	private static final AttachmentType<Long> DUE = AttachmentRegistry.create(BattleAxeMod.id("chain_eye_due"));
	private static final AttachmentType<Boolean> DUE_FIRST = AttachmentRegistry.create(BattleAxeMod.id("chain_eye_first"));
	private static final AttachmentType<Integer> DUE_BAND = AttachmentRegistry.create(BattleAxeMod.id("chain_eye_band"));

	/** Kademe atlandı: Ragnarök'se ve karar olumluysa gözü gönder ve sözü planla. */
	static void onTierUp(ServerLevel level, ServerPlayer player, int tier) {
		if (!ChainConfig.EYE_ECHO_ENABLED || !ChainEchoLogic.triggers(tier)) {
			return;
		}
		long now = level.getGameTime();
		int seen = player.getAttachedOrElse(SEEN, 0);
		Long last = player.getAttached(LAST);
		boolean go = ChainConfig.TEST_MODE
				|| ChainEchoLogic.shouldEcho(seen, ThreadLocalRandom.current().nextDouble(), now, last == null ? -1L : last);
		if (!go) {
			return;
		}
		int ticks = OmenEcho.sendEye(level, player);
		if (ticks <= 0) {
			return; // Koşul uygun değil (gündüz, kapalı gökyüzü, yağmur, tezahür kapalı): hiçbir şey tüketilmez.
		}
		player.setAttached(SEEN, ChainEchoLogic.nextSeen(seen));
		player.setAttached(LAST, now);
		player.setAttached(DUE, now + ChainEchoLogic.whisperDelay(ticks));
		player.setAttached(DUE_FIRST, seen == 0);
		// Rütbe, yankı anında (balta elde) belirlenir; söz birkaç saniye sonra söylense de aynı tonda kalır.
		player.setAttached(DUE_BAND, ChainWhisperLogic.band(SoulManager.rankOf(player.getMainHandItem())));
	}

	/** Her tick: bekleyen söz zamanı geldiyse söyle. Yalnızca bir okuma yapar. */
	static void tick(ServerLevel level, ServerPlayer player) {
		Long due = player.getAttached(DUE);
		if (due == null || due < 0L || level.getGameTime() < due) {
			return;
		}
		player.setAttached(DUE, -1L);
		boolean first = player.getAttachedOrElse(DUE_FIRST, false);
		int band = player.getAttachedOrElse(DUE_BAND, 0);
		// Göz sessizdir (açıklama, ses, boss bar yok); yalnızca balta, aksiyon çubuğunda, kısık ve soluk bir sesle konuşur.
		player.sendSystemMessage(Component.translatable(ChainEchoLogic.key(band, first), player.getName())
				.withStyle(ChatFormatting.LIGHT_PURPLE).withStyle(ChatFormatting.ITALIC), true);
	}
}
