package com.battleaxe.chain;

/**
 * Kıyım Zinciri HUD'ının SAF animasyon matematiği (Minecraft'a bağımlı değildir; test: tools/test/ChainLogicTest.java).
 * Her fonksiyon, bir olaydan beri geçen MİLİSANİYENİN saf bir işlevidir: istemci yalnızca zaman damgalarını tutar,
 * çizim her karede bu fonksiyonlardan hesaplanır. Böylece durum makinesi yoktur ve animasyonlar kendiliğinden biter.
 */
public final class ChainHudMath {
	private ChainHudMath() {
	}

	/** Her öldürmede sayının "vuruş" büyümesi süresi (ms). */
	public static final long PULSE_MS = 240L;
	/** Kademe atlama ışıması (panelin dışa yayılan çerçevesi) süresi (ms). */
	public static final long GLOW_MS = 700L;
	/** Kademe atlama başlığının toplam süresi (ms). */
	public static final long BANNER_MS = 1100L;
	/** Zincir kopma parçalanması süresi (ms). */
	public static final long SHATTER_MS = 750L;
	/** Parçalanmadaki kırık sayısı. */
	public static final int SHARDS = 10;
	/** Sayının en büyük "vuruş" ölçeği (1.0 = normal). */
	public static final float PULSE_PEAK = 1.3F;

	public static float clamp01(float value) {
		return Float.isNaN(value) ? 0.0F : Math.max(0.0F, Math.min(1.0F, value));
	}

	/** Yavaşlayan çıkış eğrisi (0-1 -> 0-1): hızlı başlar, yumuşak durur. */
	public static float easeOut(float t) {
		float c = clamp01(t);
		float inv = 1.0F - c;
		return 1.0F - inv * inv * inv;
	}

	/** Sayının vuruş ölçeği: öldürme anında {@link #PULSE_PEAK}, sonra 1'e iner. Süre dışında 1. */
	public static float killPulse(long sinceMs) {
		if (sinceMs < 0L || sinceMs >= PULSE_MS) {
			return 1.0F;
		}
		float e = sinceMs / (float) PULSE_MS;
		float inv = 1.0F - e;
		return 1.0F + (PULSE_PEAK - 1.0F) * inv * inv;
	}

	/** Kademe atlama ışıması (1 -> 0). Süre dışında 0. */
	public static float tierUpGlow(long sinceMs) {
		if (sinceMs < 0L || sinceMs >= GLOW_MS) {
			return 0.0F;
		}
		return 1.0F - sinceMs / (float) GLOW_MS;
	}

	/** Başlığın saydamlığı: hızlı belirir, kısa süre kalır, sönümlenir (göz yormasın diye kısa tutulur). */
	public static float bannerAlpha(long sinceMs) {
		if (sinceMs < 0L || sinceMs >= BANNER_MS) {
			return 0.0F;
		}
		if (sinceMs < 100L) {
			return sinceMs / 100.0F;
		}
		if (sinceMs < 700L) {
			return 1.0F;
		}
		return 1.0F - (sinceMs - 700L) / (float) (BANNER_MS - 700L);
	}

	/** Başlığın ölçeği: biraz büyük başlar, yerine oturur (1.5 -> 1.1). */
	public static float bannerScale(long sinceMs) {
		return 1.1F + 0.4F * (1.0F - easeOut(sinceMs / 220.0F));
	}

	/** Kombo göstergesinin kalıcı görünürlüğünün bekleme süresi: son öldürmeden sonra bu kadar tam parlak kalır (ms). */
	public static final long IDLE_HOLD_MS = 1500L;
	/** Bekleme bittikten sonra sönükleşme süresi (ms). */
	public static final long IDLE_FADE_MS = 1000L;
	/** Sönükleşmenin en düşük saydamlığı (gösterge hiç kaybolmaz, yalnızca geri çekilir). */
	public static final float IDLE_MIN_ALPHA = 0.5F;

	/**
	 * Göstergenin genel saydamlığı (0.5-1): son öldürmeden {@link #IDLE_HOLD_MS} sonra yarıya iner, böylece sürekli göz
	 * yormaz. Yeni öldürmede, süre azalırken (%25 altı) ve kademe atlarken yeniden tam parlar. {@code sinceKillMs} /
	 * {@code sinceTierUpMs}: o olaydan beri geçen süre (hiç olmadıysa çok büyük).
	 */
	public static float hudAlpha(long sinceKillMs, float ratio, long sinceTierUpMs) {
		if (ratio < 0.25F || (sinceTierUpMs >= 0L && sinceTierUpMs < BANNER_MS)) {
			return 1.0F;
		}
		if (sinceKillMs < IDLE_HOLD_MS) {
			return 1.0F;
		}
		float t = clamp01((sinceKillMs - IDLE_HOLD_MS) / (float) IDLE_FADE_MS);
		return 1.0F - (1.0F - IDLE_MIN_ALPHA) * easeOut(t);
	}

	/** Parçalanma ilerlemesi (0-1). */
	public static float shatterProgress(long sinceMs) {
		if (sinceMs < 0L) {
			return 0.0F;
		}
		return clamp01(sinceMs / (float) SHATTER_MS);
	}

	/** Zaman çubuğunun doluluğu (0-1): kalan süre / pencere. */
	public static float barRatio(long remainingMs, int windowTicks) {
		if (windowTicks <= 0) {
			return 0.0F;
		}
		return clamp01(remainingMs / (windowTicks * 50.0F));
	}

	/** Süre azalırken (%25 altı) nabız gibi atan uyarı (0-1); aksi halde 0. */
	public static float lowTimeFlash(long nowMs, float ratio) {
		if (!(ratio < 0.25F)) {
			return 0.0F;
		}
		return 0.5F + 0.5F * (float) Math.sin((nowMs % 100_000L) * 0.02);
	}

	/** {@code i}. kırığın yatay yer değiştirmesi (piksel) {@code t} (0-1) anında: altın açıyla dağılır. */
	public static float shardDx(int i, float t) {
		return (float) Math.cos(shardAngle(i)) * shardSpeed(i) * easeOut(t);
	}

	/** {@code i}. kırığın dikey yer değiştirmesi: dağılır ve yerçekimiyle düşer. */
	public static float shardDy(int i, float t) {
		float c = clamp01(t);
		return (float) Math.sin(shardAngle(i)) * shardSpeed(i) * easeOut(t) + 26.0F * c * c;
	}

	/** Kırığın saydamlığı: hızla söner (1 -> 0). */
	public static float shardAlpha(float t) {
		float inv = 1.0F - clamp01(t);
		return inv * inv;
	}

	/** Kırığın kenar uzunluğu (piksel): 2-4. */
	public static int shardSize(int i) {
		return 2 + Math.floorMod(i, 3);
	}

	private static double shardAngle(int i) {
		return i * 2.399963229728653 + 0.3; // altın açı: noktalar eşit dağılır
	}

	private static float shardSpeed(int i) {
		double fraction = (i * 0.6180339887) % 1.0;
		return (float) (14.0 + 22.0 * fraction);
	}
}
