package com.battleaxe.chain;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan oyuncunun kendi istemcisine: "zincir şu sayıda, bu kadar tick'lik süresi kaldı". {@code count == 0}
 * zincirin koptuğunu bildirir. Yalnızca HUD içindir; bonuslar sunucuda uygulanır. Kademe ve pencere sayıdan türetilir
 * ({@link ChainLogic}), bu yüzden pakette yalnızca iki sayı vardır. İstemci aradaki süreyi kendi saatiyle geri sayar;
 * sunucu yalnızca öldürmede ve kopmada paket gönderir (her tick'te değil).
 */
public record ChainSyncPayload(int count, int remainingTicks) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ChainSyncPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("chain_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ChainSyncPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT,
			ChainSyncPayload::count,
			ByteBufCodecs.VAR_INT,
			ChainSyncPayload::remainingTicks,
			ChainSyncPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
