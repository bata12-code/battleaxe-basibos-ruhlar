package com.battleaxe.chain;

import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.soul.SoulText;

/**
 * Balta, Kıyım Zinciri kademe atlayınca rütbesine göre konuşur ({@link ChainWhisperLogic}). Yalnızca HUD'u olan istemcilerde
 * konuşur: HUD'u olmayanlarda aksiyon çubuğu zaten kademe adını gösteriyor ve fısıltı onu ezerdi. Hiçbir hasar/ödül vermez;
 * kalıcı değildir (son fısıltı zamanı çıkışta sıfırlanır).
 */
final class ChainWhispers {
	private ChainWhispers() {
	}

	private static final AttachmentType<Long> LAST_TICK = AttachmentRegistry.create(BattleAxeMod.id("chain_whisper_last"));
	private static final AttachmentType<Integer> LAST_VARIANT = AttachmentRegistry.create(BattleAxeMod.id("chain_whisper_variant"));

	static void onTierUp(ServerLevel level, ServerPlayer player, int tier, boolean hud) {
		if (!hud) {
			return;
		}
		ThreadLocalRandom random = ThreadLocalRandom.current();
		long now = level.getGameTime();
		Long last = player.getAttached(LAST_TICK);
		if (!ChainWhisperLogic.shouldWhisper(tier, random.nextDouble(), now, last == null ? -1L : last)) {
			return;
		}
		int rank = SoulManager.rankOf(player.getMainHandItem());
		int variant = ChainWhisperLogic.pickVariant(random.nextDouble(), player.getAttachedOrElse(LAST_VARIANT, 0));
		player.setAttached(LAST_TICK, now);
		player.setAttached(LAST_VARIANT, variant);
		String key = ChainWhisperLogic.key(tier, ChainWhisperLogic.band(rank), variant);
		player.sendSystemMessage(Component.translatable(key, player.getName())
				.withStyle(SoulText.rankColor(rank)).withStyle(ChatFormatting.ITALIC), true);
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.2F, 0.5F);
	}
}
