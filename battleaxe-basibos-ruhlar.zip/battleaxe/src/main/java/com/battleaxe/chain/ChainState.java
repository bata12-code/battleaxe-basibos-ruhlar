package com.battleaxe.chain;

/**
 * Bir oyuncunun zincir durumu (değişmez). {@code lastKillTick < 0} zincir yok demektir.
 * Kalıcı değildir: çıkışta/ölümde yeni oyuncu nesnesiyle sıfırlanır.
 */
public record ChainState(int count, long lastKillTick) {
	public static final ChainState NONE = new ChainState(0, -1L);
}
