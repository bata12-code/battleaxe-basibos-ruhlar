package com.battleaxe.chain;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.evolution.EvolutionEvents;
import com.battleaxe.item.ModItems;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * <b>Kıyım Zinciri</b>: Savaş Baltasıyla (ana el veya fırlatılan balta) süre dolmadan art arda düşman öldürdükçe büyüyen
 * zincir. Eşikler (3 / 6 / 10 / 15) kademe atlatır: küçük bir hasar ve saldırı hızı bonusu, uzayan süre, dönen bir parçacık
 * aurası, kademe atlama töreni ve aksiyon çubuğunda geri sayan zincir çubuğu. Süre dolarsa zincir kopar.
 *
 * <h3>Tasarım</h3>
 * <ul>
 *   <li>Durum sunucudadır ve kalıcı değildir (çıkış/ölümle sıfırlanır). İstemciye yalnızca HUD için küçük bir paket gider
 *       ({@link ChainSyncPayload}: sayı + kalan süre; sadece öldürmede ve kopmada, her tick'te değil). HUD'u olmayan
 *       istemciler (paketi alamayanlar) için aksiyon çubuğu yazısı yedek olarak çalışmaya devam eder.</li>
 *   <li>Kademe atlayınca Evrim'e küçük bir Savaş Özü ödülü gider ({@link EvolutionEvents#onChainTierUp}; kendi sınırlayıcısından geçer).</li>
 *   <li>Mevcut sistemlere dokunmaz: kendi {@code AFTER_DEATH} dinleyicisi ve kendi sabit kimlikli geçici modifier'ları
 *       vardır; ruh, Evrim, Ruh Ağı ve Execution aynen çalışır (Execution bitiricisi de bir öldürmedir ve zincire sayılır).</li>
 *   <li>Bonuslar Hiddet/rütbe ile aynı güvenli yöntemle uygulanır: idempotent, birikmez, yalnızca balta ana eldeyken.
 *       {@code PlayerMixin} her saldırıdan hemen önce de eşitler (aynı tick'te silah değiştirip vurma açığı yok).</li>
 *   <li>Yalnızca düşmanlar (canavar kategorisi) ve oyuncular sayılır; uysal hayvanlar ve köylüler zinciri beslemez.
 *       Güçlü düşman (azami can 40+ -> 2, 150+ -> 3) zincire daha çok katkı yapar.</li>
 * </ul>
 */
public final class ChainManager {
	private ChainManager() {
	}

	private static final AttachmentType<ChainState> STATE = AttachmentRegistry.create(BattleAxeMod.id("chain_state"));
	/** En son hangi kademenin bonuslarını uyguladığımız (gereksiz modifier değişimi olmasın). */
	private static final AttachmentType<Integer> APPLIED_TIER = AttachmentRegistry.create(BattleAxeMod.id("chain_applied_tier"));

	private static final Identifier DAMAGE_MODIFIER_ID = BattleAxeMod.id("chain_damage");
	private static final Identifier SPEED_MODIFIER_ID = BattleAxeMod.id("chain_attack_speed");

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(ChainSyncPayload.TYPE, ChainSyncPayload.CODEC);
		ServerLivingEntityEvents.AFTER_DEATH.register(ChainManager::onDeath);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(ChainManager::afterDamage);
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tick(player);
			}
		});
	}

	/** Oyuncunun şu anki zincir kademesi (zincir yoksa/kopmuşsa 0). Başka sistemler okuyabilir; hiçbir şeyi değiştirmez. */
	public static int tier(ServerPlayer player) {
		if (!ChainConfig.ENABLED || !(player.level() instanceof ServerLevel level)) {
			return 0;
		}
		ChainState state = state(player);
		return ChainLogic.alive(state, level.getGameTime()) ? ChainLogic.tierOf(state.count()) : 0;
	}

	private static ChainState state(ServerPlayer player) {
		return player.getAttachedOrElse(STATE, ChainState.NONE);
	}

	/** Bu oyuncunun istemcisi zincir HUD'unu çizebilir mi? (Mod kurulu istemci: evet; aksi halde aksiyon çubuğu yedeği.) */
	private static boolean hasHud(ServerPlayer player) {
		return ServerPlayNetworking.canSend(player, ChainSyncPayload.TYPE);
	}

	/** HUD'lu istemciye zincir durumunu bildirir. HUD yoksa false döner (çağıran yedek yazıyı kullanır). */
	private static boolean sync(ServerPlayer player, int count, int remainingTicks) {
		if (!hasHud(player)) {
			return false;
		}
		ServerPlayNetworking.send(player, new ChainSyncPayload(count, remainingTicks));
		return true;
	}

	private static boolean holdingAxe(ServerPlayer player) {
		return player.getMainHandItem().is(ModItems.BATTLE_AXE);
	}

	// ------------------------------------------------------------------
	// Öldürme
	// ------------------------------------------------------------------

	private static void onDeath(LivingEntity entity, DamageSource source) {
		if (!ChainConfig.ENABLED || !(source.getEntity() instanceof ServerPlayer player) || entity == player
				|| !(player.level() instanceof ServerLevel level)) {
			return;
		}
		boolean hostile = entity.getType().getCategory() == MobCategory.MONSTER || entity instanceof Player;
		if (!hostile) {
			return;
		}
		// Fırlatılan baltayla öldürdüyse de sayılır (ruh sistemiyle aynı kural); değilse balta ana elde olmalı.
		ThrownBattleAxe thrown = ThrownBattleAxe.activeHit();
		boolean viaThrow = thrown != null && player.getUUID().equals(thrown.getOwnerUuid());
		if (!viaThrow && !holdingAxe(player)) {
			return;
		}

		long now = level.getGameTime();
		ChainState old = state(player);
		int before = ChainLogic.alive(old, now) ? old.count() : 0;
		int after = ChainLogic.advance(old.count(), old.lastKillTick(), now,
				ChainLogic.effectiveWeight(ChainLogic.weight(entity.getMaxHealth())));
		player.setAttached(STATE, new ChainState(after, now));

		int tier = ChainLogic.tierOf(after);
		syncBonuses(player);
		boolean hud = sync(player, after, ChainLogic.windowFor(tier));
		ChainEffects.flourish(level, entity, tier);
		if (ChainLogic.isTierUp(before, after)) {
			ChainEffects.tierUp(level, player, tier, after, !hud);
			EvolutionEvents.onChainTierUp(player, tier);
			ChainWhispers.onTierUp(level, player, tier, hud);
			ChainEcho.onTierUp(level, player, tier);
		} else if (after >= 2 && !hud) {
			ChainEffects.bar(player, after, tier, now, now);
		}
	}

	// ------------------------------------------------------------------
	// Beceri: hasar zinciri sarsar, Shunpo zinciri taşır
	// ------------------------------------------------------------------

	/**
	 * Oyuncu BİR DÜŞMANDAN hasar aldı: zincirin kalan süresi kısalır ({@link ChainLogic#penaltyTicks}). Kalkanla engellenen hasar ve
	 * çevre hasarı (lav, ateş, düşme) sarsmaz. Sayaç/kademe doğrudan düşmez; süre biterse zincir olağan yoldan kopar.
	 */
	private static void afterDamage(LivingEntity entity, DamageSource source, float baseDamageTaken, float damageTaken, boolean blocked) {
		if (!ChainConfig.ENABLED || !ChainConfig.DAMAGE_PENALTY_ENABLED || blocked || !(entity instanceof ServerPlayer player)
				|| !(source.getEntity() instanceof LivingEntity) || !(player.level() instanceof ServerLevel level)) {
			return;
		}
		int penalty = ChainLogic.penaltyTicks(damageTaken);
		ChainState state = state(player);
		long now = level.getGameTime();
		if (penalty <= 0 || !ChainLogic.alive(state, now)) {
			return;
		}
		ChainState next = new ChainState(state.count(), ChainLogic.penalizedLastKill(state.lastKillTick(), penalty));
		player.setAttached(STATE, next);
		resync(player, next, now);
	}

	/**
	 * Shunpo ışınlanması başarıyla gerçekleşti ({@code ShunpoManager} çağırır): zincir canlıysa kalan süresi uzar (pencereyi aşmaz).
	 * Düşmanlar arası boşluğu ışınlanarak aşan oyuncu zincirini sürdürebilir.
	 */
	public static void onShunpo(ServerPlayer player) {
		if (!ChainConfig.ENABLED || !ChainConfig.SHUNPO_EXTENDS || !(player.level() instanceof ServerLevel level)) {
			return;
		}
		ChainState state = state(player);
		long now = level.getGameTime();
		if (!ChainLogic.alive(state, now)) {
			return;
		}
		int tier = ChainLogic.tierOf(state.count());
		long extended = ChainLogic.extendedLastKill(now, state.lastKillTick(), ChainLogic.windowFor(tier), ChainConfig.SHUNPO_EXTEND_TICKS);
		if (extended == state.lastKillTick()) {
			return; // zaten dolu
		}
		ChainState next = new ChainState(state.count(), extended);
		player.setAttached(STATE, next);
		resync(player, next, now);
		ChainEffects.extended(level, player, tier);
	}

	/** Süre değişti (ceza/uzatma): HUD'lu istemciye yeni kalan süreyi bildirir. HUD'u olmayanlar aksiyon çubuğunu zaten yeniliyor. */
	private static void resync(ServerPlayer player, ChainState state, long now) {
		sync(player, state.count(), ChainLogic.remainingTicks(state.count(), state.lastKillTick(), now));
	}

	// ------------------------------------------------------------------
	// Her tick
	// ------------------------------------------------------------------

	private static void tick(ServerPlayer player) {
		if (!ChainConfig.ENABLED || !(player.level() instanceof ServerLevel level)) {
			return;
		}
		ChainEcho.tick(level, player);
		ChainState state = state(player);
		long now = level.getGameTime();
		if (state.count() > 0 && !ChainLogic.alive(state, now)) {
			player.setAttached(STATE, ChainState.NONE);
			boolean hud = sync(player, 0, 0);
			ChainEffects.broken(level, player, state.count(), !hud && state.count() >= ChainConfig.BREAK_MESSAGE_MIN_COUNT);
			state = ChainState.NONE;
		}
		syncBonuses(player);
		if (state.count() <= 0) {
			return;
		}

		int tier = ChainLogic.tierOf(state.count());
		if (tier >= 1 && holdingAxe(player) && player.tickCount % ChainConfig.AURA_INTERVAL_TICKS == 0) {
			ChainEffects.aura(level, player, tier, now);
		}
		// Aksiyon çubuğu yalnızca HUD'u olmayan istemciler için (HUD'lular çubuğu kendi çizer).
		if (tier >= 1 && player.tickCount % ChainConfig.BAR_REFRESH_TICKS == 0 && !hasHud(player)) {
			ChainEffects.bar(player, state.count(), tier, now, state.lastKillTick());
		}
	}

	// ------------------------------------------------------------------
	// Bonuslar (idempotent, birikmez)
	// ------------------------------------------------------------------

	/**
	 * Bonusları, zincir + ana eldeki eşyayla uyumlu hale getirir. Kaç kez çağrılırsa çağrılsın sonuç aynıdır.
	 * {@code PlayerMixin} bunu her saldırıdan hemen önce de çağırır.
	 */
	public static void syncBonuses(ServerPlayer player) {
		int desired = 0;
		if (ChainConfig.ENABLED && holdingAxe(player) && player.level() instanceof ServerLevel level) {
			ChainState state = state(player);
			if (ChainLogic.alive(state, level.getGameTime())) {
				desired = ChainLogic.tierOf(state.count());
			}
		}

		AttributeInstance damage = player.getAttribute(Attributes.ATTACK_DAMAGE);
		AttributeInstance speed = player.getAttribute(Attributes.ATTACK_SPEED);
		Integer appliedBoxed = player.getAttached(APPLIED_TIER);
		int applied = appliedBoxed == null ? 0 : appliedBoxed;
		boolean present = damage != null && damage.getModifier(DAMAGE_MODIFIER_ID) != null;

		// Hiçbir şey değişmedi: tier aynı ve modifier'ın varlığı beklentiyle uyumlu.
		if (applied == desired && present == (desired > 0)) {
			return;
		}

		if (damage != null && damage.getModifier(DAMAGE_MODIFIER_ID) != null) {
			damage.removeModifier(DAMAGE_MODIFIER_ID);
		}
		if (speed != null && speed.getModifier(SPEED_MODIFIER_ID) != null) {
			speed.removeModifier(SPEED_MODIFIER_ID);
		}
		if (desired > 0) {
			if (damage != null) {
				damage.addTransientModifier(new AttributeModifier(DAMAGE_MODIFIER_ID, ChainLogic.damageBonus(desired),
						AttributeModifier.Operation.ADD_VALUE));
			}
			if (speed != null) {
				// ADD_MULTIPLIED_TOTAL: değeri (1 + miktar) ile çarpar; 0.08 -> %8 daha hızlı.
				speed.addTransientModifier(new AttributeModifier(SPEED_MODIFIER_ID, ChainLogic.speedBonus(desired),
						AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
			}
		}
		player.setAttached(APPLIED_TIER, desired);
	}
}
