package com.battleaxe.chain;

/**
 * Kıyım Zinciri ayarları (Java sabitleri; yeni bir yapılandırma sistemi eklenmedi). Süreler tick'tir (20 tick = 1 sn).
 *
 * <p>Zincir: Savaş Baltasıyla (ana el veya fırlatılan balta) düşman öldürdükçe sayaç büyür; her öldürme zincir süresini
 * yeniler. Süre dolarsa zincir kopar. Eşikler aşıldıkça kademe yükselir: küçük bir hasar/saldırı hızı bonusu, daha uzun süre
 * ve görsel/işitsel şölen. Tüm bonuslar geçicidir ve yalnızca balta ana eldeyken uygulanır.
 */
public final class ChainConfig {
	private ChainConfig() {
	}

	/** false yaparsan Kıyım Zinciri tamamen kapanır. */
	public static final boolean ENABLED = true;

	/**
	 * Geliştirme/deneme modu: true yapınca her öldürme {@link #TEST_WEIGHT_FACTOR} kat sayılır; böylece HUD'u, törenleri ve fısıltıları görmek
	 * için 15 düşman öldürmek gerekmez (3 katla 5 öldürmede 4 kademenin hepsi görülür). Yayın sürümünde MUTLAKA false olmalı
	 * (test bunu denetler).
	 */
	public static final boolean TEST_MODE = false;
	public static final int TEST_WEIGHT_FACTOR = 3;

	/**
	 * Gözün Yankısı ({@link ChainEchoLogic}): Ragnarök'e ulaşınca, gece açık gökyüzünün altında Öncü Belirtiler'in "Sana Bakan Şey"i bir an geri
	 * döner. Nadirdir ve OmenConfig ayarlarına saygı duyar (göz kapalıysa hiçbir şey olmaz). false yaparsan tamamen kapanır.
	 */
	public static final boolean EYE_ECHO_ENABLED = true;

	/** Kademe 0'da (henüz eşiğe varmamışken) iki öldürme arasındaki en uzun süre. */
	public static final int BASE_WINDOW_TICKS = 100;
	/** Her kademenin süreye eklediği tick (yüksek zincir daha affedicidir). */
	public static final int WINDOW_BONUS_PER_TIER = 20;

	/** Kademe 1..4 için gereken zincir sayısı (artan). */
	public static final int[] TIER_THRESHOLDS = {3, 6, 10, 15};
	/** Sayaç üst sınırı (taşma ve aşırı büyüme olmasın). */
	public static final int MAX_COUNT = 99;

	/** Kademe 0..4: ek saldırı hasarı (düz). Rütbe/Hiddet bonuslarının yanında küçük kalır. */
	public static final double[] DAMAGE_BONUS = {0.0, 0.5, 1.0, 1.5, 2.0};
	/** Kademe 0..4: ek saldırı hızı (oran; 0.08 = %8). */
	public static final double[] SPEED_BONUS = {0.0, 0.04, 0.08, 0.12, 0.16};

	/** Bu maksimum candan itibaren bir düşman 2 (orta) veya 3 (büyük/boss) öldürme sayılır. */
	public static final float MEDIUM_MOB_HEALTH = 40.0F;
	public static final float BIG_MOB_HEALTH = 150.0F;

	/**
	 * Zincir BECERİ de ister: düşmandan hasar alırsan zincirin kalan süresi kısalır (hasar x tick/can, üst sınırlı). Kalkanla engellenen
	 * hasar ve çevre hasarı (lav, düşme, ateş) zinciri SARSMAZ. Süre biterse zincir kopar; sayaç ve kademe hasarla doğrudan düşmez.
	 */
	public static final boolean DAMAGE_PENALTY_ENABLED = true;
	public static final double DAMAGE_PENALTY_TICKS_PER_HP = 8.0;
	public static final int DAMAGE_PENALTY_MAX_TICKS = 80;
	/** Shunpo ışınlanması zincirin kalan süresini uzatır (pencereyi aşmaz): düşmanlar arası boşluğu ışınlanarak aşabilirsin. */
	public static final boolean SHUNPO_EXTENDS = true;
	public static final int SHUNPO_EXTEND_TICKS = 40;

	/** Aura ve çubuk sıklıkları (düşük yük için seyrek). */
	public static final int AURA_INTERVAL_TICKS = 2;
	public static final int BAR_REFRESH_TICKS = 10;
	public static final int BAR_CELLS = 10;
	/** Aura yarıçapı (blok) ve kademe başına büyüme. */
	public static final double ORBIT_RADIUS = 0.85;
	public static final double ORBIT_RADIUS_PER_TIER = 0.12;

	/** Zincir bu sayıya veya üstüne ulaşmışken koparsa "zincir koptu" mesajı gösterilir (küçük zincirlerde sessiz). */
	public static final int BREAK_MESSAGE_MIN_COUNT = 3;
}
