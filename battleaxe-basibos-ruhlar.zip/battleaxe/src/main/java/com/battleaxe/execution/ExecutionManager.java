package com.battleaxe.execution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.berserker.BerserkerShakePayload;
import com.battleaxe.chain.ChainManager;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusApi;
import com.battleaxe.nexus.NexusDamage;

/**
 * <b>Execution (Bitirici Animasyon)</b>: modun özel Savaş Baltası ile yapılan, hedefi ÖLDÜRECEK, tam şarjlı bir yakın
 * dövüş vuruşunun (hedef saldırıdan önce canının %30'unda veya altındaysa) %25'inde sinematik bir bitiriciye dönüşmesi.
 * Zombi ve İskelet özel sınıflarla, diğer moblar {@link ExecutionCatalog} tablosuyla ({@link ExecutionRegistry}).
 *
 * <h3>Olay akışı (tek, tutarlı ölüm)</h3>
 * <ol>
 *   <li>{@code Player#attack} başında {@link #beginAttack}: bu vuruşun GERÇEK bir yakın dövüş saldırısı olduğu, hedefi
 *       ve şarjı kaydedilir. (Yar Geç ve diğer özel saldırılar bu yoldan geçmez, böylece karışmazlar.)</li>
 *   <li>{@code ALLOW_DAMAGE}: hasar uygulanmadan ÖNCE hedefin canı ölçülür; uygunsa aday kaydedilir.</li>
 *   <li>{@code ALLOW_DEATH}: vuruş gerçekten öldürücüyse (yani hedef ölecekse) ve aday geçerliyse olasılık atılır.
 *       Başarılıysa ölüm İPTAL edilir (can 1'e ayarlanır, mevcut Son Direniş/Defiance ile aynı kalıp), hedef
 *       dondurulur ve animasyon başlar.</li>
 *   <li>Animasyon sürerken: hedef başka hasar almaz (çift ölüm/loot olmaz), oyuncu kilitlenmez; oyuncu baltayı savurur,
 *       efektler seyrek üretilir.</li>
 *   <li>Darbe anında: yapay zekâ geri verilir ve OYUNCU ADINA öldürücü hasar uygulanır. Ölüm, loot, deneyim, ruh kazancı
 *       ve diğer olaylar vanilla/mod akışıyla BİR KEZ işlenir (ilk ölüm iptal edildiği için).</li>
 * </ol>
 *
 * <h3>Güvenlik</h3>
 * Hedef/oyuncu geçersizleşirse (ölüm, çıkış, boyut değişimi, uzaklaşma, sunucu kapanışı) hedef serbest bırakılır; hedef
 * sonsuza dek dondurulmaz. Dondurulan mob bir etiket taşır; çökme/yüklenme sonrası bu etiket yüklenirken onarılır.
 * Tüm durum sunucudadır; hiçbir istemci karar vermez. Hesap yalnızca etkin bitiricilerde yapılır (dünya taraması yok).
 */
public final class ExecutionManager {
	private ExecutionManager() {
	}

	/** Bu vuruşun bağlamı: gerçek yakın dövüş saldırısı (Player#attack) ve şarjı. */
	private record Attack(long tick, int targetId, float strength) {
	}

	/** ALLOW_DAMAGE'de uygun bulunan, ALLOW_DEATH'te (aynı tick içinde) olasılığı atılacak aday. */
	private record Candidate(UUID player, long tick) {
	}

	private static final class Execution {
		final UUID target;
		final UUID player;
		final ServerLevel level;
		final ExecutionAnimation animation;
		int age;
		int swings;

		Execution(UUID target, UUID player, ServerLevel level, ExecutionAnimation animation) {
			this.target = target;
			this.player = player;
			this.level = level;
			this.animation = animation;
		}
	}

	private static final Map<UUID, Attack> ATTACKS = new HashMap<>();
	private static final Map<UUID, Candidate> CANDIDATES = new HashMap<>();
	/** Hedef kimliği -> etkin bitirici. */
	private static final Map<UUID, Execution> ACTIVE = new HashMap<>();
	/** Oyuncu kimliği -> hedef kimliği (oyuncu başına en çok bir etkin bitirici). */
	private static final Map<UUID, UUID> BY_PLAYER = new HashMap<>();
	/** Oyuncu kimliği -> bir sonraki bitiricinin başlayabileceği oyun zamanı. */
	private static final Map<UUID, Long> COOLDOWNS = new HashMap<>();
	/** Son (öldürücü) darbe uygulanırken hedefin kimliği: kendi hasarımızı engellemeyelim. */
	private static UUID finishingTarget;

	public static void initialize() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register(ExecutionManager::allowDamage);
		ServerLivingEntityEvents.ALLOW_DEATH.register(ExecutionManager::allowDeath);
		ServerTickEvents.END_SERVER_TICK.register(ExecutionManager::tick);

		// Çökme/yüklenme sonrası takılı kalmış (dondurulmuş) hedefleri onar.
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
			// removeTag etiketi silerse true döner: yani bu mob dondurulmuş olarak kaydedilmişti ve etkin bir bitiricisi yok.
			if (entity instanceof Mob mob && !ACTIVE.containsKey(mob.getUUID()) && mob.removeTag(ExecutionConfig.TAG)) {
				mob.setNoAi(false);
			}
		});

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			UUID id = handler.getPlayer().getUUID();
			ATTACKS.remove(id);
			COOLDOWNS.remove(id);
			abortOf(id);
		});
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> releaseAll());
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			ATTACKS.clear();
			CANDIDATES.clear();
			ACTIVE.clear();
			BY_PLAYER.clear();
			COOLDOWNS.clear();
			finishingTarget = null;
		});
	}

	// ------------------------------------------------------------------
	// Saldırı bağlamı (PlayerMixin#attack başından çağrılır)
	// ------------------------------------------------------------------

	/** Oyuncu baltasıyla gerçek bir yakın dövüş saldırısı başlatıyor. Yalnızca bağlamı kaydeder; hiçbir şeyi değiştirmez. */
	public static void beginAttack(ServerPlayer player, Entity target) {
		if (!ExecutionConfig.ENABLED) {
			return;
		}
		if (ExecutionRegistry.find(target.getType()) == null) {
			ATTACKS.remove(player.getUUID());
			return;
		}
		ATTACKS.put(player.getUUID(), new Attack(player.level().getGameTime(), target.getId(),
				player.getAttackStrengthScale(0.5F)));
	}

	// ------------------------------------------------------------------
	// Hasar / ölüm kancaları
	// ------------------------------------------------------------------

	private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
		if (!ExecutionConfig.ENABLED) {
			return true;
		}
		UUID id = entity.getUUID();
		if (id.equals(finishingTarget)) {
			return true;
		}
		// Bitirici sürerken hedef başka hasar almaz (çift ölüm/loot/deneyim olmasın). Void/kill gibi
		// dokunulmazlığı aşan kaynaklar serbesttir.
		if (ACTIVE.containsKey(id)) {
			return source.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
		}

		if (!(entity.level() instanceof ServerLevel level)
				|| !(source.getEntity() instanceof ServerPlayer player)
				|| source.getDirectEntity() != player
				|| !source.is(DamageTypes.PLAYER_ATTACK)) {
			return true;
		}
		ExecutionAnimation animation = ExecutionRegistry.find(entity.getType());
		Attack attack = ATTACKS.get(player.getUUID());
		long now = level.getGameTime();
		if (animation == null || attack == null || attack.tick() != now || attack.targetId() != entity.getId()
				|| !(entity instanceof Mob mob)) {
			return true;
		}
		if (eligible(player, mob, attack, now)) {
			CANDIDATES.put(id, new Candidate(player.getUUID(), now));
		}
		return true;
	}

	private static boolean allowDeath(LivingEntity entity, DamageSource source, float amount) {
		UUID id = entity.getUUID();
		if (id.equals(finishingTarget)) {
			return true;
		}
		Execution running = ACTIVE.get(id);
		if (running != null) {
			// Dokunulmazlığı aşan bir kaynak (void, /kill) dondurulmuş hedefi öldürüyor: doğal ölüme izin ver, durumu temizle.
			ACTIVE.remove(id);
			BY_PLAYER.remove(running.player);
			return true;
		}

		Candidate candidate = CANDIDATES.remove(id);
		if (candidate == null || !(entity instanceof Mob mob) || !(entity.level() instanceof ServerLevel level)
				|| !(source.getEntity() instanceof ServerPlayer player) || !player.getUUID().equals(candidate.player())
				|| candidate.tick() != level.getGameTime()) {
			return true;
		}
		ExecutionAnimation animation = ExecutionRegistry.find(entity.getType());
		if (animation == null || !ExecutionLogic.roll(ThreadLocalRandom.current(), ExecutionConfig.CHANCE + NexusApi.executionChanceBonus(player)
					+ ExecutionLogic.chainChanceBonus(ChainManager.tier(player)))) {
			return true;
		}
		start(level, player, mob, animation);
		return false;
	}

	// ------------------------------------------------------------------
	// Shunpo kombosu için giriş noktaları (başka bir ölüm/hasar yolu açmaz; mevcut start() kullanılır)
	// ------------------------------------------------------------------

	/** Bu oyuncunun etkin bir bitiricisi var mı? (Kombo bu sırada ilerlemez.) */
	public static boolean isRunningFor(UUID player) {
		return BY_PLAYER.containsKey(player);
	}

	/** Kombo bitirici dalı için uygunluk (olasılık yok; yan etkisiz). Tam şarjlı bir yakın vuruş gibi değerlendirilir. */
	public static boolean eligibleFromCombo(ServerPlayer player, Mob mob) {
		if (!ExecutionConfig.ENABLED || !(mob.level() instanceof ServerLevel level) || ExecutionRegistry.find(mob.getType()) == null) {
			return false;
		}
		long now = level.getGameTime();
		return eligible(player, mob, new Attack(now, mob.getId(), 1.0F), now);
	}

	/** Uygunsa bitirici animasyonunu şans atmadan başlatır (kombo dalı). @return başlatıldıysa true */
	public static boolean beginFromCombo(ServerPlayer player, Mob mob) {
		if (!eligibleFromCombo(player, mob) || !(mob.level() instanceof ServerLevel level)) {
			return false;
		}
		start(level, player, mob, ExecutionRegistry.find(mob.getType()));
		return true;
	}

	/** Tüm uygunluk koşulları (olasılık HARİÇ). Hedefin canı saldırıdan ÖNCE ölçülür (hasar henüz uygulanmadı). */
	private static boolean eligible(ServerPlayer player, Mob mob, Attack attack, long now) {
		if (!player.isAlive() || player.isSpectator() || !player.getMainHandItem().is(ModItems.BATTLE_AXE)
				|| !ExecutionLogic.strongEnough(attack.strength(), ExecutionConfig.MIN_ATTACK_STRENGTH)) {
			return false;
		}
		if (BY_PLAYER.containsKey(player.getUUID())
				|| !ExecutionLogic.cooldownReady(now, COOLDOWNS.getOrDefault(player.getUUID(), 0L))) {
			return false;
		}
		if (!mob.isAlive() || mob.isNoAi() || mob.isBaby() || mob.isInvulnerable() || mob.isPassenger() || mob.isVehicle()
				|| ACTIVE.containsKey(mob.getUUID())) {
			return false;
		}
		if (!ExecutionLogic.healthQualifies(mob.getHealth(), mob.getMaxHealth(),
				ExecutionConfig.HEALTH_RATIO + NexusApi.executionHealthRatioBonus(player))) {
			return false;
		}
		return ExecutionLogic.within(mob.getX() - player.getX(), mob.getY() - player.getY(), mob.getZ() - player.getZ(),
				ExecutionConfig.MAX_START_DISTANCE) && player.hasLineOfSight(mob);
	}

	// ------------------------------------------------------------------
	// Başlat / ilerlet / bitir
	// ------------------------------------------------------------------

	private static void start(ServerLevel level, ServerPlayer player, Mob mob, ExecutionAnimation animation) {
		// Ölüm iptal edildi (Defiance/Son Direniş ile aynı kalıp): can pozitif olmalı.
		mob.setHealth(1.0F);
		mob.setNoAi(true);
		mob.addTag(ExecutionConfig.TAG);
		mob.setDeltaMovement(Vec3.ZERO);
		face(mob, player);

		ACTIVE.put(mob.getUUID(), new Execution(mob.getUUID(), player.getUUID(), level, animation));
		BY_PLAYER.put(player.getUUID(), mob.getUUID());
		COOLDOWNS.put(player.getUUID(), level.getGameTime() + ExecutionConfig.PLAYER_COOLDOWN_TICKS);
		animation.start(level, player, mob);
	}

	private static void tick(MinecraftServer server) {
		if (!CANDIDATES.isEmpty()) {
			long now = server.overworld().getGameTime();
			CANDIDATES.values().removeIf(candidate -> now - candidate.tick() > 1L);
		}
		if (ACTIVE.isEmpty()) {
			return;
		}
		// Anlık görüntü üzerinde dolaş: son darbenin tetiklediği başka olaylar ACTIVE'i değiştirse bile güvenli.
		for (Execution execution : new ArrayList<>(ACTIVE.values())) {
			if (ACTIVE.get(execution.target) != execution) {
				continue; // Bu arada başka bir olay tarafından temizlendi.
			}
			if (!step(server, execution)) {
				ACTIVE.remove(execution.target);
				BY_PLAYER.remove(execution.player);
			}
		}
	}

	/** @return bitirici sürüyorsa true; bittiyse/iptal edildiyse false (çağıran durumu temizler). */
	private static boolean step(MinecraftServer server, Execution execution) {
		Entity entity = execution.level.getEntity(execution.target);
		if (!(entity instanceof Mob mob) || !mob.isAlive() || mob.isRemoved()) {
			return false; // Hedef zaten gitti: yapılacak bir şey yok.
		}
		ServerPlayer player = server.getPlayerList().getPlayer(execution.player);
		if (player == null || !player.isAlive() || player.isSpectator() || player.level() != execution.level
				|| !ExecutionLogic.within(mob.getX() - player.getX(), mob.getY() - player.getY(), mob.getZ() - player.getZ(),
						ExecutionConfig.ABORT_DISTANCE)) {
			release(mob); // Oyuncu gitti/öldü/uzaklaştı: hedef canlı ve normal davranışıyla serbest.
			return false;
		}

		ExecutionAnimation animation = execution.animation;
		ExecutionTiming timing = animation.timing();
		execution.age++;
		mob.setDeltaMovement(Vec3.ZERO);
		face(mob, player);

		if (timing.swingAt(execution.age)) {
			player.swing(InteractionHand.MAIN_HAND, true);
			animation.swing(execution.level, player, mob, execution.swings++);
			shake(player, ExecutionConfig.SHAKE_SWING, ExecutionConfig.SHAKE_SWING_TICKS);
		}
		if (timing.windupEffectAt(execution.age)) {
			animation.windup(execution.level, player, mob, execution.age);
		}
		if (execution.age >= timing.impactTick()) {
			finish(execution, player, mob);
			return false;
		}
		return true;
	}

	/** Gerçek öldürücü darbe: tek, oyuncu adına, ölüm/loot/deneyim vanilla akışıyla. */
	private static void finish(Execution execution, ServerPlayer player, Mob mob) {
		ServerLevel level = execution.level;
		ExecutionAnimation animation = execution.animation;
		release(mob);

		DamageSource source = player.damageSources().source(DamageTypes.PLAYER_ATTACK, player);
		boolean hurt;
		finishingTarget = mob.getUUID();
		// Ruh Ağı: bu ölüm bir BİTİRİCİ öldürüştür (ek ruh, aynı olaya yazılır).
		NexusApi.markFinisherKill(player, mob.getUUID(), level.getGameTime() + 2L);
		// Ruh Ağı/Evrim hasar çarpanları ilk vuruşta zaten uygulandı; bu darbe yalnızca ölümü tamamlar.
		NexusDamage.enter();
		try {
			hurt = mob.hurtServer(level, source, ExecutionConfig.FINISH_DAMAGE);
		} finally {
			NexusDamage.exit();
			finishingTarget = null;
		}

		animation.impact(level, player, mob);
		if (mob.isDeadOrDying()) {
			NexusApi.onExecutionFinish(player); // Ruh Muhafızı: bitirici sonrası şifa
		}
		if (hurt) {
			mob.knockback(animation.knockback(), player.getX() - mob.getX(), player.getZ() - mob.getZ(), source,
					ExecutionConfig.FINISH_DAMAGE);
		}
		shake(player, animation.impactShake(), animation.impactShakeTicks());
	}

	// ------------------------------------------------------------------
	// Yardımcılar
	// ------------------------------------------------------------------

	/** Hedefi dondurmayı bırakır: yapay zekâ geri gelir, etiket silinir. Hedef canlı kalabilir (iptal durumunda). */
	private static void release(Mob mob) {
		mob.setNoAi(false);
		mob.removeTag(ExecutionConfig.TAG);
	}

	private static void face(Mob mob, ServerPlayer player) {
		float yaw = ExecutionLogic.yawToward(player.getX() - mob.getX(), player.getZ() - mob.getZ());
		mob.setYRot(yaw);
		mob.setYHeadRot(yaw);
	}

	/** Kamera sarsıntısı YALNIZCA saldıran oyuncuya (mevcut Berserker sarsıntı paketi; istemci ayarı kapatabilir). */
	private static void shake(ServerPlayer player, float strength, int ticks) {
		if (ServerPlayNetworking.canSend(player, BerserkerShakePayload.TYPE)) {
			ServerPlayNetworking.send(player, new BerserkerShakePayload(strength, ticks));
		}
	}

	/** Bir oyuncunun etkin bitiricisini (varsa) iptal eder: hedef serbest bırakılır. */
	private static void abortOf(UUID playerId) {
		UUID targetId = BY_PLAYER.remove(playerId);
		if (targetId == null) {
			return;
		}
		Execution execution = ACTIVE.remove(targetId);
		if (execution != null && execution.level.getEntity(targetId) instanceof Mob mob) {
			release(mob);
		}
	}

	/** Sunucu kapanırken: hiçbir hedef dondurulmuş olarak kaydedilmesin. */
	private static void releaseAll() {
		for (Execution execution : ACTIVE.values()) {
			if (execution.level.getEntity(execution.target) instanceof Mob mob) {
				release(mob);
			}
		}
		ACTIVE.clear();
		BY_PLAYER.clear();
	}
}
