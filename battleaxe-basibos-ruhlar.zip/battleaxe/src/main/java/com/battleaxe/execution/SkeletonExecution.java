package com.battleaxe.execution;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;

/**
 * İskelet bitiricisi: zombideki tek ağır darbenin aksine İKİ hızlı savurma ve ikinci savurmada kemiği
 * parçalayan sert, yüksek perdeli bir çatırtı. Hazırlıkta kemikler titrer (kritik kıvılcımları); darbede soluk
 * kemik tozu, kıvılcım ve hafif bir geriye savrulma vardır. Süre: ~0,75 sn (darbe 15. tick).
 */
public final class SkeletonExecution implements ExecutionAnimation {
	private static final ExecutionTiming TIMING = new ExecutionTiming(new int[] {7, 12}, 15, 2);

	/** Kemik tozu: solgun beyazdan eski kemiğe. */
	private static final DustColorTransitionOptions BONE = new DustColorTransitionOptions(0xF2EEDC, 0xB8B29A, 0.9F);

	@Override
	public ExecutionTiming timing() {
		return TIMING;
	}

	@Override
	public boolean enabled() {
		return ExecutionConfig.SKELETON_ENABLED;
	}

	@Override
	public double knockback() {
		return 0.9;
	}

	@Override
	public float impactShake() {
		return 0.35F;
	}

	@Override
	public int impactShakeTicks() {
		return 6;
	}

	@Override
	public void start(ServerLevel level, ServerPlayer player, Mob target) {
		level.playSound(null, target.getX(), target.getY(0.5), target.getZ(), SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 0.4F, 1.5F);
		level.sendParticles(BONE, target.getX(), target.getY(0.5), target.getZ(), 6, 0.25, 0.4, 0.25, 0.0);
	}

	@Override
	public void windup(ServerLevel level, ServerPlayer player, Mob target, int age) {
		// Kemikler titriyor: gövdede küçük kıvılcımlar ve toz.
		level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY(0.6), target.getZ(), 2, 0.2, 0.3, 0.2, 0.05);
		level.sendParticles(BONE, target.getX(), target.getY(0.5), target.getZ(), 1, 0.2, 0.3, 0.2, 0.0);
	}

	@Override
	public void swing(ServerLevel level, ServerPlayer player, Mob target, int index) {
		// Yan/çapraz savurma: hedefin gövdesi hizasında; ikinci savurma daha keskin.
		level.playSound(null, player.getX(), player.getY(0.6), player.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS,
				0.9F, index == 0 ? 0.95F : 1.2F);
		level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY(0.6), target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
	}

	@Override
	public void impact(ServerLevel level, ServerPlayer player, Mob target) {
		double x = target.getX();
		double y = target.getY(0.6);
		double z = target.getZ();
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.0F, 1.6F);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.6F, 1.15F);
		level.sendParticles(BONE, x, y, z, 28, 0.35, 0.45, 0.35, 0.0);
		level.sendParticles(ParticleTypes.CRIT, x, y, z, 14, 0.3, 0.4, 0.3, 0.35);
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 6, 0.3, 0.4, 0.3, 0.3);
	}
}
