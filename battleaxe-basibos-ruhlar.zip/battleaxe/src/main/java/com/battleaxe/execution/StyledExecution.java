package com.battleaxe.execution;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;

/**
 * {@link ExecutionCatalog.Profile} verisinden çalışan genel bitirici animasyonu: Zombi/İskelet'teki aynı üç aşama
 * (başlangıç, hazırlık, savurma, darbe), ama süre, renk, ses perdesi ve "tat" (ruh, alev, buz, kıvılcım) tariften gelir.
 * Yalnızca {@link ZombieExecution} ve {@link SkeletonExecution}'da zaten kullanılan ses/parçacık türlerini kullanır;
 * mobun kendine özgü sesleri kasıtlı olarak yoktur (hepsi tarifteki perdelerle ayırt edilir).
 */
public final class StyledExecution implements ExecutionAnimation {
	private final ExecutionCatalog.Profile profile;
	private final DustColorTransitionOptions dust;

	public StyledExecution(ExecutionCatalog.Profile profile) {
		this.profile = profile;
		this.dust = new DustColorTransitionOptions(profile.dustStart(), profile.dustEnd(), profile.dustSize());
	}

	@Override
	public ExecutionTiming timing() {
		return profile.timing();
	}

	@Override
	public boolean enabled() {
		return ExecutionCatalog.isEnabled(ExecutionConfig.EXTRA_MOBS_ENABLED, ExecutionConfig.DISABLED_EXTRA_IDS, profile.entityId());
	}

	@Override
	public double knockback() {
		return profile.knockback();
	}

	@Override
	public float impactShake() {
		return profile.shake();
	}

	@Override
	public int impactShakeTicks() {
		return profile.shakeTicks();
	}

	@Override
	public void start(ServerLevel level, ServerPlayer player, Mob target) {
		level.playSound(null, target.getX(), target.getY(0.5), target.getZ(), SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 0.45F,
				profile.heavy() ? 0.6F : 1.4F);
		level.sendParticles(dust, target.getX(), target.getY(0.5), target.getZ(), 6, 0.25, 0.4, 0.25, 0.0);
	}

	@Override
	public void windup(ServerLevel level, ServerPlayer player, Mob target, int age) {
		double x = target.getX();
		double y = target.getY(0.6);
		double z = target.getZ();
		level.sendParticles(dust, x, y, z, 2, 0.25, 0.3, 0.25, 0.0);
		switch (profile.flair()) {
			case SOUL -> level.sendParticles(ParticleTypes.SOUL, x, y, z, 1, 0.2, 0.3, 0.2, 0.02);
			case FLAME -> level.sendParticles(ParticleTypes.FLAME, x, target.getY(0.2), z, 1, 0.2, 0.1, 0.2, 0.01);
			case FROST -> level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.2, 0.3, 0.2, 0.02);
			case SPARK -> level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 1, 0.25, 0.3, 0.25, 0.1);
			case NONE -> {
			}
		}
	}

	@Override
	public void swing(ServerLevel level, ServerPlayer player, Mob target, int index) {
		level.playSound(null, player.getX(), player.getY(0.6), player.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F,
				profile.swingPitch(index));
		// Savaşçılarda son savurma dışındakiler metal çarpışmasıdır: kısa, parlak bir "çınlama".
		if (profile.flair() == ExecutionCatalog.Flair.SPARK && !profile.lastSwing(index)) {
			level.playSound(null, target.getX(), target.getY(0.6), target.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F, 1.8F);
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY(0.7), target.getZ(), 6, 0.2, 0.2, 0.2, 0.25);
		}
		// Ağır darbeler tepeden iner (başın üstü); hızlı kesikler gövde hizasındadır.
		double y = profile.heavy() ? target.getEyeY() + 0.35 : target.getY(0.6);
		level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), y, target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
	}

	@Override
	public void impact(ServerLevel level, ServerPlayer player, Mob target) {
		double x = target.getX();
		double y = profile.heavy() ? target.getEyeY() : target.getY(0.6);
		double z = target.getZ();
		if (profile.heavy()) {
			level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.2F, 0.5F);
			level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.6F, 0.8F);
		} else {
			level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.0F, 1.6F);
			level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.6F, 1.15F);
		}
		level.sendParticles(dust, x, y, z, 24, 0.32, 0.35, 0.32, 0.0);
		level.sendParticles(ParticleTypes.CRIT, x, y, z, 10, 0.3, 0.35, 0.3, 0.3);
		switch (profile.flair()) {
			case SOUL -> {
				level.sendParticles(ParticleTypes.SOUL, x, y, z, 10, 0.3, 0.5, 0.3, 0.06);
				level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 8, 0.3, 0.4, 0.3, 0.04);
			}
			case FLAME -> {
				level.sendParticles(ParticleTypes.FLAME, x, y, z, 10, 0.3, 0.3, 0.3, 0.05);
				level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y - 0.2, z, 3, 0.25, 0.25, 0.25, 0.02);
			}
			case FROST -> level.sendParticles(ParticleTypes.END_ROD, x, y, z, 12, 0.3, 0.4, 0.3, 0.12);
			case SPARK -> level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 12, 0.3, 0.4, 0.3, 0.3);
			case NONE -> {
			}
		}
	}
}
