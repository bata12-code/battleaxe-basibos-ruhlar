package com.battleaxe.execution;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;

/**
 * Zombi bitiricisi: tek, AĞIR ve tepeden inen balta darbesi. Hedef sendeler, hazırlık sırasında kor-kırmızı
 * ve dumanlı bir gerilim oluşur; oyuncu baltayı başın üstünden indirir; darbede alçak, boğuk bir gümleme,
 * koyu kırmızı sıçrama ve güçlü bir geriye savrulma vardır. Süre: ~0,8 sn (darbe 16. tick).
 */
public final class ZombieExecution implements ExecutionAnimation {
	private static final ExecutionTiming TIMING = new ExecutionTiming(new int[] {11}, 16, 3);

	/** Stilize, sınırlı "kan": koyu kırmızıdan kömüre. Gerçekçi gore değil, küçük bir sıçrama. */
	private static final DustColorTransitionOptions BLOOD = new DustColorTransitionOptions(0x8A0A0A, 0x2A0000, 1.0F);

	@Override
	public ExecutionTiming timing() {
		return TIMING;
	}

	@Override
	public boolean enabled() {
		return ExecutionConfig.ZOMBIE_ENABLED;
	}

	@Override
	public double knockback() {
		return 1.5;
	}

	@Override
	public float impactShake() {
		return 0.45F;
	}

	@Override
	public int impactShakeTicks() {
		return 7;
	}

	@Override
	public void start(ServerLevel level, ServerPlayer player, Mob target) {
		level.playSound(null, target.getX(), target.getY(0.5), target.getZ(), SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 0.5F, 0.6F);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, target.getX(), target.getY(0.1), target.getZ(), 5, 0.3, 0.05, 0.3, 0.01);
	}

	@Override
	public void windup(ServerLevel level, ServerPlayer player, Mob target, int age) {
		level.sendParticles(BLOOD, target.getX(), target.getEyeY(), target.getZ(), 2, 0.25, 0.2, 0.25, 0.0);
		if (age % 6 == 0) {
			level.sendParticles(ParticleTypes.LARGE_SMOKE, target.getX(), target.getY(0.1), target.getZ(), 1, 0.25, 0.05, 0.25, 0.01);
		}
	}

	@Override
	public void swing(ServerLevel level, ServerPlayer player, Mob target, int index) {
		level.playSound(null, player.getX(), player.getY(0.6), player.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.55F);
		// Tepeden inen savurma: parçacık hedefin başının hemen üstünde.
		level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getEyeY() + 0.35, target.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
	}

	@Override
	public void impact(ServerLevel level, ServerPlayer player, Mob target) {
		double x = target.getX();
		double y = target.getEyeY();
		double z = target.getZ();
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.2F, 0.5F);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.6F, 0.8F);
		level.sendParticles(BLOOD, x, y, z, 22, 0.3, 0.25, 0.3, 0.0);
		level.sendParticles(ParticleTypes.CRIT, x, y, z, 10, 0.3, 0.3, 0.3, 0.25);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y - 0.2, z, 4, 0.25, 0.25, 0.25, 0.02);
	}
}
