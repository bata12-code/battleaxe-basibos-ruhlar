package com.battleaxe.execution;

/**
 * Bir bitirici animasyonunun zaman çizelgesi (SAF veri; Minecraft'a bağımlı değildir).
 *
 * @param swingTicks         oyuncunun baltayı savurduğu anlar (başlangıçtan itibaren tick; artan sırada)
 * @param impactTick         gerçek öldürücü darbe anı; son savurmadan SONRA olmalı
 * @param windupEffectEvery  hazırlık efektinin kaç tickte bir üretileceği (düşük yük için seyrek)
 */
public record ExecutionTiming(int[] swingTicks, int impactTick, int windupEffectEvery) {
	public ExecutionTiming {
		if (impactTick < 2 || windupEffectEvery < 1 || swingTicks == null || swingTicks.length == 0) {
			throw new IllegalArgumentException("Geçersiz bitirici zamanlaması");
		}
		int previous = 0;
		for (int swing : swingTicks) {
			if (swing <= previous || swing >= impactTick) {
				throw new IllegalArgumentException("Savurma anları artan olmalı ve darbeden önce gelmeli");
			}
			previous = swing;
		}
	}

	/** Bu tick'te oyuncu baltayı savuruyor mu? */
	public boolean swingAt(int age) {
		for (int swing : swingTicks) {
			if (swing == age) {
				return true;
			}
		}
		return false;
	}

	/** Hazırlık efekti bu tick'te üretilecek mi? (Darbe anında değil, yalnızca hazırlık sırasında.) */
	public boolean windupEffectAt(int age) {
		return age < impactTick && age % windupEffectEvery == 0;
	}

	/** Başlangıçtan gerçek darbeye kadar saniye. */
	public double secondsToImpact() {
		return impactTick / 20.0;
	}
}
