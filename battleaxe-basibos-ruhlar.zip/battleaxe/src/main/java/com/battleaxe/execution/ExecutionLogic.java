package com.battleaxe.execution;

import java.util.random.RandomGenerator;

/**
 * Execution'ın SAF karar mantığı (Minecraft'a bağımlı değildir; test: tools/test/ExecutionLogicTest.java).
 * Oyun nesnelerini okuyup bu fonksiyonlara sayı/bool olarak verir; kararlar burada alınır.
 */
public final class ExecutionLogic {
	private ExecutionLogic() {
	}

	/** Küçük kayan nokta toleransı: tam %30 sınırındaki can (ör. 6.0/20) uygun sayılır. */
	private static final float EPSILON = 1.0E-4F;

	/** Hedefin SALDIRIDAN ÖNCEKİ canı eşiğin altında/eşit mi? Geçersiz azami can asla uygun sayılmaz. */
	public static boolean healthQualifies(float healthBefore, float maxHealth, float ratio) {
		if (!(maxHealth > 0.0F) || !(healthBefore > 0.0F) || Float.isNaN(healthBefore)) {
			return false;
		}
		return healthBefore <= maxHealth * ratio + EPSILON;
	}

	/** Son olaydan beri bekleme süresi doldu mu? (Veri/zaman geriye giderse takılı kalmaz.) */
	public static boolean cooldownReady(long now, long readyAt) {
		return readyAt <= 0L || now >= readyAt || readyAt - now > 24L * 60L * 60L * 20L;
	}

	/** Kıyım Zinciri kademesinden ek bitirici olasılığı (0..4 kademe sınırlanır; negatif kademe 0). */
	public static double chainChanceBonus(int tier) {
		return Math.max(0, Math.min(4, tier)) * ExecutionConfig.CHAIN_CHANCE_PER_TIER;
	}

	/** Olasılık atışı. {@code chance} 0..1; yalnızca tüm koşullar sağlandıktan sonra çağrılmalıdır. */
	public static boolean roll(RandomGenerator random, double chance) {
		if (chance <= 0.0) {
			return false;
		}
		return chance >= 1.0 || random.nextDouble() < chance;
	}

	/** Saldırı yeterince şarjlı mı? */
	public static boolean strongEnough(float attackStrength, float minimum) {
		return attackStrength >= minimum;
	}

	/** (dx, dz) yönüne bakan Minecraft yaw'ı (derece): yaw 0 = güney (+Z), yaw 90 = batı (-X). */
	public static float yawToward(double dx, double dz) {
		return (float) Math.toDegrees(Math.atan2(-dx, dz));
	}

	/** İki nokta arasındaki yatay mesafenin karesi içinde mi (başlangıç/iptal mesafesi için). */
	public static boolean within(double dx, double dy, double dz, double maxDistance) {
		return dx * dx + dy * dy + dz * dz <= maxDistance * maxDistance;
	}
}
