package com.battleaxe.execution;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Zombi ve İskelet dışındaki mobların bitirici animasyonlarının VERİ tablosu (SAF; Minecraft'a bağımlı değildir,
 * test: tools/test/ExecutionCatalogTest.java). Her satır bir {@link Profile}'dır: zaman çizelgesi, darbe gücü,
 * renk ve efekt "tadı". Efektleri {@link StyledExecution} üretir; durum yönetimi, ölüm/loot güvenliği ve ağ
 * yine {@link ExecutionManager}'da ortaktır.
 *
 * <p>Moblar oyun nesnesiyle değil KAYIT DEFTERİ KİMLİĞİYLE ("minecraft:spider") eşleşir; böylece bu tablo
 * Minecraft sınıf/sabit adlarına bağımlı olmaz. <b>Yeni mob eklemek:</b> {@link #PROFILES} içine bir {@code add(...)}
 * satırı yazmak yeterlidir; test, süre/şiddet sınırlarını otomatik doğrular.
 *
 * <p>Yalnızca TAM türler eşleşir (Zombi ve İskelet gibi). Bilerek EKLENMEYENLER: Creeper (fitili tick'te ilerler,
 * yapay zekâ dondurulsa da patlayabilir), Enderman (ışınlanır), Blaze/Ghast/Phantom (uçar), Slime/Magma Küpü
 * (bölünür), Witch (iksirle kendini iyileştirir).
 */
public final class ExecutionCatalog {
	private ExecutionCatalog() {
	}

	/** Darbe anındaki ek efektin "tadı". */
	public enum Flair {
		NONE,
		/** Ruhlar yükselir (Wither İskeleti). */
		SOUL,
		/** Kor ve alev (Nether piglinleri). */
		FLAME,
		/** Buz kıvılcımları (Bozkır İskeleti). */
		FROST,
		/** Metal çarpışması kıvılcımı (savaşçılar). */
		SPARK
	}

	/** Bitirici süresinin üst sınırı (tick): animasyon asla bundan uzun sürmez; mob uzun donuk kalmaz. */
	public static final int MAX_IMPACT_TICKS = 30;

	/**
	 * Bir mobun bitirici tarifi.
	 *
	 * @param entityId  kayıt defteri kimliği ("minecraft:spider")
	 * @param timing    savurma anları, darbe anı, hazırlık efekti sıklığı
	 * @param knockback darbe sonrası geriye savrulma (0.4 hafif, 1.5 güçlü)
	 * @param shake     saldıran oyuncunun kamera sarsıntısı şiddeti (0-1)
	 * @param shakeTicks sarsıntı süresi (tick)
	 * @param dustStart parçacık renginin başı (0xRRGGBB)
	 * @param dustEnd   parçacık renginin sonu (0xRRGGBB)
	 * @param dustSize  parçacık boyutu
	 * @param flair     ek efekt tadı
	 * @param heavy     true: alçak perdeli, tepeden inen ağır darbe; false: hızlı, yüksek perdeli kesikler
	 */
	public record Profile(String entityId, ExecutionTiming timing, double knockback, float shake, int shakeTicks,
			int dustStart, int dustEnd, float dustSize, Flair flair, boolean heavy) {
		public Profile {
			if (entityId == null || entityId.indexOf(':') <= 0 || entityId.endsWith(":")) {
				throw new IllegalArgumentException("Geçersiz kayıt kimliği: " + entityId);
			}
			if (timing == null || timing.impactTick() > MAX_IMPACT_TICKS) {
				throw new IllegalArgumentException("Bitirici çok uzun veya zamanlamasız: " + entityId);
			}
			if (!(knockback >= 0.0 && knockback <= 3.0) || !(shake >= 0.0F && shake <= 1.0F) || shakeTicks < 1 || shakeTicks > 20
					|| !(dustSize > 0.0F && dustSize <= 4.0F) || flair == null) {
				throw new IllegalArgumentException("Geçersiz bitirici ayarı: " + entityId);
			}
			if ((dustStart & 0xFF000000) != 0 || (dustEnd & 0xFF000000) != 0) {
				throw new IllegalArgumentException("Renk 0xRRGGBB olmalı: " + entityId);
			}
		}

		/** Savurma sesinin perdesi: ağır darbeler alçak; art arda savurmalar hafifçe yükselir (gerilim artar). */
		public float swingPitch(int index) {
			float base = heavy ? 0.55F : 0.9F;
			return Math.min(1.6F, base + 0.12F * Math.max(0, index));
		}

		/** Bu, son savurma mı? (Metal çarpışması sesi son savurmada çalmaz; son savurma darbeye bağlanır.) */
		public boolean lastSwing(int index) {
			return index >= timing.swingTicks().length - 1;
		}
	}

	private static final Map<String, Profile> PROFILES = new LinkedHashMap<>();

	private static void add(String entityId, int[] swings, int impact, int windupEvery, double knockback, float shake,
			int shakeTicks, int dustStart, int dustEnd, float dustSize, Flair flair, boolean heavy) {
		Profile profile = new Profile(entityId, new ExecutionTiming(swings, impact, windupEvery), knockback, shake, shakeTicks,
				dustStart, dustEnd, dustSize, flair, heavy);
		if (PROFILES.put(entityId, profile) != null) {
			throw new IllegalStateException("Aynı mob iki kez eklendi: " + entityId);
		}
	}

	static {
		// Örümcek: üç hızlı pençe kesiği; ağ gibi soluk gri toz.
		add("minecraft:spider", new int[] {4, 8, 12}, 16, 2, 0.7, 0.30F, 5, 0xE8E8E8, 0x8C8C8C, 0.8F, Flair.NONE, false);
		// Mağara Örümceği: küçük ve çevik; iki kesik, zehirli turkuaz toz.
		add("minecraft:cave_spider", new int[] {4, 8}, 12, 2, 0.5, 0.20F, 4, 0x7FD6C8, 0x2F6F66, 0.7F, Flair.NONE, false);
		// Çöl Zombisi: zombi gibi tek ağır darbe, ama kuru kum tozu.
		add("minecraft:husk", new int[] {11}, 16, 3, 1.4, 0.42F, 7, 0xCDB67E, 0x7A6A3E, 1.0F, Flair.NONE, true);
		// Bozkır İskeleti: iskelet gibi iki kesik, buz kıvılcımları.
		add("minecraft:stray", new int[] {7, 12}, 15, 2, 0.9, 0.35F, 6, 0xBFEAFF, 0x6FA8D6, 0.9F, Flair.FROST, false);
		// Wither İskeleti: yavaş, iki ağır darbe; karanlık toz ve yükselen ruhlar.
		add("minecraft:wither_skeleton", new int[] {9, 16}, 21, 3, 1.1, 0.50F, 8, 0x2B2B33, 0x0A0A0F, 1.1F, Flair.SOUL, true);
		// Zombileşmiş Piglin: zombi tarzı tepeden darbe, kor ve alev.
		add("minecraft:zombified_piglin", new int[] {11}, 16, 3, 1.3, 0.42F, 7, 0xD98A7A, 0x6B2E2E, 1.0F, Flair.FLAME, true);
		// Piglin Barbarı: altın baltalı güç gösterisi; iki ağır savurma, altın kıvılcımlar.
		add("minecraft:piglin_brute", new int[] {8, 14}, 19, 3, 1.6, 0.50F, 8, 0xF2C94C, 0x8A5A00, 1.0F, Flair.SPARK, true);
		// Korucu (Vindicator): balta düellosu; iki çarpışma, ardından tepeden son darbe.
		add("minecraft:vindicator", new int[] {6, 11, 17}, 21, 3, 1.5, 0.50F, 8, 0x9A9AA5, 0x3A3A44, 1.0F, Flair.SPARK, true);
		// --- Genişleme: yapay zekâ dondurulunca güvenli olan, yakın dövüşe/sıradan hareketlere dayalı moblar ---
		// Bataklık İskeleti: iki hızlı kesik, zehir yeşili toz.
		add("minecraft:bogged", new int[] {7, 12}, 15, 2, 0.9, 0.35F, 6, 0x8DC06A, 0x3B5E2B, 0.9F, Flair.NONE, false);
		// Zombi Köylü: zombi gibi tek ağır darbe, soluk yeşil toz.
		add("minecraft:zombie_villager", new int[] {11}, 16, 3, 1.3, 0.40F, 7, 0x7FA06A, 0x3E5530, 1.0F, Flair.NONE, true);
		// Yağmacı: tüfek dipçiği gibi iki sert vuruş, metal kıvılcımı.
		add("minecraft:pillager", new int[] {7, 12}, 16, 2, 1.0, 0.40F, 6, 0xA89F8E, 0x4B453A, 0.9F, Flair.SPARK, false);
		// Çağırıcı (Evoker): büyücü; iki kısa kesik ve sönen ruh dumanı.
		add("minecraft:evoker", new int[] {6, 11}, 15, 2, 0.8, 0.35F, 6, 0xD8D0F0, 0x5A4C86, 0.9F, Flair.SOUL, false);
		// Yıkıcı (Ravager): dev; yavaş ve çok ağır tek darbe, ama devliği yüzünden geri savrulma sınırlı.
		add("minecraft:ravager", new int[] {13}, 24, 3, 0.9, 0.60F, 10, 0x6E6A66, 0x2A2826, 1.3F, Flair.NONE, true);
		// Hoglin: ağır boynuz darbesi, kor tozu.
		add("minecraft:hoglin", new int[] {10}, 17, 3, 1.2, 0.45F, 7, 0xC98A6A, 0x6A3A2A, 1.0F, Flair.FLAME, true);
		// Zoglin: bozulmuş hoglin; sönük mavi ruh alevi.
		add("minecraft:zoglin", new int[] {10}, 17, 3, 1.2, 0.45F, 7, 0x8BA7B5, 0x2F4553, 1.0F, Flair.SOUL, true);
		// Piglin: tek hızlı altın kesik.
		add("minecraft:piglin", new int[] {8}, 14, 2, 1.0, 0.35F, 6, 0xF2C94C, 0x8A5A00, 0.9F, Flair.SPARK, false);
	}

	/** Bu kimlik için tarif; yoksa null. */
	public static Profile byId(String entityId) {
		return entityId == null ? null : PROFILES.get(entityId);
	}

	/** Tüm tarifler (eklenme sırasıyla; değiştirilemez). */
	public static Collection<Profile> all() {
		return Collections.unmodifiableCollection(PROFILES.values());
	}

	/** Bu mobun bitiricisi ayarlardan açık mı? Ana anahtar kapalıysa veya kimlik kapatılanlardaysa kapalıdır. */
	public static boolean isEnabled(boolean extraMobsEnabled, Set<String> disabledIds, String entityId) {
		return extraMobsEnabled && entityId != null && (disabledIds == null || !disabledIds.contains(entityId));
	}
}
