package com.battleaxe.execution;

/**
 * Execution (Bitirici Animasyon) ayarları. Mod ayarlarını Java sabitlerinde tutar; yeni bir yapılandırma
 * sistemi eklenmedi. Süreler tick'tir (20 tick = 1 sn). Mob başına ayrı süre/ses/parçacık ayarları ilgili
 * animasyon sınıfındadır ({@link ZombieExecution}, {@link SkeletonExecution}).
 */
public final class ExecutionConfig {
	private ExecutionConfig() {
	}

	/** false yaparsan Execution tamamen kapanır (normal savaş aynen sürer). */
	public static final boolean ENABLED = true;
	public static final boolean ZOMBIE_ENABLED = true;
	public static final boolean SKELETON_ENABLED = true;
	/** Zombi/İskelet dışındaki mobların bitiricileri ({@link ExecutionCatalog}); false yaparsan yalnızca Zombi ve İskelet kalır. */
	public static final boolean EXTRA_MOBS_ENABLED = true;
	/** Tek tek kapatmak için kayıt kimlikleri, ör. {@code Set.of("minecraft:vindicator")}. */
	public static final java.util.Set<String> DISABLED_EXTRA_IDS = java.util.Set.of();

	/** Hedefin saldırıdan ÖNCEKİ canı, azami canının bu oranına veya altına olmalı. */
	public static final float HEALTH_RATIO = 0.30F;
	/** Uygun (öldürücü) saldırılarda bitirici olasılığı. Yalnızca diğer tüm koşullar sağlandıktan sonra atılır. */
	public static final double CHANCE = 0.25;
	/** Kıyım Zinciri kademesi başına ek bitirici olasılığı (kademe 4 = 4 katı); Ruh Ağı bonusuna eklenir. */
	public static final double CHAIN_CHANCE_PER_TIER = 0.04;
	/** Saldırı en az bu şarjda olmalı (kol sallama spam'i bitirici başlatmaz). */
	public static final float MIN_ATTACK_STRENGTH = 0.9F;

	/** Başlamak için oyuncu-hedef en büyük mesafesi (blok). Vanilla erişimi ~3'tür. */
	public static final double MAX_START_DISTANCE = 5.0;
	/** Animasyon sürerken oyuncu hedeften bu kadar uzaklaşırsa iptal edilir. */
	public static final double ABORT_DISTANCE = 12.0;

	/** Aynı oyuncuda iki bitirici başlangıcı arası en az süre (animasyondan uzundur: art arda sinema olmaz). */
	public static final long PLAYER_COOLDOWN_TICKS = 60L;

	/** Son (öldürücü) darbenin ham hasarı: hedefi kesin öldürmek için fazlasıyla yüksek, zırh/dirençten geçer. */
	public static final float FINISH_DAMAGE = 1024.0F;
	/** Dondurulan mobun etiketi: sunucu çökse/yüklenme olsa bile takılı kalan hedef bu etiketle onarılır. */
	public static final String TAG = "battleaxe_execution";

	/** Kamera sarsıntısı (yalnızca saldıran oyuncuya; mevcut ClientCameraShake üzerinden). */
	public static final float SHAKE_SWING = 0.10F;
	public static final int SHAKE_SWING_TICKS = 4;
}
