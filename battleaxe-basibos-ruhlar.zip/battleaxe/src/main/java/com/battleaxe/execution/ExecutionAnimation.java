package com.battleaxe.execution;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;

/**
 * Bir mob türü için bitirici animasyonu: zaman çizelgesi + her aşamanın efektleri (ses, parçacık).
 * Yeni bir mob eklemek için bu arayüzü uygulayan bir sınıf yazıp {@link ExecutionRegistry}'ye eklemek yeterlidir;
 * durum yönetimi, ölüm/loot güvenliği ve ağ {@link ExecutionManager}'da ortaktır.
 *
 * <p>Efektler SUNUCUDA üretilir (parçacık/ses paketleri yalnızca yakındaki oyunculara gider); böylece her istemci
 * aynı olayı görür ve hiçbir istemci kendi başına rastgele karar vermez. Hasar/ölüm bu arayüzde YAPILMAZ.
 */
public interface ExecutionAnimation {
	/** Zaman çizelgesi (savurma anları, darbe anı, hazırlık efekti sıklığı). */
	ExecutionTiming timing();

	/** Bu mobun bitiricisi ayarlardan açık mı? */
	boolean enabled();

	/** Darbe sonrası hedefin geriye savrulma gücü (vanilla knockback birimi; 0.4 hafif, 1.5 güçlü). */
	double knockback();

	/** Darbe anında saldıran oyuncunun kamera sarsıntısı: şiddet (0-1) ve süre (tick). */
	float impactShake();

	int impactShakeTicks();

	/** Başlangıç: ölüm iptal edildi, hedef donduruldu. */
	void start(ServerLevel level, ServerPlayer player, Mob target);

	/** Hazırlık sırasında seyrek tekrarlanan hafif efekt. */
	void windup(ServerLevel level, ServerPlayer player, Mob target, int age);

	/** Oyuncu baltayı savurdu (savurma sesi ve hareket efekti). {@code index}: kaçıncı savurma (0'dan). */
	void swing(ServerLevel level, ServerPlayer player, Mob target, int index);

	/** Gerçek darbe anının efektleri (öldürücü hasar uygulandıktan hemen sonra). */
	void impact(ServerLevel level, ServerPlayer player, Mob target);
}
