package com.battleaxe.execution;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;

/**
 * Hangi mob türünün hangi bitirici animasyonuna sahip olduğu. Zombi ve İskelet kendi sınıflarıyla çalışır;
 * diğer mobların tarifleri {@link ExecutionCatalog} tablosundadır (kayıt defteri kimliğiyle eşleşir). İLERİDE yeni
 * mob eklemek için çoğu zaman yalnızca {@link ExecutionCatalog} içine bir satır yazmak yeterlidir; tamamen özel bir
 * animasyon isteniyorsa bir {@link ExecutionAnimation} sınıfı yazılıp {@link #find} içine bir satır eklenir.
 * Yalnızca TAM türler eşleşir: Zombie ve Skeleton (Husk, Drowned, Stray, Wither İskeleti vb. kendi tarifleriyle ayrı ayrı).
 */
public final class ExecutionRegistry {
	private ExecutionRegistry() {
	}

	private static final ExecutionAnimation ZOMBIE = new ZombieExecution();
	private static final ExecutionAnimation SKELETON = new SkeletonExecution();

	/**
	 * Tür -> katalog animasyonu (yoksa boş). Her saldırıda sorgulandığı için bir kez hesaplanıp saklanır; EntityType
	 * nesneleri oyun boyunca sabittir. Yalnızca sunucu iş parçacığından çağrılır.
	 */
	private static final Map<EntityType<?>, Optional<ExecutionAnimation>> EXTRA_CACHE = new HashMap<>();

	/** Bu türün (ve ayarlarda açık olan) animasyonu; yoksa null. */
	public static ExecutionAnimation find(EntityType<?> type) {
		ExecutionAnimation animation = null;
		if (type == EntityTypes.ZOMBIE) {
			animation = ZOMBIE;
		} else if (type == EntityTypes.SKELETON) {
			animation = SKELETON;
		} else if (type != null) {
			animation = EXTRA_CACHE.computeIfAbsent(type, ExecutionRegistry::lookupExtra).orElse(null);
		}
		return animation != null && animation.enabled() ? animation : null;
	}

	private static Optional<ExecutionAnimation> lookupExtra(EntityType<?> type) {
		var key = BuiltInRegistries.ENTITY_TYPE.getKey(type);
		ExecutionCatalog.Profile profile = key == null ? null : ExecutionCatalog.byId(key.toString());
		return profile == null ? Optional.empty() : Optional.of(new StyledExecution(profile));
	}
}
