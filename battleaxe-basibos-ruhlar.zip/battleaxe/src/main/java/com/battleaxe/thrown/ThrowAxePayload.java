package com.battleaxe.thrown;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * İstemciden sunucuya: "baltayı fırlat" isteği (veri taşımaz). Sunucu isteğin geçerli olup
 * olmadığını KENDİSİ denetler; istemciye hiçbir şey için güvenilmez.
 */
public record ThrowAxePayload() implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ThrowAxePayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("throw_axe"));

	public static final StreamCodec<RegistryFriendlyByteBuf, ThrowAxePayload> CODEC =
			StreamCodec.unit(new ThrowAxePayload());

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
