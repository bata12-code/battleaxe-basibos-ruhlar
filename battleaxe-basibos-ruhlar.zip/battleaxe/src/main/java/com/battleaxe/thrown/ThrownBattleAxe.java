package com.battleaxe.thrown;

import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.berserker.BerserkerEffects;
import com.battleaxe.item.ModItems;
import com.battleaxe.soul.RankStyle;
import com.battleaxe.soul.SoulManager;

/**
 * Fırlatılmış Savaş Baltası.
 *
 * <p>Yaşam döngüsü: UÇUŞ (dönerek ilerler) -> bir canlıya çarparsa TEK SEFER hasar verir, sekip düşer
 * -> bir bloğa çarpınca SAPLANIR (artık hiç hasar vermez) -> oyuncu dokununca envanterine geri döner.
 * Balta kendiliğinden geri dönmez.
 *
 * <p>Eşya güvenliği: balta eşyası (tüm verisiyle: ruhlar, büyüler, ad) bu varlığın içinde TAŞINIR,
 * kopyalanmaz. Varlık nasıl yok olursa olsun (/kill, boşluk, başka mod) eşya ya sahibine ya da
 * dünyaya bırakılır; teslim edilmiş eşya ikinci kez verilmez ({@link #delivered}).
 */
public class ThrownBattleAxe extends ThrowableItemProjectile {
	private static final EntityDataAccessor<Boolean> DATA_STUCK =
			SynchedEntityData.defineId(ThrownBattleAxe.class, EntityDataSerializers.BOOLEAN);

	private static final EntityDataAccessor<Boolean> DATA_RETURNING =
			SynchedEntityData.defineId(ThrownBattleAxe.class, EntityDataSerializers.BOOLEAN);

	/** Vanilla Sadakat büyüsü (baltaya da basılabilir; bkz. data/minecraft/enchantment/loyalty.json). */
	private static final ResourceKey<Enchantment> LOYALTY =
			ResourceKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath("minecraft", "loyalty"));

	/** O an hasar işlenen balta: ölüm olayında ruh kredisini baltaya yazmak için. Sunucu iş parçacığı. */
	private static ThrownBattleAxe activeHit;

	public static ThrownBattleAxe activeHit() {
		return activeHit;
	}

	// ---- Sunucu tarafı durum (kaydedilir)
	private boolean dealtDamage;
	private boolean delivered;
	private int pickupDelay;
	private int originSlot = -1;
	private boolean hasStuckPos;
	private int stuckX;
	private int stuckY;
	private int stuckZ;
	private boolean hasSafePos;
	private double safeX;
	private double safeY;
	private double safeZ;
	private UUID ownerUuid;

	// ---- Geçici (kaydedilmez)
	private boolean tracked;
	private int fullMessageCooldown;
	private int loyaltyLevel = -1;
	private int flightTicks;
	private int returnCountdown = -1;
	private int retryCooldown;

	// ---- Shunpo (geçici, kaydedilmez): fırlatıldığı andaki oyuncu konumu; null = Shunpo'suz fırlatma
	private Vec3 shunpoOrigin;

	public ThrownBattleAxe(EntityType<? extends ThrowableItemProjectile> type, Level level) {
		super(type, level);
	}

	public ThrownBattleAxe(Level level, LivingEntity owner, ItemStack stack) {
		super(ModEntityTypes.THROWN_BATTLE_AXE, owner, level, stack);
		this.ownerUuid = owner.getUUID();
		this.safeX = owner.getX();
		this.safeY = owner.getY();
		this.safeZ = owner.getZ();
		this.hasSafePos = true;
	}

	@Override
	protected Item getDefaultItem() {
		return ModItems.BATTLE_AXE;
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_STUCK, false);
		builder.define(DATA_RETURNING, false);
	}

	public boolean isStuck() {
		return this.entityData.get(DATA_STUCK);
	}

	private void setStuck(boolean stuck) {
		this.entityData.set(DATA_STUCK, stuck);
	}

	/** Sadakat ile sahibine doğru geri dönüyor mu? (çizici için de) */
	public boolean isReturning() {
		return this.entityData.get(DATA_RETURNING);
	}

	private void setReturning(boolean returning) {
		this.entityData.set(DATA_RETURNING, returning);
	}

	public UUID getOwnerUuid() {
		return ownerUuid;
	}

	public void setOriginSlot(int slot) {
		this.originSlot = slot;
	}

	// ------------------------------------------------------------------
	// Shunpo
	// ------------------------------------------------------------------

	/** Shunpo büyülü fırlatma: oyuncunun FIRLATMA ANINDAKİ konumunu kaydeder (sonradan değişmez). */
	public void armShunpo(Vec3 origin) {
		this.shunpoOrigin = origin;
	}

	public boolean isShunpoArmed() {
		return shunpoOrigin != null;
	}

	public Vec3 shunpoOrigin() {
		return shunpoOrigin;
	}

	/** Shunpo ışınlanmasından ÖNCE: balta oyuncuya (ana el ya da boş yuva) teslim edilebilir mi? */
	public boolean canShunpoRecall(ServerPlayer owner) {
		if (level().isClientSide() || delivered || isRemoved() || getItem().isEmpty()) {
			return false;
		}
		return owner.getMainHandItem().isEmpty()
				|| ThrownAxeLogic.chooseSlot(originSlot, emptySlots(owner.getInventory())) >= 0;
	}

	/** Shunpo: baltayı anında sahibine verir (ana el boşsa ana ele). Mevcut yakalama yolunu kullanır. */
	public boolean shunpoRecall(ServerPlayer owner) {
		if (level().isClientSide() || delivered || isRemoved()) {
			return false;
		}
		if (owner.getMainHandItem().isEmpty()) {
			originSlot = owner.getInventory().getSelectedSlot();
		}
		return tryCatch(owner);
	}

	// ------------------------------------------------------------------
	// Kayıt / yükleme
	// ------------------------------------------------------------------

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		super.addAdditionalSaveData(output);
		output.putBoolean("Stuck", isStuck());
		output.putBoolean("DealtDamage", dealtDamage);
		output.putBoolean("Delivered", delivered);
		output.putInt("OriginSlot", originSlot);
		output.putBoolean("HasStuckPos", hasStuckPos);
		output.putInt("StuckX", stuckX);
		output.putInt("StuckY", stuckY);
		output.putInt("StuckZ", stuckZ);
		output.putBoolean("HasSafePos", hasSafePos);
		output.putDouble("SafeX", safeX);
		output.putDouble("SafeY", safeY);
		output.putDouble("SafeZ", safeZ);
		if (ownerUuid != null) {
			output.putLong("OwnerMost", ownerUuid.getMostSignificantBits());
			output.putLong("OwnerLeast", ownerUuid.getLeastSignificantBits());
		}
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		setStuck(input.getBooleanOr("Stuck", false));
		dealtDamage = input.getBooleanOr("DealtDamage", false);
		delivered = input.getBooleanOr("Delivered", false);
		originSlot = input.getIntOr("OriginSlot", -1);
		hasStuckPos = input.getBooleanOr("HasStuckPos", false);
		stuckX = input.getIntOr("StuckX", 0);
		stuckY = input.getIntOr("StuckY", 0);
		stuckZ = input.getIntOr("StuckZ", 0);
		hasSafePos = input.getBooleanOr("HasSafePos", false);
		safeX = input.getDoubleOr("SafeX", 0.0);
		safeY = input.getDoubleOr("SafeY", 0.0);
		safeZ = input.getDoubleOr("SafeZ", 0.0);
		long most = input.getLongOr("OwnerMost", 0L);
		long least = input.getLongOr("OwnerLeast", 0L);
		ownerUuid = (most == 0L && least == 0L) ? null : new UUID(most, least);
	}

	// ------------------------------------------------------------------
	// Tick
	// ------------------------------------------------------------------

	@Override
	public void tick() {
		boolean client = level().isClientSide();

		// Sadakat ile geri dönüş: hem istemci hem sunucu aynı hareketi uygular (akıcı görünsün).
		if (isReturning()) {
			tickReturning(client);
			return;
		}

		if (client) {
			if (isStuck()) {
				baseTick(); // saplanmış balta hareket etmez (yerçekimiyle kaymasın)
			} else {
				super.tick();
			}
			return;
		}

		// Sunucu: tek-balta kaydı (chunk'tan yeniden yüklenince de kayıt yenilenir).
		if (!tracked) {
			tracked = true;
			ThrownAxeTracker.register(ownerUuid, getUUID());
			if (!hasSafePos) {
				rememberSafePosition();
			}
		}
		if (pickupDelay > 0) {
			pickupDelay--;
		}
		if (fullMessageCooldown > 0) {
			fullMessageCooldown--;
		}

		if (isStuck()) {
			baseTick();
			if (tickCount % 10 == 0) {
				checkSupport();
			}
			loyaltyTick();
			return;
		}

		// Uçuşta: güvenli konumu zaman zaman güncelle (boşluğa düşerse buraya kurtarılır).
		if (tickCount % 10 == 0 && getY() > level().getMinY() + 8) {
			rememberSafePosition();
		}
		if (!isNoGravity()) {
			setDeltaMovement(getDeltaMovement().add(0.0, -ThrownAxeConfig.EXTRA_GRAVITY, 0.0));
		}
		super.tick();
		loyaltyTick();
	}

	// ------------------------------------------------------------------
	// Sadakat (Loyalty): çarpmadan sonra bir süre bekler, sonra sahibine geri uçar
	// ------------------------------------------------------------------

	/** Baltadaki Sadakat seviyesi (yoksa 0). Bir kez hesaplanır. */
	private int loyaltyLevel() {
		if (loyaltyLevel < 0) {
			loyaltyLevel = 0;
			try {
				Holder<Enchantment> enchantment = level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(LOYALTY);
				loyaltyLevel = EnchantmentHelper.getItemEnchantmentLevel(enchantment, getItem());
			} catch (RuntimeException ignored) {
				loyaltyLevel = 0;
			}
		}
		return loyaltyLevel;
	}

	private void loyaltyTick() {
		if (loyaltyLevel() <= 0 || delivered || isRemoved()) {
			return;
		}
		if (retryCooldown > 0) {
			retryCooldown--;
			return;
		}

		if (dealtDamage) {
			// Çarptı ya da saplandı: gecikme sayacı başlar, bitince geri dön.
			if (returnCountdown < 0) {
				returnCountdown = ThrownAxeLogic.returnDelay(loyaltyLevel());
			}
			if (returnCountdown > 0) {
				returnCountdown--;
				return;
			}
			tryStartReturning();
		} else {
			// Hiçbir şeye çarpmadan çok uçtuysa ya da boşluğa düştüyse yine de geri dön.
			flightTicks++;
			boolean belowWorld = getY() < level().getMinY() + 2;
			if (ThrownAxeLogic.forceReturnInFlight(flightTicks, belowWorld)) {
				tryStartReturning();
			}
		}
	}

	private void tryStartReturning() {
		ServerPlayer owner = getOwner() instanceof ServerPlayer player ? player : null;
		boolean can = owner != null && ThrownAxeLogic.canStartReturn(
				true, owner.isAlive(), owner.isSpectator(), owner.level() == level(), distanceTo(owner));
		if (!can) {
			retryCooldown = ThrownAxeConfig.RETRY_TICKS; // olduğu yerde güvende kalır, sonra tekrar dener
			return;
		}
		startReturning();
	}

	private void startReturning() {
		dealtDamage = true; // geri dönen balta artık hiç hasar vermez
		setStuck(false);
		hasStuckPos = false;
		setReturning(true);
		setDeltaMovement(Vec3.ZERO);

		if (level() instanceof ServerLevel server) {
			int rank = SoulManager.rankOf(getItem());
			server.playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.9F, 0.8F);
			server.playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.8F, 1.4F);
			server.sendParticles(RankStyle.dust(rank), getX(), getY(), getZ(), 14, 0.3, 0.3, 0.3, 0.0);
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 10, 0.3, 0.3, 0.3, 0.25);
		}
	}

	private void stopReturning() {
		setReturning(false);
		setDeltaMovement(Vec3.ZERO);
		returnCountdown = 0;
		retryCooldown = ThrownAxeConfig.RETRY_TICKS * 2; // düşüp saplanır, sonra yeniden dener
	}

	private void tickReturning(boolean client) {
		baseTick();

		Entity ownerEntity = getOwner();
		if (ownerEntity == null) {
			if (!client) {
				stopReturning(); // sahibi çevrimdışı: olduğu yere düşer ve saplanır
			}
			return;
		}

		ServerPlayer owner = null;
		if (!client) {
			owner = ownerEntity instanceof ServerPlayer player ? player : null;
			boolean can = owner != null && ThrownAxeLogic.canStartReturn(
					true, owner.isAlive(), owner.isSpectator(), owner.level() == level(), distanceTo(owner));
			if (!can) {
				stopReturning(); // sahibi öldü, izleyici oldu, boyut değiştirdi ya da çok uzaklaştı
				return;
			}
		}

		Vec3 target = ownerEntity.getEyePosition().subtract(0.0, 0.35, 0.0);
		Vec3 delta = target.subtract(position());
		double distance = delta.length();

		if (!client && ThrownAxeLogic.shouldCatch(distance) && tryCatch(owner)) {
			return; // yakalandı, varlık kaldırıldı
		}

		Vec3 velocity = getDeltaMovement();
		double[] next = ThrownAxeLogic.steer(velocity.x, velocity.y, velocity.z, delta.x, delta.y, delta.z,
				ThrownAxeLogic.returnAcceleration(loyaltyLevel()), ThrownAxeConfig.RETURN_MAX_SPEED);
		setDeltaMovement(next[0], next[1], next[2]);
		setPos(getX() + next[0], getY() + next[1], getZ() + next[2]);
		setYRot((float) (Math.atan2(-next[0], next[2]) * (180.0 / Math.PI)));

		if (!client && level() instanceof ServerLevel server) {
			returnTrail(server, delta, distance);
		}
	}

	/** Dönüş efekti: arkasında rütbe renginde iz, kıvılcımlar ve sahibine uzanan ruh bağı ipliği. */
	private void returnTrail(ServerLevel server, Vec3 delta, double distance) {
		int rank = SoulManager.rankOf(getItem());
		server.sendParticles(RankStyle.dust(rank), getX(), getY(), getZ(), 2 + rank / 3, 0.12, 0.12, 0.12, 0.0);
		server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 1, 0.1, 0.1, 0.1, 0.0);
		if (rank >= 5 && tickCount % 2 == 0) {
			server.sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 1, 0.1, 0.1, 0.1, 0.01);
		}
		if (tickCount % 3 == 0) {
			int points = (int) Math.min(10.0, distance / 1.5);
			for (int i = 1; i <= points; i++) {
				double t = (double) i / (points + 1);
				server.sendParticles(RankStyle.dust(rank), getX() + delta.x * t, getY() + delta.y * t, getZ() + delta.z * t,
						1, 0.0, 0.0, 0.0, 0.0);
			}
		}
	}

	/**
	 * Sahibe ulaşınca envantere koyar. Yer yoksa false döner: balta sahibin yanında bekler
	 * (yer açılınca yakalanır), kaybolmaz.
	 */
	private boolean tryCatch(ServerPlayer owner) {
		int slot = ThrownAxeLogic.chooseSlot(originSlot, emptySlots(owner.getInventory()));
		if (slot < 0) {
			if (fullMessageCooldown <= 0) {
				fullMessageCooldown = ThrownAxeConfig.FULL_MESSAGE_INTERVAL_TICKS;
				owner.sendSystemMessage(Component.translatable("message.battleaxe.return.full"), true);
			}
			return false;
		}

		ItemStack stack = getItem().copy();
		if (stack.isEmpty()) {
			delivered = true;
			discard();
			return true;
		}

		delivered = true; // önce işaretle: varlık kaldırılırken ikinci kez eşya verilmesin
		try {
			owner.getInventory().setItem(slot, stack);
		} catch (RuntimeException e) {
			delivered = false;
			throw e;
		}
		// Shunpo: normal geri dönüş (Sadakat/yakalama) hakkı SİLMEZ; yalnızca baltanın artık elde olduğunu bildirir.
		com.battleaxe.shunpo.ShunpoManager.onAxeDelivered(owner.getUUID(), getUUID());

		if (level() instanceof ServerLevel server) {
			int rank = SoulManager.rankOf(stack);
			server.playSound(null, owner.getX(), owner.getY(), owner.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.8F, 2.0F);
			server.sendParticles(RankStyle.dust(rank), owner.getX(), owner.getY(0.7), owner.getZ(), 16, 0.4, 0.4, 0.4, 0.0);
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK, owner.getX(), owner.getY(0.7), owner.getZ(), 8, 0.4, 0.4, 0.4, 0.2);
			server.sendParticles(ParticleTypes.SWEEP_ATTACK, owner.getX(), owner.getY(0.7), owner.getZ(), 0, 0.0, 0.0, 0.0, 0.0);
			BerserkerEffects.sendShake(owner, 0.3F, 5); // yakalayınca hafif bir sarsıntı: ağırlığı hissedilir
		}
		discard();
		return true;
	}

	private void rememberSafePosition() {
		safeX = getX();
		safeY = getY();
		safeZ = getZ();
		hasSafePos = true;
	}

	/** Saplandığı blok kırıldıysa/kaybolduysa balta düşmeye başlar. */
	private void checkSupport() {
		if (!hasStuckPos) {
			return;
		}
		BlockPos pos = new BlockPos(stuckX, stuckY, stuckZ);
		if (level().isEmptyBlock(pos)) {
			setStuck(false);
			hasStuckPos = false;
			setDeltaMovement(Vec3.ZERO);
		}
	}

	// ------------------------------------------------------------------
	// Çarpışmalar
	// ------------------------------------------------------------------

	/** Hasar verdikten ya da saplandıktan sonra hiçbir şeye tekrar çarpmaz. */
	@Override
	protected boolean canHitEntity(Entity entity) {
		return !dealtDamage && !isStuck() && super.canHitEntity(entity);
	}

	@Override
	protected void onHitEntity(EntityHitResult hitResult) {
		super.onHitEntity(hitResult);
		if (!(level() instanceof ServerLevel server) || dealtDamage) {
			return;
		}
		dealtDamage = true; // tek seferlik hasar: bundan sonra bir daha vurmaz

		Entity target = hitResult.getEntity();
		Entity owner = getOwner();
		int rank = SoulManager.rankOf(getItem());
		float damage = ThrownAxeLogic.damage(rank);
		Vec3 motion = getDeltaMovement();

		// Hasar sahibe yazılır: ödül, XP ve öfkelendirme oyuncu vuruşuymuş gibi çalışır.
		DamageSource source = damageSources().source(DamageTypes.THROWN, owner);
		boolean hurt;
		activeHit = this;
		try {
			hurt = target.hurtServer(server, source, damage);
		} finally {
			activeHit = null;
		}

		if (hurt && owner instanceof ServerPlayer thrower) {
			com.battleaxe.evolution.EvolutionEvents.onThrowHit(thrower, target);
		}

		if (hurt && target instanceof LivingEntity living) {
			living.knockback(ThrownAxeConfig.KNOCKBACK, -motion.x, -motion.z, source, damage);
		}

		impactEffects(server, hitResult.getLocation(), 1.3F, rank);

		// Shunpo: yalnızca gerçek bir canavar isabeti bağlantı kurar (blok/boşlukta bu satıra hiç gelinmez).
		if (owner instanceof ServerPlayer thrower) {
			com.battleaxe.shunpo.ShunpoManager.onHit(thrower, this, target);
		}

		// Sek ve düş: yere inince saplanır.
		setDeltaMovement(motion.multiply(-0.01, -0.1, -0.01));
	}

	@Override
	protected void onHitBlock(BlockHitResult hitResult) {
		super.onHitBlock(hitResult);
		if (!(level() instanceof ServerLevel server) || isStuck()) {
			return;
		}

		dealtDamage = true; // saplanmış balta artık hiç hasar vermez
		setStuck(true);
		pickupDelay = ThrownAxeConfig.PICKUP_DELAY_TICKS;

		BlockPos pos = hitResult.getBlockPos();
		stuckX = pos.getX();
		stuckY = pos.getY();
		stuckZ = pos.getZ();
		hasStuckPos = true;
		setDeltaMovement(Vec3.ZERO);

		impactEffects(server, hitResult.getLocation(), 1.7F, SoulManager.rankOf(getItem()));
	}

	private void impactEffects(ServerLevel server, Vec3 at, float pitch, int rank) {
		server.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.0F, pitch);
		server.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 8, 0.15, 0.15, 0.15, 0.2);
		server.sendParticles(RankStyle.dust(rank), at.x, at.y, at.z, 6, 0.2, 0.2, 0.2, 0.0);
	}

	// ------------------------------------------------------------------
	// Geri alma
	// ------------------------------------------------------------------

	@Override
	public void playerTouch(Player player) {
		if (level().isClientSide() || !isStuck() || pickupDelay > 0 || delivered || isRemoved()) {
			return;
		}
		if (player instanceof ServerPlayer serverPlayer) {
			tryPickup(serverPlayer);
		}
	}

	private void tryPickup(ServerPlayer player) {
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}

		ItemStack stack = getItem().copy();
		if (stack.isEmpty()) {
			// Beklenmeyen: içi boş varlık (ör. komutla çağrılmış). Eşya yok, sadece temizle.
			delivered = true;
			discard();
			return;
		}

		int slot = ThrownAxeLogic.chooseSlot(originSlot, emptySlots(player.getInventory()));
		if (slot < 0) {
			// Envanter dolu: balta yerde saplı KALIR (kaybolmaz), oyuncu uyarılır.
			if (fullMessageCooldown <= 0) {
				fullMessageCooldown = ThrownAxeConfig.FULL_MESSAGE_INTERVAL_TICKS;
				player.sendSystemMessage(Component.translatable("message.battleaxe.pickup.full"), true);
			}
			return;
		}

		// Önce "teslim edildi" işaretlenir ki varlık yok olurken ikinci kez eşya verilmesin.
		delivered = true;
		try {
			player.getInventory().setItem(slot, stack);
		} catch (RuntimeException e) {
			delivered = false;
			throw e;
		}

		player.take(this, 1);
		level().playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.6F, 2.0F);
		discard();
	}

	private static boolean[] emptySlots(Inventory inventory) {
		boolean[] empty = new boolean[ThrownAxeLogic.MAIN_SLOTS];
		for (int i = 0; i < empty.length; i++) {
			empty[i] = inventory.getItem(i).isEmpty();
		}
		return empty;
	}

	// ------------------------------------------------------------------
	// Kaldırılma: eşya hiçbir durumda kaybolmaz ya da çoğalmaz
	// ------------------------------------------------------------------

	@Override
	public void remove(Entity.RemovalReason reason) {
		if (!level().isClientSide()) {
			boolean destroyed = reason == Entity.RemovalReason.KILLED || reason == Entity.RemovalReason.DISCARDED;

			// Yok ediliyorsa ve henüz teslim edilmediyse eşyayı kurtar (önce işaretle: tekrar girişe karşı).
			if (destroyed && !delivered) {
				delivered = true;
				rescue();
			}

			// Kayıt: yok edilince ya da boyut değişince temizlenir; chunk boşaltmada korunur.
			if (destroyed || reason == Entity.RemovalReason.CHANGED_DIMENSION) {
				ThrownAxeTracker.release(ownerUuid, getUUID());
			}
		}
		super.remove(reason);
	}

	/** Eşyayı sahibine verir; olmazsa dünyaya (güvenli bir noktaya, süresiz) bırakır. */
	private void rescue() {
		if (!(level() instanceof ServerLevel server)) {
			return;
		}
		ItemStack stack = getItem().copy();
		if (stack.isEmpty()) {
			return;
		}

		ServerPlayer owner = getOwner() instanceof ServerPlayer player && player.isAlive() ? player : null;
		int slot = owner != null ? ThrownAxeLogic.chooseSlot(originSlot, emptySlots(owner.getInventory())) : -1;

		ThrownAxeLogic.Rescue action = ThrownAxeLogic.rescue(false, true, owner != null, slot >= 0);
		if (action == ThrownAxeLogic.Rescue.GIVE_TO_OWNER) {
			owner.getInventory().setItem(slot, stack);
			owner.sendSystemMessage(Component.translatable("message.battleaxe.rescued"), true);
			return;
		}

		// Dünyaya bırak: önce bulunduğu yer (boşluktaysa son güvenli konum), olmazsa güvenli konum, olmazsa sahibin yanı.
		double x = getX();
		double y = getY();
		double z = getZ();
		if (ThrownAxeLogic.useSafePosition(y, server.getMinY(), hasSafePos)) {
			x = safeX;
			y = safeY;
			z = safeZ;
		}
		if (dropInWorld(server, x, y, z, stack)) {
			return;
		}
		if (hasSafePos && dropInWorld(server, safeX, safeY, safeZ, stack)) {
			return;
		}
		if (getOwner() instanceof ServerPlayer player && dropInWorld(server, player.getX(), player.getY(), player.getZ(), stack)) {
			return;
		}

		// Son çare: kaydı bırak ki yönetici eşyayı geri verebilsin.
		BattleAxeMod.LOGGER.error("Fırlatılmış Savaş Baltası kurtarılamadı! Konum: {} {} {}; eşya: {}", x, y, z, stack);
	}

	private static boolean dropInWorld(ServerLevel server, double x, double y, double z, ItemStack stack) {
		ItemEntity drop = new ItemEntity(server, x, y, z, stack.copy());
		drop.setUnlimitedLifetime(); // süre dolunca silinmesin
		drop.setDefaultPickUpDelay();
		return server.addFreshEntity(drop);
	}
}
