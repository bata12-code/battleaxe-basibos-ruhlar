package com.battleaxe.thrown;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import com.battleaxe.BattleAxeMod;

/** Modun varlık tipleri. */
public final class ModEntityTypes {
	private ModEntityTypes() {
	}

	public static final ResourceKey<EntityType<?>> THROWN_BATTLE_AXE_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, BattleAxeMod.id("thrown_battle_axe"));

	public static final EntityType<ThrownBattleAxe> THROWN_BATTLE_AXE = register(
			THROWN_BATTLE_AXE_KEY,
			EntityType.Builder.<ThrownBattleAxe>of(ThrownBattleAxe::new, MobCategory.MISC)
					.sized(0.5F, 0.5F)          // çarpışma kutusu
					.clientTrackingRange(8)     // istemcilerin görebildiği uzaklık (chunk)
					.updateInterval(5)          // konum güncelleme sıklığı (tick)
					.fireImmune()               // lavda/ateşte yanmaz
	);

	private static <T extends Entity> EntityType<T> register(ResourceKey<EntityType<?>> key, EntityType.Builder<T> builder) {
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	/** Sınıfın yüklenip varlık tipinin kaydedilmesini sağlar. */
	public static void initialize() {
	}
}
