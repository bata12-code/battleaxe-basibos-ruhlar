package com.battleaxe.thrown;

/** "Ağır Balta Fırlatma" dengeleme ayarları. Süreler tick cinsindendir (20 tick = 1 sn). */
public final class ThrownAxeConfig {
	private ThrownAxeConfig() {
	}

	/** Fırlatma hızı. Mızrak (trident) 2.5, kartopu 1.5; balta ağır olduğu için daha yavaş. */
	public static final float THROW_SPEED = 1.7F;

	/** Vanilla yerçekimine eklenen fazladan düşüş (ağırlık hissi). 0 = hiç ek yok. */
	public static final double EXTRA_GRAVITY = 0.02;

	/** Çarptığı canlıya TEK SEFER verdiği hasar (rütbe bonusu üstüne eklenir). */
	public static final float DAMAGE = 14.0F;

	/** Çarptığı canlıya uygulanan geri itme. */
	public static final double KNOCKBACK = 0.6;

	/** Fırlatmalar arası bekleme (başka bir balta için). */
	public static final int THROW_COOLDOWN_TICKS = 20;

	/** Saplandıktan sonra alınabilir hale gelene kadar geçen süre (anında geri alınmasın diye). */
	public static final int PICKUP_DELAY_TICKS = 10;

	/** "Envanterin dolu" uyarısı arasındaki süre. */
	public static final int FULL_MESSAGE_INTERVAL_TICKS = 40;

	// ------------------------------------------------------------------
	// Sadakat (Loyalty): fırlatılan balta bir süre sonra sahibine geri döner.
	// Dizilerde indeks = büyü seviyesi - 1 (I, II, III). Seviye fazlaysa sonuncu değer kullanılır.
	// ------------------------------------------------------------------

	/** Çarpma/saplanmadan sonra geri dönüşün başlamasına kadar geçen süre. Seviye arttıkça kısalır. */
	public static final int[] RETURN_DELAY_TICKS = {30, 20, 10};

	/** Geri dönerken sahibine doğru ivme (blok/tick^2). Seviye arttıkça hızlanır. */
	public static final double[] RETURN_ACCELERATION = {0.06, 0.09, 0.13};

	/** Geri dönüş hız üst sınırı (blok/tick). */
	public static final double RETURN_MAX_SPEED = 2.6;

	/** Hiçbir şeye çarpmadan bu kadar uçarsa (örn. uçsuz bucaksız boşluk) yine de geri dönmeye başlar. */
	public static final int MAX_FLIGHT_TICKS_BEFORE_RETURN = 60;

	/** Sahip bu mesafeden uzaktaysa geri dönmez (yüklenmemiş bölgelere dalmasın). Blok cinsinden. */
	public static final double MAX_RETURN_DISTANCE = 64.0;

	/** Sahibe bu kadar yaklaşınca balta yakalanır (envantere girer). */
	public static final double CATCH_DISTANCE = 1.6;

	/** Geri dönüş koşulu sağlanamazsa tekrar denemeden önce beklenen süre. */
	public static final int RETRY_TICKS = 20;
}
