package com.battleaxe.thrown;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.item.ModItems;

/**
 * Ağır Balta Fırlatma: istemcinin tuş isteğini alır, SUNUCUDA doğrular ve baltayı fırlatır.
 * Eşya, ele ait yuvadan çıkarılıp varlığın içine TAŞINIR (kopyalanmaz); fırlatma başarısız olursa
 * eşya olduğu yere geri konur.
 */
public final class ThrownAxeManager {
	private ThrownAxeManager() {
	}

	public static void initialize() {
		ModEntityTypes.initialize();

		PayloadTypeRegistry.serverboundPlay().register(ThrowAxePayload.TYPE, ThrowAxePayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(ThrowAxePayload.TYPE,
				(payload, context) -> tryThrow(context.player()));

		// Sunucu durunca bellekteki kayıt silinir (balta dünyada kaydedilidir, kayıt ilk tick'te yenilenir).
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> ThrownAxeTracker.clear());
	}

	public static void tryThrow(ServerPlayer player) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}

		// Shunpo: balta bir canavara isabet ettiyse ikinci tuş basışı ışınlanmadır; normal fırlatma çalışmaz.
		if (com.battleaxe.shunpo.ShunpoManager.tryActivate(player)) {
			return;
		}

		ItemStack held = player.getMainHandItem();
		boolean holdingAxe = held.is(ModItems.BATTLE_AXE);

		ThrownAxeLogic.ThrowCheck check = ThrownAxeLogic.checkThrow(
				player.isAlive(),
				player.isSpectator(),
				holdingAxe,
				player.isUsingItem(),
				holdingAxe && player.getCooldowns().isOnCooldown(held),
				ThrownAxeTracker.hasActive(level.getServer(), player.getUUID())
		);

		if (check == ThrownAxeLogic.ThrowCheck.ALREADY_THROWN) {
			player.sendSystemMessage(Component.translatable("message.battleaxe.throw.already"), true);
		}
		if (check != ThrownAxeLogic.ThrowCheck.OK) {
			return;
		}

		// 1) Eşyayı elden al (taşınan eşya budur; ayrıca kopya yapılmaz).
		ItemStack carried = held.copy();
		int slot = player.getInventory().getSelectedSlot();
		player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);

		// 2) Varlığı oluştur ve dünyaya ekle; herhangi bir sorunda eşya ele geri konur.
		boolean added = false;
		ThrownBattleAxe axe = null;
		try {
			axe = new ThrownBattleAxe(level, player, carried);
			axe.setOriginSlot(slot);
			if (com.battleaxe.shunpo.Shunpo.has(carried, level)) {
				axe.armShunpo(player.position()); // fırlatma anındaki konum
			}
			axe.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, ThrownAxeConfig.THROW_SPEED, 0.0F);
			added = level.addFreshEntity(axe);
		} finally {
			if (!added) {
				player.setItemInHand(InteractionHand.MAIN_HAND, carried);
			}
		}
		if (!added) {
			return;
		}

		ThrownAxeTracker.register(player.getUUID(), axe.getUUID());
		com.battleaxe.shunpo.ShunpoManager.onThrow(player, axe.isShunpoArmed()); // eski Shunpo bağlantısı geçersiz
		player.getCooldowns().addCooldown(carried, ThrownAxeConfig.THROW_COOLDOWN_TICKS);
		player.swing(InteractionHand.MAIN_HAND, true);
		level.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.6F);
		com.battleaxe.nexus.NexusWhispers.onThrow(level, player);
		com.battleaxe.evolution.EvolutionEvents.onThrow(player);
	}
}
