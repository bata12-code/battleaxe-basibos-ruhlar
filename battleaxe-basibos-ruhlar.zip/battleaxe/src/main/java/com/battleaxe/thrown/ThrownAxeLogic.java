package com.battleaxe.thrown;

import com.battleaxe.soul.SoulLogic;

/**
 * Fırlatma mekaniğinin saf kararları (Minecraft'tan bağımsız, test edilebilir).
 * Eşyanın kaybolmaması ve çoğalmaması için verilen tüm kararlar burada toplanmıştır.
 */
public final class ThrownAxeLogic {
	private ThrownAxeLogic() {
	}

	/** Oyuncu envanterinin ana bölümündeki yuva sayısı (0-8 hotbar, 9-35 çanta). */
	public static final int MAIN_SLOTS = 36;

	public enum ThrowCheck {
		OK,
		NOT_ALLOWED,
		NOT_HOLDING_AXE,
		BUSY_USING_ITEM,
		ON_COOLDOWN,
		ALREADY_THROWN
	}

	/** Bir fırlatma isteğini sırayla kontrol eder; ilk başarısız koşulu döndürür. */
	public static ThrowCheck checkThrow(
			boolean alive, boolean spectator, boolean holdingAxeInMainHand,
			boolean usingItem, boolean onCooldown, boolean alreadyThrown
	) {
		if (!alive || spectator) {
			return ThrowCheck.NOT_ALLOWED;
		}
		if (!holdingAxeInMainHand) {
			return ThrowCheck.NOT_HOLDING_AXE;
		}
		if (usingItem) {
			return ThrowCheck.BUSY_USING_ITEM;
		}
		if (alreadyThrown) {
			return ThrowCheck.ALREADY_THROWN;
		}
		if (onCooldown) {
			return ThrowCheck.ON_COOLDOWN;
		}
		return ThrowCheck.OK;
	}

	/**
	 * Baltanın envantere hangi yuvaya konacağını seçer. Önce fırlatıldığı yuva (boşsa), sonra ilk boş
	 * yuva (hotbar'dan başlayarak). Boş yer yoksa -1 (balta yerde kalır, KAYBOLMAZ).
	 * Bilerek vanilla Inventory.add kullanılmaz: yaratıcı modda hasarlı eşyayı eklemeden "başarılı"
	 * sayabilir; bu da baltanın yok olmasına yol açardı.
	 */
	public static int chooseSlot(int originSlot, boolean[] empty) {
		if (originSlot >= 0 && originSlot < empty.length && empty[originSlot]) {
			return originSlot;
		}
		for (int i = 0; i < empty.length; i++) {
			if (empty[i]) {
				return i;
			}
		}
		return -1;
	}

	public enum Rescue {
		GIVE_TO_OWNER,
		DROP_IN_WORLD,
		NOTHING
	}

	/**
	 * Fırlatılmış balta yok edilirken (/kill, boşluğa düşme, başka mod...) eşyanın akıbeti.
	 * Zaten teslim edilmişse hiçbir şey yapılmaz (çoğalmayı önler); aksi halde sahibine ya da
	 * dünyaya bırakılır (kaybolmayı önler).
	 */
	public static Rescue rescue(boolean alreadyDelivered, boolean destroyed, boolean ownerOnlineAndAlive, boolean ownerHasSpace) {
		if (alreadyDelivered || !destroyed) {
			return Rescue.NOTHING;
		}
		return (ownerOnlineAndAlive && ownerHasSpace) ? Rescue.GIVE_TO_OWNER : Rescue.DROP_IN_WORLD;
	}

	/** Balta dünya sınırının altındaysa (boşluk) bırakma noktası olarak son güvenli konum kullanılır. */
	public static boolean useSafePosition(double currentY, double minY, boolean hasSafePosition) {
		return hasSafePosition && currentY < minY + 2.0;
	}

	/** Fırlatılan baltanın hasarı: temel hasar + rütbe bonusu. */
	public static float damage(int rank) {
		return (float) (ThrownAxeConfig.DAMAGE + SoulLogic.damageBonus(rank));
	}

	// ------------------------------------------------------------------
	// Sadakat (Loyalty)
	// ------------------------------------------------------------------

	private static int levelIndex(int level, int length) {
		return Math.max(0, Math.min(length - 1, level - 1));
	}

	/** Çarpmadan sonra geri dönüşün başlamasına kadar süre (tick). Sadakat yoksa -1. */
	public static int returnDelay(int loyaltyLevel) {
		if (loyaltyLevel <= 0) {
			return -1;
		}
		return ThrownAxeConfig.RETURN_DELAY_TICKS[levelIndex(loyaltyLevel, ThrownAxeConfig.RETURN_DELAY_TICKS.length)];
	}

	public static double returnAcceleration(int loyaltyLevel) {
		return ThrownAxeConfig.RETURN_ACCELERATION[levelIndex(loyaltyLevel, ThrownAxeConfig.RETURN_ACCELERATION.length)];
	}

	/**
	 * Balta geri dönmeye başlayabilir mi? Sahip çevrimiçi, yaşıyor, izleyici değil, aynı boyutta ve
	 * yeterince yakın olmalı; aksi halde balta olduğu yerde (güvenle) kalır.
	 */
	public static boolean canStartReturn(boolean ownerOnline, boolean ownerAlive, boolean ownerSpectator,
			boolean sameDimension, double distance) {
		return ownerOnline && ownerAlive && !ownerSpectator && sameDimension
				&& distance <= ThrownAxeConfig.MAX_RETURN_DISTANCE;
	}

	/** Uçuşta çarpmadan geçen süre dolduysa ya da boşluğa düştüyse geri dönüş zorlanır. */
	public static boolean forceReturnInFlight(int flightTicks, boolean belowWorld) {
		return belowWorld || flightTicks > ThrownAxeConfig.MAX_FLIGHT_TICKS_BEFORE_RETURN;
	}

	public static boolean shouldCatch(double distance) {
		return distance <= ThrownAxeConfig.CATCH_DISTANCE;
	}

	/**
	 * Geri dönerken bir sonraki hız: eski hız biraz sönümlenir, hedefe doğru ivme eklenir, üst sınır uygulanır.
	 * (dx, dy, dz): baltadan hedefe vektör. Hedef üstündeyse (uzunluk 0) ivme eklenmez, NaN üretmez.
	 */
	public static double[] steer(double vx, double vy, double vz, double dx, double dy, double dz,
			double acceleration, double maxSpeed) {
		double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
		double nx = vx * 0.9;
		double ny = vy * 0.9;
		double nz = vz * 0.9;
		if (length > 1.0E-6) {
			nx += dx / length * acceleration;
			ny += dy / length * acceleration;
			nz += dz / length * acceleration;
		}
		double speed = Math.sqrt(nx * nx + ny * ny + nz * nz);
		if (speed > maxSpeed) {
			double scale = maxSpeed / speed;
			nx *= scale;
			ny *= scale;
			nz *= scale;
		}
		return new double[] {nx, ny, nz};
	}
}
