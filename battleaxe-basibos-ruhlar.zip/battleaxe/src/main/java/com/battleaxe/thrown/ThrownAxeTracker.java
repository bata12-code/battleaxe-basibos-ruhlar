package com.battleaxe.thrown;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

/**
 * Oyuncu başına "fırlatılmış balta" kaydı: aynı anda yalnızca bir fırlatılmış balta yönetilir.
 * Kayıt, balta yok edilince (alındı, /kill...) temizlenir; chunk boşaltmada KORUNUR (balta kayıtlıdır).
 * Sunucu durunca bellekten silinir (balta yine dünyada kaydedilidir, kayıt ilk tick'te yenilenir).
 */
public final class ThrownAxeTracker {
	private ThrownAxeTracker() {
	}

	/** Sahip oyuncu UUID'si -> fırlatılmış balta varlığının UUID'si. Sadece sunucu iş parçacığı kullanır. */
	private static final Map<UUID, UUID> ACTIVE = new HashMap<>();

	public static void register(UUID owner, UUID axe) {
		if (owner != null) {
			ACTIVE.put(owner, axe);
		}
	}

	/** Bu balta kayıtlıysa kaydı siler (başkasının kaydını silmez). */
	public static void release(UUID owner, UUID axe) {
		if (owner != null && axe.equals(ACTIVE.get(owner))) {
			ACTIVE.remove(owner);
		}
	}

	public static void clear() {
		ACTIVE.clear();
	}

	/**
	 * Oyuncunun halen fırlatılmış (uçuşta, saplanmış ya da yüklenmemiş bölgede) bir baltası var mı?
	 * Kayıt var ve balta yüklü dünyalarda bulunamıyorsa, yüklenmemiş bir bölgede olduğu varsayılır.
	 */
	public static boolean hasActive(MinecraftServer server, UUID owner) {
		UUID axeId = ACTIVE.get(owner);
		if (axeId == null) {
			return false;
		}
		for (ServerLevel level : server.getAllLevels()) {
			Entity entity = level.getEntity(axeId);
			if (entity instanceof ThrownBattleAxe && !entity.isRemoved()) {
				return true;
			}
		}
		return true; // yüklü dünyalarda yok ama kayıt var: yüklenmemiş bölgede, hâlâ ortalıkta
	}
}
