package com.battleaxe.soul;

/**
 * Fısıltı ve alıntı tablosu. Metinlerin kendisi dil dosyalarındadır
 * (assets/battleaxe/lang, "item.battleaxe.battle_axe.whisper.msg.N" ve "...quote.N.text/.source");
 * burada yalnızca hangi mesajın hangi rütbeden itibaren çıkabileceği ve oyuncu adı içerip içermediği yazar.
 * Bu dosya, metinlerle birlikte bir betikten üretilmiştir; mesaj eklerken dil dosyasıyla BİRLİKTE güncelle.
 */
final class WhisperData {
	private WhisperData() {
	}

	/** N. fısıltının (1'den başlar) çıkabileceği en düşük rütbe. */
	static final int[] WHISPER_MIN_RANK = {0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 8, 9, 9};

	/** N. fısıltı oyuncunun adını (%s) içeriyor mu? */
	static final boolean[] WHISPER_PERSONAL = {false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, true, false, true, false, true};

	/** N. alıntının (1'den başlar) çıkabileceği en düşük rütbe. */
	static final int[] QUOTE_MIN_RANK = {0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 6, 7, 7, 8, 8, 9, 9};
}
