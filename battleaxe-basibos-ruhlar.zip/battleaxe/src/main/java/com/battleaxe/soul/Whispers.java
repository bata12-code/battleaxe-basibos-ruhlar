package com.battleaxe.soul;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import com.battleaxe.BattleAxeMod;

/**
 * Balta seni tanıdıkça seninle konuşur: ekranın altına arada bir kısa bir fısıltı ya da
 * şiir/mit alıntısı gelir. Mesajlar rütbeyle derinleşir ve yüksek rütbelerde adını bilir.
 * Tüm metinler dil dosyalarındadır.
 */
public final class Whispers {
	private Whispers() {
	}

	private static final String PREFIX = "item.battleaxe.battle_axe.";
	/** Alıntıları fısıltılardan ayırmak için dahili kodlama. */
	private static final int QUOTE_BASE = 1000;

	private static final AttachmentType<Long> LAST_TIME = AttachmentRegistry.create(BattleAxeMod.id("whisper_last_time"));
	private static final AttachmentType<Integer> LAST_PICK = AttachmentRegistry.create(BattleAxeMod.id("whisper_last_pick"));

	/** Sınıfı (ve ek kayıtlarını) mod başlangıcında yükler. */
	public static void initialize() {
	}

	/** Baltayla başarılı bir vuruş yapıldığında çağrılır. */
	public static void onHit(ServerLevel level, ServerPlayer player, int rank) {
		maybe(level, player, rank, SoulConfig.WHISPER_CHANCE_ON_HIT);
	}

	/** Berserker başladığında çağrılır. */
	public static void onBerserk(ServerLevel level, ServerPlayer player, int rank) {
		maybe(level, player, rank, SoulConfig.WHISPER_CHANCE_ON_BERSERK);
	}

	private static void maybe(ServerLevel level, ServerPlayer player, int rank, double chance) {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextDouble() >= chance) {
			return;
		}

		long now = level.getGameTime();
		Long last = player.getAttached(LAST_TIME);
		if (last != null && now - last < SoulConfig.WHISPER_COOLDOWN_TICKS) {
			return;
		}

		boolean quote = random.nextDouble() < SoulConfig.QUOTE_SHARE;
		int pick = choose(random, rank, quote, player.getAttachedOrElse(LAST_PICK, -1));
		if (pick < 0) {
			return;
		}

		player.setAttached(LAST_TIME, now);
		player.setAttached(LAST_PICK, pick);

		player.sendSystemMessage(build(pick, rank, player), true);
		level.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.2F, 0.5F);
	}

	/** Rütbeye uygun mesajlardan, bir öncekini tekrarlamadan rastgele birini seçer. */
	private static int choose(ThreadLocalRandom random, int rank, boolean quote, int lastPick) {
		List<Integer> eligible = new ArrayList<>();
		int[] minRanks = quote ? WhisperData.QUOTE_MIN_RANK : WhisperData.WHISPER_MIN_RANK;
		for (int i = 0; i < minRanks.length; i++) {
			int code = quote ? QUOTE_BASE + i : i;
			if (minRanks[i] <= rank && code != lastPick) {
				eligible.add(code);
			}
		}
		return eligible.isEmpty() ? -1 : eligible.get(random.nextInt(eligible.size()));
	}

	private static Component build(int pick, int rank, ServerPlayer player) {
		if (pick >= QUOTE_BASE) {
			int number = pick - QUOTE_BASE + 1;
			return Component.translatable(PREFIX + "quote." + number + ".text")
					.withStyle(ChatFormatting.GOLD).withStyle(ChatFormatting.ITALIC)
					.append(Component.literal("  \u2014  ").withStyle(ChatFormatting.DARK_GRAY))
					.append(Component.translatable(PREFIX + "quote." + number + ".source").withStyle(ChatFormatting.GRAY));
		}

		int number = pick + 1;
		String key = PREFIX + "whisper.msg." + number;
		MutableComponent text = WhisperData.WHISPER_PERSONAL[pick]
				? Component.translatable(key, player.getName())
				: Component.translatable(key);
		return text.withStyle(SoulText.rankColor(rank)).withStyle(ChatFormatting.ITALIC);
	}
}
