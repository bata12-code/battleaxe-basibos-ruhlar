package com.battleaxe.soul;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.item.ModItems;

/**
 * Rütbe başına küçük güç artışı: ana eldeki Savaş Baltası'nın rütbesine göre oyuncunun saldırı
 * hasarı ve saldırı hızı biraz artar. Berserker ile aynı güvenli yöntem: sabit kimlikli, kayda
 * yazılmayan geçici modifier; değer değişirse eskisi kaldırılıp yenisi eklenir (birikme yok).
 */
public final class RankBonuses {
	private RankBonuses() {
	}

	private static final Identifier DAMAGE_ID = BattleAxeMod.id("rank_damage");
	private static final Identifier SPEED_ID = BattleAxeMod.id("rank_attack_speed");

	/** Oyuncunun ana eldeki balta rütbesine göre bonusları uygular (balta yoksa kaldırır). */
	public static void sync(ServerPlayer player) {
		ItemStack held = player.getMainHandItem();
		int rank = held.is(ModItems.BATTLE_AXE) ? SoulManager.rankOf(held) : 0;

		set(player.getAttribute(Attributes.ATTACK_DAMAGE), DAMAGE_ID,
				SoulLogic.damageBonus(rank), AttributeModifier.Operation.ADD_VALUE);
		set(player.getAttribute(Attributes.ATTACK_SPEED), SPEED_ID,
				SoulLogic.attackSpeedBonus(rank), AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
	}

	private static void set(AttributeInstance attribute, Identifier id, double amount, AttributeModifier.Operation operation) {
		if (attribute == null) {
			return;
		}

		AttributeModifier existing = attribute.getModifier(id);
		if (amount <= 0.0) {
			if (existing != null) {
				attribute.removeModifier(id);
			}
			return;
		}

		if (existing != null) {
			if (Math.abs(existing.amount() - amount) < 1.0E-9) {
				return;
			}
			attribute.removeModifier(id);
		}
		attribute.addTransientModifier(new AttributeModifier(id, amount, operation));
	}
}
