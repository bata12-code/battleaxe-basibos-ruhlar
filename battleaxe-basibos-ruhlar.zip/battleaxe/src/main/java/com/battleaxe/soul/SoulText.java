package com.battleaxe.soul;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

/** Rütbe adlarının ve renklerinin metinleri. */
public final class SoulText {
	private SoulText() {
	}

	/** Rütbe renkleri, dokulardaki vurgu renkleriyle uyumludur. */
	private static final ChatFormatting[] RANK_COLORS = {
			ChatFormatting.GRAY,         // 0 Uykuda
			ChatFormatting.AQUA,         // 1 Uyanan
			ChatFormatting.YELLOW,       // 2 Susamış
			ChatFormatting.RED,          // 3 Kanlı
			ChatFormatting.GOLD,         // 4 Gazaplı
			ChatFormatting.LIGHT_PURPLE, // 5 Yıkıcı
			ChatFormatting.DARK_RED,     // 6 Kıyamet Habercisi
			ChatFormatting.BLUE,         // 7 Ölümsüz
			ChatFormatting.GOLD,         // 8 Efsanevi
			ChatFormatting.WHITE         // 9 Ezeli
	};

	private static int clamp(int rank) {
		return Math.max(0, Math.min(SoulLogic.MAX_RANK, rank));
	}

	public static ChatFormatting rankColor(int rank) {
		return RANK_COLORS[clamp(rank)];
	}

	public static Component rankName(int rank) {
		int safe = clamp(rank);
		Component name = Component.translatable("item.battleaxe.battle_axe.rank." + safe).withStyle(RANK_COLORS[safe]);
		if (safe >= 8) {
			name = Component.translatable("item.battleaxe.battle_axe.rank." + safe)
					.withStyle(RANK_COLORS[safe]).withStyle(ChatFormatting.BOLD);
		}
		return name;
	}
}
