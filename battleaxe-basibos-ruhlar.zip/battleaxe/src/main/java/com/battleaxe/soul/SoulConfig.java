package com.battleaxe.soul;

/**
 * Ruh Bağı sisteminin dengeleme ayarları. Rütbe eşiklerini, rütbe başına güç artışını ve
 * baltanın sana "konuşma" sıklığını buradan değiştirebilirsin.
 */
public final class SoulConfig {
	private SoulConfig() {
	}

	// ------------------------------------------------------------------
	// Rütbeler: 0 Uykuda, 1 Uyanan, 2 Susamış, 3 Kanlı, 4 Gazaplı, 5 Yıkıcı,
	//           6 Kıyamet Habercisi, 7 Ölümsüz, 8 Efsanevi, 9 Ezeli
	// ------------------------------------------------------------------

	/**
	 * Her rütbenin başladığı toplam ruh sayısı. Bir zombi öldürmek 1 ruh verir (bkz. aşağısı), yani
	 * son rütbe yüzlerce saatlik bir yolculuktur. Dizi artan sırada olmalı ve 10 eleman içermelidir
	 * (rütbe adları, dokular ve modeller 10 rütbe için hazırlanmıştır).
	 */
	public static final int[] RANK_THRESHOLDS = {0, 50, 200, 600, 1500, 3000, 6000, 10000, 16000, 25000};

	// ------------------------------------------------------------------
	// Ruh değeri: sadece düşmanlar (canavarlar) ve oyuncular ruh verir; uysal hayvanlar vermez.
	// ------------------------------------------------------------------

	/** Canavar başına ruh = maksimum can / bu değer (en az 1). Zombi (20 can) = 1, Wither (300 can) = 15. */
	public static final double HEALTH_PER_SOUL = 20.0;

	/** Tek bir öldürmeden en fazla kaç ruh alınabilir. */
	public static final int MAX_SOULS_PER_KILL = 25;

	/** Bir oyuncuyu öldürmenin verdiği ruh. */
	public static final int PLAYER_KILL_SOULS = 5;

	// ------------------------------------------------------------------
	// Rütbe başına güç artışı ("biraz güçlenir"). Sadece balta ana eldeyken geçerlidir.
	// Rütbe 9'da: +4.5 hasar (16 -> 20.5), +%18 saldırı hızı, +%27 Yar Geç hasarı.
	// ------------------------------------------------------------------

	public static final double DAMAGE_BONUS_PER_RANK = 0.5;
	public static final double ATTACK_SPEED_BONUS_PER_RANK = 0.02;
	public static final double CLEAVE_DAMAGE_BONUS_PER_RANK = 0.03;
	/** Berserker'daki görsel yıldırım olasılığına rütbe başına eklenen değer (0.01 = %1). */
	public static final double LIGHTNING_CHANCE_BONUS_PER_RANK = 0.01;

	// ------------------------------------------------------------------
	// Efektler
	// ------------------------------------------------------------------

	/** Parçacık sayılarının rütbe başına artışı (1.0 + rütbe x bu değer). Rütbe 9'da 2.35 kat. */
	public static final double EFFECT_SCALE_PER_RANK = 0.15;

	// ------------------------------------------------------------------
	// Balta seninle "konuşur": ekran altına arada gelen fısıltılar ve alıntılar
	// ------------------------------------------------------------------

	/** İki mesaj arasındaki en kısa süre (tick). 800 = 40 sn. */
	public static final int WHISPER_COOLDOWN_TICKS = 800;

	/** Başarılı her balta vuruşunda mesaj gelme olasılığı. */
	public static final double WHISPER_CHANCE_ON_HIT = 0.03;

	/** Berserker başladığında mesaj gelme olasılığı. */
	public static final double WHISPER_CHANCE_ON_BERSERK = 0.5;

	/** Gelen mesajın şiir/mit alıntısı olma olasılığı (kalanı baltanın kendi sözü). */
	public static final double QUOTE_SHARE = 0.45;
}
