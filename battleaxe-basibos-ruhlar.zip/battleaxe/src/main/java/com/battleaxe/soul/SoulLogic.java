package com.battleaxe.soul;

/**
 * "Ruh Bağı" mantığı (saf, Minecraft'tan bağımsız): rütbe, ruh değeri, rütbe bonusları.
 * Rütbe bonusları küçüktür ("biraz güçlenir"); asıl yenilik görünüm ve havadır.
 */
public final class SoulLogic {
	private SoulLogic() {
	}

	public static final int MAX_RANK = SoulConfig.RANK_THRESHOLDS.length - 1;

	public static int rank(int souls) {
		int rank = 0;
		for (int i = 0; i < SoulConfig.RANK_THRESHOLDS.length; i++) {
			if (souls >= SoulConfig.RANK_THRESHOLDS[i]) {
				rank = i;
			}
		}
		return rank;
	}

	/** Bir sonraki rütbenin eşiği; son rütbedeyse -1. */
	public static int nextThreshold(int souls) {
		int rank = rank(souls);
		return rank >= MAX_RANK ? -1 : SoulConfig.RANK_THRESHOLDS[rank + 1];
	}

	/** Bu öldürmeyle rütbe atlandı mı? */
	public static boolean isRankUp(int before, int after) {
		return rank(after) > rank(before);
	}

	/**
	 * Bir öldürmenin verdiği ruh. Oyuncu: sabit; canavar: maksimum cana göre (en az 1, en çok sınır);
	 * diğer canlılar (köylü, inek, domuz...): 0.
	 */
	public static int soulValue(boolean isMonster, boolean isPlayer, double maxHealth) {
		if (isPlayer) {
			return SoulConfig.PLAYER_KILL_SOULS;
		}
		if (!isMonster) {
			return 0;
		}
		int value = (int) Math.round(maxHealth / SoulConfig.HEALTH_PER_SOUL);
		return Math.max(1, Math.min(SoulConfig.MAX_SOULS_PER_KILL, value));
	}

	/** Taşmaya karşı güvenli toplama. */
	public static int addSouls(int current, int add) {
		long sum = (long) current + add;
		return sum >= Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) sum;
	}

	private static int clampRank(int rank) {
		return Math.max(0, Math.min(MAX_RANK, rank));
	}

	/** Rütbeye göre ek saldırı hasarı (düz değer). */
	public static double damageBonus(int rank) {
		return clampRank(rank) * SoulConfig.DAMAGE_BONUS_PER_RANK;
	}

	/** Rütbeye göre saldırı hızı artışı (0.1 = %10 daha hızlı). */
	public static double attackSpeedBonus(int rank) {
		return clampRank(rank) * SoulConfig.ATTACK_SPEED_BONUS_PER_RANK;
	}

	/** Yar Geç hasar çarpanı (1.0 = değişmez). */
	public static double cleaveMultiplier(int rank) {
		return 1.0 + clampRank(rank) * SoulConfig.CLEAVE_DAMAGE_BONUS_PER_RANK;
	}

	public static double lightningChanceBonus(int rank) {
		return clampRank(rank) * SoulConfig.LIGHTNING_CHANCE_BONUS_PER_RANK;
	}

	/** Parçacık yoğunluğu çarpanı. */
	public static double effectScale(int rank) {
		return 1.0 + clampRank(rank) * SoulConfig.EFFECT_SCALE_PER_RANK;
	}

	/** Bir temel parçacık sayısını rütbeye göre ölçekler (en az 1). */
	public static int scaled(int base, int rank) {
		return Math.max(1, (int) Math.round(base * effectScale(rank)));
	}
}
