package com.battleaxe.soul;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/** Sıradan (kritik olmayan) balta vuruşlarına rütbeyle zenginleşen isabet efektleri. Sadece parçacık. */
public final class RankEffects {
	private RankEffects() {
	}

	public static void onHit(ServerLevel level, ServerPlayer attacker, Entity target, int rank) {
		if (rank <= 0) {
			return;
		}

		double x = target.getX();
		double y = target.getY(0.5);
		double z = target.getZ();

		// Hedefin gövde ortasından saldırgana doğru biraz kaydır (vurulan yüzeyde görünsün).
		double dx = attacker.getX() - x;
		double dz = attacker.getZ() - z;
		double length = Math.sqrt(dx * dx + dz * dz);
		if (length > 1.0E-4) {
			x += dx / length * 0.3;
			z += dz / length * 0.3;
		}

		level.sendParticles(RankStyle.dust(rank), x, y, z, SoulLogic.scaled(2, rank), 0.22, 0.25, 0.22, 0.0);

		if (rank >= 3) {
			level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0.0, 0.0, 0.0, 0.0);
		}
		if (rank >= 5) {
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, rank, 0.2, 0.25, 0.2, 0.15);
		}
		if (rank >= 7) {
			level.sendParticles(ParticleTypes.FLAME, x, y, z, 3, 0.15, 0.2, 0.15, 0.05);
		}
	}
}
