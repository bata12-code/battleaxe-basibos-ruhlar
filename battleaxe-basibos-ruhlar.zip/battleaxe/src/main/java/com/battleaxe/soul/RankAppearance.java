package com.battleaxe.soul;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.BattleAxeMod;

/**
 * Baltanın rütbesine göre eşya modelini (görünüm) ve adını ayarlar. Sadece kozmetiktir.
 * Idempotent'tir: zaten doğruysa hiçbir şeyi yeniden yazmaz.
 */
public final class RankAppearance {
	private RankAppearance() {
	}

	private static final Identifier[] MODELS = new Identifier[SoulLogic.MAX_RANK + 1];
	private static final Component[] TITLES = new Component[SoulLogic.MAX_RANK + 1];

	static {
		for (int rank = 0; rank <= SoulLogic.MAX_RANK; rank++) {
			// Rütbe 0: vanilla varsayılanıyla aynı (eşya kimliği ve varsayılan ad); 1+: items/battle_axe_rN.json
			MODELS[rank] = rank == 0 ? BattleAxeMod.id("battle_axe") : BattleAxeMod.id("battle_axe_r" + rank);
			TITLES[rank] = rank == 0
					? Component.translatable("item.battleaxe.battle_axe")
					: Component.translatable("item.battleaxe.battle_axe.title." + rank);
		}
	}

	public static void sync(ItemStack stack, int rank) {
		int safe = Math.max(0, Math.min(SoulLogic.MAX_RANK, rank));

		Identifier model = MODELS[safe];
		if (!model.equals(stack.get(DataComponents.ITEM_MODEL))) {
			stack.set(DataComponents.ITEM_MODEL, model);
		}

		Component title = TITLES[safe];
		if (!title.equals(stack.get(DataComponents.ITEM_NAME))) {
			stack.set(DataComponents.ITEM_NAME, title);
		}
	}
}
