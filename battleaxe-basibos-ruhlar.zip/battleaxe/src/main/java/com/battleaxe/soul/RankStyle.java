package com.battleaxe.soul;

import net.minecraft.core.particles.DustColorTransitionOptions;

/** Her rütbenin vurgu rengi (dokulardaki süslerle aynı), parçacık efektleri için. */
public final class RankStyle {
	private RankStyle() {
	}

	/** {başlangıç, bitiş} 0xRRGGBB. */
	private static final int[][] ACCENTS = {
			{0xB48CF0, 0x6A3FC0}, // 0 mor
			{0x7FF0E0, 0x1AA89A}, // 1 ayaz yeşili
			{0xFFD27A, 0xD88A10}, // 2 kehribar
			{0xFF5060, 0x7A0A18}, // 3 kızıl
			{0xFFB040, 0xFF4010}, // 4 erimiş turuncu
			{0xFF70E8, 0x8A20D0}, // 5 macenta
			{0xFFF0E0, 0x602020}, // 6 beyaz-kırmızı
			{0xB0F0FF, 0x2090E0}, // 7 buz mavisi
			{0xFFF0A0, 0xE0A020}, // 8 altın
			{0x80FFFF, 0xFF60FF}  // 9 prizma
	};

	private static final DustColorTransitionOptions[] DUST = new DustColorTransitionOptions[ACCENTS.length];

	static {
		for (int i = 0; i < ACCENTS.length; i++) {
			DUST[i] = new DustColorTransitionOptions(ACCENTS[i][0], ACCENTS[i][1], 0.9F);
		}
	}

	public static DustColorTransitionOptions dust(int rank) {
		return DUST[Math.max(0, Math.min(DUST.length - 1, rank))];
	}
}
