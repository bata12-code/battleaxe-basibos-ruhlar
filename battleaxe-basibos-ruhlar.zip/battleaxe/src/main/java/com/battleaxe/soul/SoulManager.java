package com.battleaxe.soul;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.component.ModComponents;
import com.battleaxe.boss.KaraKorukConfig;
import com.battleaxe.boss.KaraKorukEntity;
import com.battleaxe.spirit.SpiritEntity;
import com.battleaxe.evolution.EvolutionEvents;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusSoul;
import com.battleaxe.nexus.NexusWhispers;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * "Ruh Bağı": oyuncu Savaş Baltası ana elde iken düşman öldürdükçe baltanın ruh sayacı artar,
 * rütbe atlayınca balta görünüm değiştirir, biraz güçlenir ve bir tören oynar.
 * Uysal hayvanlar ve köylüler ruh vermez; güçlü düşmanlar daha çok ruh verir (bkz. SoulConfig).
 */
public final class SoulManager {
	private SoulManager() {
	}

	/** Eşyadaki ruh sayısından rütbe. */
	public static int rankOf(ItemStack stack) {
		return SoulLogic.rank(stack.getOrDefault(ModComponents.SOULS, 0));
	}

	public static void initialize() {
		Whispers.initialize();

		ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
			if (!(damageSource.getEntity() instanceof ServerPlayer player) || entity == player) {
				return;
			}

			// Fırlatılan baltayla öldürdüyse ruh, havadaki baltanın eşyasına yazılır; değilse ana eldekine.
			ThrownBattleAxe thrown = ThrownBattleAxe.activeHit();
			boolean viaThrow = thrown != null && player.getUUID().equals(thrown.getOwnerUuid());
			ItemStack stack = viaThrow ? thrown.getItem().copy() : player.getMainHandItem();
			if (!stack.is(ModItems.BATTLE_AXE)) {
				return;
			}

			boolean monster = entity.getType().getCategory() == MobCategory.MONSTER;
			// Kara Körük: can artsa da ruh değeri sabittir (mevcut etkileşim korunur; bkz. KaraKorukConfig.SOUL_VALUE).
			// Başıboş Ruhlar: türe göre SABİT, küçük ödül (bkz. SpiritConfig); ruh dengesini bozan bir açık yoktur.
			int baseValue = entity instanceof KaraKorukEntity
					? KaraKorukConfig.SOUL_VALUE
					: entity instanceof SpiritEntity spirit
							? spirit.getSoulReward()
							: SoulLogic.soulValue(monster, entity instanceof Player, entity.getMaxHealth());
			if (baseValue <= 0) {
				return;
			}

			// Ruh Ağı: AYNI öldürme olayı için tek ödül. Ağ bonusları bu değere eklenir ve hem baltanın
			// ruh sayacına (rütbe) hem oyuncunun ağ defterine (yetenek puanı) aynı miktar yazılır.
			// Berserker Evrimi (Ruh Yırtıcısı): ödüle eklenen düz bonus; Ruh Ağı bonusuyla birlikte TEK ödül olarak yazılır.
			int value = NexusSoul.onKill(player, entity, stack, baseValue, EvolutionEvents.soulBonus(player, entity, baseValue));

			int before = stack.getOrDefault(ModComponents.SOULS, 0);
			int after = SoulLogic.addSouls(before, value);
			if (after == before) {
				// Sayaç doluysa balta değişmez, ama Ruh Ağı'nın öldürmeye bağlı etkileri yine işler.
				if (player.level() instanceof ServerLevel cappedLevel) {
					NexusSoul.afterKill(cappedLevel, player, entity, baseValue, value);
				}
				EvolutionEvents.onKill(player, entity, baseValue);
				return;
			}

			stack.set(ModComponents.SOULS, after);
			if (!stack.has(ModComponents.OWNER)) {
				stack.set(ModComponents.OWNER, player.getName().getString());
			}

			int rank = SoulLogic.rank(after);
			RankAppearance.sync(stack, rank);
			if (viaThrow) {
				thrown.setItem(stack); // kopya üzerinde değiştirdik, geri yaz
			}

			if (SoulLogic.isRankUp(before, after) && player.level() instanceof ServerLevel level) {
				rankUp(level, player, rank);
				NexusWhispers.onRankUp(level, player, rank);
			}

			if (player.level() instanceof ServerLevel killLevel) {
				NexusSoul.afterKill(killLevel, player, entity, baseValue, value);
			}
			EvolutionEvents.onKill(player, entity, baseValue);
		});

		// Rütbe bonusları: ana eldeki balta rütbesine göre, her tick eşitlenir (idempotent).
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				RankBonuses.sync(player);
			}
		});
	}

	/** Rütbe atlama töreni: yazı, söz, ses ve rütbeyle büyüyen parçacıklar. */
	private static void rankUp(ServerLevel level, ServerPlayer player, int rank) {
		double x = player.getX();
		double y = player.getY(0.6);
		double z = player.getZ();

		player.sendSystemMessage(
				Component.translatable("item.battleaxe.battle_axe.rankup", SoulText.rankName(rank))
						.withStyle(ChatFormatting.GRAY),
				true);
		player.sendSystemMessage(
				Component.translatable("item.battleaxe.battle_axe.rankup.line." + rank)
						.withStyle(SoulText.rankColor(rank)).withStyle(ChatFormatting.ITALIC));

		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.8F, Math.max(0.3F, 0.8F - rank * 0.05F));
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F, 1.6F);
		if (rank >= 5) {
			level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 0.6F, 1.2F);
		}

		level.sendParticles(RankStyle.dust(rank), x, y, z, 30 + rank * 10, 0.5, 0.8, 0.5, 0.0);
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 12 + rank * 4, 0.5, 0.7, 0.5, 0.25);
		level.sendParticles(ParticleTypes.FLAME, x, y, z, 6 + rank * 2, 0.4, 0.6, 0.4, 0.06);
		if (rank >= 5) {
			level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 3, 0.6, 0.5, 0.6, 0.0);
		}
	}
}
