package com.battleaxe.loot;

import java.util.List;
import java.util.ArrayList;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.network.Filterable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.WrittenBookContent;

import com.battleaxe.item.ModItems;

/** Kara Körük'ün garantili ganimeti: Kara Çubuk ve "Körüğün Ardındaki Akıl" günlüğü. */
public final class KaraKorukLoot {
	private KaraKorukLoot() {
	}

	public static final String BOOK_TITLE = "Körüğün Ardındaki Akıl";
	public static final String BOOK_AUTHOR = "Kara Körük";

	/** Kitap sayfaları; her sayfa oyun içi kitap arayüzüne sığacak uzunluktadır. */
	private static final String[] PAGES = {
			"Birinci kayıt — Uyanış\n\nNe End'in sessizliğine aitim ne de Piglinlerin açgözlülüğüne.",
			"Onlar beni bir ucube olarak gördü. Ben ise onların göremediği şeyi gördüm: Ateş, doğru ellerde bir silahtan fazlasıdır. Ateş, dünyayı yeniden yazmanın yoludur.",
			"İlk çekici elime aldığımda ne bir ustam vardı ne de bana yol gösterecek bir tanrı. Yalnızca taş, ateş ve düşüncelerim vardı. Diğerleri ateşten korktu. Ben ona sorular sordum.",
			"İkinci kayıt — Savaş Baltası\n\nOnu demirden yapmadım. Demir, biçim alır ama hatırlamaz.",
			"Ona bir sap verdim. Sıradan bir Blaze'in özünden koparılmış, ateşi taşıyan bir çubuk. Sonra ona bir ağız değil, bir irade kazandırdım.",
			"İlk ruh içine girdiğinde örsüm titredi. İkinci ruh girdiğinde alevler eğildi. Üçüncüsünde ise çekiç sesini duydum.\n\nÇekiç elimdeydi.\n\nSes, baltanın içinden geliyordu.",
			"Üçüncü kayıt — Ölümsüz Sap\n\nBlaze'in özü güçlüdür, fakat her ateş bir gün söner. Her madde bir gün parçalanır. Her silah, sahibinden daha uzun yaşayamaz.\n\nBen bu kusuru kabul etmedim.",
			"Kendi özümden bir parçayı metalin içine hapsettim. Onu bir sapın biçimine soktum ve örsün altına gömdüm. Henüz tamamlanmadı. Bir gün biri onu bulacaksa, önce benim ateşimi susturmuş olmalı.",
			"O zaman anlayacak: Ben baltayı sonsuza dek dayanıklı kılmadım.\n\nOna sonunu reddetmeyi öğrettim.",
			"Son kayıt — Ustanın Korkusu\n\nBana canavar dediler. Belki haklıydılar.\n\nAma beni korkutan şey ölüm değil. Ölüm, yalnızca bir son. Beni korkutan, benden sonra gelecek olanın yaptıklarımı anlayamaması.",
			"Baltayı kim taşıyacak? Onu bir silah olarak mı kullanacak, yoksa benim yaptığım hatayı tekrarlayarak kendi iradesini ona mı bırakacak?\n\nBilmiyorum.\n\nİlk defa bilmiyorum.",
			"Ve bu düşünce, bütün düşmanlarımdan daha çok korkutuyor beni."
	};

	/** Okunabilir günlük: vanilla yazılı kitap eşyası, ama içeriği Kara Körük'ün kayıtları. */
	public static ItemStack createJournal() {
		List<Filterable<Component>> pages = new ArrayList<>();
		for (String page : PAGES) {
			pages.add(Filterable.passThrough(Component.literal(page)));
		}
		ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
		book.set(DataComponents.WRITTEN_BOOK_CONTENT, new WrittenBookContent(
				Filterable.passThrough(BOOK_TITLE), BOOK_AUTHOR, 0, pages, true));
		return book;
	}

	/** Boss ölürken bir kez çağrılır: iki ganimeti de boss'un konumuna düşürür. */
	public static void dropAll(ServerLevel level, Entity boss) {
		drop(level, boss, new ItemStack(ModItems.KARA_CUBUK));
		drop(level, boss, createJournal());
	}

	private static void drop(ServerLevel level, Entity boss, ItemStack stack) {
		ItemEntity item = new ItemEntity(level, boss.getX(), boss.getY() + 0.5, boss.getZ(), stack);
		item.setDefaultPickUpDelay();
		level.addFreshEntity(item);
	}
}
