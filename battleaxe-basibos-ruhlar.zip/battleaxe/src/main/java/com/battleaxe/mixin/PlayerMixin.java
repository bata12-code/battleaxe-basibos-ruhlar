package com.battleaxe.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.berserker.HiddetRoar;
import com.battleaxe.chain.ChainManager;
import com.battleaxe.effect.CritEffects;
import com.battleaxe.evolution.EvolutionEvents;
import com.battleaxe.execution.ExecutionManager;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusApi;
import com.battleaxe.nexus.NexusCombat;
import com.battleaxe.nexus.NexusDamage;
import com.battleaxe.soul.RankBonuses;
import com.battleaxe.soul.RankEffects;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.soul.Whispers;

@Mixin(Player.class)
public abstract class PlayerMixin {
	/**
	 * Vanilla, bir saldırı başarıyla vurduktan sonra ses/parçacık efektlerini
	 * Player#attackVisualEffects içinde oynatır ve ikinci parametre o saldırının
	 * vanilla kritik vuruş sonucudur. Kritik vuruşu kendimiz tahmin etmeyiz;
	 * sadece vanilla'nın verdiği sonuca bakarız.
	 *
	 * <p>require = 0: Bu görsel bir ekstra olduğu için, hedef metot bir güncellemede
	 * değişirse oyun çökmez; efekt sadece devre dışı kalır (latest.log'a uyarı düşer).
	 */
	@Inject(
			method = "attackVisualEffects(Lnet/minecraft/world/entity/Entity;ZZZZF)V",
			at = @At("HEAD"),
			require = 0
	)
	private void battleaxe$playCritEffect(
			Entity target,
			boolean criticalAttack,
			boolean sweepAttack,
			boolean fullStrengthAttack,
			boolean ignored,
			float magicBoost,
			CallbackInfo ci
	) {
		Player player = (Player) (Object) this;

		// Metot hem istemcide hem sunucuda çalışır; efektleri yalnızca sunucu gönderir,
		// böylece yakındaki herkes görür ve iki kez oynamaz.
		if (!(player.level() instanceof ServerLevel level) || !player.getMainHandItem().is(ModItems.BATTLE_AXE)) {
			return;
		}

		boolean struck = false;
		if (player instanceof ServerPlayer serverPlayer) {
			int rank = SoulManager.rankOf(serverPlayer.getMainHandItem());

			// Berserker aktifken (kritik olsun olmasın) vurulan mobun üzerine görsel yıldırım düşebilir.
			struck = BerserkerManager.tryLightningStrike(level, serverPlayer, target);

			// Rütbeyle zenginleşen sıradan isabet efekti (kritik vuruşun kendi efekti CritEffects'te).
			if (!criticalAttack) {
				RankEffects.onHit(level, serverPlayer, target, rank);
			}

			// Hiddet kükremesi: kritik (vanilla sonucu ya da Cellat darbesi) bir vuruş hedefi öldürdüyse.
			// Hedef bu noktada zaten ölüdür; yeni bir kritik tespiti yoktur.
			if ((criticalAttack || NexusApi.critProcThisTick(serverPlayer, level.getGameTime()))
					&& target instanceof LivingEntity victim && victim.isDeadOrDying()) {
				HiddetRoar.onCriticalKill(level, serverPlayer, victim);
			}

			// Balta seni tanıdıkça arada bir seninle konuşur.
			Whispers.onHit(level, serverPlayer, rank);

			// Ruh Ağı: başarılı vuruştan sonra kısa süreli savunma (Muhafız).
			NexusDamage.onSuccessfulHit(serverPlayer);

			// Berserker Evrimi: başarılı vuruş -> Savaş Özü, ivme, ustalık (kopya ve zayıf vuruş korumalı).
			EvolutionEvents.onMeleeHit(serverPlayer, target, criticalAttack);
		}

		// Kritik vuruşu kendimiz tahmin etmeyiz; vanilla'nın sonucuna bakarız.
		// Aynı vuruşta gerçek yıldırım düştüyse parçacık yıldırımı oynatılmaz (üst üste binmesin).
		if (criticalAttack) {
			CritEffects.play(level, player, target, struck);
		}
	}

	/**
	 * Her saldırının hemen öncesinde Berserker ve rütbe bonuslarını ana eldeki eşyayla eşitler.
	 * Normalde bu her tick yapılır; ama oyuncu aynı tick içinde silah değiştirip vurursa
	 * (ör. Berserker aktifken baltadan kılıca geçip hemen vurmak) başka silah bonus almasın diye
	 * hasar hesaplanmadan önce tekrar kontrol edilir. İşlem idempotent'tir (bonus birikmez).
	 */
	@Inject(method = "attack", at = @At("HEAD"), require = 0)
	private void battleaxe$syncBerserkerBonuses(Entity target, CallbackInfo ci) {
		if ((Object) this instanceof ServerPlayer player) {
			BerserkerManager.syncBonuses(player);
			RankBonuses.sync(player);
			ChainManager.syncBonuses(player);
			// Ruh Ağı: ağır vuruş / kritik bağlamı bu saldırı için kaydedilir (hasar kancası okur).
			if (player.getMainHandItem().is(ModItems.BATTLE_AXE)) {
				NexusCombat.beginAttack(player, target);
				EvolutionEvents.beginAttack(player, target);
				// Execution: bu vuruşun GERÇEK bir yakın dövüş saldırısı olduğunu işaretler (bitirici adayı için).
				ExecutionManager.beginAttack(player, target);
			}
		}
	}
}
