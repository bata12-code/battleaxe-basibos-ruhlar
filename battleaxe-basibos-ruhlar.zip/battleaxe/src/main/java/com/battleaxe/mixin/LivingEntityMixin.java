package com.battleaxe.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

import com.battleaxe.evolution.EvolutionDamage;
import com.battleaxe.nexus.NexusDamage;

/**
 * Ruh Ağı hasar kancası. Hasar HAM miktar üzerinde (zırh/büyü hesabından ÖNCE) ölçeklenir ve
 * hurtServer aynı sonuçla yeniden çağrılır; böylece vanilla'nın zırh, koruma, direnç ve vuruş sonrası
 * dokunulmazlık hesapları değişmeden çalışır. Yeniden giriş koruması ölçeklemenin iki kez uygulanmasını önler.
 *
 * <p>require = 0: hedef metot değişirse oyun çökmez; yalnızca hasar düğümleri devre dışı kalır.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	@Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true, require = 0)
	private void battleaxe$nexusDamage(ServerLevel level, DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
		if (NexusDamage.isBusy()) {
			return;
		}
		LivingEntity self = (LivingEntity) (Object) this;
		// Önce Ruh Ağı, ardından Berserker Evrimi; ikisinin birleşik etkisi evrim tarafında sınırlandırılır.
		float afterNexus = NexusDamage.modify(self, source, amount);
		float modified = EvolutionDamage.modify(self, source, amount, afterNexus);
		if (modified == amount) {
			return;
		}
		NexusDamage.enter();
		try {
			cir.setReturnValue(self.hurtServer(level, source, modified));
		} finally {
			NexusDamage.exit();
		}
	}
}
