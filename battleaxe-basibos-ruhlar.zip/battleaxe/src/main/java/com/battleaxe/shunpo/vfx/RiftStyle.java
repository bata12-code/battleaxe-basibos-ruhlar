package com.battleaxe.shunpo.vfx;

/**
 * Rütbeye (0-9) bağlı yarık görünümü. Yalnızca GÖRSEL parametrelerdir; hasar, menzil, süre ya da kombo gücüyle ilgisi yoktur.
 * Hepsi sınırlıdır: en yüksek rütbede bile ömür 18 tick, yükseklik 2,6 blok, kenar başına 6 parçacıktır.
 */
public record RiftStyle(double height, double halfWidth, int openTicks, int holdTicks, int closeTicks,
		int edgeParticles, boolean secondLine, boolean runes, boolean signature) {

	public static final int MAX_RANK = 9;

	public int totalTicks() {
		return openTicks + holdTicks + closeTicks;
	}

	public static int clampRank(int rank) {
		return Math.max(0, Math.min(MAX_RANK, rank));
	}

	/** Shunpo başlangıç/varış yarığı. */
	public static RiftStyle main(int rank) {
		int r = clampRank(rank);
		return new RiftStyle(
				1.9 + 0.075 * r,
				0.26 + 0.012 * r,
				3 + (r >= RiftConfig.RUNE_RANK ? 1 : 0),
				5 + r / 3,
				4 + r / 4,
				2 + r / 2,
				r >= RiftConfig.SECOND_LINE_RANK,
				r >= RiftConfig.RUNE_RANK,
				r >= RiftConfig.SIGNATURE_RANK);
	}

	/** Küçük yarık (isabet çatlağı, 2. vuruş, bitirici): ana yarığın kısaltılmış, daha kısa ömürlü hâli. */
	public static RiftStyle small(int rank, double heightScale, int holdTicks) {
		RiftStyle m = main(rank);
		double h = Math.max(0.5, m.height() * Math.max(0.2, Math.min(1.0, heightScale)));
		return new RiftStyle(h, m.halfWidth() * 0.75, 2, Math.max(1, Math.min(6, holdTicks)), 3,
				Math.max(1, m.edgeParticles() - 1), false, false, false);
	}
}
