package com.battleaxe.shunpo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Shunpo'nun saf kararları (Minecraft'tan bağımsız, test edilebilir).
 * Dünya/varlık sorguları {@link ShunpoManager} içindedir; burada yalnızca "bu durumda izin var mı?" ve
 * "hangi sırayla hangi konumlar denenir?" hesaplanır.
 */
public final class ShunpoLogic {
	private ShunpoLogic() {
	}

	public enum Check {
		OK,
		NO_LINK,
		OWNER_INVALID,
		WRONG_DIMENSION,
		EXPIRED,
		AXE_INVALID,
		NO_ENCHANT,
		TARGET_INVALID
	}

	/** Bağlantı hâlâ kullanılabilir mi? İlk başarısız koşulu döndürür. */
	public static Check check(boolean hasLink, boolean ownerAliveAndPlaying, boolean sameDimension,
			long now, long expiresAt, boolean axeValid, boolean enchanted, boolean targetValid) {
		if (!hasLink) {
			return Check.NO_LINK;
		}
		if (!ownerAliveAndPlaying) {
			return Check.OWNER_INVALID;
		}
		if (!sameDimension) {
			return Check.WRONG_DIMENSION;
		}
		if (!windowOpen(now, expiresAt)) {
			return Check.EXPIRED;
		}
		if (!axeValid) {
			return Check.AXE_INVALID;
		}
		if (!enchanted) {
			return Check.NO_ENCHANT;
		}
		if (!targetValid) {
			return Check.TARGET_INVALID;
		}
		return Check.OK;
	}

	/** Tuş basışına verilen karar. */
	public enum KeyAction {
		/** Kombo sürüyor: basış yutulur (ne yeniden fırlatma ne ikinci Shunpo). */
		SWALLOW_COMBO,
		/** Geçerli Shunpo hakkı: ışınlanma denenir. */
		SHUNPO,
		/** Shunpo yok/geçersiz: istek normal fırlatma akışına bırakılır (geçersiz bağ silinir). */
		PASS_THROUGH
	}

	public static KeyAction keyAction(boolean comboActive, Check linkState) {
		if (comboActive) {
			return KeyAction.SWALLOW_COMBO;
		}
		return linkState == Check.OK ? KeyAction.SHUNPO : KeyAction.PASS_THROUGH;
	}

	/**
	 * İsabet bağ açar mı? Hedef bir canavar olmalı ve dünyadan KALDIRILMAMIŞ olmalı; hedefin canlı olması şart DEĞİLDİR
	 * (balta öldürse bile isabet geçerlidir, ışınlanma fırlatma konumuna yapılır).
	 */
	public static boolean canOpenLink(boolean armed, boolean targetIsMob, boolean targetRemoved, boolean ownerPlaying,
			boolean sameLevel, boolean enchanted) {
		return armed && targetIsMob && !targetRemoved && ownerPlaying && sameLevel && enchanted;
	}

	/**
	 * Bağlantının "balta tarafı" kullanılabilir mi? Balta ya hâlâ dünyada geçerli bir varlıktır ya da Sadakat/yakalama ile
	 * sahibine ZATEN TESLİM edilmiştir (normal geri dönüş Shunpo hakkını silmez). Teslim edilmeden kaybolmuş balta geçersizdir.
	 */
	public static boolean axeUsable(boolean deliveredToOwner, boolean entityValid) {
		return deliveredToOwner || entityValid;
	}

	/** Süre dolmadıysa true (bitiş anı dahil). */
	public static boolean windowOpen(long now, long expiresAt) {
		return now <= expiresAt;
	}

	public static long expiry(long hitTick) {
		return hitTick + ShunpoConfig.WINDOW_TICKS;
	}

	/** Aranacak konum farkları: (0,0,0) ilk, sonra fırlatma noktasına en yakından en uzağa. */
	public static final List<int[]> OFFSETS = buildOffsets(
			ShunpoConfig.SEARCH_RADIUS, ShunpoConfig.SEARCH_UP, ShunpoConfig.SEARCH_DOWN);

	/**
	 * (dx, dy, dz) farkları, merkezden uzaklığa göre sıralı; eşitlikte önce aynı yükseklik, sonra daha az aşağı.
	 * Sıralama deterministiktir: aynı durumda hep aynı konum seçilir.
	 */
	public static List<int[]> buildOffsets(int radius, int up, int down) {
		List<int[]> list = new ArrayList<>();
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				for (int dy = -down; dy <= up; dy++) {
					list.add(new int[] {dx, dy, dz});
				}
			}
		}
		list.sort(Comparator
				.comparingInt((int[] o) -> o[0] * o[0] + o[1] * o[1] + o[2] * o[2])
				.thenComparingInt(o -> Math.abs(o[1]))
				.thenComparingInt(o -> -o[1])
				.thenComparingInt(o -> o[0])
				.thenComparingInt(o -> o[2]));
		return List.copyOf(list);
	}

	/** Konum sayıları geçerli mi (NaN/sonsuz değil)? Bozuk veri ışınlanmayı asla başlatmaz. */
	public static boolean finite(double x, double y, double z) {
		return Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z);
	}
}
