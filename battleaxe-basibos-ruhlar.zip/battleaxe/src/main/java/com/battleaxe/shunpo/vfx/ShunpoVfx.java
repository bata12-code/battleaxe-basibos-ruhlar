package com.battleaxe.shunpo.vfx;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Sunucu tarafı: doğrulanmış Shunpo/kombo olaylarını yakındaki oyunculara küçük bir paketle bildirir. Parçacık hesabı
 * YAPMAZ; yalnızca olay türü, oyuncu, rütbe ve iki konum gider. Mekanik (ışınlanma, hasar, süre) bu sınıfa bağlı değildir:
 * burada olan hiçbir şey oyun durumunu değiştirmez.
 */
public final class ShunpoVfx {
	private ShunpoVfx() {
	}

	private static final Map<UUID, Long> LAST_FAIL = new HashMap<>();

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(ShunpoVfxPayload.TYPE, ShunpoVfxPayload.CODEC);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LAST_FAIL.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> LAST_FAIL.clear());
	}

	/** İki konumlu olay (Shunpo, kombo vuruşları). */
	public static void send(ServerLevel level, RiftKind kind, ServerPlayer actor, int rank, Vec3 a, Vec3 b) {
		if (!RiftConfig.ENABLED || a == null || b == null) {
			return;
		}
		int clamped = RiftStyle.clampRank(rank);
		if (!RiftLogic.validPayload(kind.code, clamped, a.x, a.y, a.z, b.x, b.y, b.z)) {
			return;
		}
		if (kind == RiftKind.FAIL) {
			long now = level.getGameTime();
			long last = LAST_FAIL.getOrDefault(actor.getUUID(), Long.MIN_VALUE / 2);
			if (!RiftLogic.failAllowed(last, now)) {
				return;
			}
			LAST_FAIL.put(actor.getUUID(), now);
		}
		ShunpoVfxPayload payload = new ShunpoVfxPayload(kind.code, actor.getId(), clamped, a.x, a.y, a.z, b.x, b.y, b.z);
		double radiusSq = RiftConfig.VIEW_RADIUS * RiftConfig.VIEW_RADIUS;
		for (ServerPlayer viewer : level.players()) {
			if (viewer.distanceToSqr(a.x, a.y, a.z) <= radiusSq || viewer.distanceToSqr(b.x, b.y, b.z) <= radiusSq) {
				ServerPlayNetworking.send(viewer, payload);
			}
		}
	}

	/** Tek konumlu olay. */
	public static void send(ServerLevel level, RiftKind kind, ServerPlayer actor, int rank, Vec3 at) {
		send(level, kind, actor, rank, at, at);
	}
}
