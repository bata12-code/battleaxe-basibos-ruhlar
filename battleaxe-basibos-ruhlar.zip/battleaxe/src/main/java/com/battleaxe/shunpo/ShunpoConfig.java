package com.battleaxe.shunpo;

/** Shunpo dengeleme ayarları. Süreler tick cinsindendir (20 tick = 1 sn). */
public final class ShunpoConfig {
	private ShunpoConfig() {
	}

	/**
	 * Sunucu günlüğüne (INFO) Shunpo'nun yaşam döngüsünü yazar: fırlatma (büyülü mü), isabet (kabul/ret nedeni),
	 * bağın silinme nedeni, ikinci tuş sonucu. Oyunda "ışınlanmıyor" sorunlarını tek bakışta teşhis etmek içindir;
	 * sorun yoksa false yap. Satırlar "[Shunpo]" ile başlar.
	 */
	public static final boolean DEBUG = true;

	/** Balta bir canavara isabet ettikten sonra ikinci tuş basışının geçerli olduğu süre. */
	public static final int WINDOW_TICKS = 80;

	/** Fırlatma noktası güvenli değilse çevresinde aranan en uzak yatay mesafe (blok). */
	public static final int SEARCH_RADIUS = 2;

	/** Aramada fırlatma noktasının en çok kaç blok üstüne / altına bakılır. */
	public static final int SEARCH_UP = 2;
	public static final int SEARCH_DOWN = 2;

	/** Ayakların altında en çok bu kadar blok içinde zemin (ya da sıvı) aranır; boşluğa ışınlanmayı önler. */
	public static final int GROUND_DEPTH = 32;

	/**
	 * Başarılı Shunpo sonrası baltaya uygulanan kısa bekleme: hızlı çift tuş basışı baltayı yanlışlıkla
	 * yeniden fırlatmasın.
	 */
	public static final int POST_COOLDOWN_TICKS = 10;
}
