package com.battleaxe.shunpo;

/**
 * Kombonun SAF kararları (Minecraft'tan bağımsız, test edilebilir: tools/test/ShunpoLogicTest.java).
 * Oyun nesnelerini okuyan {@link ShunpoCombo} sayı/bool verir; hangi dalın seçileceği burada belirlenir.
 */
public final class ComboLogic {
	private ComboLogic() {
	}

	public enum Phase {
		/** Hedefin yanına kısa güvenli adım. */
		APPROACH,
		/** Açılış vuruşu. */
		FIRST,
		/** İkinci vuruş (dallanma noktası). */
		SECOND,
		/** Bitirici dal. */
		FINISH
	}

	/** İkinci vuruştaki dal. */
	public enum SecondDecision {
		/** Ana hedef hayatta: kombo ana hedefte sürer. */
		HIT_MAIN,
		/** Ana hedef öldü ve ağ izin veriyor ve geçerli aday var: yeni hedefe geç (kombo başına bir kez). */
		RETARGET,
		/** Ana hedef gitti ve geçiş yok: kombo güvenle sonlanır. */
		END
	}

	/** Bitirici dalı. */
	public enum FinishDecision {
		/** Hedef Execution için uygun: bitirici animasyonu başlar (kombo hasar vermez). */
		EXECUTION,
		/** Normal bitirici: ağır, sabit kritik vuruş (+ varsa süpürme). */
		HEAVY,
		/** Hedef yok: kombo hasarsız bir son hareketle (efekt) biter. */
		FLOURISH
	}

	public static SecondDecision decideSecond(boolean mainAlive, boolean retargetAllowed, boolean alreadyRetargeted,
			boolean candidateExists) {
		if (mainAlive) {
			return SecondDecision.HIT_MAIN;
		}
		if (retargetAllowed && !alreadyRetargeted && candidateExists) {
			return SecondDecision.RETARGET;
		}
		return SecondDecision.END;
	}

	public static FinishDecision decideFinish(boolean mainAlive, boolean executionEligible) {
		if (!mainAlive) {
			return FinishDecision.FLOURISH;
		}
		return executionEligible ? FinishDecision.EXECUTION : FinishDecision.HEAVY;
	}

	/**
	 * Bir vuruşun ham hasarı. {@code percent} (kombo + Hiddet + bitirici) {@link ComboConfig#BONUS_CAP_PCT} ile sınırlıdır;
	 * negatif/geçersiz girdi 0 hasar verir.
	 */
	public static double damage(double attackDamage, double multiplier, double percent) {
		if (!(attackDamage > 0.0) || !(multiplier > 0.0) || Double.isNaN(percent)) {
			return 0.0;
		}
		double pct = Math.max(0.0, Math.min(ComboConfig.BONUS_CAP_PCT, percent));
		return attackDamage * multiplier * (1.0 + pct / 100.0);
	}

	public static double multiplier(Phase hit) {
		return switch (hit) {
			case FIRST -> ComboConfig.FIRST_MULTIPLIER;
			case SECOND -> ComboConfig.SECOND_MULTIPLIER;
			case FINISH -> ComboConfig.FINISH_MULTIPLIER;
			case APPROACH -> 0.0;
		};
	}

	public static boolean withinReach(double distanceSquared, double reach) {
		return distanceSquared <= reach * reach;
	}

	public static boolean timedOut(long now, long startTick, int maxTicks) {
		return now - startTick > maxTicks;
	}

	public static boolean approachAllowed(double distance) {
		return ComboConfig.APPROACH_ENABLED && distance <= ComboConfig.APPROACH_MAX_DISTANCE;
	}

	public static double retargetRadius(double bonusBlocks) {
		return ComboConfig.RETARGET_BASE_RADIUS + Math.max(0.0, bonusBlocks);
	}

	/**
	 * Hiddet bedeli ödenebilir mi? Bedel yoksa (0) her zaman evet; varsa ödemeden sonra can en az
	 * {@link ComboConfig#COST_MIN_REMAINING_HEALTH} kalmalı (bedel seni asla öldürmez).
	 */
	public static boolean canPayCost(float health, double cost) {
		return cost <= 0.0 || health - cost >= ComboConfig.COST_MIN_REMAINING_HEALTH;
	}

	/** Pitch (derece) hedefe bakmak için: yatay mesafe ve yükseklik farkından. Yukarı bakış negatiftir. */
	public static float pitchToward(double horizontal, double dy) {
		return (float) -Math.toDegrees(Math.atan2(dy, Math.max(1.0E-6, horizontal)));
	}
}
