package com.battleaxe.shunpo.vfx;

/**
 * Gerçeklik yarığı görsellerinin merkezi ayarları. Görseller yalnızca istemci tarafında üretilir; bu değerler hasarı,
 * menzili, süreyi ya da kombo gücünü ETKİLEMEZ.
 */
public final class RiftConfig {
	private RiftConfig() {
	}

	/** false: hiç görsel olay gönderilmez/çizilmez (yalnızca ses ve mekanik kalır). */
	public static final boolean ENABLED = true;

	/** Parçacık yoğunluğu çarpanı (0 = kapalı, 1 = varsayılan, en çok 2). Tek merkezi düğme. */
	public static final float DENSITY = 1.0F;

	/** İstemcide tek tick'te üretilebilecek en çok parçacık (yoğunluk çarpanından önce). */
	public static final int MAX_PARTICLES_PER_TICK = 150;

	/** Aynı anda açık en çok yarık; fazlası en eskiyi kapatır. */
	public static final int MAX_ACTIVE_RIFTS = 8;
	public static final int MAX_ACTIVE_TRAILS = 4;

	/** Sunucu, görseli yalnızca bu yarıçaptaki (blok) oyunculara gönderir; istemci de bundan uzağı çizmez. */
	public static final double VIEW_RADIUS = 48.0;

	/** Geçiş izinin süresi (tick) ve toplam en çok nokta sayısı (uzun mesafede sınırlıdır). */
	public static final int TRAIL_TICKS = 6;
	public static final int TRAIL_MAX_POINTS = 30;

	/** Varış yarığı, başlangıç yarığından kaç tick sonra açılır (geçiş hissi). */
	public static final int ARRIVAL_DELAY_TICKS = 3;

	/** Aynı olayın (tür + oyuncu + yaklaşık konum) bu kadar tick içinde tekrarı yok sayılır. */
	public static final int DUPLICATE_WINDOW_TICKS = 3;

	/** Başarısız girişim kıvılcımı için oyuncu başına en kısa aralık (tick). */
	public static final int FAIL_MIN_GAP_TICKS = 10;

	/** Yeni Shunpo gelince aynı oyuncunun eski yarıkları bu kadar tick içinde kapanışa zorlanır. */
	public static final int FORCED_CLOSE_TICKS = 3;

	/** En yüksek rütbe için yarık imzası (halka) açılır. */
	public static final int SIGNATURE_RANK = 9;
	public static final int SECOND_LINE_RANK = 3;
	public static final int RUNE_RANK = 6;
}
