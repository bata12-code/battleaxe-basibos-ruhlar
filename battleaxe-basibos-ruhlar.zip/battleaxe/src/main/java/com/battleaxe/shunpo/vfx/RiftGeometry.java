package com.battleaxe.shunpo.vfx;

/**
 * Yarık siluetinin (kırık, düzensiz kenar) saf geometrisi. Tohum aynıysa sonuç aynıdır (efekt tutarlıdır, test edilebilir).
 */
public final class RiftGeometry {
	private RiftGeometry() {
	}

	public static final int POINTS = 12;

	/** Basit, platformdan bağımsız deterministik [0,1) üretici (splitmix64). */
	public static double unit(long seed, int index) {
		long z = seed + 0x9E3779B97F4A7C15L * (index + 1L);
		z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
		z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
		z = z ^ (z >>> 31);
		return (z >>> 11) * 0x1.0p-53;
	}

	/**
	 * Bir kenarın yarı genişlik profili (alttan üste {@link #POINTS} nokta). Uçlarda sıfıra yaklaşır (sivri uçlu yarık),
	 * ortada {@code halfWidth} civarındadır; her nokta düzensizdir ama asla 0'dan küçük ya da 1,3 x halfWidth'den büyük değildir.
	 */
	public static double[] edgeProfile(long seed, double halfWidth) {
		double[] profile = new double[POINTS];
		for (int i = 0; i < POINTS; i++) {
			double t = i / (double) (POINTS - 1);
			double taper = Math.pow(Math.sin(Math.PI * t), 0.7);
			double jitter = 0.55 + 0.75 * unit(seed, i); // 0.55 .. 1.30
			// Kırık görünüm için ardışık noktalar zaman zaman belirgin dalgalanır
			double kink = (i % 3 == 1) ? 0.8 : 1.0;
			profile[i] = Math.max(0.0, Math.min(1.3 * halfWidth, halfWidth * taper * jitter * kink));
		}
		return profile;
	}

	/** Profil üzerinde t (0..1) konumundaki doğrusal ara değer. */
	public static double sample(double[] profile, double t) {
		double clamped = Math.max(0.0, Math.min(1.0, t));
		double pos = clamped * (profile.length - 1);
		int i = (int) Math.floor(pos);
		int j = Math.min(profile.length - 1, i + 1);
		double f = pos - i;
		return profile[i] * (1.0 - f) + profile[j] * f;
	}

	/** Geçiş izi için nokta sayısı: mesafeyle artar ama {@link RiftConfig#TRAIL_MAX_POINTS} ile sınırlıdır. */
	public static int trailPoints(double distance) {
		if (!(distance > 0.0)) {
			return 0;
		}
		return (int) Math.max(2, Math.min(RiftConfig.TRAIL_MAX_POINTS, Math.ceil(distance * 1.2)));
	}
}
