package com.battleaxe.shunpo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.chain.ChainManager;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusApi;
import com.battleaxe.nexus.Stat;
import com.battleaxe.shunpo.vfx.RiftKind;
import com.battleaxe.shunpo.vfx.RiftLogic;
import com.battleaxe.shunpo.vfx.ShunpoVfx;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * <b>Shunpo</b>: Shunpo büyülü Savaş Baltası bir canavara isabet ettikten sonra, kısa bir süre içinde fırlatma tuşuna
 * (varsayılan R) ikinci kez basılırsa oyuncu baltanın FIRLATILDIĞI konuma ışınlanır ve baltayı anında geri alır.
 *
 * <p>Tüm durum sunucudadır; istemci yalnızca mevcut {@code ThrowAxePayload} ile "tuşa basıldı" der (veri taşımaz).
 * Fırlatma konumu istemciden gelmez: balta fırlatılırken sunucu kaydeder. Bağlantı oyuncu başınadır ve
 * (balta, hedef, fırlatma konumu, boyut, süre) üçlüsünü taşır; yeni fırlatma, ölüm, çıkış, boyut değişimi,
 * süre sonu, balta/hedef kaybı ya da başarılı kullanım bağlantıyı siler. Bir isabet en fazla bir ışınlanma verir.
 * Balta bloğa çarparsa ya da hiçbir şeye çarpmazsa bağlantı HİÇ oluşmaz.
 */
public final class ShunpoManager {
	private ShunpoManager() {
	}

	/**
	 * Bir isabetin Shunpo hakkı. {@code delivered}: balta Sadakat/yakalama ile sahibine zaten döndü; hak bundan ETKİLENMEZ
	 * (yalnızca süre, ölüm, boyut, yeni fırlatma ve kullanım siler). Hedefin sonradan ölmesi de hakkı silmez: ışınlanma
	 * hedefe değil fırlatma konumuna yapılır, isabet kaydı zaten geçerlidir.
	 */
	private static final class Link {
		final UUID axe;
		final UUID target;
		final ResourceKey<Level> dimension;
		final Vec3 origin;
		final long expiresAt;
		boolean delivered;

		Link(UUID axe, UUID target, ResourceKey<Level> dimension, Vec3 origin, long expiresAt) {
			this.axe = axe;
			this.target = target;
			this.dimension = dimension;
			this.origin = origin;
			this.expiresAt = expiresAt;
		}
	}

	private static void debug(String message, Object... args) {
		if (ShunpoConfig.DEBUG) {
			BattleAxeMod.LOGGER.info("[Shunpo] " + message, args);
		}
	}

	/** Oyuncu kimliği -> etkin bağlantı. Yalnızca sunucu iş parçacığı kullanır. */
	private static final Map<UUID, Link> LINKS = new HashMap<>();

	public static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(ShunpoManager::tick);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LINKS.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> LINKS.clear());
		ShunpoCombo.initialize();
		ShunpoVfx.initialize();
	}

	/** Oyuncu yeni bir balta fırlatıyor: eski bağlantı geçersizdir. */
	public static void onThrow(ServerPlayer player, boolean armed) {
		LINKS.remove(player.getUUID());
		ShunpoCombo.cancel(player); // eski kombo yeni fırlatmayla kesilir (bekleyen görseller de kapanır)
		debug("{} baltayı fırlattı: Shunpo {}", player.getName().getString(), armed ? "HAZIR (büyülü)" : "yok (balta Shunpo büyülü değil)");
	}

	/** Balta Sadakat/yakalama ile sahibine teslim edildi: bağ varsa korunur, yalnızca "teslim edildi" işaretlenir. */
	public static void onAxeDelivered(UUID owner, UUID axe) {
		Link link = LINKS.get(owner);
		if (link != null && link.axe.equals(axe)) {
			link.delivered = true;
			debug("balta sahibine döndü; Shunpo hakkı korunuyor (süre dolana dek)");
		}
	}

	/** Fırlatılan balta bir varlığa çarptı (ThrownBattleAxe#onHitEntity, tek seferlik). Yalnızca geçerli canavar isabeti bağ kurar. */
	public static void onHit(ServerPlayer owner, ThrownBattleAxe axe, Entity target) {
		Mob mob = target instanceof Mob m ? m : null;
		ServerLevel level = axe.level() instanceof ServerLevel sl ? sl : null;
		Vec3 origin = axe.shunpoOrigin();
		boolean sameLevel = level != null && owner.level() == level;
		// Hedefin CANLI olması şart değildir: balta bir canavara gerçekten çarptıysa (öldürse bile) isabet geçerlidir.
		boolean enchanted = level != null && Shunpo.has(axe.getItem(), level);
		boolean ok = ShunpoLogic.canOpenLink(axe.isShunpoArmed(), mob != null, mob == null || mob.isRemoved(),
				owner.isAlive() && !owner.isSpectator(), sameLevel, enchanted)
				&& origin != null && ShunpoLogic.finite(origin.x, origin.y, origin.z);
		if (!ok) {
			debug("isabet: bağ AÇILMADI (büyülü fırlatma: {}, hedef canavar: {}, büyü hâlâ baltada: {}, oyuncu/boyut uygun: {})",
					axe.isShunpoArmed(), mob != null, enchanted, sameLevel);
			return;
		}
		// Ruh Ağı (Yarık Gezgini): ikinci tuş penceresi düğümlerle uzayabilir.
		long window = (long) NexusApi.stats(owner).get(Stat.SHUNPO_WINDOW_TICKS);
		LINKS.put(owner.getUUID(), new Link(axe.getUUID(), mob.getUUID(), level.dimension(), origin,
				ShunpoLogic.expiry(level.getGameTime()) + window));
		// Hedefte kısa süreli ruhsal çatlak: isabetin gerçekleştiğini gösterir (ışınlanma ayrı bir olaydır).
		ShunpoVfx.send(level, RiftKind.HIT_CRACK, owner, SoulManager.rankOf(axe.getItem()),
				mob.position().add(0.0, mob.getBbHeight() * 0.5, 0.0));
		debug("{} için Shunpo hakkı AÇILDI: hedef {} (canlı: {}), süre {} tick", owner.getName().getString(), mob.getType(),
				mob.isAlive(), ShunpoLogic.expiry(0L) + window);
	}

	/**
	 * Fırlatma tuşu isteği geldiğinde ÖNCE çağrılır.
	 *
	 * @return true: istek Shunpo tarafından işlendi (normal fırlatma akışı çalışmamalı); false: Shunpo yok, normal akış sürer.
	 */
	public static boolean tryActivate(ServerPlayer player) {
		Link link = LINKS.get(player.getUUID());
		if (!(player.level() instanceof ServerLevel level)) {
			return false;
		}
		ShunpoLogic.Check state = link == null ? ShunpoLogic.Check.NO_LINK : evaluate(player, link);
		switch (ShunpoLogic.keyAction(ShunpoCombo.isActive(player.getUUID()), state)) {
			case SWALLOW_COMBO -> {
				// Kombo sürerken gelen tuş basışı yutulur: ne yeniden fırlatma ne ikinci Shunpo.
				debug("{}: kombo sürerken tuş basışı yutuldu", player.getName().getString());
				return true;
			}
			case PASS_THROUGH -> {
				if (link == null) {
					debug("{}: tuş geldi ama etkin Shunpo hakkı YOK (normal akış sürer)", player.getName().getString());
				} else {
					debug("{}: hak geçersiz, siliniyor (neden: {})", player.getName().getString(), state);
					LINKS.remove(player.getUUID());
				}
				return false;
			}
			case SHUNPO -> {
				// devam
			}
		}
		// Balta hâlâ dünyadaysa varlığı; Sadakat/yakalamayla zaten teslim edildiyse null (geri çağırılacak bir şey yok).
		ThrownBattleAxe axe = link.delivered ? null : (level.getEntity(link.axe) instanceof ThrownBattleAxe found ? found : null);

		// Işınlanmadan ÖNCE: balta teslim edilebilmeli ve güvenli bir konum bulunmalı; yoksa hiçbir şey değişmez.
		if (axe != null && !axe.canShunpoRecall(player)) {
			player.sendSystemMessage(Component.translatable("message.battleaxe.shunpo.no_space"), true);
			failSpark(level, player);
			return true;
		}
		Vec3 destination = findSafe(level, player, link.origin);
		if (destination == null) {
			debug("{}: fırlatma noktası ve çevresinde güvenli konum yok; ışınlanma iptal", player.getName().getString());
			player.sendSystemMessage(Component.translatable("message.battleaxe.shunpo.no_safe"), true);
			failSpark(level, player);
			return true;
		}

		LINKS.remove(player.getUUID()); // tek hak: yeniden girişe karşı ışınlanmadan önce silinir
		Vec3 from = player.position();
		ItemStack stack = axe != null ? axe.getItem().copy()
				: (player.getMainHandItem().is(ModItems.BATTLE_AXE) ? player.getMainHandItem().copy() : new ItemStack(ModItems.BATTLE_AXE));

		if (!teleport(level, player, destination, player.getYRot(), player.getXRot())) {
			LINKS.put(player.getUUID(), link); // ışınlanma olmadı: hak harcanmadı
			player.sendSystemMessage(Component.translatable("message.battleaxe.shunpo.no_safe"), true);
			failSpark(level, player);
			return true;
		}

		boolean returned = axe == null || axe.shunpoRecall(player);
		debug("{}: ışınlandı (balta {})", player.getName().getString(), axe == null ? "zaten elde/envanterde" : "geri alındı: " + returned);
		if (returned && !stack.isEmpty()) {
			// Hızlı çift tuş basışı baltayı yanlışlıkla yeniden fırlatmasın.
			player.getCooldowns().addCooldown(stack, ShunpoConfig.POST_COOLDOWN_TICKS);
		}
		effects(level, player, from, destination, SoulManager.rankOf(stack));

		// Ruh Ağı: Shunpo sonrası kısa süreli hız/zırh/şifa; ardından (açıksa) kombo hedefe karşı başlar.
		long now = level.getGameTime();
		NexusApi.onShunpo(player, now);
		// Kıyım Zinciri: ışınlanma zincirin kalan süresini uzatır (düşmanlar arası boşluğu aşmak için).
		ChainManager.onShunpo(player);
		// Başıboş Ruhlar: Shunpo, Zincirli Ruh'un zincirle mühürlemesini kırar (kısa bir kaçış bağışıklığıyla).
		com.battleaxe.spirit.SpiritSeal.onShunpo(player);
		if (ComboConfig.ENABLED && returned && level.getEntity(link.target) instanceof Mob comboTarget) {
			ShunpoCombo.start(level, player, comboTarget);
		}
		return true;
	}

	/**
	 * Oyuncuyu aynı boyutta {@code dest} konumuna ışınlar (hız sıfırlanır, düşme mesafesi silinir). Güvenlik denetimi
	 * ÇAĞIRANIN işidir ({@link #isSafe}). Tek ışınlama noktası: yalnızca burası API'ye dokunur.
	 */
	static boolean teleport(ServerLevel level, ServerPlayer player, Vec3 dest, float yRot, float xRot) {
		Entity moved = player.teleport(new TeleportTransition(level, dest, Vec3.ZERO, yRot, xRot, TeleportTransition.DO_NOTHING));
		if (moved == null) {
			return false;
		}
		player.fallDistance = 0;
		return true;
	}

	// ------------------------------------------------------------------
	// Doğrulama ve temizlik
	// ------------------------------------------------------------------

	private static ShunpoLogic.Check evaluate(ServerPlayer player, Link link) {
		if (!(player.level() instanceof ServerLevel level)) {
			return ShunpoLogic.Check.OWNER_INVALID;
		}
		ThrownBattleAxe axe = level.getEntity(link.axe) instanceof ThrownBattleAxe found ? found : null;
		boolean entityValid = axe != null && !axe.isRemoved() && axe.isShunpoArmed()
				&& player.getUUID().equals(axe.getOwnerUuid());
		// Teslim edilmiş baltada büyü isabet anında zaten doğrulandı; dünyadaki baltada her seferinde yeniden bakılır.
		boolean enchanted = link.delivered || (entityValid && Shunpo.has(axe.getItem(), level));
		// Hedef artık şart değil (isabet kaydı geçerli; ışınlanma fırlatma konumuna): targetValid hep true.
		return ShunpoLogic.check(true, player.isAlive() && !player.isSpectator(),
				level.dimension() == link.dimension, level.getGameTime(), link.expiresAt,
				ShunpoLogic.axeUsable(link.delivered, entityValid), enchanted, true);
	}

	/** Her tick: geçersizleşen (süre, ölüm, boyut, balta, hedef) bağlantıları siler. Bağlantı yoksa maliyeti yoktur. */
	private static void tick(MinecraftServer server) {
		if (LINKS.isEmpty()) {
			return;
		}
		Iterator<Map.Entry<UUID, Link>> it = LINKS.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, Link> entry = it.next();
			ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
			ShunpoLogic.Check state = player == null ? ShunpoLogic.Check.OWNER_INVALID : evaluate(player, entry.getValue());
			if (state != ShunpoLogic.Check.OK) {
				debug("hak silindi (neden: {})", state);
				it.remove();
			}
		}
	}

	// ------------------------------------------------------------------
	// Güvenli konum
	// ------------------------------------------------------------------

	/**
	 * Fırlatma noktasını, olmazsa ona en yakın geçerli konumu döndürür (yoksa null: ışınlanma iptal).
	 * Geçerli konum: yüklü bölge, dünya tabanının üstü, oyuncu gövdesine yetecek boşluk, ayak/baş hizasında
	 * lav ya da ateş yok, altında (en çok GROUND_DEPTH blok içinde) zemin ya da sıvı var.
	 */
	private static Vec3 findSafe(ServerLevel level, ServerPlayer player, Vec3 origin) {
		Vec3 here = player.position();
		double baseX = Math.floor(origin.x) + 0.5;
		double baseZ = Math.floor(origin.z) + 0.5;
		for (int[] o : ShunpoLogic.OFFSETS) {
			Vec3 candidate = (o[0] == 0 && o[1] == 0 && o[2] == 0)
					? origin
					: new Vec3(baseX + o[0], origin.y + o[1], baseZ + o[2]);
			if (isSafe(level, player, here, candidate)) {
				return candidate;
			}
		}
		return null;
	}

	static boolean isSafe(ServerLevel level, ServerPlayer player, Vec3 here, Vec3 c) {
		if (!ShunpoLogic.finite(c.x, c.y, c.z)) {
			return false;
		}
		BlockPos feet = BlockPos.containing(c.x, c.y, c.z);
		if (!level.hasChunkAt(feet) || c.y < level.getMinY() + 1) {
			return false;
		}
		if (!level.noCollision(player, player.getBoundingBox().move(c.x - here.x, c.y - here.y, c.z - here.z))) {
			return false;
		}
		if (harmful(level.getBlockState(feet)) || harmful(level.getBlockState(feet.above()))) {
			return false;
		}
		for (int i = 1; i <= ShunpoConfig.GROUND_DEPTH; i++) {
			BlockPos below = feet.below(i);
			if (below.getY() < level.getMinY()) {
				return false;
			}
			BlockState state = level.getBlockState(below);
			if (!state.getCollisionShape(level, below).isEmpty() || !state.getFluidState().isEmpty()) {
				return !state.getFluidState().is(FluidTags.LAVA);
			}
		}
		return false;
	}

	private static boolean harmful(BlockState state) {
		return state.is(BlockTags.FIRE) || state.getFluidState().is(FluidTags.LAVA);
	}

	// ------------------------------------------------------------------
	// Efektler (sade): iki uçta kıvılcım/ses, aralarında kısa iz
	// ------------------------------------------------------------------

	/**
	 * BAŞARILI ışınlanmanın sesi ve görseli. Görsel (yarıklar + geçiş izi) istemcide üretilir; sunucu yalnızca
	 * gerçek başlangıç ve gerçek varış konumunu (güvenli konum araması sonrası) küçük bir olay paketiyle bildirir.
	 */
	static void effects(ServerLevel level, ServerPlayer player, Vec3 from, Vec3 to, int rank) {
		level.playSound(null, from.x, from.y, from.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.7F, 1.8F);
		level.playSound(null, to.x, to.y, to.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.5F, 1.7F);
		ShunpoVfx.send(level, RiftLogic.kindForOutcome(true), player, rank, from, to);
	}

	/** Başarısız girişim: gerçek ışınlanma izlenimi vermeyen küçük kıvılcım (oyuncu başına hız sınırlı). */
	private static void failSpark(ServerLevel level, ServerPlayer player) {
		ShunpoVfx.send(level, RiftLogic.kindForOutcome(false), player, 0, player.position());
	}
}
