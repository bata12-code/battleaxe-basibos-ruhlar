package com.battleaxe.shunpo;

import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;

import com.battleaxe.BattleAxeMod;

/**
 * "Shunpo" büyüsüne erişim. Büyünün kendisi veri odaklıdır
 * (data/battleaxe/enchantment/shunpo.json; yalnızca Savaş Baltası'na basılabilir); burada sadece eşyada
 * olup olmadığına bakılır. Yar Geç ile aynı kalıp.
 */
public final class Shunpo {
	private Shunpo() {
	}

	public static final ResourceKey<Enchantment> KEY =
			ResourceKey.create(Registries.ENCHANTMENT, BattleAxeMod.id("shunpo"));

	/** Eşyadaki Shunpo seviyesi (yoksa 0). Büyü kayıtta bulunamazsa da 0 döner, çökmez. */
	public static int getLevel(ItemStack stack, RegistryAccess registries) {
		if (stack.isEmpty()) {
			return 0;
		}
		try {
			Holder<Enchantment> enchantment = registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(KEY);
			return EnchantmentHelper.getItemEnchantmentLevel(enchantment, stack);
		} catch (RuntimeException e) {
			return 0;
		}
	}

	public static boolean has(ItemStack stack, Level level) {
		return getLevel(stack, level.registryAccess()) > 0;
	}
}
