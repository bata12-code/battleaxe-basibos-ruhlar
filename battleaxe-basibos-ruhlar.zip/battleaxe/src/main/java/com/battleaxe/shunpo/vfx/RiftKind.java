package com.battleaxe.shunpo.vfx;

/** Sunucunun istemciye bildirdiği görsel olay türleri (ağda tek bayt). */
public enum RiftKind {
	/** Shunpo: başlangıç yarığı + geçiş izi + varış yarığı. a = başlangıç, b = gerçek varış. */
	SHUNPO(0),
	/** Balta mob'a isabet etti: hedefte küçük ruhsal çatlak. a = isabet noktası. */
	HIT_CRACK(1),
	/** Kombo 1. vuruş: ince kesik izi. a = oyuncu, b = hedef. */
	COMBO_FIRST(2),
	/** Kombo 2. vuruş: belirgin çatlak. */
	COMBO_SECOND(3),
	/** Kombo bitirici: kısa süreli yarık + kapanış patlaması. */
	COMBO_FINISH(4),
	/** Başarısız girişim: gerçek ışınlanma izlenimi vermeyen küçük kıvılcım. a = oyuncu. */
	FAIL(5),
	/** Komboyu/oyuncuyu iptal: bu oyuncuya ait açık yarıklar hızla kapatılır. */
	CANCEL(6);

	public final int code;

	RiftKind(int code) {
		this.code = code;
	}

	/** Bayttan tür; bilinmeyen kod null (istemci paketi yok sayar). */
	public static RiftKind byCode(int code) {
		for (RiftKind kind : values()) {
			if (kind.code == code) {
				return kind;
			}
		}
		return null;
	}
}
