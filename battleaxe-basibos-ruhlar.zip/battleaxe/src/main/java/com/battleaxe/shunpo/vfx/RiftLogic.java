package com.battleaxe.shunpo.vfx;

/** Yarık görsellerinin SAF karar ve zamanlama mantığı (Minecraft'tan bağımsız, test edilebilir). */
public final class RiftLogic {
	private RiftLogic() {
	}

	public enum Phase { WAITING, OPENING, HOLD, CLOSING, DONE }

	/** Yaşa göre aşama. {@code delay}: açılışa kalan bekleme (varış yarığı için). */
	public static Phase phase(int age, RiftStyle style) {
		if (age < 0) {
			return Phase.WAITING;
		}
		if (age < style.openTicks()) {
			return Phase.OPENING;
		}
		if (age < style.openTicks() + style.holdTicks()) {
			return Phase.HOLD;
		}
		if (age < style.totalTicks()) {
			return Phase.CLOSING;
		}
		return Phase.DONE;
	}

	/** Açılış ilerlemesi 0..1 (açılış bittikten sonra 1). */
	public static double openProgress(int age, RiftStyle style) {
		return clamp01((age + 1.0) / Math.max(1, style.openTicks()));
	}

	/** Kapanış ilerlemesi 0..1 (kapanış başlamadan 0). */
	public static double closeProgress(int age, RiftStyle style) {
		int start = style.openTicks() + style.holdTicks();
		return clamp01((age - start + 1.0) / Math.max(1, style.closeTicks()));
	}

	/**
	 * Yeni Shunpo ile eski yarığın hızla kapanması: yaş, bitişe en çok {@link RiftConfig#FORCED_CLOSE_TICKS} tick kalacak
	 * şekilde ilerletilir. Geri gitmez (zaten daha ileriyse aynı kalır).
	 */
	public static int forcedCloseAge(int age, RiftStyle style) {
		return Math.max(age, style.totalTicks() - RiftConfig.FORCED_CLOSE_TICKS);
	}

	/** Tek tick'lik parçacık bütçesinden {@code requested} kadarını verir (bütçe aşılırsa kalanı kadar). */
	public static int takeBudget(int requested, int remaining) {
		return Math.max(0, Math.min(requested, remaining));
	}

	public static int tickBudget() {
		float density = Math.max(0.0F, Math.min(2.0F, RiftConfig.DENSITY));
		return Math.round(RiftConfig.MAX_PARTICLES_PER_TICK * density);
	}

	/** Parçacık sayısına yoğunluk çarpanı uygular (en az 0). */
	public static int scaled(int count) {
		float density = Math.max(0.0F, Math.min(2.0F, RiftConfig.DENSITY));
		return Math.max(0, Math.round(count * density));
	}

	/** Başarılı ışınlanma SHUNPO görseli verir; başarısız girişim yalnızca küçük FAIL kıvılcımı (gerçek ışınlanma izlenimi yok). */
	public static RiftKind kindForOutcome(boolean teleported) {
		return teleported ? RiftKind.SHUNPO : RiftKind.FAIL;
	}

	/** Başarısız girişim kıvılcımı için oyuncu başına hız sınırı. */
	public static boolean failAllowed(long lastTick, long now) {
		return now - lastTick >= RiftConfig.FAIL_MIN_GAP_TICKS;
	}

	/** Aynı olayın kısa sürede tekrarı mı? (istemcideki çift işleme koruması) */
	public static boolean isDuplicate(long lastSignature, long lastTick, long signature, long now) {
		return signature == lastSignature && now - lastTick <= RiftConfig.DUPLICATE_WINDOW_TICKS;
	}

	/** Olay imzası: tür, oyuncu ve iki konumun ~0,25 blok çözünürlüklü değerleri. */
	public static long signature(int kind, int actor, double ax, double ay, double az, double bx, double by, double bz) {
		long h = 1125899906842597L;
		h = 31 * h + kind;
		h = 31 * h + actor;
		h = 31 * h + Math.round(ax * 4.0);
		h = 31 * h + Math.round(ay * 4.0);
		h = 31 * h + Math.round(az * 4.0);
		h = 31 * h + Math.round(bx * 4.0);
		h = 31 * h + Math.round(by * 4.0);
		h = 31 * h + Math.round(bz * 4.0);
		return h;
	}

	/** Paket içeriği güvenli mi? Bozuk/tuhaf veri hiçbir görsel üretmez. */
	public static boolean validPayload(int kindCode, int rank, double... coords) {
		if (RiftKind.byCode(kindCode) == null || rank < 0 || rank > 64) {
			return false;
		}
		for (double c : coords) {
			if (!Double.isFinite(c) || Math.abs(c) > 3.0E7) {
				return false;
			}
		}
		return true;
	}

	private static double clamp01(double v) {
		return Math.max(0.0, Math.min(1.0, v));
	}
}
