package com.battleaxe.shunpo;

/**
 * Shunpo kombosunun dengeleme ayarları. Süreler tick (20 tick = 1 sn).
 *
 * <p>Hasar: her vuruşun ham hasarı = oyuncunun o anki SALDIRI HASARI özniteliği (balta + rütbe + Hiddet bonusları
 * dahil) x vuruş çarpanı x (1 + kombo yüzdeleri). Ardından normal hasar hattından geçer: Ruh Ağı/Evrim çarpanları,
 * zırh, büyü koruması, direnç ve vuruş sonrası dokunulmazlık aynen işler. Vuruşlar "tam şarjlı saldırı" sayılmaz:
 * ağır vuruş ve rastgele kritik düğümleri kombo vuruşlarına uygulanmaz; bitirici vuruş sabit bir kritik olarak
 * çarpanına işlenmiştir (rastgelelik yok).
 */
public final class ComboConfig {
	private ComboConfig() {
	}

	/** false yaparsan Shunpo yalnızca eski davranışı (fırlatma konumuna ışınlan, baltayı al) uygular; kombo başlamaz. */
	public static final boolean ENABLED = true;

	/**
	 * Shunpo fırlatma konumuna döndürür; hedef bundan uzaksa kombo, hedefin hemen yanına kısa ve güvenli bir
	 * "yaklaşma adımı" atar. false: hedef vuruş menzilinde değilse kombo iptal olur (oyuncu fırlatma konumunda kalır).
	 */
	public static final boolean APPROACH_ENABLED = true;
	/** Yaklaşma adımının en çok kat edebileceği mesafe (blok). Daha uzak hedeflerde kombo başlamaz. */
	public static final double APPROACH_MAX_DISTANCE = 16.0;
	/** Yaklaşma adımında hedefin yanında aranan mesafeler (blok), sırayla. */
	public static final double[] APPROACH_RANGES = {2.0, 2.5, 1.6, 3.0};

	/** Bir vuruşun isabet edebilmesi için oyuncu-hedef en büyük mesafesi (blok). */
	public static final double STRIKE_REACH = 4.5;

	// Zamanlama
	public static final int APPROACH_DELAY_TICKS = 4;
	public static final int FIRST_DELAY_TICKS = 8;
	public static final int SECOND_DELAY_TICKS = 10;
	public static final int FINISH_DELAY_TICKS = 12;
	/** Komboya başlandıktan sonra bu süre geçerse kombo (ne olursa olsun) sonlanır. */
	public static final int TIMEOUT_TICKS = 90;

	// Hasar çarpanları (saldırı hasarı özniteliğine göre)
	public static final double FIRST_MULTIPLIER = 0.40;
	public static final double SECOND_MULTIPLIER = 0.50;
	/** Bitirici vuruş: sabit kritik dahil. */
	public static final double FINISH_MULTIPLIER = 1.25;
	/** Süpürme: bitirici vuruşun yanındaki ek hedeflere uygulanan hasar oranı. */
	public static final double SWEEP_MULTIPLIER = 0.60;
	public static final double SWEEP_RADIUS = 3.0;
	/** Toplam kombo yüzdesi (düğümler + Hiddet) bu sınırı aşmaz. */
	public static final double BONUS_CAP_PCT = 75.0;

	/** Hedef değiştirme yarıçapı (blok); düğümler artırır. */
	public static final double RETARGET_BASE_RADIUS = 4.0;

	/** Hiddet bedeli (HIDDET_COMBO_COST) ödendikten sonra canın en az bu kadar kalması gerekir; yoksa bedel ödenmez, bonus da verilmez. */
	public static final float COST_MIN_REMAINING_HEALTH = 3.0F;

	/** Bitirici öldürüş işareti (ek ruh): öldürme vuruşla AYNI tick içinde işlendiği için çok kısa tutulur. */
	public static final int FINISHER_MARK_TICKS = 2;
}
