package com.battleaxe.shunpo.vfx;

import net.minecraft.core.particles.DustColorTransitionOptions;

/**
 * Shunpo yarıklarının ve (uyum için) Yar Geç kesiklerinin ortak renk dili: koyu mor, kızıl, siyaha yakın gölge ve çok
 * sınırlı beyaz enerji. Tüm parçacıklar vanilla toz parçacığıdır (özel renderer yok).
 */
public final class RiftPalette {
	private RiftPalette() {
	}

	/** Yarığın içi: neredeyse siyah, çok hafif mor. */
	public static final DustColorTransitionOptions VOID = new DustColorTransitionOptions(0x180024, 0x020006, 1.25F);
	/** Sol kenar: koyu mor. */
	public static final DustColorTransitionOptions PURPLE = new DustColorTransitionOptions(0xA060FF, 0x2A0A58, 0.8F);
	/** Sağ kenar: koyu kızıl. */
	public static final DustColorTransitionOptions CRIMSON = new DustColorTransitionOptions(0xD01C34, 0x2E0008, 0.8F);
	/** İnce enerji damarı / kapanış çizgisi: beyazdan mora. */
	public static final DustColorTransitionOptions VEIN = new DustColorTransitionOptions(0xFFFFFF, 0xB070FF, 0.55F);
	/** Geçiş izi: ince, keskin. */
	public static final DustColorTransitionOptions TRAIL = new DustColorTransitionOptions(0xE8D8FF, 0x6A2BC0, 0.5F);
}
