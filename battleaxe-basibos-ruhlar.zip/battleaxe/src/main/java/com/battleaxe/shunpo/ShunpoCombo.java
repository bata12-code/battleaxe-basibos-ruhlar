package com.battleaxe.shunpo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.berserker.BerserkerEffects;
import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.berserker.HiddetRoar;
import com.battleaxe.effect.CritEffects;
import com.battleaxe.execution.ExecutionLogic;
import com.battleaxe.execution.ExecutionManager;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusApi;
import com.battleaxe.nexus.NexusDamage;
import com.battleaxe.nexus.NexusStats;
import com.battleaxe.nexus.Stat;
import com.battleaxe.shunpo.ComboLogic.FinishDecision;
import com.battleaxe.shunpo.ComboLogic.Phase;
import com.battleaxe.shunpo.ComboLogic.SecondDecision;
import com.battleaxe.shunpo.vfx.RiftKind;
import com.battleaxe.shunpo.vfx.ShunpoVfx;
import com.battleaxe.soul.SoulManager;

/**
 * <b>Shunpo kombosu</b>: başarılı bir Shunpo'dan sonra hedefe karşı kendiliğinden akan üç vuruşluk, DALLANAN saldırı.
 * Shunpo'nun kendi kuralları ({@link ShunpoManager}: geçerli mob isabeti, güvenli konum, tek hak, bekleme) aynen
 * korunur; kombo yalnızca bu kurallar sağlanıp ışınlanma gerçekten yapıldıktan sonra başlar. Blok/boşluk atışlarında
 * Shunpo da kombo da yoktur.
 *
 * <h3>Durum makinesi (oyuncu başına en çok bir kombo)</h3>
 * <pre>
 *  APPROACH (gerekirse) -> FIRST -> SECOND -> FINISH -> bitti
 *                                     |          |
 *                         (ana hedef öldü?)   (Execution uygun mu?)
 *                         HIT_MAIN | RETARGET | END      EXECUTION | HEAVY | FLOURISH
 * </pre>
 * <ul>
 *   <li><b>APPROACH:</b> Shunpo oyuncuyu FIRLATMA konumuna götürür; hedef vuruş menzilinden uzaksa kombo, hedefin
 *       hemen yanında güvenli bir yere (aynı güvenlik denetimiyle) kısa bir adım atar. Güvenli yer yoksa ya da hedef
 *       çok uzaksa kombo iptal olur; oyuncu fırlatma konumunda kalır (eski Shunpo sonucu).</li>
 *   <li><b>SECOND dalı:</b> ana hedef hayatta -> ana hedefte sürer; ana hedef öldü + Ruh Ağı'nda "Dallanan Adım"
 *       açık + yakında geçerli düşman var -> kombo başına BİR KEZ o düşmana geçer; aksi hâlde güvenle sonlanır.</li>
 *   <li><b>FINISH dalı:</b> hedef Execution'a uygunsa (Zombi/İskelet, can eşiği, mesafe, görüş, bekleme) bitirici
 *       animasyonu başlar ve kombo hasar vermez; değilse ağır, sabit kritik bitirici vuruş (+ varsa süpürme);
 *       hedef yoksa hasarsız bir son hareket.</li>
 * </ul>
 *
 * <h3>Hasar</h3>
 * Her vuruş tek hasar işlemidir (oyuncu adına, {@code PLAYER_ATTACK}); ölüm, ruh, loot, deneyim vanilla/mod
 * akışıyla BİR KEZ işlenir. Ayrıntı için {@link ComboConfig}. İstemci hiçbir şeye karar vermez; hedef, mesafe,
 * zamanlama ve oyuncu durumu her adımda sunucuda yeniden doğrulanır.
 */
public final class ShunpoCombo {
	private ShunpoCombo() {
	}

	private static final class Combo {
		final long id;
		final UUID player;
		final ResourceKey<Level> dimension;
		final long startTick;
		UUID target;
		Phase phase;
		Phase afterApproach = Phase.FIRST;
		long dueTick;
		boolean retargeted;
		double hiddetPct;

		Combo(long id, UUID player, ResourceKey<Level> dimension, long startTick, UUID target) {
			this.id = id;
			this.player = player;
			this.dimension = dimension;
			this.startTick = startTick;
			this.target = target;
		}
	}

	/** Oyuncu kimliği -> etkin kombo. */
	private static final Map<UUID, Combo> BY_PLAYER = new HashMap<>();
	private static long nextId = 1L;

	static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(ShunpoCombo::tick);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> BY_PLAYER.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> BY_PLAYER.clear());
	}

	/** Oyuncunun etkin kombosunu (varsa) güvenle sonlandırır. */
	static void cancel(ServerPlayer player) {
		if (BY_PLAYER.remove(player.getUUID()) != null && player.level() instanceof ServerLevel level) {
			ShunpoVfx.send(level, RiftKind.CANCEL, player, 0, player.position());
		}
	}

	public static boolean isActive(UUID player) {
		return BY_PLAYER.containsKey(player);
	}

	/** Başlatır; koşullar sağlanmıyorsa hiçbir şey yapmaz. Aynı oyuncudaki eski kombo güvenle sonlandırılır (üst üste çalışmaz). */
	static void start(ServerLevel level, ServerPlayer player, Mob target) {
		if (!ComboConfig.ENABLED || !isComboTarget(player, target) || !player.getMainHandItem().is(ModItems.BATTLE_AXE)) {
			return;
		}
		boolean inReach = ComboLogic.withinReach(player.distanceToSqr(target), ComboConfig.STRIKE_REACH);
		if (!inReach && !ComboLogic.approachAllowed(player.distanceTo(target))) {
			return;
		}
		BY_PLAYER.remove(player.getUUID());

		long now = level.getGameTime();
		Combo combo = new Combo(nextId++, player.getUUID(), level.dimension(), now, target.getUUID());
		NexusStats stats = NexusApi.stats(player);

		// Lanetli Bilinç: Hiddet aktifken bedel karşılığı kombo hasarı. Bedel ödenemezse bonus da yoktur.
		if (BerserkerManager.isActive(player)) {
			double cost = stats.get(Stat.HIDDET_COMBO_COST);
			if (ComboLogic.canPayCost(player.getHealth(), cost)) {
				if (cost > 0.0) {
					player.setHealth(player.getHealth() - (float) cost);
				}
				combo.hiddetPct = stats.get(Stat.HIDDET_COMBO_PCT);
			}
		}

		if (inReach) {
			combo.phase = Phase.FIRST;
			combo.dueTick = now + ComboConfig.FIRST_DELAY_TICKS;
		} else {
			combo.phase = Phase.APPROACH;
			combo.afterApproach = Phase.FIRST;
			combo.dueTick = now + ComboConfig.APPROACH_DELAY_TICKS;
		}
		BY_PLAYER.put(player.getUUID(), combo);
	}

	// ------------------------------------------------------------------
	// Tick
	// ------------------------------------------------------------------

	private static void tick(MinecraftServer server) {
		if (BY_PLAYER.isEmpty()) {
			return;
		}
		for (Combo combo : new ArrayList<>(BY_PLAYER.values())) {
			if (BY_PLAYER.get(combo.player) != combo) {
				continue; // bu arada başka bir olay tarafından değiştirildi
			}
			ServerPlayer player = server.getPlayerList().getPlayer(combo.player);
			if (player == null || !player.isAlive() || player.isSpectator() || !(player.level() instanceof ServerLevel level)
					|| level.dimension() != combo.dimension || !player.getMainHandItem().is(ModItems.BATTLE_AXE)
					|| ExecutionManager.isRunningFor(player.getUUID())
					|| ComboLogic.timedOut(level.getGameTime(), combo.startTick, ComboConfig.TIMEOUT_TICKS)) {
				BY_PLAYER.remove(combo.player);
				if (player != null && player.level() instanceof ServerLevel cancelLevel) {
					ShunpoVfx.send(cancelLevel, RiftKind.CANCEL, player, 0, player.position()); // bekleyen görseller kapanır
				}
				continue;
			}
			long now = level.getGameTime();
			if (now < combo.dueTick) {
				continue;
			}
			try {
				step(level, player, combo, now);
			} catch (RuntimeException e) {
				BY_PLAYER.remove(combo.player); // hata kombonun takılı kalmasına yol açmasın
				throw e;
			}
		}
	}

	private static void step(ServerLevel level, ServerPlayer player, Combo combo, long now) {
		switch (combo.phase) {
			case APPROACH -> stepApproach(level, player, combo, now);
			case FIRST -> {
				Mob target = liveMob(level, combo.target);
				if (target == null) {
					combo.phase = Phase.SECOND; // ana hedef daha ilk vuruştan önce gitti: dallanma kararı SECOND'da
					combo.dueTick = now;
					return;
				}
				strike(level, player, target, combo, Phase.FIRST);
				combo.phase = Phase.SECOND;
				combo.dueTick = now + ComboConfig.SECOND_DELAY_TICKS;
			}
			case SECOND -> stepSecond(level, player, combo, now);
			case FINISH -> stepFinish(level, player, combo);
		}
	}

	private static void stepApproach(ServerLevel level, ServerPlayer player, Combo combo, long now) {
		Mob target = liveMob(level, combo.target);
		if (target == null) {
			BY_PLAYER.remove(combo.player);
			return;
		}
		if (!ComboLogic.withinReach(player.distanceToSqr(target), ComboConfig.STRIKE_REACH) && !approach(level, player, target)) {
			BY_PLAYER.remove(combo.player); // güvenli yer yok: oyuncu olduğu yerde kalır
			return;
		}
		combo.phase = combo.afterApproach;
		combo.dueTick = now + (combo.phase == Phase.FIRST ? ComboConfig.FIRST_DELAY_TICKS : ComboConfig.APPROACH_DELAY_TICKS);
	}

	private static void stepSecond(ServerLevel level, ServerPlayer player, Combo combo, long now) {
		Mob main = liveMob(level, combo.target);
		NexusStats stats = NexusApi.stats(player);
		boolean retargetAllowed = stats.get(Stat.COMBO_RETARGET) > 0.0;
		Mob candidate = null;
		if (main == null && retargetAllowed && !combo.retargeted) {
			candidate = findCandidate(level, player, ComboLogic.retargetRadius(stats.get(Stat.COMBO_RETARGET_RADIUS)));
		}
		SecondDecision decision = ComboLogic.decideSecond(main != null, retargetAllowed, combo.retargeted, candidate != null);
		switch (decision) {
			case HIT_MAIN -> {
				strike(level, player, main, combo, Phase.SECOND);
				combo.phase = Phase.FINISH;
				combo.dueTick = now + ComboConfig.FINISH_DELAY_TICKS;
			}
			case RETARGET -> {
				combo.target = candidate.getUUID();
				combo.retargeted = true;
				flourish(level, player.position().add(0.0, 1.0, 0.0));
				if (ComboLogic.withinReach(player.distanceToSqr(candidate), ComboConfig.STRIKE_REACH)) {
					combo.dueTick = now + 2; // bir sonraki adımda HIT_MAIN (yeni hedef artık ana hedeftir)
				} else {
					combo.phase = Phase.APPROACH;
					combo.afterApproach = Phase.SECOND;
					combo.dueTick = now + ComboConfig.APPROACH_DELAY_TICKS;
				}
			}
			case END -> {
				flourish(level, player.position().add(0.0, 1.0, 0.0));
				BY_PLAYER.remove(combo.player);
			}
		}
	}

	private static void stepFinish(ServerLevel level, ServerPlayer player, Combo combo) {
		Mob main = liveMob(level, combo.target);
		boolean eligible = main != null && ExecutionManager.eligibleFromCombo(player, main);
		FinishDecision decision = ComboLogic.decideFinish(main != null, eligible);
		BY_PLAYER.remove(combo.player); // son adım: ne olursa olsun kombo biter (tek sefer)
		switch (decision) {
			case EXECUTION -> {
				// Bitirici animasyonu başlarsa hedef donar ve ölümcül darbe animasyonun sonunda tek sefer uygulanır.
				if (!ExecutionManager.beginFromCombo(player, main)) {
					finisher(level, player, main, combo);
				}
			}
			case HEAVY -> finisher(level, player, main, combo);
			case FLOURISH -> flourish(level, player.position().add(0.0, 1.0, 0.0));
		}
	}

	// ------------------------------------------------------------------
	// Vuruşlar
	// ------------------------------------------------------------------

	/** Bitirici ağır vuruş: sabit kritik, varsa süpürme. Ölüm kritik öldürüş sayılır (Hiddet kükremesi). */
	private static void finisher(ServerLevel level, ServerPlayer player, Mob target, Combo combo) {
		boolean hurt = strike(level, player, target, combo, Phase.FINISH);
		if (hurt) {
			CritEffects.play(level, player, target, false);
		}
		if (target.isDeadOrDying()) {
			HiddetRoar.onCriticalKill(level, player, target);
		}
		int sweepTargets = (int) NexusApi.stats(player).get(Stat.COMBO_SWEEP_TARGETS);
		if (sweepTargets > 0) {
			sweep(level, player, target, combo, sweepTargets);
		}
	}

	/**
	 * Tek hasar işlemi. Hasar hattı (Ruh Ağı/Evrim çarpanları, zırh, koruma, dokunulmazlık) normal çalışır; hedef
	 * vuruş sonrası dokunulmazlıktaysa vuruş etkisiz kalabilir (kombo yine sürer).
	 *
	 * @return hasar gerçekten uygulandıysa true
	 */
	private static boolean strike(ServerLevel level, ServerPlayer player, Mob target, Combo combo, Phase hit) {
		if (!ComboLogic.withinReach(player.distanceToSqr(target), ComboConfig.STRIKE_REACH + 1.0)) {
			return false;
		}
		NexusStats stats = NexusApi.stats(player);
		boolean finisher = hit == Phase.FINISH;
		double percent = stats.get(Stat.COMBO_DAMAGE_PCT) + combo.hiddetPct + (finisher ? stats.get(Stat.COMBO_FINISH_PCT) : 0.0);
		float amount = (float) ComboLogic.damage(player.getAttributeValue(Attributes.ATTACK_DAMAGE), ComboLogic.multiplier(hit), percent);
		if (!(amount > 0.0F)) {
			return false;
		}

		player.swing(InteractionHand.MAIN_HAND, true);
		DamageSource source = player.damageSources().source(DamageTypes.PLAYER_ATTACK, player);
		if (finisher) {
			// Ek ruh yalnızca BU öldürmeye yazılır (aynı tick içinde işlenir); ayrı bir ödül değildir.
			NexusApi.markFinisherKill(player, target.getUUID(), level.getGameTime() + ComboConfig.FINISHER_MARK_TICKS);
		}
		boolean hurt = target.hurtServer(level, source, amount);
		if (hurt) {
			target.knockback(finisher ? 0.6 : 0.25, player.getX() - target.getX(), player.getZ() - target.getZ(), source, amount);
			NexusDamage.onSuccessfulHit(player);
		}
		impact(level, player, target, hit);
		return hurt;
	}

	private static void sweep(ServerLevel level, ServerPlayer player, Mob main, Combo combo, int maxTargets) {
		NexusStats stats = NexusApi.stats(player);
		double percent = stats.get(Stat.COMBO_DAMAGE_PCT) + combo.hiddetPct + stats.get(Stat.COMBO_FINISH_PCT);
		float amount = (float) (ComboLogic.damage(player.getAttributeValue(Attributes.ATTACK_DAMAGE),
				ComboLogic.multiplier(Phase.FINISH), percent) * ComboConfig.SWEEP_MULTIPLIER);
		if (!(amount > 0.0F)) {
			return;
		}
		List<Mob> others = level.getEntitiesOfClass(Mob.class, main.getBoundingBox().inflate(ComboConfig.SWEEP_RADIUS),
				entity -> entity != main && entity.isAlive() && isComboTarget(player, entity));
		others.sort(Comparator.comparingDouble(entity -> entity.distanceToSqr(main)));
		DamageSource source = player.damageSources().source(DamageTypes.PLAYER_ATTACK, player);
		int hit = 0;
		for (Mob other : others) {
			if (hit >= maxTargets) {
				break;
			}
			if (!ComboLogic.withinReach(player.distanceToSqr(other), ComboConfig.STRIKE_REACH + 2.0)) {
				continue;
			}
			if (other.hurtServer(level, source, amount)) {
				NexusDamage.onSuccessfulHit(player);
				ShunpoVfx.send(level, RiftKind.COMBO_FIRST, player, SoulManager.rankOf(player.getMainHandItem()),
						player.position(), other.position().add(0.0, other.getBbHeight() * 0.5, 0.0));
				hit++;
			}
		}
	}

	// ------------------------------------------------------------------
	// Hedef / konum yardımcıları
	// ------------------------------------------------------------------

	/** Kombo yalnızca düşman mobları hedefler (Enemy ya da oyuncuyu hedef alan mob); sakin hayvan/köylüye vurmaz. */
	static boolean isComboTarget(ServerPlayer player, Mob mob) {
		return mob.isAlive() && !mob.isRemoved() && !mob.isSpectator() && mob.isAttackable() && !player.isAlliedTo(mob)
				&& (mob instanceof Enemy || mob.getTarget() == player);
	}

	private static Mob liveMob(ServerLevel level, UUID id) {
		Entity entity = level.getEntity(id);
		return entity instanceof Mob mob && mob.isAlive() && !mob.isRemoved() ? mob : null;
	}

	private static Mob findCandidate(ServerLevel level, ServerPlayer player, double radius) {
		List<Mob> list = level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(radius),
				entity -> isComboTarget(player, entity) && player.distanceToSqr(entity) <= radius * radius);
		list.sort(Comparator.comparingDouble(entity -> player.distanceToSqr(entity)));
		return list.isEmpty() ? null : list.get(0);
	}

	/** Hedefin yanında (oyuncu tarafında) güvenli bir yere kısa adım. Bulunamazsa false: kombo iptal. */
	private static boolean approach(ServerLevel level, ServerPlayer player, Mob target) {
		Vec3 from = player.position();
		Vec3 at = target.position();
		double dx = from.x - at.x;
		double dz = from.z - at.z;
		double length = Math.sqrt(dx * dx + dz * dz);
		if (length < 1.0E-4) {
			dx = 1.0;
			dz = 0.0;
			length = 1.0;
		}
		dx /= length;
		dz /= length;
		for (double range : ComboConfig.APPROACH_RANGES) {
			for (int dy : new int[] {0, 1, -1}) {
				Vec3 candidate = new Vec3(at.x + dx * range, at.y + dy, at.z + dz * range);
				if (!ShunpoManager.isSafe(level, player, from, candidate)) {
					continue;
				}
				float yaw = ExecutionLogic.yawToward(at.x - candidate.x, at.z - candidate.z);
				double horizontal = Math.hypot(at.x - candidate.x, at.z - candidate.z);
				float pitch = ComboLogic.pitchToward(horizontal, at.y + target.getBbHeight() * 0.5 - (candidate.y + player.getEyeHeight()));
				if (!ShunpoManager.teleport(level, player, candidate, yaw, pitch)) {
					return false;
				}
				ShunpoManager.effects(level, player, from, candidate, SoulManager.rankOf(player.getMainHandItem()));
				return true;
			}
		}
		return false;
	}

	// ------------------------------------------------------------------
	// Efektler (sade; yalnızca sunucudan parçacık/ses)
	// ------------------------------------------------------------------

	private static void impact(ServerLevel level, ServerPlayer player, Mob target, Phase hit) {
		boolean finisher = hit == Phase.FINISH;
		double x = target.getX();
		double y = target.getY(0.5);
		double z = target.getZ();
		// Görsel istemcide üretilir: 1. vuruş ince kesik, 2. vuruş belirgin çatlak, bitirici kapanış patlaması.
		RiftKind kind = finisher ? RiftKind.COMBO_FINISH : hit == Phase.SECOND ? RiftKind.COMBO_SECOND : RiftKind.COMBO_FIRST;
		ShunpoVfx.send(level, kind, player, SoulManager.rankOf(player.getMainHandItem()), player.position(), new Vec3(x, y, z));
		level.playSound(null, x, y, z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, finisher ? 0.9F : 0.6F, finisher ? 0.8F : 1.3F);
		if (finisher) {
			level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F, 1.5F);
		}
		BerserkerEffects.sendShake(player, finisher ? 0.35F : 0.12F, finisher ? 6 : 3);
	}

	private static void flourish(ServerLevel level, Vec3 at) {
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 6, 0.4, 0.4, 0.4, 0.15);
		level.playSound(null, at.x, at.y, at.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.4F, 1.6F);
	}
}
