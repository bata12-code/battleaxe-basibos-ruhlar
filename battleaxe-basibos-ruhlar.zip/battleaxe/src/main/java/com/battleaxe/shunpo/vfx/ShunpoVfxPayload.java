package com.battleaxe.shunpo.vfx;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan yakındaki istemcilere: "şu doğrulanmış olay oldu, şu konumlarda görselleştir". Parçacık taşımaz; konumlar
 * sunucunun gerçek (doğrulanmış) ışınlanma/isabet konumlarıdır. İstemci bu paketle HİÇBİR oyun durumunu değiştirmez.
 */
public record ShunpoVfxPayload(int kind, int actor, int rank, double ax, double ay, double az, double bx, double by,
		double bz) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<ShunpoVfxPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("shunpo_vfx"));

	/** Alan sayısı çok olduğundan elle yazılan kodek. */
	public static final StreamCodec<RegistryFriendlyByteBuf, ShunpoVfxPayload> CODEC = new StreamCodec<>() {
		@Override
		public ShunpoVfxPayload decode(RegistryFriendlyByteBuf buf) {
			return new ShunpoVfxPayload(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
					buf.readDouble(), buf.readDouble(), buf.readDouble(),
					buf.readDouble(), buf.readDouble(), buf.readDouble());
		}

		@Override
		public void encode(RegistryFriendlyByteBuf buf, ShunpoVfxPayload p) {
			buf.writeVarInt(p.kind());
			buf.writeVarInt(p.actor());
			buf.writeVarInt(p.rank());
			buf.writeDouble(p.ax());
			buf.writeDouble(p.ay());
			buf.writeDouble(p.az());
			buf.writeDouble(p.bx());
			buf.writeDouble(p.by());
			buf.writeDouble(p.bz());
		}
	};

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
