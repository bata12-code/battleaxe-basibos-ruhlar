package com.battleaxe.component;

import com.mojang.serialization.Codec;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.util.ExtraCodecs;

import com.battleaxe.BattleAxeMod;

/** Savaş Baltası'nın eşya üzerinde taşıdığı özel veri bileşenleri. */
public final class ModComponents {
	private ModComponents() {
	}

	/** "Ruh Bağı": baltayla öldürülen canlı sayısı. Tooltip'te rütbe olarak görünür; sadece kozmetik. */
	public static final DataComponentType<Integer> SOULS = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			BattleAxeMod.id("souls"),
			DataComponentType.<Integer>builder()
					.persistent(ExtraCodecs.NON_NEGATIVE_INT)
					.networkSynchronized(ByteBufCodecs.VAR_INT)
					.build()
	);

	/**
	 * Berserker görünüm bayrağı. Berserker aktifken ve balta ana eldeyken sunucu bunu ekler,
	 * aksi halde kaldırır; item model tanımı (items/battle_axe.json) bu bileşen varsa alevli
	 * modele geçer. Oyunu etkilemez, yalnızca görünümdür.
	 */
	public static final DataComponentType<Boolean> BERSERK = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			BattleAxeMod.id("berserk"),
			DataComponentType.<Boolean>builder()
					.persistent(Codec.BOOL)
					.networkSynchronized(ByteBufCodecs.BOOL)
					.build()
	);

	/** "Ruhdaş": baltanın ilk ruhu aldığı oyuncunun adı. Rütbe 1'den itibaren tooltip'te görünür. */
	public static final DataComponentType<String> OWNER = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			BattleAxeMod.id("owner"),
			DataComponentType.<String>builder()
					.persistent(Codec.STRING)
					.networkSynchronized(ByteBufCodecs.STRING_UTF8)
					.build()
	);

	/**
	 * Kara Çubuk sap yükseltmesi (kalıcı). Varsa balta siyah saplı görünür (item model tanımı bu bileşene
	 * bakar) ve ayrıca vanilla UNBREAKABLE bileşeniyle kırılmaz olur.
	 */
	public static final DataComponentType<Boolean> BLACK_HANDLE = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			BattleAxeMod.id("black_handle"),
			DataComponentType.<Boolean>builder()
					.persistent(Codec.BOOL)
					.networkSynchronized(ByteBufCodecs.BOOL)
					.build()
	);

	/**
	 * Ruh Ağı: bu baltanın ESKİ ruhlarının (güncellemeden önce biriken) bir oyuncunun ağ ilerlemesine
	 * sayıldığını gösterir. Her balta, eski ruhlarını yalnızca BİR KEZ ve yalnızca BİR oyuncuya
	 * kazandırabilir; böylece el değiştiren balta aynı ilerlemeyi tekrar tekrar üretemez.
	 */
	public static final DataComponentType<Boolean> NEXUS_CLAIMED = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			BattleAxeMod.id("nexus_claimed"),
			DataComponentType.<Boolean>builder()
					.persistent(Codec.BOOL)
					.networkSynchronized(ByteBufCodecs.BOOL)
					.build()
	);

	/** Sınıfın yüklenip bileşenlerin kaydedilmesini sağlar. */
	public static void initialize() {
	}
}
