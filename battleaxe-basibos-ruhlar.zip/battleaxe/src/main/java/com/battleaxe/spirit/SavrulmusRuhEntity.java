package com.battleaxe.spirit;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Savrulmuş Ruh: yakın dövüş avcısı. Hızlıdır, sürekli hareket eder, oyuncuyu rahat bırakmaz ve açık verince cezalandırır.
 *
 * <p>Davranış ({@link SavrulmusLogic}): oyuncunun çevresinde ani yön değişikliğiyle dönüp ARKAYA geçmeye çalışır; kombo hazır olunca
 * yaklaşır ve iki seri pençe vuruşu yapar, ardından geri çekilip yeni açı arar (kombolar arası bekleme: saldırı spam'i yok).
 * Uzak/orta mesafede, bekleme bitince <b>Ruh Sıçrayışı</b>: eğilip uyarı verir, kilitlediği YERE doğru sıçrar (hedefi takip etmez;
 * yana kaçılır), iniş sonrası kısa süre SAVUNMASIZdır (ek hasar alır). Hiçbir saldırı duvarların içinden vurmaz: pençe görüş hattı
 * ister, sıçrayış gerçek fizikle uçar.
 */
public class SavrulmusRuhEntity extends SpiritEntity {
	private final SavrulmusLogic.Brain brain = new SavrulmusLogic.Brain();

	private int strafeDir = 1;
	private int flipTimer;
	private boolean leapHit;

	public SavrulmusRuhEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, SavrulmusConfig.MAX_HEALTH)
				.add(Attributes.ARMOR, SavrulmusConfig.ARMOR)
				.add(Attributes.MOVEMENT_SPEED, SavrulmusConfig.MOVEMENT_SPEED)
				.add(Attributes.FOLLOW_RANGE, SavrulmusConfig.FOLLOW_RANGE)
				.add(Attributes.KNOCKBACK_RESISTANCE, SavrulmusConfig.KNOCKBACK_RESISTANCE)
				.add(Attributes.ATTACK_DAMAGE, SavrulmusConfig.ATTACK_DAMAGE)
				.add(Attributes.SAFE_FALL_DISTANCE, 32.0);
	}

	@Override
	public SpiritKind kind() {
		return SpiritKind.SAVRULMUS;
	}

	@Override
	protected boolean isExposed() {
		return brain.exposed();
	}

	@Override
	protected void onCleanup() {
		brain.abort();
	}

	// ------------------------------------------------------------------ Savaş

	@Override
	protected void tickSpirit(ServerLevel server) {
		LivingEntity target = getTarget();
		boolean has = validTarget(target);
		trackTarget(has ? target : null);

		double distance = has ? Math.sqrt(distanceToSqr(target)) : 0.0;
		boolean lineOfSight = has && getSensing().hasLineOfSight(target);
		boolean inReach = has && lineOfSight && distance <= SavrulmusConfig.CLAW_REACH;
		boolean landed = brain.attack() == SavrulmusLogic.Attack.LEAP_AIR && (onGround() || this.horizontalCollision);

		SavrulmusLogic.Event event = brain.step(new SavrulmusLogic.Inputs(has, distance, lineOfSight, inReach, landed, this.random.nextDouble()));
		switch (event) {
			case CLAW_WINDUP_START -> SpiritFx.sound(server, this, SoundEvents.VEX_CHARGE, 0.7F, 1.6F);
			case CLAW_HIT -> claw(server, has ? target : null, inReach);
			case LEAP_WINDUP_START -> {
				getNavigation().stop();
				SpiritFx.sound(server, this, SoundEvents.VEX_CHARGE, 1.0F, 0.6F);
				SpiritFx.sound(server, this, SoundEvents.ENDERMAN_STARE, 0.5F, 1.8F);
			}
			case LEAP_LAUNCH -> launchLeap(server, target);
			case LEAP_LANDED -> {
				SpiritFx.shatterTick(server, this, 0);
				SpiritFx.sound(server, this, SoundEvents.VEX_HURT, 0.6F, 0.5F);
			}
			default -> {
			}
		}

		switch (brain.attack()) {
			case CLAW_WINDUP, CLAW_SWING, LEAP_RECOVER -> {
				getNavigation().stop();
				if (has) {
					faceTarget(target);
				}
			}
			case RETREAT -> retreat(target, has);
			case LEAP_WINDUP -> {
				getNavigation().stop();
				if (has && brain.progress() < 0.75F) {
					faceTarget(target); // doğrultu son anda kilitlenir: oyuncu yana kaçabilir
				}
				if (this.tickCount % 2 == 0) {
					leapTelegraph(server);
				}
			}
			case LEAP_AIR -> leapAirTick(server, has ? target : null);
			case IDLE -> stalk(target, has, distance);
		}

		syncState(brain.attack().ordinal(), brain.progress(), brain.exposed());
	}

	/** Çevresinde dönme: ani yön değişimi, arkaya geçme eğilimi; kombo hazırsa daralan çember. */
	private void stalk(LivingEntity target, boolean has, double distance) {
		if (!has) {
			return;
		}
		faceTarget(target);
		if (this.tickCount % SavrulmusConfig.REPLAN_TICKS != 0) {
			return;
		}
		if (distance > SavrulmusConfig.FAR_DISTANCE) {
			getNavigation().moveTo(target, SavrulmusConfig.APPROACH_SPEED);
			return;
		}
		flipTimer -= SavrulmusConfig.REPLAN_TICKS;
		if (flipTimer <= 0) {
			flipTimer = SavrulmusConfig.FLIP_MIN_TICKS + this.random.nextInt(SavrulmusConfig.FLIP_MAX_TICKS - SavrulmusConfig.FLIP_MIN_TICKS + 1);
			if (this.random.nextDouble() < SavrulmusConfig.BACKSTAB_BIAS) {
				double from = SpiritLogic.angleAround(getX(), getZ(), target.getX(), target.getZ());
				strafeDir = SpiritLogic.shortestArcSign(from, SpiritLogic.backAngle(target.getYRot()));
			} else {
				strafeDir = this.random.nextBoolean() ? 1 : -1;
			}
		}
		boolean comboReady = brain.comboCooldown() == 0;
		double radius = comboReady ? SavrulmusConfig.COMBO_APPROACH_RADIUS : SavrulmusConfig.STRAFE_RADIUS;
		double speed = comboReady ? SavrulmusConfig.APPROACH_SPEED : SavrulmusConfig.STRAFE_SPEED;
		double[] p = SpiritLogic.orbitPoint(getX(), getZ(), target.getX(), target.getZ(), radius, strafeDir * SavrulmusConfig.STRAFE_ANGLE_STEP);
		if (!getNavigation().moveTo(p[0], target.getY(), p[1], speed)) {
			getNavigation().moveTo(target, speed);
		}
	}

	private void retreat(LivingEntity target, boolean has) {
		if (has) {
			faceTarget(target);
		}
		if (this.tickCount % 4 != 0) {
			return;
		}
		Vec3 away = has ? awayFrom(target) : forward().scale(-1.0);
		getNavigation().moveTo(getX() + away.x * 6.0, getY(), getZ() + away.z * 6.0, SavrulmusConfig.RETREAT_SPEED);
	}

	/** Pençe vuruşu: menzilde ve görüş hattı varsa hasar; ıskalarsa yalnızca ses/görsel. */
	private void claw(ServerLevel server, LivingEntity target, boolean inReach) {
		Vec3 forward = forward();
		Vec3 hand = position().add(forward.scale(1.1)).add(0.0, getBbHeight() * 0.6, 0.0);
		SpiritFx.sound(server, this, SoundEvents.PLAYER_ATTACK_SWEEP, 0.7F, 1.5F);
		server.sendParticles(SpiritFx.PALE, hand.x, hand.y, hand.z, 6, 0.35, 0.25, 0.35, 0.0);
		if (target == null || !inReach) {
			return;
		}
		float damage = SavrulmusConfig.CLAW_DAMAGE_MIN
				+ this.random.nextFloat() * (SavrulmusConfig.CLAW_DAMAGE_MAX - SavrulmusConfig.CLAW_DAMAGE_MIN);
		strike(server, target, damage, SavrulmusConfig.CLAW_KNOCKBACK);
	}

	private void strike(ServerLevel server, LivingEntity victim, float damage, double knockback) {
		DamageSource source = damageSources().mobAttack(this);
		if (victim.hurtServer(server, source, damage)) {
			victim.knockback(knockback, getX() - victim.getX(), getZ() - victim.getZ(), source, damage);
		}
	}

	// ------------------------------------------------------------------ Ruh Sıçrayışı

	private void leapTelegraph(ServerLevel server) {
		double p = brain.progress();
		// Hazırlık: ayaklarının altında toplanan koyu halka + yükselen soluk kıvılcımlar
		SpiritFx.ring(server, getX(), getY() + 0.1, getZ(), 1.2 - 0.7 * p, 8, SpiritFx.VIOLET);
		server.sendParticles(SpiritFx.PALE, getX(), getY() + 0.9, getZ(), 2, 0.25, 0.4, 0.25, 0.0);
	}

	private void launchLeap(ServerLevel server, LivingEntity target) {
		if (target == null) {
			return;
		}
		Vec3 to = new Vec3(target.getX() - getX(), 0.0, target.getZ() - getZ());
		double length = to.length();
		if (length < 1.0E-3) {
			return;
		}
		Vec3 direction = to.scale(1.0 / length);
		double speed = SpiritLogic.leapSpeed(length); // hedefin O ANKİ yeri: takip yok, yana kaçılır
		getNavigation().stop();
		setDeltaMovement(direction.x * speed, SavrulmusConfig.LEAP_VERTICAL_SPEED, direction.z * speed);
		leapHit = false;
		SpiritFx.sound(server, this, SoundEvents.PHANTOM_SWOOP, 0.9F, 1.2F);
		server.sendParticles(SpiritFx.DARK, getX(), getY() + 0.4, getZ(), 12, 0.3, 0.2, 0.3, 0.05);
	}

	private void leapAirTick(ServerLevel server, LivingEntity target) {
		getNavigation().stop();
		server.sendParticles(SpiritFx.VIOLET, getX(), getY() + getBbHeight() * 0.5, getZ(), 3, 0.2, 0.3, 0.2, 0.0);
		if (leapHit) {
			return;
		}
		for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.4, 0.3, 0.4), e -> e != this)) {
			boolean valid = victim == target || (victim instanceof Player player && validTarget(player));
			if (!valid || !victim.isAlive()) {
				continue;
			}
			leapHit = true;
			strike(server, victim, SavrulmusConfig.LEAP_DAMAGE, SavrulmusConfig.LEAP_KNOCKBACK);
			Vec3 motion = getDeltaMovement();
			setDeltaMovement(motion.x * 0.3, motion.y, motion.z * 0.3);
			break;
		}
	}

	// ------------------------------------------------------------------ Ses kimliği: kesik, boğuk fısıltılar; ani hareket sesleri

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.VEX_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.VEX_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.VEX_DEATH;
	}
}
