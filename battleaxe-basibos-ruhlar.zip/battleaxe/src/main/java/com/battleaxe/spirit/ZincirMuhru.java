package com.battleaxe.spirit;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Zincir Mührü: Zincirli Ruh'un oyuncuya fırlattığı ruhsal zincirin ucu.
 *
 * <p>Ayrı bir varlık DEĞİLDİR: Zincirli Ruh'un içinde sunucuda simüle edilen hafif bir nesnedir (ruh ölünce yok olur). Düz bir
 * doğrultuda uçar ve hedefi TAKİP ETMEZ (atış doğrultusu hazırlığın sonunda kilitlenir): oyuncu yana kaçarak önleyebilir. Her
 * adımda 3 alt adımla ilerler (tünelleme olmaz); bloklar zinciri durdurur (duvarın ardından mühür olmaz). Zincirin kendisi,
 * ruhun elinden ucuna uzanan parçacık çizgisidir.
 */
final class ZincirMuhru {
	enum Outcome {
		FLYING, HIT_PLAYER, HIT_BLOCK, EXPIRED, LOST
	}

	private static final int SUBSTEPS = 3;

	private final Vec3 origin;
	private Vec3 position;
	private final Vec3 velocity;
	private int age;

	/** Sonuç HIT_* ise çarpma noktası; HIT_PLAYER ise vurulan oyuncu. */
	private Vec3 impact;
	private Player victim;

	ZincirMuhru(Vec3 start, Vec3 velocity) {
		this.origin = start;
		this.position = start;
		this.velocity = velocity;
	}

	Vec3 position() {
		return position;
	}

	Vec3 impact() {
		return impact;
	}

	Player victim() {
		return victim;
	}

	/** {@code hand}: ruhun elinin o anki konumu (zincir buradan uzanır). */
	Outcome step(ServerLevel level, Vec3 hand) {
		age++;
		if (age > ZincirliConfig.CHAIN_MAX_THROW_TICKS || position.distanceTo(origin) > ZincirliConfig.CHAIN_MAX_DISTANCE) {
			impact = position;
			return Outcome.EXPIRED;
		}

		Vec3 sub = velocity.scale(1.0 / SUBSTEPS);
		for (int i = 0; i < SUBSTEPS; i++) {
			Vec3 next = position.add(sub);
			BlockPos blockPos = BlockPos.containing(next);
			if (!level.hasChunkAt(blockPos)) {
				return Outcome.LOST;
			}

			var state = level.getBlockState(blockPos);
			if (!state.getCollisionShape(level, blockPos).isEmpty()) {
				impact = position;
				return Outcome.HIT_BLOCK;
			}

			double r = ZincirliConfig.CHAIN_HIT_RADIUS;
			AABB box = new AABB(next.x - r, next.y - r, next.z - r, next.x + r, next.y + r, next.z + r);
			for (Player player : level.getEntitiesOfClass(Player.class, box, p -> p.isAlive() && !p.isSpectator())) {
				victim = player;
				impact = next;
				return Outcome.HIT_PLAYER;
			}
			position = next;
		}

		// Zincir: elden uca seyrek çizgi + uçta tek parlak nokta (ölçülü)
		SpiritFx.line(level, hand, position, 1.0, SpiritFx.PALE);
		level.sendParticles(SpiritFx.VIOLET, position.x, position.y, position.z, 2, 0.05, 0.05, 0.05, 0.0);
		return Outcome.FLYING;
	}
}
