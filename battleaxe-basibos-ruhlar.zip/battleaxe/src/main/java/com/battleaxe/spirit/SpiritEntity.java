package com.battleaxe.spirit;

import java.util.UUID;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusDamage;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * Başıboş Ruhlar'ın ortak tabanı: kendi boyutlarını terk edip bu dünyaya sürüklenmiş, amacını yitirmiş düşmanca ruhsal varlıklar.
 * (Burada gördüklerimiz güçlerinin yalnızca soluk bir kısmıdır; kendi dünyalarındaki türleri çok daha korkunçtur.)
 *
 * <p>Taban sınıf şunları sağlar: senkronlanan animasyon durumu, hedef hızı takibi (önden nişan için), ruhsal doğaya göre hasar
 * ayarı (mermiye direnç; Savaş Baltası bedeni keser; savunmasız anlarda ek hasar), sabit ruh ödülü, ölümde parçalanarak dağılma
 * ve ortak hedefleme. Türler yalnızca {@link #tickSpirit} içindeki savaş davranışını ve {@link SpiritKind} kimliğini tanımlar.
 *
 * <p>Tüm savaş kararları ve hasar yalnızca SUNUCUDA verilir; istemci durumu ve ilerlemeyi okuyup canlandırır.
 */
public abstract class SpiritEntity extends Monster {
	/** Saldırı durumu (türün Attack enum sırası). İstemci animasyonu için okur. */
	private static final EntityDataAccessor<Integer> DATA_STATE =
			SynchedEntityData.defineId(SpiritEntity.class, EntityDataSerializers.INT);
	/** Durumun ilerlemesi, yüzde (0-100). */
	private static final EntityDataAccessor<Integer> DATA_PROGRESS =
			SynchedEntityData.defineId(SpiritEntity.class, EntityDataSerializers.INT);
	/** Savunmasız mı (istemci için: gövde titrer/solar). */
	private static final EntityDataAccessor<Boolean> DATA_EXPOSED =
			SynchedEntityData.defineId(SpiritEntity.class, EntityDataSerializers.BOOLEAN);

	private Vec3 lastTargetPos;
	private UUID lastTargetId;
	private Vec3 targetVelocity = Vec3.ZERO;

	protected SpiritEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
	}

	/** Bu varlığın ruh türü. */
	public abstract SpiritKind kind();

	/** Sunucu tarafı savaş tick'i (hayattayken, her tick). */
	protected abstract void tickSpirit(ServerLevel server);

	/** Şu an savunmasız mı (türün durum makinesinden). */
	protected abstract boolean isExposed();

	/** Ölümde/kaldırılırken: türün tuttuğu mermi, izin ve mühürleri bırakması için. */
	protected abstract void onCleanup();

	/** Savaş sırasında alınan hasar (ayarlanmış miktar); türler bağ kopması gibi tepkiler için kullanır. */
	protected void onSpiritHurt(ServerLevel level, DamageSource source, float adjusted, int axeRank) {
	}

	/** Baltaya verilen ruh ödülü (sabit; can formülüne bağlı DEĞİL). */
	public int getSoulReward() {
		return SpiritConfig.SOUL_REWARD_ENABLED ? kind().soulReward() : 0;
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_STATE, 0);
		builder.define(DATA_PROGRESS, 0);
		builder.define(DATA_EXPOSED, false);
	}

	/** İstemci animasyonu: türün Attack enum sırası. */
	public int getSpiritState() {
		return this.entityData.get(DATA_STATE);
	}

	/** İstemci animasyonu: durum ilerlemesi (0-1). */
	public float getSpiritProgress() {
		return this.entityData.get(DATA_PROGRESS) / 100.0F;
	}

	public boolean isSpiritExposed() {
		return this.entityData.get(DATA_EXPOSED);
	}

	protected void syncState(int state, float progress, boolean exposed) {
		if (this.entityData.get(DATA_STATE) != state) {
			this.entityData.set(DATA_STATE, state);
		}
		int percent = Math.max(0, Math.min(100, Math.round(progress * 100.0F)));
		if (this.entityData.get(DATA_PROGRESS) != percent) {
			this.entityData.set(DATA_PROGRESS, percent);
		}
		if (this.entityData.get(DATA_EXPOSED) != exposed) {
			this.entityData.set(DATA_EXPOSED, exposed);
		}
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		// Gezinme yalnızca hedef yokken: savaşta hareketi türün kendi mantığı yürütür.
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8) {
			@Override
			public boolean canUse() {
				return SpiritEntity.this.getTarget() == null && super.canUse();
			}

			@Override
			public boolean canContinueToUse() {
				return SpiritEntity.this.getTarget() == null && super.canContinueToUse();
			}
		});
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		// Oyuncuyu GÖRDÜĞÜ anda hedefler (tereddüt, dostluk veya kaçış yok).
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	// ------------------------------------------------------------------ Hasar: ruhsal doğa

	/**
	 * Hasarı Savaş Baltası veriyorsa baltanın ruh rütbesi (0-9), değilse -1. Yakın vuruş ve Yar Geç (doğrudan saldıran oyuncu,
	 * ana elde balta) ile fırlatılan balta (Shunpo/Loyalty) sayılır; ok gibi mermiler sayılmaz.
	 */
	public static int axeRank(DamageSource source) {
		if (!(source.getEntity() instanceof ServerPlayer player)) {
			return -1;
		}
		ThrownBattleAxe thrown = ThrownBattleAxe.activeHit();
		if (thrown != null && player.getUUID().equals(thrown.getOwnerUuid())) {
			return SoulManager.rankOf(thrown.getItem());
		}
		if (source.getDirectEntity() == player) {
			ItemStack held = player.getMainHandItem();
			if (held.is(ModItems.BATTLE_AXE)) {
				return SoulManager.rankOf(held);
			}
		}
		return -1;
	}

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		// Ruh Ağı hasar ölçeklemesi kendi hurtServer çağrısını yeniden girer: aynı hasara ikinci kez direnç uygulanmasın.
		if (NexusDamage.isBusy()) {
			return super.hurtServer(level, source, amount);
		}
		int axeRank = axeRank(source);
		float adjusted = SpiritLogic.incoming(amount, source.is(DamageTypeTags.IS_PROJECTILE), axeRank, isExposed());
		boolean hurt = super.hurtServer(level, source, adjusted);
		if (hurt) {
			onSpiritHurt(level, source, adjusted, axeRank);
		}
		return hurt;
	}

	// ------------------------------------------------------------------ Hedef takibi

	protected static boolean validTarget(LivingEntity target) {
		return target != null && target.isAlive() && !(target instanceof Player player && (player.isSpectator() || player.isCreative()));
	}

	/** Hedefin KENDİ izlediğimiz hızı (blok/tick; ışınlanmalar yok sayılır). Sunucudaki oyuncu hızı güvenilmez, bu yüzden elle izlenir. */
	protected Vec3 targetVelocity() {
		return targetVelocity;
	}

	protected void trackTarget(LivingEntity target) {
		if (target == null) {
			lastTargetPos = null;
			lastTargetId = null;
			targetVelocity = Vec3.ZERO;
			return;
		}
		Vec3 pos = target.position();
		if (lastTargetPos != null && target.getUUID().equals(lastTargetId)) {
			Vec3 delta = pos.subtract(lastTargetPos);
			if (delta.lengthSqr() < 16.0) {
				double s = SpiritConfig.TARGET_VELOCITY_SMOOTHING;
				targetVelocity = targetVelocity.scale(1.0 - s).add(delta.scale(s));
			} else {
				targetVelocity = Vec3.ZERO; // ışınlanma (Shunpo vb.): hız tahmini sıfırlanır
			}
		} else {
			targetVelocity = Vec3.ZERO;
		}
		lastTargetPos = pos;
		lastTargetId = target.getUUID();
	}

	protected void faceTarget(LivingEntity target) {
		if (target != null) {
			getLookControl().setLookAt(target, 30.0F, 30.0F);
		}
	}

	/** Ruhun baktığı yatay yön (birim vektör). */
	protected Vec3 forward() {
		double yaw = Math.toRadians(getYRot());
		return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
	}

	/** Ruhun hedeften uzaklaşma yönü (yatay, birim); hedef üstündeyse bakışın tersi. */
	protected Vec3 awayFrom(LivingEntity target) {
		Vec3 away = new Vec3(getX() - target.getX(), 0.0, getZ() - target.getZ());
		if (away.lengthSqr() < 1.0E-4) {
			return forward().scale(-1.0);
		}
		return away.normalize();
	}

	protected Vec3 chestOf(LivingEntity target) {
		return target.position().add(0.0, target.getBbHeight() * 0.6, 0.0);
	}

	// ------------------------------------------------------------------ Yaşam döngüsü

	@Override
	public void aiStep() {
		super.aiStep();
		if (!(level() instanceof ServerLevel server)) {
			return;
		}
		if (isDeadOrDying()) {
			// Ruhsal beden düşmez: parçalanarak dağılır (istemci modeli de bunu çizer).
			int t = this.deathTime;
			if (t % 2 == 0 || t >= SpiritConfig.DEATH_TICKS - 3) {
				SpiritFx.shatterTick(server, this, t);
			}
			return;
		}
		if (!isAlive()) {
			return;
		}
		tickSpirit(server);
		if (this.tickCount % 6 == 0) {
			SpiritFx.wisp(server, this);
		}
	}

	@Override
	public void die(DamageSource source) {
		onCleanup();
		super.die(source);
		if (level() instanceof ServerLevel server) {
			SpiritFx.shatterBurst(server, this);
		}
	}

	@Override
	public int getAmbientSoundInterval() {
		return 160;
	}
}
