package com.battleaxe.spirit;

/**
 * Başıboş Ruh ailesinin türleri (SAF; Minecraft'tan bağımsız). Yeni bir ruh türü eklemek: buraya bir satır, ardından
 * {@code ModSpiritTypes} içine kayıt. Kayıt defteri kimlikleri DEĞİŞTİRİLMEMELİDİR (dünyalarda kayıtlı varlıklar bunlara bağlıdır).
 *
 * <p>Bu ilk üç tür, ruhların kendi boyutlarındaki GERÇEK güçlerinin yalnızca soluk bir kısmıdır (boyut geçişinde güç kaybettiler).
 * Ruhlar boyutundaki çok daha güçlü türler ileride eklenecektir; bu enum o genişleme için ortak kimlik noktasıdır.
 */
public enum SpiritKind {
	SAVRULMUS("savrulmus_ruh", "Yakın dövüş avcısı"),
	RUH_YIYEN("ruh_yiyen", "Menzilli avcı"),
	ZINCIRLI("zincirli_ruh", "Ağır muhafız");

	private final String id;
	private final String role;

	SpiritKind(String id, String role) {
		this.id = id;
		this.role = role;
	}

	/** Kayıt defteri yolu ("battleaxe:" ön ekiyle kullanılır), komut seçeneği ve dil anahtarı. */
	public String id() {
		return id;
	}

	public String role() {
		return role;
	}

	/** Baltaya verilen sabit ruh ödülü (bkz. {@link SpiritConfig}). */
	public int soulReward() {
		return switch (this) {
			case SAVRULMUS -> SpiritConfig.SAVRULMUS_SOUL;
			case RUH_YIYEN -> SpiritConfig.RUH_YIYEN_SOUL;
			case ZINCIRLI -> SpiritConfig.ZINCIRLI_SOUL;
		};
	}

	public static SpiritKind byId(String id) {
		for (SpiritKind kind : values()) {
			if (kind.id.equals(id)) {
				return kind;
			}
		}
		return null;
	}
}
