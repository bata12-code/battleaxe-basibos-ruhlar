package com.battleaxe.spirit;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

/**
 * Kontrol yeteneği koordinasyonu: bir hedefe aynı anda yalnızca TEK ruh kontrol yeteneği (Ruh Emdirme veya Zincirle Mühürleme)
 * uygulayabilir; biri bitince {@link SpiritConfig#CONTROL_GAP_TICKS} boşluk bırakılır. Böylece ruhlar birbirinin rollerini
 * tamamlar (biri kısıtlarken diğeri yakın/uzak baskı kurar) ama oyuncuya kaçış imkânı bırakmayan bir kontrol zinciri kurmaz.
 * Sıradan saldırılar (pençe, ruh oku, savurma) bu izne tabi DEĞİLDİR; kendi bekleme süreleri vardır.
 *
 * <p>Yalnızca sunucu iş parçacığında kullanılır. Durum oyun saatine bağlıdır; saat geriye giderse (dünya değişimi) izin serbest sayılır.
 */
public final class SpiritCoordinator {
	private SpiritCoordinator() {
	}

	private record Claim(UUID owner, long start, long until) {
	}

	private static final Map<UUID, Claim> CLAIMS = new HashMap<>();

	public static void initialize() {
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> CLAIMS.clear());
	}

	/** {@code owner} bu hedefe kontrol yeteneği başlatabilir mi (hedefte başkasının izni yoksa veya süresi dolduysa). */
	public static boolean canClaim(UUID target, UUID owner, long now) {
		Claim claim = CLAIMS.get(target);
		if (claim == null || claim.owner.equals(owner) || now < claim.start || now >= claim.until) {
			return true;
		}
		return false;
	}

	/** İzni alır (öncesinde {@link #canClaim} denetlenmiş olmalı). {@code duration}: en uzun beklenen süre. */
	public static void claim(UUID target, UUID owner, long now, int duration) {
		CLAIMS.put(target, new Claim(owner, now, now + duration + SpiritConfig.CONTROL_GAP_TICKS));
	}

	/** Yetenek bitti: izin kısa bir boşlukla sona erer (erken bitişte kalan süre kısalır). */
	public static void release(UUID target, UUID owner, long now) {
		Claim claim = CLAIMS.get(target);
		if (claim != null && claim.owner.equals(owner)) {
			CLAIMS.put(target, new Claim(owner, Math.min(claim.start, now), now + SpiritConfig.CONTROL_GAP_TICKS));
		}
	}

	/** Ruh öldü/kaldırıldı: tuttuğu bütün izinler hemen serbest kalır. */
	public static void forget(UUID owner) {
		CLAIMS.values().removeIf(claim -> claim.owner.equals(owner));
	}
}
