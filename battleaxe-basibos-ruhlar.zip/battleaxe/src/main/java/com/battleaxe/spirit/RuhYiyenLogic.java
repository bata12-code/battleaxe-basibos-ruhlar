package com.battleaxe.spirit;

/**
 * Ruh Yiyen'in savaş mantığı: SAF durum makinesi (test: tools/test/SpiritBrainTest.java).
 *
 * <p>İki saldırı: Ruh Oku (sık, menzilli) ve Ruh Emdirme (nadir, bağlantılı; hasar + sınırlı iyileşme). Emme bağı şu yollarla
 * KOPAR: görüş hattı {@link RuhYiyenConfig#DRAIN_LOS_GRACE_TICKS} tick kesilirse, mesafe aşılırsa, tek seferde yeterince hasar
 * alınırsa ({@link RuhYiyenConfig#DRAIN_INTERRUPT_DAMAGE}) veya hedef kaybolursa. Kopma geri tepmesi ruhu savunmasız bırakır.
 */
public final class RuhYiyenLogic {
	private RuhYiyenLogic() {
	}

	/** Anlık durum (istemciye sıra numarasıyla senkronlanır; SIRAYI DEĞİŞTİRME). */
	public enum Attack {
		IDLE,
		BOLT_WINDUP,
		BOLT_RELEASE,
		DRAIN_WINDUP,
		DRAIN_CHANNEL,
		DRAIN_RECOVER;

		public static Attack byOrdinal(int ordinal) {
			Attack[] values = values();
			return ordinal >= 0 && ordinal < values.length ? values[ordinal] : IDLE;
		}
	}

	public enum Event {
		NONE,
		BOLT_WINDUP_START,
		BOLT_FIRE,
		DRAIN_WINDUP_START,
		DRAIN_LINK,
		DRAIN_PULSE,
		/** Bağ süresi doldu (normal bitiş). */
		DRAIN_END,
		/** Bağ zorla koptu (görüş/mesafe/hasar/hedef). */
		DRAIN_BROKEN,
		/** Bağ hiç kurulamadı (hazırlık sırasında kesildi veya koşullar bozuldu). */
		DRAIN_CANCELLED
	}

	/**
	 * @param claimOk     bu hedefe kontrol yeteneği uygulama izni var (koordinasyon; bkz. SpiritCoordinator)
	 * @param interrupted bağlantı/hazırlık sırasında alınan hasar eşiği aştı
	 */
	public record Inputs(boolean hasTarget, double distance, boolean lineOfSight, boolean claimOk, boolean interrupted,
			double healthRatio, double roll) {
	}

	public static final class Brain {
		private Attack attack = Attack.IDLE;
		private int ticksLeft;
		private int phaseTotal;
		private int boltCooldown = RuhYiyenConfig.BOLT_INITIAL_COOLDOWN_TICKS;
		private int drainCooldown = RuhYiyenConfig.DRAIN_INITIAL_COOLDOWN_TICKS;
		private int globalGap;
		private int lostSight;
		private int pulseTimer;

		public Attack attack() {
			return attack;
		}

		public boolean isIdle() {
			return attack == Attack.IDLE;
		}

		/** Emme kopması/bitişi sonrası yorgunluk: ruh bu sürede ek hasar alır. */
		public boolean exposed() {
			return attack == Attack.DRAIN_RECOVER;
		}

		public int boltCooldown() {
			return boltCooldown;
		}

		public int drainCooldown() {
			return drainCooldown;
		}

		public int globalGap() {
			return globalGap;
		}

		public float progress() {
			if (phaseTotal <= 0 || attack == Attack.IDLE) {
				return 0.0F;
			}
			return (float) SpiritLogic.clamp(1.0 - (double) ticksLeft / phaseTotal, 0.0, 1.0);
		}

		/** Ruh öldü/hedef yok: saldırıyı güvenle sonlandırır; bekleme süreleri KORUNUR. */
		public void abort() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			lostSight = 0;
		}

		public Event step(Inputs in) {
			boltCooldown = Math.max(0, boltCooldown - 1);
			drainCooldown = Math.max(0, drainCooldown - 1);
			globalGap = Math.max(0, globalGap - 1);

			switch (attack) {
				case BOLT_WINDUP -> {
					if (--ticksLeft <= 0) {
						boltCooldown = RuhYiyenConfig.BOLT_COOLDOWN_TICKS;
						begin(Attack.BOLT_RELEASE, RuhYiyenConfig.BOLT_RELEASE_TICKS);
						return Event.BOLT_FIRE;
					}
					return Event.NONE;
				}
				case BOLT_RELEASE -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				case DRAIN_WINDUP -> {
					if (in.interrupted()) {
						drainCooldown = RuhYiyenConfig.DRAIN_FAIL_COOLDOWN_TICKS;
						finish();
						return Event.DRAIN_CANCELLED;
					}
					if (--ticksLeft <= 0) {
						boolean ok = in.hasTarget() && in.lineOfSight() && in.claimOk()
								&& in.distance() <= RuhYiyenConfig.DRAIN_START_RANGE + 3.0;
						if (ok) {
							lostSight = 0;
							pulseTimer = RuhYiyenConfig.DRAIN_PULSE_INTERVAL_TICKS / 2;
							begin(Attack.DRAIN_CHANNEL, RuhYiyenConfig.DRAIN_CHANNEL_TICKS);
							return Event.DRAIN_LINK;
						}
						drainCooldown = RuhYiyenConfig.DRAIN_FAIL_COOLDOWN_TICKS;
						finish();
						return Event.DRAIN_CANCELLED;
					}
					return Event.NONE;
				}
				case DRAIN_CHANNEL -> {
					boolean broken = in.interrupted() || !in.hasTarget() || in.distance() > RuhYiyenConfig.DRAIN_BREAK_RANGE;
					if (!broken) {
						lostSight = in.lineOfSight() ? 0 : lostSight + 1;
						broken = lostSight >= RuhYiyenConfig.DRAIN_LOS_GRACE_TICKS;
					}
					if (broken) {
						drainCooldown = RuhYiyenConfig.DRAIN_COOLDOWN_TICKS;
						begin(Attack.DRAIN_RECOVER, RuhYiyenConfig.DRAIN_BROKEN_RECOVER_TICKS);
						return Event.DRAIN_BROKEN;
					}
					if (--ticksLeft <= 0) {
						drainCooldown = RuhYiyenConfig.DRAIN_COOLDOWN_TICKS;
						begin(Attack.DRAIN_RECOVER, RuhYiyenConfig.DRAIN_RECOVER_TICKS);
						return Event.DRAIN_END;
					}
					if (--pulseTimer <= 0) {
						pulseTimer = RuhYiyenConfig.DRAIN_PULSE_INTERVAL_TICKS;
						return Event.DRAIN_PULSE;
					}
					return Event.NONE;
				}
				case DRAIN_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				default -> {
					return choose(in);
				}
			}
		}

		private Event choose(Inputs in) {
			if (!in.hasTarget() || globalGap > 0) {
				return Event.NONE;
			}
			double d = in.distance();
			double chance = in.healthRatio() <= RuhYiyenConfig.WOUNDED_HEALTH_RATIO
					? RuhYiyenConfig.DRAIN_CHANCE_WOUNDED_PER_TICK
					: RuhYiyenConfig.DRAIN_CHANCE_PER_TICK;
			if (drainCooldown == 0 && in.lineOfSight() && in.claimOk()
					&& d >= RuhYiyenConfig.DRAIN_MIN_RANGE && d <= RuhYiyenConfig.DRAIN_START_RANGE && in.roll() < chance) {
				begin(Attack.DRAIN_WINDUP, RuhYiyenConfig.DRAIN_WINDUP_TICKS);
				return Event.DRAIN_WINDUP_START;
			}
			if (boltCooldown == 0 && in.lineOfSight() && d >= RuhYiyenConfig.BOLT_MIN_RANGE && d <= RuhYiyenConfig.BOLT_MAX_RANGE) {
				begin(Attack.BOLT_WINDUP, RuhYiyenConfig.BOLT_WINDUP_TICKS);
				return Event.BOLT_WINDUP_START;
			}
			return Event.NONE;
		}

		private void begin(Attack next, int ticks) {
			attack = next;
			ticksLeft = Math.max(1, ticks);
			phaseTotal = ticksLeft;
		}

		private void finish() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			lostSight = 0;
			globalGap = Math.max(globalGap, 8);
		}
	}
}
