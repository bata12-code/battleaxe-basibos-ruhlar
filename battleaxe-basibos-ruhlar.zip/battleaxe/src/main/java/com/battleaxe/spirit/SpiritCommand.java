package com.battleaxe.spirit;

import java.util.List;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

/**
 * Geliştirme/test komutu (yalnızca yetkililer):
 * <ul>
 *   <li>{@code /baltaruh summon <savrulmus_ruh|ruh_yiyen|zincirli_ruh>}: bakılan yönde 6 blok ötede tek ruh.</li>
 *   <li>{@code /baltaruh encounter <düzen>}: bir karşılaşma düzeni ({@link SpiritEncounter.Layout#id()}); ruhlar size doğru bakar.</li>
 *   <li>{@code /baltaruh clear}: 64 blok çevredeki bütün Başıboş Ruhlar'ı kaldırır (ödül/ganimet YOK).</li>
 * </ul>
 * Tek ruh için vanilla {@code /summon battleaxe:<tür>} de çalışır. Seçenekler sekme tamamlamasıyla gelir (her biri ayrı alt komuttur).
 */
public final class SpiritCommand {
	private SpiritCommand() {
	}

	private static final double SUMMON_DISTANCE = 6.0;
	private static final double ENCOUNTER_DISTANCE = 14.0;
	private static final double CLEAR_RADIUS = 64.0;

	public static void initialize() {
		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> {
			LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("baltaruh")
					.requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS));

			LiteralArgumentBuilder<CommandSourceStack> summon = Commands.literal("summon");
			for (SpiritKind kind : SpiritKind.values()) {
				summon.then(Commands.literal(kind.id()).executes(context -> summon(context.getSource(), kind)));
			}

			LiteralArgumentBuilder<CommandSourceStack> encounter = Commands.literal("encounter");
			for (SpiritEncounter.Layout layout : SpiritEncounter.Layout.values()) {
				encounter.then(Commands.literal(layout.id()).executes(context -> encounter(context.getSource(), layout)));
			}

			root.then(summon);
			root.then(encounter);
			root.then(Commands.literal("clear").executes(context -> clear(context.getSource())));
			dispatcher.register(root);
		});
	}

	private static Vec3 lookDirection(CommandSourceStack source) {
		Vec2 rotation = source.getRotation();
		double yaw = Math.toRadians(rotation.y);
		return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
	}

	private static int summon(CommandSourceStack source, SpiritKind kind) {
		ServerLevel level = source.getLevel();
		Vec3 origin = source.getPosition();
		Vec3 direction = lookDirection(source);
		double x = origin.x + direction.x * SUMMON_DISTANCE;
		double z = origin.z + direction.z * SUMMON_DISTANCE;
		double y = SpiritSpawner.findStandY(level, x, origin.y, z);
		if (Double.isNaN(y)) {
			source.sendFailure(Component.translatable("message.battleaxe.spirit.cmd.no_room"));
			return 0;
		}
		float yaw = source.getRotation().y + 180.0F;
		SpiritEntity spirit = SpiritSpawner.spawn(level, kind, x, y, z, yaw);
		if (spirit == null) {
			source.sendFailure(Component.translatable("message.battleaxe.spirit.cmd.no_room"));
			return 0;
		}
		source.sendSuccess(() -> Component.translatable("message.battleaxe.spirit.cmd.summoned", spirit.getDisplayName()), true);
		return 1;
	}

	private static int encounter(CommandSourceStack source, SpiritEncounter.Layout layout) {
		ServerLevel level = source.getLevel();
		Vec3 origin = source.getPosition();
		Vec3 direction = lookDirection(source);
		Vec3 center = new Vec3(origin.x + direction.x * ENCOUNTER_DISTANCE, origin.y, origin.z + direction.z * ENCOUNTER_DISTANCE);
		List<SpiritEntity> spawned = SpiritSpawner.spawnEncounter(level, layout, center, origin);
		if (spawned.isEmpty()) {
			source.sendFailure(Component.translatable("message.battleaxe.spirit.cmd.no_room"));
			return 0;
		}
		int count = spawned.size();
		source.sendSuccess(() -> Component.translatable("message.battleaxe.spirit.cmd.encounter", layout.id(), count), true);
		return count;
	}

	private static int clear(CommandSourceStack source) {
		ServerLevel level = source.getLevel();
		Vec3 c = source.getPosition();
		AABB box = new AABB(c.x - CLEAR_RADIUS, level.getMinY(), c.z - CLEAR_RADIUS, c.x + CLEAR_RADIUS, level.getMaxY(), c.z + CLEAR_RADIUS);
		List<SpiritEntity> spirits = level.getEntitiesOfClass(SpiritEntity.class, box);
		for (SpiritEntity spirit : spirits) {
			spirit.discard();
		}
		int count = spirits.size();
		source.sendSuccess(() -> Component.translatable("message.battleaxe.spirit.cmd.cleared", count), true);
		return count;
	}
}
