package com.battleaxe.spirit;

/** Savrulmuş Ruh (yakın dövüş avcısı) dengeleme ayarları. */
public final class SavrulmusConfig {
	private SavrulmusConfig() {
	}

	// ---- Temel özellikler
	public static final double MAX_HEALTH = 40.0;
	public static final double ARMOR = 2.0;
	/** Yüksek hareket hızı (zombi 0.23). */
	public static final double MOVEMENT_SPEED = 0.33;
	public static final double FOLLOW_RANGE = 28.0;
	public static final double KNOCKBACK_RESISTANCE = 0.2;
	/** Yalnızca bilgi amaçlı öznitelik; gerçek hasarlar aşağıdaki aralıklardan gelir. */
	public static final double ATTACK_DAMAGE = 7.0;

	// ---- Pençe kombosu: iki seri vuruş, ardından geri çekilme
	public static final double CLAW_TRIGGER_RANGE = 2.6;
	/** Vuruşun isabet mesafesi (görüş hattı da gerekir: duvarın ardından vurulmaz). */
	public static final double CLAW_REACH = 3.0;
	public static final float CLAW_DAMAGE_MIN = 6.0F;
	public static final float CLAW_DAMAGE_MAX = 8.0F;
	public static final double CLAW_KNOCKBACK = 0.35;
	public static final int CLAW_WINDUP_TICKS = 7;
	public static final int CLAW_FOLLOWUP_WINDUP_TICKS = 5;
	public static final int CLAW_SWING_TICKS = 5;
	public static final int COMBO_HITS = 2;
	public static final int RETREAT_TICKS = 16;
	/** Komboların arası: sürekli saldırı spam'i yok. */
	public static final int COMBO_COOLDOWN_TICKS = 40;
	/** Her saldırı bittikten sonra kısa nefes boşluğu. */
	public static final int GLOBAL_GAP_TICKS = 6;

	// ---- Ruh Sıçrayışı
	public static final double LEAP_MIN_RANGE = 4.5;
	public static final double LEAP_MAX_RANGE = 11.0;
	/** Hazırlık: eğilir, ses ve parçacık uyarısı. Oyuncunun yana kaçmasına yeter. */
	public static final int LEAP_WINDUP_TICKS = 14;
	public static final int LEAP_MAX_AIR_TICKS = 24;
	public static final int LEAP_MIN_AIR_TICKS = 4;
	/** İniş sonrası SAVUNMASIZ süre (ek hasar alır). */
	public static final int LEAP_RECOVER_TICKS = 24;
	public static final int LEAP_COOLDOWN_TICKS = 140;
	public static final int LEAP_INITIAL_COOLDOWN_TICKS = 60;
	/** Fırlatma görüş hattını/mesafeyi yitirdiyse kısa bir bekleme. */
	public static final int LEAP_FAIL_COOLDOWN_TICKS = 50;
	/** Boştayken her tick sıçrama seçme olasılığı (bekleme bitince hemen değil, biraz rastgele). */
	public static final double LEAP_CHANCE_PER_TICK = 0.08;
	public static final float LEAP_DAMAGE = 8.0F;
	public static final double LEAP_KNOCKBACK = 0.8;
	public static final double LEAP_VERTICAL_SPEED = 0.5;
	/** Yatay hız = mesafe / bu değer (havadaki sürtünme hesaba katılmıştır), sınırlar içinde. */
	public static final double LEAP_SPEED_DIVISOR = 6.8;
	public static final double LEAP_MIN_SPEED = 0.55;
	public static final double LEAP_MAX_SPEED = 1.35;

	// ---- Hareket: çevresinde dönme, ani yön değişimi, arkaya geçme
	public static final double STRAFE_RADIUS = 3.4;
	public static final double COMBO_APPROACH_RADIUS = 2.0;
	/** Yeniden yol planı aralığı (pahalı olduğundan seyrek). */
	public static final int REPLAN_TICKS = 10;
	public static final int FLIP_MIN_TICKS = 18;
	public static final int FLIP_MAX_TICKS = 40;
	/** Dönüş yönünü oyuncunun ARKASINA doğru seçme olasılığı. */
	public static final double BACKSTAB_BIAS = 0.6;
	public static final double STRAFE_ANGLE_STEP = 0.55;
	public static final double STRAFE_SPEED = 1.15;
	public static final double APPROACH_SPEED = 1.25;
	public static final double RETREAT_SPEED = 1.1;
	/** Bu mesafeden uzaktaysa doğrudan hedefe koşar. */
	public static final double FAR_DISTANCE = 8.0;
}
