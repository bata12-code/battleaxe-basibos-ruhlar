package com.battleaxe.spirit;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Başıboş Ruhlar'ın ortak görsel/işitsel yardımcıları. Palet: koyu mor, soluk beyaz, gerektiğinde koyu kırmızı.
 * Parçacıklar ölçülüdür (her çağrı birkaç tane); yalnızca sunucu çağırır, istemci yalnızca görür.
 */
final class SpiritFx {
	private SpiritFx() {
	}

	static final DustColorTransitionOptions VIOLET = new DustColorTransitionOptions(0x9A5CF0, 0x2A1048, 1.0F);
	static final DustColorTransitionOptions PALE = new DustColorTransitionOptions(0xE6E0F4, 0x6A5A90, 0.9F);
	static final DustColorTransitionOptions BLOOD = new DustColorTransitionOptions(0xB01030, 0x300410, 0.9F);
	static final DustColorTransitionOptions DARK = new DustColorTransitionOptions(0x2A1448, 0x08040E, 1.1F);

	static void sound(ServerLevel level, Entity at, SoundEvent sound, float volume, float pitch) {
		level.playSound(null, at.getX(), at.getY(), at.getZ(), sound, SoundSource.HOSTILE, volume, pitch);
	}

	static void sound(ServerLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
		level.playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
	}

	/** Boştayken ruhun çevresinde süzülen silik kıvılcımlar (türe göre palet). */
	static void wisp(ServerLevel level, SpiritEntity spirit) {
		double h = spirit.getBbHeight();
		level.sendParticles(DARK, spirit.getX(), spirit.getY() + h * 0.4, spirit.getZ(), 2, 0.3, h * 0.3, 0.3, 0.0);
		if (spirit.tickCount % 18 == 0) {
			level.sendParticles(ParticleTypes.SOUL, spirit.getX(), spirit.getY() + h * 0.7, spirit.getZ(), 1, 0.25, 0.2, 0.25, 0.01);
		}
	}

	/** Ölüm anı: gövde parçalanır; çekirdek ışık saçar. */
	static void shatterBurst(ServerLevel level, SpiritEntity spirit) {
		double h = spirit.getBbHeight();
		double x = spirit.getX();
		double y = spirit.getY() + h * 0.55;
		double z = spirit.getZ();
		level.sendParticles(PALE, x, y, z, 24, 0.35, h * 0.3, 0.35, 0.02);
		level.sendParticles(DARK, x, y, z, 30, 0.4, h * 0.35, 0.4, 0.0);
		level.sendParticles(ParticleTypes.SOUL, x, y, z, 8, 0.3, h * 0.3, 0.3, 0.06);
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 10, 0.3, h * 0.3, 0.3, 0.3);
	}

	/** Ölüm süresince dağılma: dışa savrulan parçalar; sonlara doğru çekirdek parlar ve söner. */
	static void shatterTick(ServerLevel level, SpiritEntity spirit, int deathTime) {
		double h = spirit.getBbHeight();
		double x = spirit.getX();
		double y = spirit.getY() + h * 0.5;
		double z = spirit.getZ();
		double spread = 0.2 + deathTime * 0.05;
		level.sendParticles(DARK, x, y, z, 3, spread, h * 0.3, spread, 0.0);
		level.sendParticles(ParticleTypes.ASH, x, y, z, 2, spread, h * 0.3, spread, 0.0);
		if (deathTime >= SpiritConfig.DEATH_TICKS - 4 && deathTime < SpiritConfig.DEATH_TICKS - 1) {
			level.sendParticles(ParticleTypes.END_ROD, x, y + h * 0.1, z, 3, 0.08, 0.08, 0.08, 0.03);
		}
	}

	/** İki nokta arasına seyrek bir parçacık çizgisi (zincir, enerji akışı, nişan ipucu). */
	static void line(ServerLevel level, Vec3 from, Vec3 to, double spacing, ParticleOptions options) {
		Vec3 delta = to.subtract(from);
		double length = delta.length();
		if (length < 0.2) {
			return;
		}
		int steps = (int) Math.min(40, Math.max(1, Math.floor(length / spacing)));
		Vec3 step = delta.scale(1.0 / steps);
		for (int i = 0; i <= steps; i++) {
			Vec3 p = from.add(step.scale(i));
			level.sendParticles(options, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	/** Zemine paralel halka (uyarı çemberi, şok dalgası). */
	static void ring(ServerLevel level, double cx, double y, double cz, double radius, int points, ParticleOptions options) {
		for (int i = 0; i < points; i++) {
			double angle = i * (Math.PI * 2.0 / points);
			level.sendParticles(options, cx + Math.cos(angle) * radius, y, cz + Math.sin(angle) * radius, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}
}
