package com.battleaxe.spirit;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Zincirli Ruh: ağır muhafız / alan kontrolü. Yavaştır ama saldırıları çok yüksek hasarlıdır ve her biri belirgin bir hazırlık ister.
 *
 * <p>Davranış ({@link ZincirliLogic}): oyuncuya doğrudan yürüyüp alanını daraltır. Yakında <b>Zincir Savurma</b> (geniş yatay yay)
 * veya <b>Ruhani Darbe</b> (yere ağır vuruş; çevresine yayılan şok dalgası, doğru anda SIÇRAYARAK atlatılır). Orta mesafede
 * <b>Zincirle Mühürleme</b>: zincirini fırlatır; doğrultu hazırlığın sonunda kilitlenir, yana kaçılır. İsabet halinde oyuncu kısa
 * süre yavaşlar ve ruha doğru hafifçe çekilir (hareketsiz KALMAZ); Shunpo mührü kırar, ruha ağır bir vuruş da kırar, aynı oyuncu
 * art arda mühürlenemez. Her ağır saldırı sonrası ruh kısa süre savunmasız kalır.
 */
public class ZincirliRuhEntity extends SpiritEntity {
	private final ZincirliLogic.Brain brain = new ZincirliLogic.Brain();

	private ZincirMuhru chain;
	private boolean chainDone;
	private Vec3 aimLock;
	private UUID claimTarget;

	private final Set<UUID> shockHit = new HashSet<>();
	private int shockTicks;

	public ZincirliRuhEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, ZincirliConfig.MAX_HEALTH)
				.add(Attributes.ARMOR, ZincirliConfig.ARMOR)
				.add(Attributes.MOVEMENT_SPEED, ZincirliConfig.MOVEMENT_SPEED)
				.add(Attributes.FOLLOW_RANGE, ZincirliConfig.FOLLOW_RANGE)
				.add(Attributes.KNOCKBACK_RESISTANCE, ZincirliConfig.KNOCKBACK_RESISTANCE)
				.add(Attributes.ATTACK_DAMAGE, ZincirliConfig.ATTACK_DAMAGE)
				.add(Attributes.SAFE_FALL_DISTANCE, 32.0);
	}

	@Override
	public SpiritKind kind() {
		return SpiritKind.ZINCIRLI;
	}

	@Override
	protected boolean isExposed() {
		return brain.exposed();
	}

	@Override
	protected void onCleanup() {
		chain = null;
		brain.abort();
		releaseClaim();
		SpiritCoordinator.forget(getUUID());
		if (level() instanceof ServerLevel server) {
			SpiritSeal.releaseOwnedBy(server, getUUID());
		}
	}

	@Override
	protected void onSpiritHurt(ServerLevel level, DamageSource source, float adjusted, int axeRank) {
		// Mühürlü oyuncu zinciri ağır bir vuruşla koparabilir.
		if (adjusted >= SpiritConfig.SEAL_BREAK_DAMAGE && source.getEntity() instanceof ServerPlayer player
				&& SpiritSeal.isSealedBy(player, getUUID())) {
			SpiritSeal.release(player, level.getGameTime(), 0);
			SpiritFx.sound(level, this, SoundEvents.ANVIL_HIT, 0.9F, 1.4F);
		}
	}

	// ------------------------------------------------------------------ Savaş

	@Override
	protected void tickSpirit(ServerLevel server) {
		LivingEntity target = getTarget();
		boolean has = validTarget(target);
		trackTarget(has ? target : null);

		long now = server.getGameTime();
		double distance = has ? Math.sqrt(distanceToSqr(target)) : 0.0;
		boolean lineOfSight = has && getSensing().hasLineOfSight(target);
		boolean sealable = has && target instanceof ServerPlayer player && SpiritSeal.canSeal(player, now);
		boolean claimOk = has && SpiritCoordinator.canClaim(target.getUUID(), getUUID(), now);

		ZincirliLogic.Event event = brain.step(new ZincirliLogic.Inputs(
				has, distance, lineOfSight, sealable, claimOk, chainDone, this.random.nextDouble()));
		switch (event) {
			case SWEEP_WINDUP_START -> SpiritFx.sound(server, this, SoundEvents.IRON_GOLEM_ATTACK, 0.8F, 0.5F);
			case SWEEP_HIT -> sweepStrike(server);
			case SLAM_WINDUP_START -> {
				shockHit.clear();
				SpiritFx.sound(server, this, SoundEvents.ANVIL_HIT, 0.8F, 0.5F);
			}
			case SLAM_IMPACT -> {
				shockHit.clear();
				shockTicks = 0;
				SpiritFx.sound(server, this, SoundEvents.RAVAGER_ROAR, 0.9F, 0.6F);
				SpiritFx.sound(server, this, SoundEvents.ANVIL_HIT, 1.2F, 0.4F);
				server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 1, 0.0, 0.0, 0.0, 0.0);
			}
			case CHAIN_WINDUP_START -> {
				aimLock = null;
				if (has) {
					claimTarget = target.getUUID();
					int span = ZincirliConfig.CHAIN_WINDUP_TICKS + ZincirliConfig.CHAIN_MAX_THROW_TICKS + SpiritConfig.SEAL_TICKS
							+ ZincirliConfig.CHAIN_RECOVER_TICKS;
					SpiritCoordinator.claim(claimTarget, getUUID(), now, span);
				}
				SpiritFx.sound(server, this, SoundEvents.IRON_GOLEM_ATTACK, 0.9F, 0.4F);
			}
			case CHAIN_LAUNCH -> launchChain(server, has ? target : null);
			case CHAIN_END -> {
				chain = null;
				// Mühür uygulandıysa izin mühür süresince tutulur; yoksa hemen bırakılır.
				if (claimTarget != null && !isTargetSealed(server)) {
					releaseClaim();
				}
			}
			default -> {
			}
		}

		switch (brain.attack()) {
			case SWEEP_WINDUP -> {
				getNavigation().stop();
				if (has && brain.progress() < ZincirliConfig.SWEEP_AIM_LOCK_PROGRESS) {
					faceTarget(target);
				}
				telegraphCone(server);
			}
			case SWEEP_STRIKE, SWEEP_RECOVER, SLAM_RECOVER, CHAIN_RECOVER -> getNavigation().stop();
			case SLAM_WINDUP -> {
				getNavigation().stop();
				if (has) {
					faceTarget(target);
				}
				telegraphRing(server);
			}
			case SLAM_STRIKE -> {
				getNavigation().stop();
				shockwaveTick(server);
			}
			case CHAIN_WINDUP -> {
				getNavigation().stop();
				chainAimTick(server, has ? target : null);
			}
			case CHAIN_THROW -> {
				getNavigation().stop();
				chainFlightTick(server);
			}
			case IDLE -> chase(target, has, distance);
		}

		syncState(brain.attack().ordinal(), brain.progress(), brain.exposed());
	}

	/** Oyuncuya doğrudan yaklaşarak alanını daraltır; ruhlar iç içe girmesin diye belli bir mesafede durur. */
	private void chase(LivingEntity target, boolean has, double distance) {
		if (!has) {
			return;
		}
		faceTarget(target);
		if (distance <= ZincirliConfig.STOP_DISTANCE) {
			getNavigation().stop();
			return;
		}
		if (this.tickCount % ZincirliConfig.CHASE_REPLAN_TICKS == 0) {
			getNavigation().moveTo(target, ZincirliConfig.CHASE_SPEED);
		}
	}

	/** Mührün altındaki oyuncu hâlâ mühürlü mü (izni mühür boyunca tutmak için). */
	private boolean isTargetSealed(ServerLevel server) {
		if (claimTarget == null) {
			return false;
		}
		ServerPlayer player = server.getServer().getPlayerList().getPlayer(claimTarget);
		return player != null && SpiritSeal.isSealedBy(player, getUUID());
	}

	private void releaseClaim() {
		if (claimTarget != null) {
			SpiritCoordinator.release(claimTarget, getUUID(), level().getGameTime());
			claimTarget = null;
		}
	}

	private boolean isEnemy(LivingEntity e) {
		if (e == this || !e.isAlive() || e instanceof SpiritEntity) {
			return false;
		}
		return e instanceof Player player ? validTarget(player) : e == getTarget();
	}

	private void hit(ServerLevel server, LivingEntity victim, float damage, double knockback) {
		DamageSource source = damageSources().mobAttack(this);
		if (victim.hurtServer(server, source, damage)) {
			victim.knockback(knockback, getX() - victim.getX(), getZ() - victim.getZ(), source, damage);
		}
	}

	// ------------------------------------------------------------------ Zincir Savurma

	/** Hazırlık: savrulacak yayın iki kenarı zemine çizilir (alan görünür). */
	private void telegraphCone(ServerLevel server) {
		if (this.tickCount % 3 != 0) {
			return;
		}
		double yaw = Math.toRadians(getYRot());
		double half = Math.toRadians(ZincirliConfig.SWEEP_HALF_ANGLE_DEG);
		double fill = 0.35 + 0.65 * brain.progress();
		for (int i = 0; i <= 6; i++) {
			double a = -half + (2.0 * half) * (i / 6.0);
			double dx = -Math.sin(yaw + a);
			double dz = Math.cos(yaw + a);
			double r = ZincirliConfig.SWEEP_RADIUS * fill;
			server.sendParticles(SpiritFx.VIOLET, getX() + dx * r, getY() + 0.1, getZ() + dz * r, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	private void sweepStrike(ServerLevel server) {
		double r = ZincirliConfig.SWEEP_RADIUS;
		SpiritFx.sound(server, this, SoundEvents.IRON_GOLEM_ATTACK, 1.2F, 0.6F);
		SpiritFx.sound(server, this, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 0.5F);
		double yaw = Math.toRadians(getYRot());
		double half = Math.toRadians(ZincirliConfig.SWEEP_HALF_ANGLE_DEG);
		for (int i = 0; i <= 8; i++) {
			double a = -half + (2.0 * half) * (i / 8.0);
			server.sendParticles(SpiritFx.PALE, getX() - Math.sin(yaw + a) * r * 0.8, getY() + 1.0, getZ() + Math.cos(yaw + a) * r * 0.8,
					1, 0.1, 0.2, 0.1, 0.0);
		}
		for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, 1.5, r), this::isEnemy)) {
			double dx = victim.getX() - getX();
			double dz = victim.getZ() - getZ();
			if (dx * dx + dz * dz > r * r || !SpiritLogic.inCone(dx, dz, getYRot(), ZincirliConfig.SWEEP_HALF_ANGLE_DEG)) {
				continue;
			}
			if (!getSensing().hasLineOfSight(victim)) {
				continue; // duvarın ardından vurulmaz
			}
			float damage = ZincirliConfig.SWEEP_DAMAGE_MIN
					+ this.random.nextFloat() * (ZincirliConfig.SWEEP_DAMAGE_MAX - ZincirliConfig.SWEEP_DAMAGE_MIN);
			hit(server, victim, damage, ZincirliConfig.SWEEP_KNOCKBACK);
		}
	}

	// ------------------------------------------------------------------ Ruhani Darbe

	/** Hazırlık: şok dalgasının nihai yarıçapı zemine çizilir; içi hazırlıkla dolar. */
	private void telegraphRing(ServerLevel server) {
		if (this.tickCount % 3 != 0) {
			return;
		}
		double p = brain.progress();
		SpiritFx.ring(server, getX(), getY() + 0.1, getZ(), ZincirliConfig.SLAM_RADIUS, 20, SpiritFx.BLOOD);
		SpiritFx.ring(server, getX(), getY() + 0.1, getZ(), ZincirliConfig.SLAM_RADIUS * p, 12, SpiritFx.VIOLET);
	}

	/** Şok dalgası: halka dışa genişler; ayakları zeminde olan oyuncuya halka ulaşınca hasar. Halka geçerken SIÇRAYAN kurtulur. */
	private void shockwaveTick(ServerLevel server) {
		shockTicks++;
		double radius = ZincirliConfig.SLAM_RADIUS * Math.min(1.0, (double) shockTicks / ZincirliConfig.SLAM_STRIKE_TICKS);
		SpiritFx.ring(server, getX(), getY() + 0.15, getZ(), radius, Math.max(10, (int) (radius * 7)), SpiritFx.PALE);
		SpiritFx.ring(server, getX(), getY() + 0.1, getZ(), radius, Math.max(8, (int) (radius * 4)), SpiritFx.DARK);
		double reach = ZincirliConfig.SLAM_RADIUS + ZincirliConfig.SLAM_RING_THICKNESS;
		for (LivingEntity victim : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(reach, 2.0, reach), this::isEnemy)) {
			double dx = victim.getX() - getX();
			double dz = victim.getZ() - getZ();
			double dist = Math.sqrt(dx * dx + dz * dz);
			if (!SpiritLogic.ringReaches(dist, radius, ZincirliConfig.SLAM_RING_THICKNESS) || shockHit.contains(victim.getUUID())) {
				continue;
			}
			if (victim.getY() - getY() >= ZincirliConfig.SLAM_JUMP_CLEARANCE) {
				continue; // doğru anda sıçrayan halkanın üstünden geçer
			}
			shockHit.add(victim.getUUID());
			hit(server, victim, ZincirliConfig.SLAM_DAMAGE, ZincirliConfig.SLAM_KNOCKBACK);
		}
	}

	// ------------------------------------------------------------------ Zincirle Mühürleme

	private Vec3 handPosition() {
		Vec3 forward = forward();
		Vec3 right = new Vec3(-forward.z, 0.0, forward.x).scale(-1.0);
		return position().add(forward.scale(0.9)).add(right.scale(0.8)).add(0.0, getBbHeight() * 0.55, 0.0);
	}

	/** Hazırlık: hedefe doğru ince bir çizgi; ilerlemenin son bölümünde doğrultu KİLİTLENİR ve çizgi sabit kalır. */
	private void chainAimTick(ServerLevel server, LivingEntity target) {
		Vec3 hand = handPosition();
		if (aimLock == null && target != null) {
			if (brain.progress() < ZincirliConfig.CHAIN_AIM_LOCK_PROGRESS) {
				faceTarget(target);
			} else {
				Vec3 toward = chestOf(target).subtract(hand);
				if (toward.lengthSqr() > 1.0E-4) {
					aimLock = toward.normalize();
				}
			}
		}
		if (this.tickCount % 3 == 0 && target != null) {
			Vec3 direction = aimLock != null ? aimLock : chestOf(target).subtract(hand).normalize();
			double reach = Math.min(ZincirliConfig.CHAIN_MAX_DISTANCE * 0.6, hand.distanceTo(chestOf(target)));
			SpiritFx.line(server, hand, hand.add(direction.scale(reach)), 1.4, aimLock != null ? SpiritFx.BLOOD : SpiritFx.PALE);
		}
		if (this.tickCount % 4 == 0) {
			server.sendParticles(SpiritFx.DARK, hand.x, hand.y, hand.z, 2, 0.2, 0.2, 0.2, 0.0);
		}
	}

	private void launchChain(ServerLevel server, LivingEntity target) {
		Vec3 hand = handPosition();
		Vec3 direction = aimLock;
		if (direction == null && target != null) {
			Vec3 toward = chestOf(target).subtract(hand);
			direction = toward.lengthSqr() > 1.0E-4 ? toward.normalize() : forward();
		}
		if (direction == null) {
			direction = forward();
		}
		chain = new ZincirMuhru(hand, direction.scale(ZincirliConfig.CHAIN_SPEED));
		chainDone = false;
		SpiritFx.sound(server, this, SoundEvents.IRON_GOLEM_ATTACK, 1.0F, 0.7F);
		SpiritFx.sound(server, this, SoundEvents.WITHER_SHOOT, 0.5F, 0.6F);
	}

	private void chainFlightTick(ServerLevel server) {
		if (chain == null) {
			chainDone = true;
			return;
		}
		ZincirMuhru.Outcome outcome = chain.step(server, handPosition());
		if (outcome == ZincirMuhru.Outcome.FLYING) {
			return;
		}
		Vec3 at = chain.impact();
		if (at != null) {
			server.sendParticles(SpiritFx.PALE, at.x, at.y, at.z, 5, 0.15, 0.15, 0.15, 0.02);
		}
		if (outcome == ZincirMuhru.Outcome.HIT_PLAYER && chain.victim() instanceof ServerPlayer player) {
			onChainHit(server, player);
		}
		chain = null;
		chainDone = true;
	}

	private void onChainHit(ServerLevel server, ServerPlayer player) {
		DamageSource source = damageSources().mobAttack(this);
		player.hurtServer(server, source, ZincirliConfig.CHAIN_DAMAGE);
		long now = server.getGameTime();
		if (player.isBlocking()) {
			// Kalkan zinciri karşılar: mühür uygulanmaz.
			SpiritFx.sound(server, player, SoundEvents.ANVIL_HIT, 0.9F, 1.6F);
			return;
		}
		if (!SpiritSeal.canSeal(player, now)) {
			return; // bağışıklık / zaten mühürlü: yalnızca hafif hasar
		}
		SpiritSeal.apply(player, this, now);
		if (SpiritConfig.SEAL_PULL > 0.0) {
			// Ruha doğru hafif çekiş (alanı daraltır); oyuncu hareketsiz bırakılmaz.
			player.knockback(SpiritConfig.SEAL_PULL, player.getX() - getX(), player.getZ() - getZ(), source, 0.0F);
		}
	}

	// ------------------------------------------------------------------ Ses kimliği: ağır zincir sürtünmeleri, metalik darbeler, derin titreşim

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.IRON_GOLEM_STEP;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.IRON_GOLEM_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.IRON_GOLEM_DEATH;
	}
}
