package com.battleaxe.spirit;

/**
 * Başıboş Ruhlar'ın ORTAK dengeleme ayarları (tek merkez). Türlere özgü değerler {@link SavrulmusConfig},
 * {@link RuhYiyenConfig} ve {@link ZincirliConfig} içindedir. Süreler tick (20 tick = 1 sn), mesafeler bloktur.
 */
public final class SpiritConfig {
	private SpiritConfig() {
	}

	// ---- Ruhsal doğa: fiziksel saldırılara sınırlı direnç, savaş baltasına duyarlılık
	/** Mermi (ok, trident...) hasarındaki kesinti. Ruhsal beden delinir ama etkisi sönümlenir. */
	public static final double PROJECTILE_RESISTANCE = 0.30;
	/** Savaş Baltası (vuruş, Yar Geç, fırlatma) bu bedenleri keser: direnci yok sayar ve ek hasar verir. */
	public static final double AXE_BONUS_BASE = 0.10;
	/** Baltanın her ruh rütbesi için ek hasar oranı (rütbe 9: +%13.5, toplam +%23.5). */
	public static final double AXE_BONUS_PER_RANK = 0.015;
	/** Savunmasız anlarda (sıçrayış sonrası, emme kopması, ağır saldırı sonrası) alınan ek hasar. */
	public static final double EXPOSED_DAMAGE_BONUS = 0.25;

	// ---- Ruh ödülü: baltanın ruh dengesi korunur. Türe göre SABİT, küçük ödül (can/20 formülüyle aynı değerler).
	public static final boolean SOUL_REWARD_ENABLED = true;
	public static final int SAVRULMUS_SOUL = 2;
	public static final int RUH_YIYEN_SOUL = 3;
	public static final int ZINCIRLI_SOUL = 6;

	// ---- Koordinasyon: bir hedefe aynı anda yalnızca TEK kontrol yeteneği (emme veya mühür) uygulanır
	/** Bir kontrol yeteneği bittikten sonra başka bir ruhun yenisini başlatabilmesi için gereken boşluk. */
	public static final int CONTROL_GAP_TICKS = 50;

	// ---- Zincirle Mühürleme (oyuncu üzerindeki etki)
	public static final int SEAL_TICKS = 36;
	/** Hareket hızı değişimi (ADD_MULTIPLIED_TOTAL): -0.55 = %55 yavaş. Oyuncu hareketsiz KALMAZ. */
	public static final double SEAL_SPEED_PENALTY = -0.55;
	public static final double SEAL_JUMP_PENALTY = -0.40;
	/** Mühür isabetinde oyuncuyu ruha doğru çeken küçük itki (0 = çekme yok). */
	public static final double SEAL_PULL = 0.45;
	/** Mühür bittikten (veya kırıldıktan) sonra aynı hedefe yeniden mühür uygulanamayan süre. */
	public static final int SEAL_IMMUNITY_TICKS = 160;
	/** Mühürlü oyuncu mühürleyen ruha tek vuruşta bu kadar hasar verirse zincir kırılır. */
	public static final float SEAL_BREAK_DAMAGE = 12.0F;
	/** Shunpo ile kurtulunca hedefin kısa süre daha mühürlenememesi (hemen yeniden yakalanmasın). */
	public static final int SHUNPO_ESCAPE_GRACE_TICKS = 30;

	// ---- Ölüm: ruhsal beden parçalanıp dağılır (vanilla ölüm süresi 20 tick)
	public static final int DEATH_TICKS = 20;

	// ---- Genel yapay zekâ
	/** Hedef konumunun hız tahmini yumuşatması (0-1; büyük = daha çevik takip). */
	public static final double TARGET_VELOCITY_SMOOTHING = 0.4;

	// ---- Karşılaşma / spawn altyapısı (bkz. SpiritEncounter, SpiritSpawner). Henüz hiçbir biyom/boyuta BAĞLI DEĞİL.
	public static final int ENCOUNTER_MAX_SIZE = 4;
	/** Karşılaşmada üyeler arası asgari mesafe (blok): ruhlar birbirinin üstüne yığılmaz. */
	public static final double ENCOUNTER_MIN_SEPARATION = 3.0;
	public static final double ENCOUNTER_SPAWN_SEARCH_UP = 3.0;
	public static final double ENCOUNTER_SPAWN_SEARCH_DOWN = 6.0;

	// ---- Baltanın fısıltısı (ruh öldürünce, nadir)
	public static final int WHISPER_COOLDOWN_TICKS = 6000;
	public static final double WHISPER_CHANCE = 0.12;
}
