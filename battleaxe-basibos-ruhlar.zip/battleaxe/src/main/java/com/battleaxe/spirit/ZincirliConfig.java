package com.battleaxe.spirit;

/** Zincirli Ruh (ağır muhafız, alan kontrolü) dengeleme ayarları. */
public final class ZincirliConfig {
	private ZincirliConfig() {
	}

	// ---- Temel özellikler
	public static final double MAX_HEALTH = 120.0;
	public static final double ARMOR = 8.0;
	/** Düşük hareket hızı (zombi 0.23). */
	public static final double MOVEMENT_SPEED = 0.2;
	public static final double FOLLOW_RANGE = 32.0;
	public static final double KNOCKBACK_RESISTANCE = 0.6;
	public static final double ATTACK_DAMAGE = 10.0;

	public static final double CHASE_SPEED = 1.0;
	public static final int CHASE_REPLAN_TICKS = 10;
	/** Bu mesafeye yaklaşınca durur (ruh iç içe girmez). */
	public static final double STOP_DISTANCE = 2.8;
	public static final int GLOBAL_GAP_TICKS = 14;

	// ---- Zincir Savurma (yakın, geniş yatay)
	public static final double SWEEP_TRIGGER_RANGE = 3.6;
	public static final double SWEEP_RADIUS = 4.2;
	/** Yarı açı (derece): toplam 150°'lik yay. */
	public static final double SWEEP_HALF_ANGLE_DEG = 75.0;
	public static final float SWEEP_DAMAGE_MIN = 9.0F;
	public static final float SWEEP_DAMAGE_MAX = 12.0F;
	public static final double SWEEP_KNOCKBACK = 0.9;
	public static final int SWEEP_WINDUP_TICKS = 18;
	public static final int SWEEP_STRIKE_TICKS = 6;
	public static final int SWEEP_RECOVER_TICKS = 16;
	public static final int SWEEP_COOLDOWN_TICKS = 70;
	public static final int SWEEP_INITIAL_COOLDOWN_TICKS = 30;
	/** Hazırlığın son bölümünde ruh dönmeyi bırakır: oyuncu yan hareketle kaçabilir. */
	public static final float SWEEP_AIM_LOCK_PROGRESS = 0.7F;

	// ---- Ruhani Darbe (yere ağır vuruş, genişleyen şok dalgası)
	public static final double SLAM_TRIGGER_RANGE = 4.4;
	public static final double SLAM_RADIUS = 5.5;
	public static final float SLAM_DAMAGE = 10.0F;
	public static final double SLAM_KNOCKBACK = 0.9;
	public static final int SLAM_WINDUP_TICKS = 26;
	/** Şok dalgasının genişleme süresi. */
	public static final int SLAM_STRIKE_TICKS = 8;
	public static final int SLAM_RECOVER_TICKS = 22;
	public static final int SLAM_COOLDOWN_TICKS = 130;
	public static final int SLAM_INITIAL_COOLDOWN_TICKS = 70;
	/** Halka oyuncuya ulaştığında ayakları ruhun zemininden bu kadar yukarıdaysa (sıçrama) hasar almaz. */
	public static final double SLAM_JUMP_CLEARANCE = 0.55;
	public static final double SLAM_RING_THICKNESS = 1.4;

	// ---- Zincirle Mühürleme (menzilli; yana kaçılabilir)
	public static final double CHAIN_MIN_RANGE = 5.0;
	public static final double CHAIN_MAX_RANGE = 14.0;
	public static final int CHAIN_WINDUP_TICKS = 22;
	public static final int CHAIN_MAX_THROW_TICKS = 16;
	public static final int CHAIN_RECOVER_TICKS = 20;
	public static final int CHAIN_COOLDOWN_TICKS = 300;
	public static final int CHAIN_INITIAL_COOLDOWN_TICKS = 90;
	public static final double CHAIN_SPEED = 1.4;
	public static final double CHAIN_MAX_DISTANCE = 18.0;
	public static final double CHAIN_HIT_RADIUS = 0.8;
	public static final float CHAIN_DAMAGE = 6.0F;
	/** Hazırlığın bu bölümünden sonra nişan KİLİTLENİR (oyuncu son çizgiyi görüp yana kaçar). */
	public static final float CHAIN_AIM_LOCK_PROGRESS = 0.7F;
}
