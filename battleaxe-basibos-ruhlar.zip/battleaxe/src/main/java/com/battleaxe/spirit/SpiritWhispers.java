package com.battleaxe.spirit;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Baltanın Başıboş Ruhlar'a tepkisi: bir ruhu Savaş Baltası ile devirdiğinde (vuruş, Yar Geç, fırlatma) kısa bir söz. İlk
 * devirmede her tür için bir söz; sonra nadiren, baltanın ruh rütbesine göre. Sözler açıklama değil, soru doğurur.
 * Durum yalnızca oturum boyunca bellektedir (kayda yazılmaz).
 */
public final class SpiritWhispers {
	private SpiritWhispers() {
	}

	private static final Map<UUID, Long> LAST = new HashMap<>();
	private static final Map<UUID, Set<SpiritKind>> SEEN = new HashMap<>();
	private static final Map<UUID, Integer> LAST_VARIANT = new HashMap<>();

	public static void initialize() {
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(entity instanceof SpiritEntity spirit) || !(source.getEntity() instanceof ServerPlayer player)) {
				return;
			}
			int rank = SpiritEntity.axeRank(source);
			if (rank < 0) {
				return; // yalnızca baltanın devirdiği ruhlar baltayı konuşturur
			}
			whisper(player, spirit.kind(), rank);
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			LAST.clear();
			SEEN.clear();
			LAST_VARIANT.clear();
		});
	}

	private static void whisper(ServerPlayer player, SpiritKind kind, int rank) {
		UUID id = player.getUUID();
		long now = player.level().getGameTime();
		Set<SpiritKind> seen = SEEN.computeIfAbsent(id, k -> EnumSet.noneOf(SpiritKind.class));
		boolean first = !seen.contains(kind);
		if (!SpiritWhisperLogic.shouldWhisper(first, player.getRandom().nextDouble(), now, LAST.getOrDefault(id, -1L))) {
			return;
		}
		String key;
		if (first) {
			key = SpiritWhisperLogic.firstKey(kind);
		} else {
			int variant = SpiritWhisperLogic.pickVariant(player.getRandom().nextDouble(), LAST_VARIANT.getOrDefault(id, 0));
			LAST_VARIANT.put(id, variant);
			key = SpiritWhisperLogic.key(SpiritWhisperLogic.band(rank), variant);
		}
		seen.add(kind);
		LAST.put(id, now);
		player.sendSystemMessage(Component.translatable(key).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
	}
}
