package com.battleaxe.spirit;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.berserker.BerserkerManager;

/**
 * Ruh Yiyen: menzilli avcı; baskı kurar ve fırsat bulunca oyuncunun yaşam enerjisiyle kendini iyileştirir.
 *
 * <p>Davranış ({@link RuhYiyenLogic}): oyuncudan belirli bir mesafeyi korur (yaklaşılırsa geri çekilir, uzaksa yaklaşır, görüş
 * kaybolursa konum değiştirir). Sık sık <b>Ruh Oku</b> atar: hazırlıkta çekirdeği parlar; ok oyuncunun HAREKET YÖNÜNE göre önden
 * nişanlanır (aynı yönde koşana isabet ihtimali artar) ama düz uçar, yana dönülerek kaçınılır. Nadiren <b>Ruh Emdirme</b>:
 * belirgin bir hazırlıktan sonra oyuncuyla arasında görünür bir enerji akışı kurar, bağlantı sürdükçe darbe vurur ve bir kısmını
 * canına katar. Bağ; görüş hattı kesilirse, uzaklaşılırsa veya tek seferde yeterince hasar alırsa (tek balta vuruşu) kopar ve
 * ruh bir süre savunmasız kalır. İyileşme sınırlıdır (bağlantı başına tavan + ömür boyu bütçe); Hiddet'teki oyuncunun kanı acıdır.
 */
public class RuhYiyenEntity extends SpiritEntity {
	private final RuhYiyenLogic.Brain brain = new RuhYiyenLogic.Brain();
	private final List<RuhMermisi> bolts = new ArrayList<>();

	private float channelDamage;
	private float healedThisChannel;
	private float healedTotal;
	private int noSightTicks;
	private int strafeDir = 1;
	private int flipTimer;
	private UUID claimTarget;

	public RuhYiyenEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, RuhYiyenConfig.MAX_HEALTH)
				.add(Attributes.ARMOR, RuhYiyenConfig.ARMOR)
				.add(Attributes.MOVEMENT_SPEED, RuhYiyenConfig.MOVEMENT_SPEED)
				.add(Attributes.FOLLOW_RANGE, RuhYiyenConfig.FOLLOW_RANGE)
				.add(Attributes.KNOCKBACK_RESISTANCE, RuhYiyenConfig.KNOCKBACK_RESISTANCE)
				.add(Attributes.ATTACK_DAMAGE, RuhYiyenConfig.ATTACK_DAMAGE)
				.add(Attributes.SAFE_FALL_DISTANCE, 32.0);
	}

	@Override
	public SpiritKind kind() {
		return SpiritKind.RUH_YIYEN;
	}

	@Override
	protected boolean isExposed() {
		return brain.exposed();
	}

	@Override
	protected void onCleanup() {
		bolts.clear();
		brain.abort();
		releaseClaim();
		SpiritCoordinator.forget(getUUID());
	}

	@Override
	protected void onSpiritHurt(ServerLevel level, DamageSource source, float adjusted, int axeRank) {
		RuhYiyenLogic.Attack attack = brain.attack();
		if (attack == RuhYiyenLogic.Attack.DRAIN_WINDUP || attack == RuhYiyenLogic.Attack.DRAIN_CHANNEL) {
			channelDamage += adjusted;
		}
	}

	// ------------------------------------------------------------------ Savaş

	@Override
	protected void tickSpirit(ServerLevel server) {
		LivingEntity target = getTarget();
		boolean has = validTarget(target);
		trackTarget(has ? target : null);

		long now = server.getGameTime();
		double distance = has ? Math.sqrt(distanceToSqr(target)) : 0.0;
		boolean lineOfSight = has && getSensing().hasLineOfSight(target);
		noSightTicks = has && !lineOfSight ? noSightTicks + 1 : 0;
		boolean claimOk = has && SpiritCoordinator.canClaim(target.getUUID(), getUUID(), now);
		boolean interrupted = channelDamage >= RuhYiyenConfig.DRAIN_INTERRUPT_DAMAGE;
		double healthRatio = getHealth() / Math.max(1.0F, getMaxHealth());

		RuhYiyenLogic.Event event = brain.step(new RuhYiyenLogic.Inputs(
				has, distance, lineOfSight, claimOk, interrupted, healthRatio, this.random.nextDouble()));
		switch (event) {
			case BOLT_WINDUP_START -> SpiritFx.sound(server, this, SoundEvents.ENDERMAN_STARE, 0.7F, 1.6F);
			case BOLT_FIRE -> {
				if (has) {
					fireBolt(server, target);
				}
			}
			case DRAIN_WINDUP_START -> {
				channelDamage = 0.0F;
				if (has) {
					claimTarget = target.getUUID();
					int span = RuhYiyenConfig.DRAIN_WINDUP_TICKS + RuhYiyenConfig.DRAIN_CHANNEL_TICKS + RuhYiyenConfig.DRAIN_BROKEN_RECOVER_TICKS;
					SpiritCoordinator.claim(claimTarget, getUUID(), now, span);
				}
				SpiritFx.sound(server, this, SoundEvents.WARDEN_SONIC_CHARGE, 0.9F, 1.4F);
			}
			case DRAIN_LINK -> {
				healedThisChannel = 0.0F;
				SpiritFx.sound(server, this, SoundEvents.ENDERMAN_STARE, 1.0F, 0.5F);
			}
			case DRAIN_PULSE -> {
				if (has) {
					drainPulse(server, target);
				}
			}
			case DRAIN_END -> releaseClaim();
			case DRAIN_BROKEN -> {
				releaseClaim();
				SpiritFx.sound(server, this, SoundEvents.ENDERMAN_HURT, 0.9F, 0.6F);
				SpiritFx.shatterBurst(server, this);
			}
			case DRAIN_CANCELLED -> releaseClaim();
			default -> {
			}
		}

		switch (brain.attack()) {
			case BOLT_WINDUP -> {
				getNavigation().stop();
				faceTarget(target);
				gatherFx(server);
			}
			case BOLT_RELEASE, DRAIN_RECOVER -> {
				getNavigation().stop();
				faceTarget(target);
			}
			case DRAIN_WINDUP -> {
				getNavigation().stop();
				faceTarget(target);
				gatherFx(server);
				if (has && this.tickCount % 4 == 0) {
					// Nişan ipucu: çekirdekten hedefe seyrek, soluk bir çizgi (bağ kurulacağını önceden gösterir)
					SpiritFx.line(server, corePosition(), chestOf(target), 1.6, SpiritFx.PALE);
				}
			}
			case DRAIN_CHANNEL -> {
				getNavigation().stop();
				faceTarget(target);
				if (has && this.tickCount % 2 == 0) {
					drainFlowFx(server, target);
				}
			}
			case IDLE -> kite(target, has, distance, lineOfSight);
		}

		tickBolts(server);
		syncState(brain.attack().ordinal(), brain.progress(), brain.exposed());
	}

	/** Mesafeyi korur: yakınsa geri çekilir, uzaksa yaklaşır, görüş yoksa konum değiştirir, aksi halde yavaşça yan yürür. */
	private void kite(LivingEntity target, boolean has, double distance, boolean lineOfSight) {
		if (!has) {
			return;
		}
		faceTarget(target);
		if (this.tickCount % RuhYiyenConfig.REPOSITION_TICKS != 0) {
			return;
		}
		if (!lineOfSight && noSightTicks >= RuhYiyenConfig.NO_SIGHT_REPOSITION_TICKS) {
			getNavigation().moveTo(target, RuhYiyenConfig.APPROACH_SPEED);
			return;
		}
		if (distance < RuhYiyenConfig.KITE_MIN_DISTANCE) {
			Vec3 away = awayFrom(target);
			getNavigation().moveTo(getX() + away.x * 7.0, getY(), getZ() + away.z * 7.0, RuhYiyenConfig.KITE_SPEED);
			return;
		}
		if (distance > RuhYiyenConfig.KITE_MAX_DISTANCE) {
			getNavigation().moveTo(target, RuhYiyenConfig.APPROACH_SPEED);
			return;
		}
		flipTimer--;
		if (flipTimer <= 0) {
			flipTimer = 2 + this.random.nextInt(3);
			strafeDir = this.random.nextBoolean() ? 1 : -1;
		}
		double[] p = SpiritLogic.orbitPoint(getX(), getZ(), target.getX(), target.getZ(), distance, strafeDir * 0.35);
		getNavigation().moveTo(p[0], getY(), p[1], RuhYiyenConfig.STRAFE_SPEED);
	}

	/** Gövdenin ortasındaki ruh çekirdeğinin dünya konumu. */
	private Vec3 corePosition() {
		return position().add(forward().scale(0.35)).add(0.0, getBbHeight() * 0.62, 0.0);
	}

	private void gatherFx(ServerLevel server) {
		// Hazırlık: çekirdeğe doğru toplanan enerji (ölçülü)
		if (this.tickCount % 2 != 0) {
			return;
		}
		Vec3 core = corePosition();
		double r = 1.2 * (1.0 - brain.progress()) + 0.2;
		double angle = this.tickCount * 0.5;
		server.sendParticles(SpiritFx.VIOLET, core.x + Math.cos(angle) * r, core.y + Math.sin(angle * 0.7) * 0.4, core.z + Math.sin(angle) * r,
				1, 0.0, 0.0, 0.0, 0.0);
		server.sendParticles(ParticleTypes.END_ROD, core.x, core.y, core.z, 1, 0.1, 0.1, 0.1, 0.0);
	}

	// ------------------------------------------------------------------ Ruh Oku

	private void fireBolt(ServerLevel server, LivingEntity target) {
		Vec3 origin = corePosition().add(forward().scale(0.4));
		Vec3 aim = chestOf(target);
		double flight = SpiritLogic.leadTicks(origin.distanceTo(aim), RuhYiyenConfig.BOLT_SPEED,
				RuhYiyenConfig.BOLT_MAX_LEAD_TICKS, RuhYiyenConfig.BOLT_LEAD_FACTOR);
		Vec3 predicted = aim.add(targetVelocity().scale(flight));
		Vec3 direction = predicted.subtract(origin);
		if (direction.lengthSqr() < 1.0E-4) {
			return;
		}
		bolts.add(new RuhMermisi(origin, direction.normalize().scale(RuhYiyenConfig.BOLT_SPEED)));
		SpiritFx.sound(server, this, SoundEvents.WITHER_SHOOT, 0.6F, 1.7F);
	}

	private void tickBolts(ServerLevel server) {
		Iterator<RuhMermisi> iterator = bolts.iterator();
		while (iterator.hasNext()) {
			RuhMermisi bolt = iterator.next();
			RuhMermisi.Outcome outcome = bolt.step(server);
			if (outcome == RuhMermisi.Outcome.FLYING) {
				continue;
			}
			iterator.remove();
			Vec3 at = bolt.impact();
			if (at != null) {
				server.sendParticles(SpiritFx.PALE, at.x, at.y, at.z, 6, 0.15, 0.15, 0.15, 0.02);
				server.sendParticles(ParticleTypes.SOUL, at.x, at.y, at.z, 2, 0.1, 0.1, 0.1, 0.02);
			}
			if (outcome == RuhMermisi.Outcome.HIT_PLAYER && bolt.victim() != null) {
				LivingEntity victim = bolt.victim();
				float damage = RuhYiyenConfig.BOLT_DAMAGE_MIN
						+ this.random.nextFloat() * (RuhYiyenConfig.BOLT_DAMAGE_MAX - RuhYiyenConfig.BOLT_DAMAGE_MIN);
				DamageSource source = damageSources().mobAttack(this);
				if (victim.hurtServer(server, source, damage)) {
					Vec3 v = bolt.velocity();
					victim.knockback(RuhYiyenConfig.BOLT_KNOCKBACK, -v.x, -v.z, source, damage);
				}
				SpiritFx.sound(server, at != null ? at : victim.position(), SoundEvents.VEX_HURT, 0.7F, 0.6F);
			}
		}
	}

	// ------------------------------------------------------------------ Ruh Emdirme

	private void drainPulse(ServerLevel server, LivingEntity target) {
		float dealt = RuhYiyenConfig.DRAIN_PULSE_DAMAGE;
		// Ruhsal enerji: zırhı yok sayar (bağ kopmadıkça kaçınılamaz bir baskı DEĞİL; bağı bozmanın yolları var).
		if (!target.hurtServer(server, damageSources().magic(), dealt)) {
			return;
		}
		boolean hiddet = target instanceof ServerPlayer player && BerserkerManager.isActive(player);
		float heal = SpiritLogic.drainHeal(dealt, hiddet, healedThisChannel, healedTotal, getMaxHealth());
		if (heal > 0.0F) {
			heal(heal);
			healedThisChannel += heal;
			healedTotal += heal;
		}
		SpiritFx.sound(server, this, SoundEvents.ENDERMAN_TELEPORT, 0.5F, 0.5F);
		Vec3 core = corePosition();
		server.sendParticles(hiddet ? SpiritFx.BLOOD : SpiritFx.PALE, core.x, core.y, core.z, 5, 0.2, 0.2, 0.2, 0.02);
	}

	/** Oyuncudan ruhun çekirdeğine akan enerji: bağ görünür (ölçülü, her 2 tick'te birkaç nokta). */
	private void drainFlowFx(ServerLevel server, LivingEntity target) {
		Vec3 from = chestOf(target);
		Vec3 to = corePosition();
		Vec3 delta = to.subtract(from);
		int points = (int) Math.min(10, Math.max(3, delta.length() / 1.2));
		double phase = (this.tickCount % 10) / 10.0;
		for (int i = 0; i < points; i++) {
			double t = ((i + phase) / points);
			Vec3 p = from.add(delta.scale(t));
			server.sendParticles(SpiritFx.VIOLET, p.x, p.y, p.z, 1, 0.04, 0.04, 0.04, 0.0);
		}
		server.sendParticles(ParticleTypes.SOUL, from.x, from.y, from.z, 1, 0.2, 0.3, 0.2, 0.02);
	}

	private void releaseClaim() {
		if (claimTarget != null) {
			SpiritCoordinator.release(claimTarget, getUUID(), level().getGameTime());
			claimTarget = null;
		}
	}

	// ------------------------------------------------------------------ Ses kimliği: derinden uğultular, enerji birikimi ve emme sesleri

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.WITHER_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.ENDERMAN_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.ENDERMAN_DEATH;
	}
}
