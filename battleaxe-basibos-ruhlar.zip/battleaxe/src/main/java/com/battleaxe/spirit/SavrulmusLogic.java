package com.battleaxe.spirit;

/**
 * Savrulmuş Ruh'un savaş mantığı: SAF durum makinesi (Minecraft'tan bağımsız; test: tools/test/SpiritBrainTest.java).
 *
 * <p>Tek bir {@link Attack} durumu vardır; iki saldırı aynı anda yürümez. Her tick'te en çok BİR olay döner. Bekleme süreleri
 * saldırı çözülürken kurulur ve her tick yalnızca azalır. Hareket (çevresinde dönme, arkaya geçme) varlıktadır; bu sınıf
 * yalnızca NE ZAMAN saldıracağına karar verir.
 *
 * <p>Sıra: pençe kombosu (2 seri vuruş) → geri çekilme → çevresinde dönüp yeni açı arama. Uzak mesafede, görüş hattı varken ve
 * bekleme bitince Ruh Sıçrayışı; iniş sonrası savunmasız kalır.
 */
public final class SavrulmusLogic {
	private SavrulmusLogic() {
	}

	/** Anlık durum (istemciye sıra numarasıyla senkronlanır; SIRAYI DEĞİŞTİRME). */
	public enum Attack {
		IDLE,
		CLAW_WINDUP,
		CLAW_SWING,
		RETREAT,
		LEAP_WINDUP,
		LEAP_AIR,
		LEAP_RECOVER;

		public static Attack byOrdinal(int ordinal) {
			Attack[] values = values();
			return ordinal >= 0 && ordinal < values.length ? values[ordinal] : IDLE;
		}
	}

	public enum Event {
		NONE,
		CLAW_WINDUP_START,
		CLAW_HIT,
		RETREAT_START,
		LEAP_WINDUP_START,
		LEAP_LAUNCH,
		LEAP_CANCELLED,
		LEAP_LANDED
	}

	/**
	 * @param distance  hedefe mesafe
	 * @param inReach   pençe menzilinde VE görüş hattı var
	 * @param landed    havadaysa: yere indi veya bir engele çarptı
	 * @param roll      0-1 rastgele (test edilebilirlik için dışarıdan)
	 */
	public record Inputs(boolean hasTarget, double distance, boolean lineOfSight, boolean inReach, boolean landed, double roll) {
	}

	public static final class Brain {
		private Attack attack = Attack.IDLE;
		private int ticksLeft;
		private int phaseTotal;
		private int hitsDone;
		private int comboCooldown = SavrulmusConfig.COMBO_COOLDOWN_TICKS / 2;
		private int leapCooldown = SavrulmusConfig.LEAP_INITIAL_COOLDOWN_TICKS;
		private int globalGap;

		public Attack attack() {
			return attack;
		}

		public boolean isIdle() {
			return attack == Attack.IDLE;
		}

		/** Sıçrayış sonrası yorgunluk: ruh bu sürede ek hasar alır. */
		public boolean exposed() {
			return attack == Attack.LEAP_RECOVER;
		}

		public int comboCooldown() {
			return comboCooldown;
		}

		public int leapCooldown() {
			return leapCooldown;
		}

		public int globalGap() {
			return globalGap;
		}

		public int hitsDone() {
			return hitsDone;
		}

		public float progress() {
			if (phaseTotal <= 0 || attack == Attack.IDLE) {
				return 0.0F;
			}
			return (float) SpiritLogic.clamp(1.0 - (double) ticksLeft / phaseTotal, 0.0, 1.0);
		}

		/** Ruh öldü/hedef yok: saldırıyı güvenle sonlandırır; bekleme süreleri KORUNUR. */
		public void abort() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			hitsDone = 0;
		}

		public Event step(Inputs in) {
			comboCooldown = Math.max(0, comboCooldown - 1);
			leapCooldown = Math.max(0, leapCooldown - 1);
			globalGap = Math.max(0, globalGap - 1);

			switch (attack) {
				case CLAW_WINDUP -> {
					if (--ticksLeft <= 0) {
						hitsDone++;
						begin(Attack.CLAW_SWING, SavrulmusConfig.CLAW_SWING_TICKS);
						return Event.CLAW_HIT;
					}
					return Event.NONE;
				}
				case CLAW_SWING -> {
					if (--ticksLeft <= 0) {
						if (hitsDone < SavrulmusConfig.COMBO_HITS && in.hasTarget() && in.inReach()) {
							begin(Attack.CLAW_WINDUP, SavrulmusConfig.CLAW_FOLLOWUP_WINDUP_TICKS);
							return Event.CLAW_WINDUP_START;
						}
						comboCooldown = SavrulmusConfig.COMBO_COOLDOWN_TICKS;
						hitsDone = 0;
						begin(Attack.RETREAT, SavrulmusConfig.RETREAT_TICKS);
						return Event.RETREAT_START;
					}
					return Event.NONE;
				}
				case RETREAT -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				case LEAP_WINDUP -> {
					if (--ticksLeft <= 0) {
						double d = in.distance();
						boolean ok = in.hasTarget() && in.lineOfSight()
								&& d >= SavrulmusConfig.LEAP_MIN_RANGE * 0.5 && d <= SavrulmusConfig.LEAP_MAX_RANGE * 1.3;
						if (ok) {
							begin(Attack.LEAP_AIR, SavrulmusConfig.LEAP_MAX_AIR_TICKS);
							return Event.LEAP_LAUNCH;
						}
						leapCooldown = SavrulmusConfig.LEAP_FAIL_COOLDOWN_TICKS;
						finish();
						return Event.LEAP_CANCELLED;
					}
					return Event.NONE;
				}
				case LEAP_AIR -> {
					ticksLeft--;
					int elapsed = phaseTotal - ticksLeft;
					if (ticksLeft <= 0 || (in.landed() && elapsed >= SavrulmusConfig.LEAP_MIN_AIR_TICKS)) {
						leapCooldown = SavrulmusConfig.LEAP_COOLDOWN_TICKS;
						begin(Attack.LEAP_RECOVER, SavrulmusConfig.LEAP_RECOVER_TICKS);
						return Event.LEAP_LANDED;
					}
					return Event.NONE;
				}
				case LEAP_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				default -> {
					return choose(in);
				}
			}
		}

		private Event choose(Inputs in) {
			if (!in.hasTarget() || globalGap > 0) {
				return Event.NONE;
			}
			double d = in.distance();
			if (leapCooldown == 0 && in.lineOfSight() && d >= SavrulmusConfig.LEAP_MIN_RANGE && d <= SavrulmusConfig.LEAP_MAX_RANGE
					&& in.roll() < SavrulmusConfig.LEAP_CHANCE_PER_TICK) {
				begin(Attack.LEAP_WINDUP, SavrulmusConfig.LEAP_WINDUP_TICKS);
				return Event.LEAP_WINDUP_START;
			}
			if (comboCooldown == 0 && in.inReach() && d <= SavrulmusConfig.CLAW_TRIGGER_RANGE) {
				hitsDone = 0;
				begin(Attack.CLAW_WINDUP, SavrulmusConfig.CLAW_WINDUP_TICKS);
				return Event.CLAW_WINDUP_START;
			}
			return Event.NONE;
		}

		private void begin(Attack next, int ticks) {
			attack = next;
			ticksLeft = Math.max(1, ticks);
			phaseTotal = ticksLeft;
		}

		private void finish() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			hitsDone = 0;
			globalGap = Math.max(globalGap, SavrulmusConfig.GLOBAL_GAP_TICKS);
		}
	}
}
