package com.battleaxe.spirit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.BattleAxeMod;

/**
 * Zincirle Mühürleme'nin oyuncu üzerindeki etkisi: kısa süreli (oyuncuyu hareketsiz BIRAKMAYAN) hız ve zıplama kısıtı.
 *
 * <p>Güvenlik: etki iki GEÇİCİ öznitelik değiştiricisidir (kayda yazılmaz; sunucu kapansa/oyuncu çıksa kalmaz), sabit kimliklidir
 * (üst üste binmez). Mühür şu yollarla biter: süre dolar, Shunpo kullanılır, oyuncu mühürleyen ruha tek vuruşta yeterince hasar
 * verir, ruh ölür veya oyuncu ölür/ayrılır. Her bitişte {@link SpiritConfig#SEAL_IMMUNITY_TICKS} boyunca aynı oyuncu yeniden
 * mühürlenemez (art arda zincirleme yok).
 */
public final class SpiritSeal {
	private SpiritSeal() {
	}

	private static final Identifier SPEED_ID = BattleAxeMod.id("spirit_seal_speed");
	private static final Identifier JUMP_ID = BattleAxeMod.id("spirit_seal_jump");

	private record Seal(UUID owner, long end) {
	}

	private static final Map<UUID, Seal> SEALS = new HashMap<>();
	/** Oyuncu -> bağışıklığın bittiği oyun saati. */
	private static final Map<UUID, Long> IMMUNE = new HashMap<>();

	public static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(SpiritSeal::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			SEALS.clear();
			IMMUNE.clear();
		});
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (entity instanceof ServerPlayer player && SEALS.containsKey(player.getUUID())) {
				release(player, player.level().getGameTime(), 0);
			}
		});
	}

	/** Oyuncu şu an mühürlenebilir mi (zaten mühürlü değil, bağışıklığı yok, hayatta). */
	public static boolean canSeal(ServerPlayer player, long now) {
		if (!player.isAlive() || player.isSpectator() || SEALS.containsKey(player.getUUID())) {
			return false;
		}
		Long immuneUntil = IMMUNE.get(player.getUUID());
		// Saat geriye gittiyse (bağışıklık beklenenden uzak geleceğe düşüyorsa) bağışıklık geçersiz sayılır.
		return immuneUntil == null || now >= immuneUntil || immuneUntil - now > SpiritConfig.SEAL_IMMUNITY_TICKS + 40L;
	}

	public static boolean isSealed(ServerPlayer player) {
		return SEALS.containsKey(player.getUUID());
	}

	public static boolean isSealedBy(ServerPlayer player, UUID owner) {
		Seal seal = SEALS.get(player.getUUID());
		return seal != null && seal.owner.equals(owner);
	}

	/** Mührü uygular (öncesinde {@link #canSeal} denetlenmiş olmalı). */
	public static void apply(ServerPlayer player, Entity owner, long now) {
		SEALS.put(player.getUUID(), new Seal(owner.getUUID(), now + SpiritConfig.SEAL_TICKS));
		addModifier(player.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_ID, SpiritConfig.SEAL_SPEED_PENALTY);
		addModifier(player.getAttribute(Attributes.JUMP_STRENGTH), JUMP_ID, SpiritConfig.SEAL_JUMP_PENALTY);
		if (player.level() instanceof ServerLevel level) {
			SpiritFx.sound(level, player, net.minecraft.sounds.SoundEvents.ANVIL_HIT, 0.8F, 0.6F);
			SpiritFx.ring(level, player.getX(), player.getY() + 1.0, player.getZ(), 0.7, 12, SpiritFx.VIOLET);
		}
	}

	/**
	 * Mührü kaldırır ve bağışıklık başlatır. {@code extraGrace}: ek bağışıklık (Shunpo kaçışı gibi).
	 */
	public static void release(ServerPlayer player, long now, int extraGrace) {
		Seal seal = SEALS.remove(player.getUUID());
		removeModifier(player.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_ID);
		removeModifier(player.getAttribute(Attributes.JUMP_STRENGTH), JUMP_ID);
		if (seal != null) {
			IMMUNE.put(player.getUUID(), now + SpiritConfig.SEAL_IMMUNITY_TICKS + Math.max(0, extraGrace));
			if (player.level() instanceof ServerLevel level) {
				SpiritFx.ring(level, player.getX(), player.getY() + 1.0, player.getZ(), 0.9, 14, SpiritFx.PALE);
			}
		}
	}

	/** Shunpo ışınlanması mührü kırar (ShunpoManager çağırır). */
	public static void onShunpo(ServerPlayer player) {
		if (isSealed(player)) {
			release(player, player.level().getGameTime(), SpiritConfig.SHUNPO_ESCAPE_GRACE_TICKS);
		}
	}

	/** Ruh öldü/kaldırıldı: onun mühürlediği herkes serbest kalır. */
	public static void releaseOwnedBy(ServerLevel level, UUID owner) {
		List<UUID> freed = new ArrayList<>();
		for (Map.Entry<UUID, Seal> entry : SEALS.entrySet()) {
			if (entry.getValue().owner.equals(owner)) {
				freed.add(entry.getKey());
			}
		}
		for (UUID id : freed) {
			ServerPlayer player = level.getServer().getPlayerList().getPlayer(id);
			if (player != null) {
				release(player, level.getGameTime(), 0);
			} else {
				SEALS.remove(id);
			}
		}
	}

	private static void tick(MinecraftServer server) {
		if (SEALS.isEmpty()) {
			if (!IMMUNE.isEmpty() && server.getTickCount() % 200 == 0) {
				cleanImmunity(server);
			}
			return;
		}
		for (Map.Entry<UUID, Seal> entry : new ArrayList<>(SEALS.entrySet())) {
			ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
			if (player == null || !player.isAlive() || player.isRemoved()) {
				SEALS.remove(entry.getKey()); // oyuncu nesnesi gittiyse geçici değiştiriciler de gitmiştir
				continue;
			}
			long now = player.level().getGameTime();
			Seal seal = entry.getValue();
			if (now >= seal.end || seal.end - now > SpiritConfig.SEAL_TICKS + 40L) {
				release(player, now, 0);
				continue;
			}
			if (player.level() instanceof ServerLevel level && player.tickCount % 3 == 0) {
				Vec3 chest = player.position().add(0.0, 1.0, 0.0);
				SpiritFx.ring(level, chest.x, chest.y - 0.3, chest.z, 0.6, 6, SpiritFx.DARK);
				Entity owner = level.getEntity(seal.owner);
				if (owner != null) {
					SpiritFx.line(level, owner.position().add(0.0, owner.getBbHeight() * 0.6, 0.0), chest, 1.1, SpiritFx.VIOLET);
				}
				level.sendParticles(ParticleTypes.ELECTRIC_SPARK, chest.x, chest.y, chest.z, 1, 0.3, 0.4, 0.3, 0.02);
			}
		}
	}

	private static void cleanImmunity(MinecraftServer server) {
		ServerLevel overworld = server.overworld();
		if (overworld == null) {
			return;
		}
		long now = overworld.getGameTime();
		IMMUNE.values().removeIf(until -> now >= until || until - now > SpiritConfig.SEAL_IMMUNITY_TICKS + 400L);
	}

	private static void addModifier(AttributeInstance instance, Identifier id, double amount) {
		if (instance != null && instance.getModifier(id) == null) {
			instance.addTransientModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		}
	}

	private static void removeModifier(AttributeInstance instance, Identifier id) {
		if (instance != null && instance.getModifier(id) != null) {
			instance.removeModifier(id);
		}
	}
}
