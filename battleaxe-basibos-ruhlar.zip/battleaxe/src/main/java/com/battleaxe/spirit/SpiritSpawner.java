package com.battleaxe.spirit;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;

/**
 * Başıboş Ruh spawn altyapısı. Henüz hiçbir biyom/boyuta/portala BAĞLI DEĞİLDİR; ruhlar normal dünyada kontrolsüz doğmaz.
 *
 * <p>İleride Anormal Biyom ve Ruhlar Boyutu bir karşılaşma çıkaracağı zaman şu iki adım yeter: {@link SpiritEncounter#pick(double)}
 * ile bir düzen seçmek ve {@link #spawnEncounter} çağırmak. Tek ruh için {@link #spawn}. Geliştirme sırasında {@code /baltaruh}
 * komutu aynı çağrıları kullanır (bkz. {@link SpiritCommand}).
 */
public final class SpiritSpawner {
	private SpiritSpawner() {
	}

	/** Verilen yere tek bir ruh yerleştirir; sığmıyorsa (blok içinde) {@code null}. Ruh kalıcıdır (uzaklaşınca silinmez). */
	public static SpiritEntity spawn(ServerLevel level, SpiritKind kind, double x, double y, double z, float yaw) {
		EntityType<? extends SpiritEntity> type = ModSpiritTypes.typeOf(kind);
		SpiritEntity spirit = type.create(level, EntitySpawnReason.COMMAND);
		if (spirit == null) {
			return null;
		}
		spirit.snapTo(x, y, z, yaw, 0.0F);
		if (!level.noCollision(spirit)) {
			return null;
		}
		spirit.setPersistenceRequired();
		level.addFreshEntity(spirit);
		return spirit;
	}

	/**
	 * Bir karşılaşma düzenini yerleştirir. {@code center}: karşılaşmanın merkezi; {@code toward}: ruhların yöneldiği nokta
	 * (genelde oyuncu). Her üye zemine oturtulur; sığmayan üye atlanır. Üyeler asgari mesafeyle yerleşir (yığılma yok).
	 */
	public static List<SpiritEntity> spawnEncounter(ServerLevel level, SpiritEncounter.Layout layout, Vec3 center, Vec3 toward) {
		double base = Math.atan2(toward.z - center.z, toward.x - center.x);
		List<SpiritEntity> spawned = new ArrayList<>();
		for (SpiritEncounter.Slot slot : SpiritEncounter.slots(layout)) {
			double angle = base + Math.toRadians(slot.angleDeg());
			double x = center.x + Math.cos(angle) * slot.distance();
			double z = center.z + Math.sin(angle) * slot.distance();
			double y = findStandY(level, x, center.y, z);
			if (Double.isNaN(y)) {
				continue;
			}
			// Ruh, merkezden oyuncuya doğru bakar.
			float yaw = (float) (Math.toDegrees(Math.atan2(toward.z - z, toward.x - x)) - 90.0);
			SpiritEntity spirit = spawn(level, slot.kind(), x, y, z, yaw);
			if (spirit != null) {
				spawned.add(spirit);
			}
		}
		return spawned;
	}

	/** Verilen sütunda ayakların durabileceği yüksekliği (blok y) arar; bulunamazsa NaN. */
	public static double findStandY(ServerLevel level, double x, double aroundY, double z) {
		int top = (int) Math.floor(aroundY + SpiritConfig.ENCOUNTER_SPAWN_SEARCH_UP);
		int bottom = (int) Math.floor(aroundY - SpiritConfig.ENCOUNTER_SPAWN_SEARCH_DOWN);
		for (int y = top; y >= bottom; y--) {
			BlockPos feet = BlockPos.containing(x, y, z);
			BlockPos below = feet.below();
			BlockPos head = feet.above();
			var feetState = level.getBlockState(feet);
			boolean feetFree = feetState.getCollisionShape(level, feet).isEmpty() && feetState.getFluidState().isEmpty();
			boolean headFree = level.getBlockState(head).getCollisionShape(level, head).isEmpty();
			boolean ground = !level.getBlockState(below).getCollisionShape(level, below).isEmpty();
			if (feetFree && headFree && ground) {
				return y;
			}
		}
		return Double.NaN;
	}
}
