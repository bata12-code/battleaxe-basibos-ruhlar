package com.battleaxe.spirit;

/** Ruh Yiyen (menzilli avcı, baskı ve iyileşme) dengeleme ayarları. */
public final class RuhYiyenConfig {
	private RuhYiyenConfig() {
	}

	// ---- Temel özellikler
	public static final double MAX_HEALTH = 60.0;
	public static final double ARMOR = 4.0;
	public static final double MOVEMENT_SPEED = 0.25;
	public static final double FOLLOW_RANGE = 32.0;
	public static final double KNOCKBACK_RESISTANCE = 0.1;
	public static final double ATTACK_DAMAGE = 6.0;

	// ---- Mesafe koruma
	public static final double KITE_MIN_DISTANCE = 7.0;
	public static final double KITE_MAX_DISTANCE = 16.0;
	public static final double KITE_SPEED = 1.3;
	public static final double STRAFE_SPEED = 0.8;
	public static final double APPROACH_SPEED = 1.0;
	public static final int REPOSITION_TICKS = 10;
	/** Bu kadar tick görüş hattı yoksa hedefe doğru konum değiştirir. */
	public static final int NO_SIGHT_REPOSITION_TICKS = 20;

	// ---- Ruh Okları (menzilli saldırı)
	public static final double BOLT_MIN_RANGE = 2.5;
	public static final double BOLT_MAX_RANGE = 26.0;
	public static final int BOLT_WINDUP_TICKS = 16;
	public static final int BOLT_RELEASE_TICKS = 8;
	public static final int BOLT_COOLDOWN_TICKS = 50;
	public static final int BOLT_INITIAL_COOLDOWN_TICKS = 40;
	public static final float BOLT_DAMAGE_MIN = 5.0F;
	public static final float BOLT_DAMAGE_MAX = 7.0F;
	/** Mermi hızı (blok/tick): hızlı ama uyarı + yan hareketle kaçınılabilir. */
	public static final double BOLT_SPEED = 0.85;
	public static final int BOLT_MAX_AGE_TICKS = 50;
	public static final double BOLT_HIT_RADIUS = 0.8;
	public static final double BOLT_KNOCKBACK = 0.4;
	/** Hareket yönüne göre tahmin: 1 = tam; <1 kaçınılmaz olmasın. Aynı yönde koşan oyuncunun isabet ihtimali artar. */
	public static final double BOLT_LEAD_FACTOR = 0.65;
	public static final int BOLT_MAX_LEAD_TICKS = 18;

	// ---- Ruh Emdirme
	public static final double DRAIN_MIN_RANGE = 5.0;
	public static final double DRAIN_START_RANGE = 14.0;
	/** Bağlantı bu mesafeyi aşarsa kopar (oyuncu uzaklaşarak bozabilir). */
	public static final double DRAIN_BREAK_RANGE = 17.0;
	public static final int DRAIN_WINDUP_TICKS = 24;
	public static final int DRAIN_CHANNEL_TICKS = 60;
	public static final int DRAIN_PULSE_INTERVAL_TICKS = 10;
	public static final float DRAIN_PULSE_DAMAGE = 2.0F;
	/** Bağlantı için kesintisiz görüş hattı toleransı (tick): köşe dönerek kesmek işe yarar. */
	public static final int DRAIN_LOS_GRACE_TICKS = 5;
	/** Bağlantı sürerken alınan bu kadar hasar bağı koparır (tek balta vuruşu yeter). */
	public static final float DRAIN_INTERRUPT_DAMAGE = 10.0F;
	public static final int DRAIN_COOLDOWN_TICKS = 320;
	public static final int DRAIN_INITIAL_COOLDOWN_TICKS = 100;
	public static final int DRAIN_FAIL_COOLDOWN_TICKS = 80;
	/** Normal bitişten sonra yorgunluk (savunmasız). */
	public static final int DRAIN_RECOVER_TICKS = 16;
	/** Bağ ZORLA kopunca geri tepme: daha uzun savunmasızlık. */
	public static final int DRAIN_BROKEN_RECOVER_TICKS = 28;
	/** Boştayken her tick emme seçme olasılığı; can azaldıkça artar (uygun fırsatta iyileşir). */
	public static final double DRAIN_CHANCE_PER_TICK = 0.04;
	public static final double DRAIN_CHANCE_WOUNDED_PER_TICK = 0.12;
	public static final double WOUNDED_HEALTH_RATIO = 0.7;

	// ---- İyileşme sınırları: sınırsız iyileşme YOK
	/** Emilen hasarın ruhun canına dönen oranı. */
	public static final double HEAL_FRACTION = 0.6;
	/** Hiddet'teki oyuncunun öfkeli kanı acıdır: iyileşme bu çarpanla azalır. */
	public static final double HIDDET_HEAL_MULTIPLIER = 0.5;
	/** Tek bağlantıda iyileşebileceği en çok can. */
	public static final float HEAL_CAP_PER_CHANNEL = 8.0F;
	/** Ruhun ömrü boyunca iyileşebileceği toplam (maksimum canın oranı). */
	public static final double HEAL_BUDGET_RATIO = 0.5;
}
