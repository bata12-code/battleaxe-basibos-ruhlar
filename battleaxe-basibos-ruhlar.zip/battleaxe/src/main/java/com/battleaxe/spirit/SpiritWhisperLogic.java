package com.battleaxe.spirit;

import com.battleaxe.chain.ChainWhisperLogic;

/**
 * Baltanın Başıboş Ruhlar'a tepkisi (SAF; test: tools/test/SpiritWhisperTest.java). Balta, bir ruhu İLK kez devirdiğinde (oturum
 * başına tür başına) kısa bir söz söyler; sonraki öldürmelerde nadiren rütbesine göre konuşur. Sözler açıklama değil, soru doğurur.
 * Metinler dil dosyalarındadır: {@code message.battleaxe.spirit.first.<tür>} ve {@code message.battleaxe.spirit.whisper.<bant>.<söz>}.
 */
public final class SpiritWhisperLogic {
	private SpiritWhisperLogic() {
	}

	public static final int VARIANTS = 3;
	/** İlk-öldürme sözünde iki söz arası en kısa süre (farklı türleri art arda devirince susmasın ama sıkmasın). */
	public static final int FIRST_COOLDOWN_TICKS = 400;

	private static final String FIRST_PREFIX = "message.battleaxe.spirit.first.";
	private static final String PREFIX = "message.battleaxe.spirit.whisper.";

	/** Rütbe bandı: zincir fısıltılarıyla aynı üç ton (yabancı / susamış / sadık). */
	public static int band(int rank) {
		return ChainWhisperLogic.band(rank);
	}

	/**
	 * Konuşmalı mı? {@code roll}: 0-1 rastgele; {@code lastTick}: son söz (yoksa negatif). Zaman geriye giderse serbest bırakır.
	 */
	public static boolean shouldWhisper(boolean firstOfKind, double roll, long now, long lastTick) {
		double chance = firstOfKind ? 1.0 : SpiritConfig.WHISPER_CHANCE;
		if (!(roll < chance)) {
			return false;
		}
		int cooldown = firstOfKind ? FIRST_COOLDOWN_TICKS : SpiritConfig.WHISPER_COOLDOWN_TICKS;
		return lastTick < 0L || now < lastTick || now - lastTick >= cooldown;
	}

	/** 1..VARIANTS arası söz; {@code last} (0 = yok) ile aynı olmaz. */
	public static int pickVariant(double roll01, int last) {
		double clamped = Double.isNaN(roll01) ? 0.0 : Math.max(0.0, Math.min(0.999999, roll01));
		int pick = (int) (clamped * VARIANTS) + 1;
		if (pick == last) {
			pick = pick % VARIANTS + 1;
		}
		return pick;
	}

	public static String firstKey(SpiritKind kind) {
		return FIRST_PREFIX + kind.id();
	}

	public static String key(int band, int variant) {
		int b = Math.max(0, Math.min(ChainWhisperLogic.BANDS - 1, band));
		int v = Math.max(1, Math.min(VARIANTS, variant));
		return PREFIX + b + "." + v;
	}
}
