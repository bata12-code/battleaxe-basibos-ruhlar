package com.battleaxe.spirit;

/**
 * Zincirli Ruh'un savaş mantığı: SAF durum makinesi (test: tools/test/SpiritBrainTest.java).
 *
 * <p>Üç saldırı: Zincir Savurma (yakın, geniş yatay), Ruhani Darbe (yere ağır vuruş + genişleyen şok dalgası) ve Zincirle
 * Mühürleme (menzilli; yana kaçılabilir). Her saldırı belirgin bir hazırlık süresine sahiptir ve ardından ruh SAVUNMASIZ kalır.
 * Tek durum vardır: iki ağır saldırı aynı anda yürümez. Bekleme süreleri saldırı çözülürken kurulur, her tick yalnızca azalır.
 */
public final class ZincirliLogic {
	private ZincirliLogic() {
	}

	/** Anlık durum (istemciye sıra numarasıyla senkronlanır; SIRAYI DEĞİŞTİRME). */
	public enum Attack {
		IDLE,
		SWEEP_WINDUP,
		SWEEP_STRIKE,
		SWEEP_RECOVER,
		SLAM_WINDUP,
		SLAM_STRIKE,
		SLAM_RECOVER,
		CHAIN_WINDUP,
		CHAIN_THROW,
		CHAIN_RECOVER;

		public static Attack byOrdinal(int ordinal) {
			Attack[] values = values();
			return ordinal >= 0 && ordinal < values.length ? values[ordinal] : IDLE;
		}
	}

	public enum Event {
		NONE,
		SWEEP_WINDUP_START,
		SWEEP_HIT,
		SLAM_WINDUP_START,
		SLAM_IMPACT,
		CHAIN_WINDUP_START,
		CHAIN_LAUNCH,
		CHAIN_END
	}

	/**
	 * @param targetSealable hedef şu an mühürlenebilir (bağışıklığı yok, zaten mühürlü değil)
	 * @param claimOk        bu hedefe kontrol yeteneği uygulama izni var (koordinasyon)
	 * @param chainResolved  fırlatılmış zincir bir şeye çarptı/sona erdi
	 */
	public record Inputs(boolean hasTarget, double distance, boolean lineOfSight, boolean targetSealable, boolean claimOk,
			boolean chainResolved, double roll) {
	}

	public static final class Brain {
		private Attack attack = Attack.IDLE;
		private int ticksLeft;
		private int phaseTotal;
		private int sweepCooldown = ZincirliConfig.SWEEP_INITIAL_COOLDOWN_TICKS;
		private int slamCooldown = ZincirliConfig.SLAM_INITIAL_COOLDOWN_TICKS;
		private int chainCooldown = ZincirliConfig.CHAIN_INITIAL_COOLDOWN_TICKS;
		private int globalGap;

		public Attack attack() {
			return attack;
		}

		public boolean isIdle() {
			return attack == Attack.IDLE;
		}

		/** Ağır bir saldırının toparlanma anı: ruh bu sürede ek hasar alır. */
		public boolean exposed() {
			return attack == Attack.SWEEP_RECOVER || attack == Attack.SLAM_RECOVER || attack == Attack.CHAIN_RECOVER;
		}

		public int sweepCooldown() {
			return sweepCooldown;
		}

		public int slamCooldown() {
			return slamCooldown;
		}

		public int chainCooldown() {
			return chainCooldown;
		}

		public int globalGap() {
			return globalGap;
		}

		public float progress() {
			if (phaseTotal <= 0 || attack == Attack.IDLE) {
				return 0.0F;
			}
			return (float) SpiritLogic.clamp(1.0 - (double) ticksLeft / phaseTotal, 0.0, 1.0);
		}

		/** Ruh öldü/hedef yok: saldırıyı güvenle sonlandırır; bekleme süreleri KORUNUR. */
		public void abort() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
		}

		public Event step(Inputs in) {
			sweepCooldown = Math.max(0, sweepCooldown - 1);
			slamCooldown = Math.max(0, slamCooldown - 1);
			chainCooldown = Math.max(0, chainCooldown - 1);
			globalGap = Math.max(0, globalGap - 1);

			switch (attack) {
				case SWEEP_WINDUP -> {
					if (--ticksLeft <= 0) {
						sweepCooldown = ZincirliConfig.SWEEP_COOLDOWN_TICKS;
						begin(Attack.SWEEP_STRIKE, ZincirliConfig.SWEEP_STRIKE_TICKS);
						return Event.SWEEP_HIT;
					}
					return Event.NONE;
				}
				case SWEEP_STRIKE -> {
					if (--ticksLeft <= 0) {
						begin(Attack.SWEEP_RECOVER, ZincirliConfig.SWEEP_RECOVER_TICKS);
					}
					return Event.NONE;
				}
				case SWEEP_RECOVER, SLAM_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				case SLAM_WINDUP -> {
					if (--ticksLeft <= 0) {
						slamCooldown = ZincirliConfig.SLAM_COOLDOWN_TICKS;
						begin(Attack.SLAM_STRIKE, ZincirliConfig.SLAM_STRIKE_TICKS);
						return Event.SLAM_IMPACT;
					}
					return Event.NONE;
				}
				case SLAM_STRIKE -> {
					if (--ticksLeft <= 0) {
						begin(Attack.SLAM_RECOVER, ZincirliConfig.SLAM_RECOVER_TICKS);
					}
					return Event.NONE;
				}
				case CHAIN_WINDUP -> {
					if (--ticksLeft <= 0) {
						chainCooldown = ZincirliConfig.CHAIN_COOLDOWN_TICKS;
						begin(Attack.CHAIN_THROW, ZincirliConfig.CHAIN_MAX_THROW_TICKS);
						return Event.CHAIN_LAUNCH;
					}
					return Event.NONE;
				}
				case CHAIN_THROW -> {
					if (--ticksLeft <= 0 || in.chainResolved()) {
						begin(Attack.CHAIN_RECOVER, ZincirliConfig.CHAIN_RECOVER_TICKS);
						return Event.CHAIN_END;
					}
					return Event.NONE;
				}
				case CHAIN_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				default -> {
					return choose(in);
				}
			}
		}

		private Event choose(Inputs in) {
			if (!in.hasTarget() || globalGap > 0) {
				return Event.NONE;
			}
			double d = in.distance();
			boolean slamReady = slamCooldown == 0 && d <= ZincirliConfig.SLAM_TRIGGER_RANGE;
			boolean sweepReady = sweepCooldown == 0 && in.lineOfSight() && d <= ZincirliConfig.SWEEP_TRIGGER_RANGE;
			if (slamReady && sweepReady) {
				if (in.roll() < 0.5) {
					return startSweep();
				}
				return startSlam();
			}
			if (sweepReady) {
				return startSweep();
			}
			if (slamReady) {
				return startSlam();
			}
			// Yakın mesafede ama bekleme sürüyorsa mühür/menzilli seçilmez: ruh alanı daraltmaya devam eder.
			if (d <= ZincirliConfig.SLAM_TRIGGER_RANGE) {
				return Event.NONE;
			}
			if (chainCooldown == 0 && in.lineOfSight() && in.targetSealable() && in.claimOk()
					&& d >= ZincirliConfig.CHAIN_MIN_RANGE && d <= ZincirliConfig.CHAIN_MAX_RANGE) {
				begin(Attack.CHAIN_WINDUP, ZincirliConfig.CHAIN_WINDUP_TICKS);
				return Event.CHAIN_WINDUP_START;
			}
			return Event.NONE;
		}

		private Event startSweep() {
			begin(Attack.SWEEP_WINDUP, ZincirliConfig.SWEEP_WINDUP_TICKS);
			return Event.SWEEP_WINDUP_START;
		}

		private Event startSlam() {
			begin(Attack.SLAM_WINDUP, ZincirliConfig.SLAM_WINDUP_TICKS);
			return Event.SLAM_WINDUP_START;
		}

		private void begin(Attack next, int ticks) {
			attack = next;
			ticksLeft = Math.max(1, ticks);
			phaseTotal = ticksLeft;
		}

		private void finish() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			globalGap = Math.max(globalGap, ZincirliConfig.GLOBAL_GAP_TICKS);
		}
	}
}
