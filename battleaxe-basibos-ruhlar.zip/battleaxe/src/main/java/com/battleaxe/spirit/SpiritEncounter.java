package com.battleaxe.spirit;

import java.util.ArrayList;
import java.util.List;

/**
 * Başıboş Ruh karşılaşma düzenleri (SAF; test: tools/test/SpiritEncounterTest.java). Henüz hiçbir biyom/boyuta bağlı DEĞİLDİR:
 * ileride Anormal Biyom ve Ruhlar Boyutu bir karşılaşma çıkaracağı zaman {@link #pick(double)} ile bir düzen seçip
 * {@code SpiritSpawner.spawnEncounter(...)} çağırır. Düzenler ruhların rollerini tamamlar ve birbirinin üstüne yığılmaz:
 * en çok bir Zincirli Ruh ve bir Ruh Yiyen; Savrulmuş Ruhlar iki yandan açılır; Ruh Yiyen geride durur.
 */
public final class SpiritEncounter {
	private SpiritEncounter() {
	}

	/** Karşılaşma düzeni: üyeler ve seçilme ağırlığı. Komut seçenekleri {@link #id()} ile verilir. */
	public enum Layout {
		SOLO_SAVRULMUS("tek_savrulmus", 1.0, SpiritKind.SAVRULMUS),
		SOLO_RUH_YIYEN("tek_ruh_yiyen", 0.5, SpiritKind.RUH_YIYEN),
		SOLO_ZINCIRLI("tek_zincirli", 0.5, SpiritKind.ZINCIRLI),
		/** İki Savrulmuş Ruh: iki yandan baskı. */
		HUNTERS("avcilar", 2.0, SpiritKind.SAVRULMUS, SpiritKind.SAVRULMUS),
		/** Yakın baskı + uzaktan atış. */
		SKIRMISH("catisma", 2.0, SpiritKind.SAVRULMUS, SpiritKind.RUH_YIYEN),
		/** Ağır muhafız + yan baskı. */
		WARD("muhafiz", 1.5, SpiritKind.ZINCIRLI, SpiritKind.SAVRULMUS),
		/** Üçünün tehlikeli birleşimi. */
		TRIAD("uclu", 1.0, SpiritKind.ZINCIRLI, SpiritKind.SAVRULMUS, SpiritKind.RUH_YIYEN),
		/** En kalabalık düzen (sınır: {@link SpiritConfig#ENCOUNTER_MAX_SIZE}). */
		SIEGE("kusatma", 0.5, SpiritKind.ZINCIRLI, SpiritKind.SAVRULMUS, SpiritKind.SAVRULMUS, SpiritKind.RUH_YIYEN);

		private final String id;
		private final double weight;
		private final List<SpiritKind> members;

		Layout(String id, double weight, SpiritKind... members) {
			this.id = id;
			this.weight = weight;
			this.members = List.of(members);
		}

		public String id() {
			return id;
		}

		public double weight() {
			return weight;
		}

		public List<SpiritKind> members() {
			return members;
		}

		public static Layout byId(String id) {
			for (Layout layout : values()) {
				if (layout.id.equals(id)) {
					return layout;
				}
			}
			return null;
		}
	}

	/**
	 * Düzendeki bir üyenin yeri: karşılaşma merkezine göre mesafe ve açı (derece). 0° = merkezden OYUNCUYA doğru,
	 * 180° = oyuncudan uzağa. Zincirli Ruh öne, Savrulmuş Ruhlar yanlara, Ruh Yiyen geriye yerleşir.
	 */
	public record Slot(SpiritKind kind, double distance, double angleDeg) {
		public double x() {
			return Math.cos(Math.toRadians(angleDeg)) * distance;
		}

		public double z() {
			return Math.sin(Math.toRadians(angleDeg)) * distance;
		}
	}

	private static final double[] SAVRULMUS_ANGLES = {70.0, -70.0, 0.0, 140.0};
	private static final double[] SAVRULMUS_DISTANCES = {5.0, 5.0, 6.5, 6.5};

	/** Düzenin üyelerinin göreli yerleri. */
	public static List<Slot> slots(Layout layout) {
		List<Slot> out = new ArrayList<>();
		int savrulmus = 0;
		for (SpiritKind kind : layout.members()) {
			switch (kind) {
				case ZINCIRLI -> out.add(new Slot(kind, 3.0, 0.0));
				case RUH_YIYEN -> out.add(new Slot(kind, 7.0, 180.0));
				case SAVRULMUS -> {
					// Tek başına gelen Savrulmuş Ruh doğrudan öne yerleşir; kalabalıkta yanlara açılır.
					boolean alone = layout.members().size() == 1;
					int i = Math.min(savrulmus, SAVRULMUS_ANGLES.length - 1);
					out.add(new Slot(kind, alone ? 4.0 : SAVRULMUS_DISTANCES[i], alone ? 0.0 : SAVRULMUS_ANGLES[i]));
					savrulmus++;
				}
			}
		}
		return out;
	}

	/** Ağırlıklı düzen seçimi; {@code roll01} 0-1 arası rastgele sayıdır. */
	public static Layout pick(double roll01) {
		double total = 0.0;
		for (Layout layout : Layout.values()) {
			total += layout.weight;
		}
		double target = SpiritLogic.clamp(roll01, 0.0, 0.999999) * total;
		double acc = 0.0;
		for (Layout layout : Layout.values()) {
			acc += layout.weight;
			if (target < acc) {
				return layout;
			}
		}
		return Layout.SOLO_SAVRULMUS;
	}

	/** Üyelerin hepsi birbirinden en az {@code minSeparation} uzakta mı. */
	public static boolean separated(List<Slot> slots, double minSeparation) {
		for (int i = 0; i < slots.size(); i++) {
			for (int j = i + 1; j < slots.size(); j++) {
				double dx = slots.get(i).x() - slots.get(j).x();
				double dz = slots.get(i).z() - slots.get(j).z();
				if (Math.sqrt(dx * dx + dz * dz) < minSeparation) {
					return false;
				}
			}
		}
		return true;
	}
}
