package com.battleaxe.spirit;

/**
 * Başıboş Ruhlar'ın ortak SAF mantığı (Minecraft'tan bağımsız; test: tools/test/SpiritLogicTest.java):
 * gelen hasarın ruhsal doğaya göre ayarı, Ruh Emdirme iyileşme sınırları ve konumlandırma geometrisi.
 */
public final class SpiritLogic {
	private SpiritLogic() {
	}

	// ------------------------------------------------------------------ Hasar

	/** Savaş Baltası hasar çarpanı; negatif rütbe (balta değil) 1.0 döndürür. */
	public static double axeMultiplier(int axeRank) {
		if (axeRank < 0) {
			return 1.0;
		}
		return 1.0 + SpiritConfig.AXE_BONUS_BASE + SpiritConfig.AXE_BONUS_PER_RANK * Math.min(axeRank, 9);
	}

	/**
	 * Ruhsal bedenin aldığı hasar.
	 *
	 * @param axeRank  hasarı Savaş Baltası veriyorsa baltanın ruh rütbesi (0-9), değilse -1
	 * @param exposed  ruh şu an savunmasız mı (sıçrayış sonrası, emme kopması, ağır saldırı sonrası)
	 */
	public static float incoming(float amount, boolean projectile, int axeRank, boolean exposed) {
		if (!(amount > 0.0F)) {
			return Math.max(0.0F, amount);
		}
		double result = amount;
		if (axeRank >= 0) {
			result *= axeMultiplier(axeRank); // balta ruhsal bedeni keser: direnç yok sayılır
		} else if (projectile) {
			result *= 1.0 - SpiritConfig.PROJECTILE_RESISTANCE;
		}
		if (exposed) {
			result *= 1.0 + SpiritConfig.EXPOSED_DAMAGE_BONUS;
		}
		return (float) result;
	}

	// ------------------------------------------------------------------ Ruh Emdirme iyileşmesi

	/**
	 * Bir emme darbesinden ruhun kazanacağı can. Hiddet'teki oyuncudan emilen enerji acıdır (çarpan);
	 * tek bağlantıdaki ve ömür boyu toplam iyileşme sınırlıdır; sınırsız iyileşme yoktur.
	 */
	public static float drainHeal(float dealt, boolean hiddet, float healedThisChannel, float healedTotal, float maxHealth) {
		if (!(dealt > 0.0F) || !(maxHealth > 0.0F)) {
			return 0.0F;
		}
		double heal = dealt * RuhYiyenConfig.HEAL_FRACTION * (hiddet ? RuhYiyenConfig.HIDDET_HEAL_MULTIPLIER : 1.0);
		double channelRoom = RuhYiyenConfig.HEAL_CAP_PER_CHANNEL - healedThisChannel;
		double lifetimeRoom = maxHealth * RuhYiyenConfig.HEAL_BUDGET_RATIO - healedTotal;
		heal = Math.min(heal, Math.min(channelRoom, lifetimeRoom));
		return (float) Math.max(0.0, heal);
	}

	// ------------------------------------------------------------------ Geometri

	/** Açıyı (-PI, PI] aralığına getirir. */
	public static double wrapAngle(double angle) {
		double a = angle % (Math.PI * 2.0);
		if (a > Math.PI) {
			a -= Math.PI * 2.0;
		} else if (a <= -Math.PI) {
			a += Math.PI * 2.0;
		}
		return a;
	}

	/** Hedefin tam ARKASINI gösteren yön açısı (atan2(z, x)); {@code yawDeg} Minecraft bakış açısıdır. */
	public static double backAngle(double targetYawDeg) {
		double yaw = Math.toRadians(targetYawDeg);
		return Math.atan2(-Math.cos(yaw), Math.sin(yaw));
	}

	/** {@code from} açısından {@code to} açısına en kısa yönün işareti (+1 / -1); eşitse +1. */
	public static int shortestArcSign(double from, double to) {
		return wrapAngle(to - from) >= 0.0 ? 1 : -1;
	}

	/** Hedefin çevresinde, ruhun bulunduğu açıdan {@code step} radyan ilerideki çember noktası: {x, z}. */
	public static double[] orbitPoint(double selfX, double selfZ, double targetX, double targetZ, double radius, double step) {
		double angle = Math.atan2(selfZ - targetZ, selfX - targetX) + step;
		return new double[] {targetX + Math.cos(angle) * radius, targetZ + Math.sin(angle) * radius};
	}

	/** Ruhun hedefe göre bulunduğu açı (atan2(z, x)). */
	public static double angleAround(double selfX, double selfZ, double targetX, double targetZ) {
		return Math.atan2(selfZ - targetZ, selfX - targetX);
	}

	/** (dx, dz) vektörü, Minecraft bakış açısı {@code yawDeg} yönünden en çok {@code halfAngleDeg} sapmış mı. */
	public static boolean inCone(double dx, double dz, double yawDeg, double halfAngleDeg) {
		double length = Math.sqrt(dx * dx + dz * dz);
		if (length < 1.0E-6) {
			return true;
		}
		double yaw = Math.toRadians(yawDeg);
		double fx = -Math.sin(yaw);
		double fz = Math.cos(yaw);
		double cos = (dx * fx + dz * fz) / length;
		return cos >= Math.cos(Math.toRadians(halfAngleDeg));
	}

	/** Genişleyen şok halkası bu mesafedeki oyuncuya ulaştı mı (halka kalınlığı içinde). */
	public static boolean ringReaches(double distance, double radius, double thickness) {
		return Math.abs(distance - radius) <= thickness * 0.5;
	}

	/** Sıçrayışın yatay hızı: mesafeyle orantılı, sınırlı. */
	public static double leapSpeed(double distance) {
		double speed = distance / SavrulmusConfig.LEAP_SPEED_DIVISOR;
		return Math.max(SavrulmusConfig.LEAP_MIN_SPEED, Math.min(SavrulmusConfig.LEAP_MAX_SPEED, speed));
	}

	/**
	 * Mermi önden nişanı: hedefin (kendi izlediğimiz) hızına göre atış noktası kayması, uçuş süresi sınırlı ve
	 * tam isabetli olmayan bir çarpanla ölçeklenir. Dönüş: ölçeklenmiş uçuş tick sayısı.
	 */
	public static double leadTicks(double distance, double speed, int maxLeadTicks, double factor) {
		if (!(speed > 0.0)) {
			return 0.0;
		}
		return Math.min(maxLeadTicks, distance / speed) * factor;
	}

	public static double clamp(double v, double lo, double hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
