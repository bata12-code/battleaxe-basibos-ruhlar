package com.battleaxe.spirit;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import com.battleaxe.BattleAxeMod;

/**
 * Başıboş Ruh varlık tipleri. Test için: /summon battleaxe:savrulmus_ruh | ruh_yiyen | zincirli_ruh, ya da
 * /baltaruh (bkz. {@link SpiritCommand}). Hiçbir biyom/boyuta bağlı DEĞİLDİR; doğal olarak doğmazlar.
 */
public final class ModSpiritTypes {
	private ModSpiritTypes() {
	}

	public static final ResourceKey<EntityType<?>> SAVRULMUS_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, BattleAxeMod.id(SpiritKind.SAVRULMUS.id()));
	public static final ResourceKey<EntityType<?>> RUH_YIYEN_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, BattleAxeMod.id(SpiritKind.RUH_YIYEN.id()));
	public static final ResourceKey<EntityType<?>> ZINCIRLI_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, BattleAxeMod.id(SpiritKind.ZINCIRLI.id()));

	/** Hızlı, çevik; orta boy (süzülen, eğri gövde). */
	public static final EntityType<SavrulmusRuhEntity> SAVRULMUS = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			SAVRULMUS_KEY,
			EntityType.Builder.<SavrulmusRuhEntity>of(SavrulmusRuhEntity::new, MobCategory.MONSTER)
					.sized(0.7F, 1.9F)
					.eyeHeight(1.6F)
					.clientTrackingRange(10)
					.build(SAVRULMUS_KEY)
	);

	/** Uzun ve ince silüet. */
	public static final EntityType<RuhYiyenEntity> RUH_YIYEN = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			RUH_YIYEN_KEY,
			EntityType.Builder.<RuhYiyenEntity>of(RuhYiyenEntity::new, MobCategory.MONSTER)
					.sized(0.7F, 2.7F)
					.eyeHeight(2.3F)
					.clientTrackingRange(10)
					.build(RUH_YIYEN_KEY)
	);

	/** En büyük ve ağır silüet. */
	public static final EntityType<ZincirliRuhEntity> ZINCIRLI = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			ZINCIRLI_KEY,
			EntityType.Builder.<ZincirliRuhEntity>of(ZincirliRuhEntity::new, MobCategory.MONSTER)
					.sized(1.2F, 2.6F)
					.eyeHeight(2.2F)
					.clientTrackingRange(10)
					.build(ZINCIRLI_KEY)
	);

	/** Türe karşılık gelen varlık tipi (spawn altyapısı ve komutlar kullanır). */
	public static EntityType<? extends SpiritEntity> typeOf(SpiritKind kind) {
		return switch (kind) {
			case SAVRULMUS -> SAVRULMUS;
			case RUH_YIYEN -> RUH_YIYEN;
			case ZINCIRLI -> ZINCIRLI;
		};
	}

	public static void initialize() {
		FabricDefaultAttributeRegistry.register(SAVRULMUS, SavrulmusRuhEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(RUH_YIYEN, RuhYiyenEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(ZINCIRLI, ZincirliRuhEntity.createAttributes());

		SpiritCoordinator.initialize();
		SpiritSeal.initialize();
		SpiritWhispers.initialize();
		SpiritCommand.initialize();
	}
}
