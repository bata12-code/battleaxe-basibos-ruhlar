package com.battleaxe.effect;

import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.berserker.BerserkerConfig;
import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.soul.RankStyle;
import com.battleaxe.soul.SoulLogic;
import com.battleaxe.soul.SoulManager;

/**
 * Savaş Baltası ile yapılan kritik vuruşlarda oynatılan görsel efektler.
 *
 * <p>Bu sınıf YALNIZCA parçacık gönderir. Hiçbir entity (yıldırım dahil), blok, hasar veya ateş
 * oluşturmaz; dolayısıyla çevreye ve mobların canına hiçbir etkisi yoktur.
 */
public final class CritEffects {
	private CritEffects() {
	}

	// ------------------------------------------------------------------
	// AYARLAR
	// ------------------------------------------------------------------

	/** Yıldırım efektinin seçilme olasılığı (0.0 - 1.0). Kalan olasılıkla alevli efekt oynar. */
	public static final float LIGHTNING_CHANCE = 0.25F;

	/** Efektin, hedefin gövde ortasından saldırgana doğru kaydırılma mesafesi (blok). */
	private static final double TOWARD_ATTACKER_OFFSET = 0.3;

	/** Yıldırımın, vuruş noktasının ne kadar üstünden başladığı (blok). */
	private static final double BOLT_HEIGHT = 4.5;

	/** Yıldırımın kaç noktadan çizileceği (yüksek = daha sürekli görünür). */
	private static final int BOLT_SEGMENTS = 18;

	// Renkler 0xRRGGBB. Toz parçacıkları ömürleri boyunca "ilk renkten ikinci renge" geçer.
	/** Alev kıvılcımı: turuncu -> koyu kırmızı. */
	private static final DustColorTransitionOptions EMBER =
			new DustColorTransitionOptions(0xFF9A1F, 0xC81E00, 0.7F);
	/** Yıldırım çekirdeği: beyaz -> mor. */
	private static final DustColorTransitionOptions BOLT_CORE =
			new DustColorTransitionOptions(0xFFFFFF, 0x7C3AED, 0.9F);
	/** Yıldırım parıltısı: açık mavi -> koyu mor. */
	private static final DustColorTransitionOptions BOLT_GLOW =
			new DustColorTransitionOptions(0x7DD3FC, 0x6D28D9, 0.8F);

	// Berserker aktifken kullanılan, daha koyu ve sert renkler.
	/** Berserker alevi: parlak turuncu-kırmızı -> kömür siyahı. */
	private static final DustColorTransitionOptions BERSERKER_EMBER =
			new DustColorTransitionOptions(0xFF3A10, 0x2A0000, 0.9F);
	/** Berserker yıldırım çekirdeği: beyaz -> kan kırmızısı. */
	private static final DustColorTransitionOptions BERSERKER_BOLT_CORE =
			new DustColorTransitionOptions(0xFFFFFF, 0xFF2040, 0.95F);
	/** Berserker yıldırım parıltısı: pembe-kırmızı -> koyu bordo. */
	private static final DustColorTransitionOptions BERSERKER_BOLT_GLOW =
			new DustColorTransitionOptions(0xFF5A6E, 0x7A0020, 0.9F);

	// ------------------------------------------------------------------

	/** Kritik vuruş efektini oynatır: iki efektten biri rastgele seçilir. */
	public static void play(ServerLevel level, Player attacker, Entity target) {
		play(level, attacker, target, false);
	}

	/**
	 * Kritik vuruş efektini oynatır. Saldırgan Berserker modundaysa efektler koyu/sert
	 * Berserker varyantına geçer ve parçacık yıldırımı daha sık seçilir.
	 *
	 * @param suppressLightning true ise parçacık yıldırımı seçilmez (aynı vuruşta zaten gerçek
	 *                          görsel yıldırım düştüyse üst üste binmesin diye)
	 */
	public static void play(ServerLevel level, Player attacker, Entity target, boolean suppressLightning) {
		// Vuruş noktası: hedefin gövde ortası, saldırgana doğru biraz kaydırılmış.
		// Böylece efekt mobun içinde kalmaz, vurulan yüzeyde görünür.
		double x = target.getX();
		double y = target.getY(0.5);
		double z = target.getZ();

		double dx = attacker.getX() - x;
		double dz = attacker.getZ() - z;
		double length = Math.sqrt(dx * dx + dz * dz);
		if (length > 1.0E-4) {
			x += dx / length * TOWARD_ATTACKER_OFFSET;
			z += dz / length * TOWARD_ATTACKER_OFFSET;
		}

		boolean berserker = attacker instanceof ServerPlayer player && BerserkerManager.isActive(player);
		// Rütbe: balta ne kadar çok ruh topladıysa efektler o kadar yoğun ve katmanlı olur.
		int rank = SoulManager.rankOf(attacker.getMainHandItem());
		double lightningChance = berserker ? BerserkerConfig.BERSERKER_CRIT_LIGHTNING_CHANCE : LIGHTNING_CHANCE;

		if (!suppressLightning && ThreadLocalRandom.current().nextDouble() < lightningChance) {
			lightning(level, x, y, z, berserker, rank);
		} else {
			flame(level, x, y, z, berserker, rank);
		}

		rankLayers(level, x, y, z, rank);
	}

	/**
	 * Alevli kritik: küçük, yoğun, kısa. Ana efekt turuncu-kırmızı kıvılcımlardır
	 * (yaklaşık 0.3 - 0.6 sn), üstüne birkaç gerçek alev parçacığı eklenir.
	 * Berserker varyantı daha koyu, daha yoğun ve dumanlıdır.
	 */
	private static void flame(ServerLevel level, double x, double y, double z, boolean berserker, int rank) {
		if (berserker) {
			level.sendParticles(BERSERKER_EMBER, x, y, z, SoulLogic.scaled(22, rank), 0.24, 0.24, 0.24, 0.0);
			level.sendParticles(ParticleTypes.FLAME, x, y, z, SoulLogic.scaled(6, rank), 0.15, 0.15, 0.15, 0.07);
			level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 3, 0.15, 0.15, 0.15, 0.02);
			return;
		}

		level.sendParticles(EMBER, x, y, z, SoulLogic.scaled(12, rank), 0.18, 0.18, 0.18, 0.0);
		level.sendParticles(ParticleTypes.FLAME, x, y, z, SoulLogic.scaled(4, rank), 0.12, 0.12, 0.12, 0.05);
	}

	/**
	 * Yıldırımlı kritik: yukarıdan vuruş noktasına inen zikzaklı bir çizgi ve çarpma noktasında
	 * elektrik kıvılcımları. Gerçek LightningBolt entity'si KULLANILMAZ. Normalde beyaz-mavi-mor;
	 * Berserker'da beyaz-kan kırmızısı, daha uzun ve daha sık noktalı.
	 */
	private static void lightning(ServerLevel level, double x, double y, double z, boolean berserker, int rank) {
		ThreadLocalRandom random = ThreadLocalRandom.current();

		DustColorTransitionOptions core = berserker ? BERSERKER_BOLT_CORE : BOLT_CORE;
		DustColorTransitionOptions glow = berserker ? BERSERKER_BOLT_GLOW : BOLT_GLOW;
		double height = berserker ? BOLT_HEIGHT + 1.0 : BOLT_HEIGHT;
		int segments = (berserker ? BOLT_SEGMENTS + 4 : BOLT_SEGMENTS) + rank / 3 * 2;

		// Yıldırım vuruş noktasının biraz yanından başlayıp tam noktaya iner.
		double startOffsetX = random.nextDouble(-0.6, 0.6);
		double startOffsetZ = random.nextDouble(-0.6, 0.6);

		for (int i = 0; i <= segments; i++) {
			double t = (double) i / segments; // 0 = üst uç, 1 = vuruş noktası
			double fade = 1.0 - t;            // zikzak aşağı indikçe sönümlenir

			double px = x + (startOffsetX + random.nextDouble(-0.18, 0.18)) * fade;
			double pz = z + (startOffsetZ + random.nextDouble(-0.18, 0.18)) * fade;
			double py = y + height * fade;

			level.sendParticles(core, px, py, pz, 2, 0.04, 0.04, 0.04, 0.0);
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, px, py, pz, 1, 0.05, 0.05, 0.05, 0.0);
		}

		// Çarpma noktasında kıvılcım patlaması.
		level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, SoulLogic.scaled(berserker ? 20 : 14, rank), 0.2, 0.2, 0.2, 0.4);
		level.sendParticles(glow, x, y, z, SoulLogic.scaled(berserker ? 14 : 10, rank), 0.25, 0.25, 0.25, 0.0);
	}

	/**
	 * Rütbeyle eklenen ekstra katmanlar (rütbe 0'da hiçbir şey eklenmez):
	 * 1+ rütbe renginde kor, 2+ duman, 3+ süpürme çizgisi, 5+ elektrik sütunu,
	 * 6+ üçlü süpürme, 7+ patlama, 9+ kıvılcım halkası.
	 */
	private static void rankLayers(ServerLevel level, double x, double y, double z, int rank) {
		if (rank <= 0) {
			return;
		}

		level.sendParticles(RankStyle.dust(rank), x, y, z, SoulLogic.scaled(6, rank), 0.3, 0.3, 0.3, 0.0);

		if (rank >= 2) {
			level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, rank / 2, 0.2, 0.2, 0.2, 0.02);
		}
		if (rank >= 3) {
			level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0.0, 0.0, 0.0, 0.0);
		}
		if (rank >= 5) {
			for (int i = 0; i < 6; i++) {
				level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 0.25 * i, z, 1, 0.05, 0.05, 0.05, 0.0);
			}
		}
		if (rank >= 6) {
			level.sendParticles(ParticleTypes.SWEEP_ATTACK, x + 0.6, y, z, 0, 0.0, 0.0, 0.0, 0.0);
			level.sendParticles(ParticleTypes.SWEEP_ATTACK, x - 0.6, y, z, 0, 0.0, 0.0, 0.0, 0.0);
		}
		if (rank >= 7) {
			level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
		}
		if (rank >= 9) {
			for (int i = 0; i < 16; i++) {
				double angle = i * (Math.PI * 2.0 / 16.0);
				level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
						x + Math.cos(angle) * 0.9, y - 0.3, z + Math.sin(angle) * 0.9, 1, 0.0, 0.0, 0.0, 0.0);
			}
		}
	}
}
