package com.battleaxe.call;

/**
 * Gökyüzü/ay geometrisi (SAF mantık; Minecraft'a bağımlı değildir, hem sunucuda hem istemcide kullanılır).
 *
 * <p>Vanilla gökyüzü: gün zamanından "gök açısı" hesaplanır; gök kürenin dönüşü X ekseni etrafındadır
 * (önce Y ekseninde -90 derece), güneş açı 0'da tepede, ay tam karşısındadır. Dünya koordinatında ay yönü
 * {@code (sin t, -cos t, 0)}'dır (t = gök açısı x 2pi): öğlen (6000) güneş tepede, gece yarısı (18000) ay tepede,
 * ay doğudan (+X) doğup batıdan (-X) batar. Bakış yönü için Minecraft kuralları: yaw 0 = güney (+Z),
 * yaw 90 = batı (-X); pitch pozitif = aşağı.
 */
public final class CallMoon {
	private CallMoon() {
	}

	/** Vanilla'daki gün zamanı -> gök açısı (0..1) dönüşümü (doğrusal değildir). */
	public static double celestialAngle(long dayTime) {
		double d = frac(dayTime / 24000.0 - 0.25);
		double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
		return (d * 2.0 + e) / 3.0;
	}

	/** Ayın dünyadaki birim yön vektörü {x, y, z}. */
	public static double[] moonDirection(double celestial) {
		double t = celestial * 2.0 * Math.PI;
		return new double[] {Math.sin(t), -Math.cos(t), 0.0};
	}

	/** Ayın ufuktan yüksekliği (sin açısı): 1 = tam tepede, 0 = ufukta, negatif = ufkun altında. */
	public static double moonElevationSin(double celestial) {
		return -Math.cos(celestial * 2.0 * Math.PI);
	}

	/** Vanilla ay evresi: 0 dolunay ... 4 yeni ay (görünmez) ... 7. */
	public static int moonPhase(long dayTime) {
		return (int) Math.floorMod(Math.floorDiv(dayTime, 24000L), 8L);
	}

	/** Ay diskinin yeterince görünür olduğu evre mi? Yeni ay ve ince hilaller (3, 4, 5) görünür sayılmaz. */
	public static boolean phaseVisible(int phase) {
		return phase != 3 && phase != 4 && phase != 5;
	}

	/** Bakış vektörünü (yaw, pitch derece) verir: {x, y, z}. */
	public static double[] lookVector(double yawDeg, double pitchDeg) {
		double yaw = Math.toRadians(yawDeg);
		double pitch = Math.toRadians(pitchDeg);
		double cp = Math.cos(pitch);
		return new double[] {-Math.sin(yaw) * cp, -Math.sin(pitch), Math.cos(yaw) * cp};
	}

	/** İki birim vektör arasındaki açı (derece). */
	public static double angleBetweenDegrees(double[] a, double[] b) {
		double dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
		return Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, dot))));
	}

	/**
	 * Dünya yönünü ekran koordinatına izdüşürür.
	 *
	 * @param dir     birim yön (dünya)
	 * @param yawDeg  kamera yaw (derece)
	 * @param pitchDeg kamera pitch (derece, pozitif = aşağı)
	 * @param fovDeg  DİKEY görüş alanı (derece; Minecraft'ın FOV ayarı dikeydir)
	 * @return {ekranX, ekranY, pikselBaşınaTanjant} ya da yön kameranın arkasındaysa null.
	 *         Üçüncü değer: 1 birim tanjantın ekranda kaç piksel ettiği (ay yarıçapını piksele çevirmek için).
	 */
	public static double[] project(double[] dir, double yawDeg, double pitchDeg, double fovDeg, double width, double height) {
		double yaw = Math.toRadians(yawDeg);
		double pitch = Math.toRadians(pitchDeg);
		double sy = Math.sin(yaw);
		double cy = Math.cos(yaw);
		double sp = Math.sin(pitch);
		double cp = Math.cos(pitch);

		// Kamera tabanı: ileri f, sağ r, yukarı u (dünya koordinatında).
		double fx = -sy * cp, fy = -sp, fz = cy * cp;
		double rx = -cy, ry = 0.0, rz = -sy;
		double ux = -sy * sp, uy = cp, uz = cy * sp;

		double zc = dir[0] * fx + dir[1] * fy + dir[2] * fz;
		if (zc < 0.05) {
			return null;
		}
		double xc = dir[0] * rx + dir[1] * ry + dir[2] * rz;
		double yc = dir[0] * ux + dir[1] * uy + dir[2] * uz;

		double tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
		double pxPerTan = (height / 2.0) / tanHalf;
		double sx = width / 2.0 + (xc / zc) * pxPerTan;
		double sYpx = height / 2.0 - (yc / zc) * pxPerTan;
		return new double[] {sx, sYpx, pxPerTan};
	}

	/** Ay diskinin yaklaşık açısal yarıçapının tanjantı (vanilla: 20 birimlik kare, 100 uzaklık -> 0.1; disk karenin ~%90'ı). */
	public static final double MOON_RADIUS_TAN = 0.09;

	private static double frac(double v) {
		return v - Math.floor(v);
	}
}
