package com.battleaxe.call;

import java.util.HashMap;
import java.util.Map;
import java.util.OptionalLong;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biomes;

import com.battleaxe.evolution.EvolutionAttachments;
import com.battleaxe.evolution.EvolutionData;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusAttachments;
import com.battleaxe.nexus.NexusData;
import com.battleaxe.thrown.ThrownAxeTracker;

/**
 * <b>Baltanın Çağrısı</b>: oyuncu Savaş Baltası'nı edinmeden ÖNCE onu hissettiren seyrek, gizemli mesaj ve işaretler.
 *
 * <ul>
 *   <li><b>Aşama 1 - Fısıltı</b>: nadir, kısa, bağlama (gece, yeraltı, Nether) duyarlı mesajlar.</li>
 *   <li><b>Aşama 2 - İşaretler</b>: gece aya bakarken ayın önünden geçen karanlık balta silueti (istemcide
 *       çizilir) ve Nether'da uzaktan gelen örs sesi. Çoğu zaman hiçbir şey olmaz.</li>
 *   <li><b>Aşama 3 - Tanınma</b>: Nether'a girmek, Wither'ı görmek/yenmek, Nether Yıldızı edinmek mesajları
 *       daha anlamlı hâle getirir; her dönüm noktası bir kez özel bir söz getirir.</li>
 * </ul>
 *
 * <p><b>Güvenlik ilkeleri:</b> hiçbir tarif, eşya, boss ya da ilerleme değiştirilmez/kilitlenmez; her şey yalnızca
 * mesaj ve görsel/işitsel ipucudur. Veri OYUNCUYA bağlıdır (başkasına uygulanamaz); mesajlar, sesler ve paketler
 * yalnızca ilgili oyuncuya gider. Balta edinilince (ya da edinilmiş olduğu anlaşılınca) sistem o oyuncu için sonsuza
 * dek susar. Ayarlar: {@link CallConfig}.
 */
public final class CallManager {
	private CallManager() {
	}

	/** Oyun oturumuna özgü (kalıcı olmayan) sayaçlar; çıkışta temizlenir, ölümle sıfırlanmaz. */
	private static final class Session {
		long sessionStart;
		long lastEvent;
		int messages;
		int moonSigns;
		int forgeSigns;

		// Planlanmış demir vuruşları
		int strikesLeft;
		long nextStrike;

		// Planlanmış dönüm noktası mesajı (kalıcı değil: yeniden girişte yeniden hesaplanır)
		int pendingMilestone;
		long milestoneDue;
	}

	private static final Map<UUID, Session> SESSIONS = new HashMap<>();

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(CallSignPayload.TYPE, CallSignPayload.CODEC);
		OmenManager.initialize();

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (!CallConfig.ENABLED) {
				return;
			}
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tick(server, player);
			}
		});

		// Wither doğuşu: yakındaki oyuncular tanık olur (yalnızca yüklenirken/doğarken; yoklama yok).
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
			if (CallConfig.ENABLED && entity.getType() == EntityTypes.WITHER) {
				witness(level, entity, null, CallLogic.F_WITHER_SEEN);
			}
		});

		// Wither ölümü: öldüren ve yakındaki tanıklar. (Baltanın mevcut ruh/ödül akışına dokunmaz.)
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (CallConfig.ENABLED && entity.getType() == EntityTypes.WITHER && entity.level() instanceof ServerLevel level) {
				ServerPlayer killer = source.getEntity() instanceof ServerPlayer p ? p : null;
				witness(level, entity, killer, CallLogic.F_WITHER_SEEN | CallLogic.F_WITHER_DEFEATED);
			}
		});

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> SESSIONS.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> SESSIONS.clear());
	}

	// ------------------------------------------------------------------
	// Durum erişimi
	// ------------------------------------------------------------------

	private static CallData data(ServerPlayer player) {
		return player.getAttachedOrElse(CallAttachments.DATA, CallData.EMPTY);
	}

	private static Session session(ServerPlayer player, long now) {
		Session session = SESSIONS.get(player.getUUID());
		if (session == null) {
			session = new Session();
			session.sessionStart = now;
			SESSIONS.put(player.getUUID(), session);
		}
		return session;
	}

	/** Bayrak(lar)ı kalıcı olarak yakar (geri dönmez). Yalnızca o oyuncunun verisini değiştirir. */
	private static void addFlags(ServerPlayer player, int flags) {
		CallData current = data(player);
		int merged = current.flags() | flags;
		if (merged != current.flags()) {
			player.setAttached(CallAttachments.DATA, current.withFlags(merged));
		}
	}

	/** Wither olayı: öldüren (varsa) ve aynı boyutta tanıklık yarıçapındaki oyuncular. */
	private static void witness(ServerLevel level, Entity wither, ServerPlayer killer, int flags) {
		MinecraftServer server = level.getServer();
		double radiusSq = CallConfig.WITHER_WITNESS_RADIUS * CallConfig.WITHER_WITNESS_RADIUS;
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			boolean nearby = player.level() == level && player.distanceToSqr(wither) <= radiusSq;
			if (nearby || player == killer) {
				addFlags(player, flags);
			}
		}
	}

	// ------------------------------------------------------------------
	// Oyuncu başına tick
	// ------------------------------------------------------------------

	private static void tick(MinecraftServer server, ServerPlayer player) {
		CallData data = data(player);
		if (CallLogic.silenced(data.flags())) {
			// Balta edinildi: Çağrı (öncü belirtiler dahil) sonsuza dek susar; kalan çalışma zamanı verisi bırakılmaz.
			SESSIONS.remove(player.getUUID());
			OmenManager.silence(player); // yalnızca ESKİ dört belirtiyi susturur
			// Kozmik Anomaliler balta sonrası da sürer: dünya, balta elde olsa da susmaz.
			if (player.isAlive() && !player.isSpectator() && player.level() instanceof ServerLevel level) {
				OmenManager.tickAfterAxe(level, player, data);
			}
			return;
		}
		if (!player.isAlive()) {
			OmenManager.interrupt(player);
			return;
		}
		if (player.isSpectator()) {
			return;
		}
		ServerLevel level = player.level() instanceof ServerLevel serverLevel ? serverLevel : null;
		if (level == null) {
			return;
		}

		long now = level.getGameTime();

		// Baltanın edinilmesi 10 sn'lik taramaya BIRAKILMAZ: her 0.2 sn'de envanter, imleç ve kalıcı istatistikler denetlenir.
		if ((player.tickCount + player.getId()) % OmenConfig.ACQUIRE_CHECK_TICKS == 0
				&& (AxeAcquisition.holdsNow(player) || AxeAcquisition.recordedByStats(player))) {
			onAxeAcquired(player);
			return;
		}

		Session rt = session(player, now);

		// Planlanmış demir vuruşları (yalnızca bekleyen varsa iş yapar).
		if (rt.strikesLeft > 0 && now >= rt.nextStrike) {
			playStrike(player, rt, now);
		}
		// Planlanmış dönüm noktası mesajı.
		if (rt.pendingMilestone != 0 && now >= rt.milestoneDue) {
			deliverMilestone(player, rt, now);
			data = data(player);
		}

		// Öncü belirtiler (gök/ufuk tezahürleri): ayrıntılar OmenManager'da.
		if (OmenManager.tick(level, player, data(player), now, rt.sessionStart, rt.lastEvent, rt.strikesLeft > 0 || rt.pendingMilestone != 0)) {
			rt.lastEvent = now;
		}

		int slot = player.tickCount + player.getId();
		if (slot % CallConfig.CHECK_INTERVAL_TICKS == 0) {
			periodicCheck(server, level, player, data, rt, now);
		}
		if (slot % CallConfig.GAZE_INTERVAL_TICKS == 0) {
			moonGazeCheck(level, player, data(player), rt, now);
		}
	}

	/** Her ~10 sn'de bir: ilerleme bayrakları, baltanın edinilip edinilmediği, mesaj ve demir sesi. */
	private static void periodicCheck(MinecraftServer server, ServerLevel level, ServerPlayer player, CallData data, Session rt, long now) {
		// 1) Envanter taraması: balta edinildiyse Çağrı biter; Nether Yıldızı ilerleme sayılır.
		int flags = data.flags();
		boolean hasStar = false;
		boolean hasAxe = false;
		Inventory inventory = player.getInventory();
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.getItem(i);
			if (stack.isEmpty()) {
				continue;
			}
			if (stack.is(ModItems.BATTLE_AXE)) {
				hasAxe = true;
				break;
			}
			if (stack.is(Items.NETHER_STAR)) {
				hasStar = true;
			}
		}
		if (hasAxe || usedAxeBefore(server, player) || AxeAcquisition.inEnderChest(player)) {
			onAxeAcquired(player);
			return;
		}

		int newFlags = flags;
		if (hasStar) {
			newFlags |= CallLogic.F_STAR;
		}
		if (level.dimension() == Level.NETHER) {
			newFlags |= CallLogic.F_NETHER;
		}
		if (newFlags != flags) {
			addFlags(player, newFlags);
			data = data(player);
		}

		int progress = CallLogic.progress(data.flags());

		// 2) Dönüm noktası: gösterilmemiş en yüksek aşama için tek seferlik mesaj planla.
		if (rt.pendingMilestone == 0 && CallConfig.MESSAGES_ENABLED) {
			int bit = CallLogic.pendingMilestone(data.flags(), data.milestones());
			if (bit != 0) {
				rt.pendingMilestone = bit;
				rt.milestoneDue = now + CallConfig.MILESTONE_DELAY_BASE_TICKS
						+ ThreadLocalRandom.current().nextInt(CallConfig.MILESTONE_DELAY_RANDOM_TICKS + 1);
			}
		}

		if (!calm(player, rt, now)) {
			return;
		}

		// 3) Mesaj (Fısıltı / Tanınma).
		if (CallConfig.MESSAGES_ENABLED) {
			maybeMessage(level, player, data, rt, now, progress);
			data = data(player);
		}

		// 4) Nether'da uzaktan örs sesi.
		if (CallConfig.FORGE_SIGN_ENABLED && level.dimension() == Level.NETHER) {
			maybeForge(level, player, data, rt, now);
		}
	}

	/**
	 * Eski dünyalar/oyuncular için: baltayı daha önce kullandığı kayıtlarından anlaşılıyorsa (Ruh Ağı'nda
	 * kazanılmış ruh, seçili evrim dalı) ya da havada fırlatılmış balta varsa, balta zaten edinilmiş sayılır.
	 */
	private static boolean usedAxeBefore(MinecraftServer server, ServerPlayer player) {
		NexusData nexus = player.getAttachedOrElse(NexusAttachments.DATA, NexusData.EMPTY);
		if (nexus.lifetimeSouls() > 0L) {
			return true;
		}
		EvolutionData evolution = player.getAttachedOrElse(EvolutionAttachments.DATA, EvolutionData.EMPTY);
		return evolution.path() >= 0 || ThrownAxeTracker.hasActive(server, player.getUUID());
	}

	/**
	 * Balta bu oyuncu tarafından ilk kez edinildi (ya da edinilmiş olduğu anlaşıldı): Çağrı bu oyuncu için KALICI olarak
	 * kapanır. Bayrak oyuncuya bağlı kalıcı veridir: ölüm, yeniden doğma, yeniden giriş ve boyut değişimiyle geri gelmez;
	 * baltanın sonradan kaybolması/atılması/sandığa konması onu açmaz. Yalnızca BU oyuncuyu etkiler.
	 */
	static void onAxeAcquired(ServerPlayer player) {
		addFlags(player, CallLogic.F_AXE);
		SESSIONS.remove(player.getUUID());
		OmenManager.silence(player);
	}

	/** Oyuncu yeni oyuna girmişse, az önce başka bir çağrı olayı olduysa, hasar yediyse ya da uyuyorsa sessizlik. */
	private static boolean calm(ServerPlayer player, Session rt, long now) {
		return now - rt.sessionStart >= CallConfig.INITIAL_QUIET_TICKS
				&& CallLogic.ready(now, rt.lastEvent, CallConfig.GLOBAL_EVENT_GAP_TICKS)
				&& player.hurtTime <= 0
				&& !player.isSleeping()
				&& !OmenManager.isBusy(player, now);
	}

	// ------------------------------------------------------------------
	// Mesajlar
	// ------------------------------------------------------------------

	private static void maybeMessage(ServerLevel level, ServerPlayer player, CallData data, Session rt, long now, int progress) {
		if (rt.messages >= CallConfig.MESSAGES_PER_SESSION
				|| !CallLogic.ready(now, data.lastMessage(), CallConfig.MESSAGE_MIN_GAP_TICKS)) {
			return;
		}
		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextDouble() >= CallLogic.messageChance(progress)) {
			return; // Çoğu denetimde hiçbir şey olmaz: sessizlik sistemin parçasıdır.
		}

		int ctx = context(level, player);
		long seen = data.seenMask();
		int pick = CallLogic.choose(random, progress, ctx, seen, data.lastPick(), false);
		if (pick < 0) {
			// Tüm uygun mesajlar gösterilmişse ancak çok uzun süre sonra tekrara izin verilir.
			if (!CallLogic.ready(now, data.lastMessage(), CallConfig.MESSAGE_REPEAT_GAP_TICKS)
					|| CallLogic.hasUnseen(progress, ctx, seen, data.lastPick())) {
				return;
			}
			pick = CallLogic.choose(random, progress, ctx, seen, data.lastPick(), true);
			if (pick < 0) {
				return;
			}
			seen = CallLogic.resetSeen(seen, pick);
		}

		CallLogic.Entry entry = CallLogic.TABLE[pick];
		send(player, entry);
		player.setAttached(CallAttachments.DATA, data.withMessage(seen | (1L << pick), pick, now));
		rt.messages++;
		rt.lastEvent = now;
	}

	private static void send(ServerPlayer player, CallLogic.Entry entry) {
		boolean recognition = entry.kind() == CallLogic.Kind.RECOGNITION;
		Component text = Component.translatable(entry.key())
				.withStyle(recognition ? ChatFormatting.RED : ChatFormatting.GRAY)
				.withStyle(ChatFormatting.ITALIC);
		// Sohbet mesajı (action bar değil): okunaklı, geçmişte tekrar okunabilir; yalnızca bu oyuncuya.
		player.sendSystemMessage(text, false);
	}

	private static void deliverMilestone(ServerPlayer player, Session rt, long now) {
		CallData data = data(player);
		int bit = rt.pendingMilestone;
		// Mesaj hemen gösterilemiyorsa (yeni olay, uyku, hasar...) bir sonraki denetime ertelenir.
		if (!calm(player, rt, now) || !CallLogic.ready(now, rt.lastEvent, CallConfig.MILESTONE_MIN_GAP_TICKS)) {
			rt.milestoneDue = now + CallConfig.CHECK_INTERVAL_TICKS;
			return;
		}
		rt.pendingMilestone = 0;
		if ((data.flags() & bit) == 0 || (data.milestones() & bit) != 0) {
			return;
		}
		Component text = Component.translatable("call.milestone." + CallLogic.milestoneNumber(bit))
				.withStyle(ChatFormatting.RED).withStyle(ChatFormatting.ITALIC);
		player.sendSystemMessage(text, false);
		int shown = data.milestones() | CallLogic.milestonesCovered(bit);
		player.setAttached(CallAttachments.DATA, data.withMilestoneShown(shown, now));
		rt.lastEvent = now;
	}

	private static int context(ServerLevel level, ServerPlayer player) {
		boolean nether = level.dimension() == Level.NETHER;
		boolean end = level.dimension() == Level.END;
		boolean night = false;
		if (level.dimension() == Level.OVERWORLD) {
			OptionalLong dayTime = SkyProbe.dayTime(level);
			if (dayTime.isPresent()) {
				night = CallMoon.moonElevationSin(CallMoon.celestialAngle(dayTime.getAsLong())) > 0.0;
			}
		}
		boolean underground = !nether && !end && player.getY() < CallConfig.UNDERGROUND_Y;
		return CallLogic.context(nether, end, night, underground);
	}

	// ------------------------------------------------------------------
	// İşaret: Nether'da uzaktan demir dövme sesi
	// ------------------------------------------------------------------

	private static void maybeForge(ServerLevel level, ServerPlayer player, CallData data, Session rt, long now) {
		if (rt.forgeSigns >= CallConfig.FORGE_SIGNS_PER_SESSION || rt.strikesLeft > 0
				|| !CallLogic.ready(now, data.lastForge(), CallConfig.FORGE_MIN_GAP_TICKS)) {
			return;
		}
		if (!aloneNearby(level, player)) {
			return; // Yakında başka oyuncu varken çalınmaz: işaret yalnızca bu oyuncuya aittir.
		}
		double chance = CallConfig.FORGE_CHANCE;
		if (level.getBiome(player.blockPosition()).is(Biomes.BASALT_DELTAS)) {
			chance *= CallConfig.FORGE_CHANCE_BASALT_MULTIPLIER;
		}
		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (random.nextDouble() >= chance) {
			return;
		}
		rt.strikesLeft = CallConfig.FORGE_STRIKES_MIN
				+ random.nextInt(CallConfig.FORGE_STRIKES_MAX - CallConfig.FORGE_STRIKES_MIN + 1);
		rt.nextStrike = now + 1;
		rt.forgeSigns++;
		rt.lastEvent = now;
		player.setAttached(CallAttachments.DATA, data.withForge(now));
	}

	/** Oyuncunun {@link CallConfig#FORGE_PRIVACY_RADIUS} blok yakınında, aynı boyutta başka oyuncu yok mu? */
	private static boolean aloneNearby(ServerLevel level, ServerPlayer player) {
		double radiusSq = CallConfig.FORGE_PRIVACY_RADIUS * CallConfig.FORGE_PRIVACY_RADIUS;
		for (ServerPlayer other : level.getServer().getPlayerList().getPlayers()) {
			if (other != player && other.level() == level && other.distanceToSqr(player) <= radiusSq) {
				return false;
			}
		}
		return true;
	}

	/** Tek bir demir vuruşu: yalnızca bu oyuncuya, alçak ve kısık. */
	private static void playStrike(ServerPlayer player, Session rt, long now) {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		float pitch = CallConfig.FORGE_PITCH_MIN + random.nextFloat() * (CallConfig.FORGE_PITCH_MAX - CallConfig.FORGE_PITCH_MIN);
		// Her vuruş bir öncekinden biraz daha sönük: uzaklaşan bir yankı.
		float volume = CallConfig.FORGE_VOLUME * (0.7F + 0.3F * rt.strikesLeft / CallConfig.FORGE_STRIKES_MAX);
		// Oyuncuya özel ses paketi API'si kullanılmaz; kısık ses oyuncunun konumunda çalınır. Başka oyuncu duymasın diye
		// işaret yalnızca yakınında (CallConfig.FORGE_PRIVACY_RADIUS) başka oyuncu yokken planlanır (bkz. maybeForge).
		if (player.level() instanceof ServerLevel level) {
			level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.AMBIENT, volume, pitch);
		}
		rt.strikesLeft--;
		int spacing = CallConfig.FORGE_STRIKE_SPACING_MIN_TICKS
				+ random.nextInt(CallConfig.FORGE_STRIKE_SPACING_MAX_TICKS - CallConfig.FORGE_STRIKE_SPACING_MIN_TICKS + 1);
		rt.nextStrike = now + spacing;
	}

	// ------------------------------------------------------------------
	// İşaret: ayın önünden geçen balta silueti
	// ------------------------------------------------------------------

	private static void moonGazeCheck(ServerLevel level, ServerPlayer player, CallData data, Session rt, long now) {
		// Ucuz önkoşullar önce: boyut, oturum sınırı, bekleme süreleri.
		if (!CallConfig.MOON_SIGN_ENABLED || level.dimension() != Level.OVERWORLD
				|| rt.moonSigns >= CallConfig.MOON_SIGNS_PER_SESSION
				|| !CallLogic.ready(now, data.lastMoon(), CallConfig.MOON_MIN_GAP_TICKS)
				|| !calm(player, rt, now)) {
			return;
		}
		OptionalLong dayTime = SkyProbe.dayTime(level);
		if (dayTime.isEmpty()) {
			return;
		}
		// Gece mi, ay yeterince yüksekte mi, ay evresi görünür mü?
		double celestial = CallMoon.celestialAngle(dayTime.getAsLong());
		if (CallMoon.moonElevationSin(celestial) < CallConfig.MOON_MIN_ELEVATION_SIN
				|| !CallMoon.phaseVisible(CallMoon.moonPhase(dayTime.getAsLong()))) {
			return;
		}
		// Oyuncu gerçekten gökyüzünü görebilmeli ve yağmur/fırtına ayı gizlememeli.
		if (!level.canSeeSky(player.blockPosition()) || SkyProbe.precipitating(level)) {
			return;
		}
		// Oyuncu aya bakıyor mu? (Bakış yönü ile ay yönü arasındaki açı.)
		double[] look = CallMoon.lookVector(player.getYRot(), player.getXRot());
		if (CallMoon.angleBetweenDegrees(look, CallMoon.moonDirection(celestial)) > CallConfig.MOON_GAZE_DEGREES) {
			return;
		}
		if (ThreadLocalRandom.current().nextDouble() >= CallConfig.MOON_CHANCE_PER_GAZE_CHECK) {
			return;
		}

		int progress = CallLogic.progress(data.flags());
		if (ServerPlayNetworking.canSend(player, CallSignPayload.TYPE)) {
			ServerPlayNetworking.send(player, new CallSignPayload(
					CallSignPayload.KIND_MOON_AXE, (float) celestial, CallLogic.moonDuration(progress), CallLogic.moonIntensity(progress)));
		}
		// İstemci paketi alamasa bile bekleme süresi işler: sistem takılmaz, tekrar tekrar denemez.
		rt.moonSigns++;
		rt.lastEvent = now;
		player.setAttached(CallAttachments.DATA, data.withMoon(now));
	}
}
