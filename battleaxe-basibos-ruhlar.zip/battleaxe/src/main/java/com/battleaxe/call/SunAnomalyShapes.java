package com.battleaxe.call;

import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;

/**
 * <b>Parçalanmış Güneş</b>'in şekilleri (SAF; Minecraft'a bağımlı değildir; test: tools/test/AnomalyLogicTest.java).
 *
 * <p>Minecraft'ın güneşi bir KAREDİR (kenarları gökyüzünün dönüş eksenine hizalı, gün boyunca ekrana göre döner). Şekiller güneş
 * karesinin YARI KENARI = 1 birimde tanımlanır; x sağa, y yukarı. İstemci bunları güneşin gerçek yerel eksenlerine (vanilla'nın
 * kendi dönüş zinciriyle) eşler, böylece kopmalar güneşin kendi köşelerine ve kenarlarına oturur.
 *
 * <p>Parçalar yalnızca ÜSTE çizilen karanlıklardır (güneşin kendisi ve ışığı değiştirilmez): {@code dim=false} kopmuş, simsiyah
 * kısım; {@code dim=true} parlaklığını kaybetmiş, sönük bölge (yarı saydam).
 */
public final class SunAnomalyShapes {
	private SunAnomalyShapes() {
	}

	/** Bir karanlık parça: {@code xy} = x,y,x,y... (güneş karesi birimi). */
	public record Piece(float alpha, boolean dim, float[] xy) {
	}

	/** Parça ve köşe sınırları (performans ve testler için). */
	public static final int MAX_PIECES = 40;
	public static final int MAX_POINTS = 64;
	/** Karenin yarı kenarı, güneş yönüne göre tanjant: karenin gökteki görünür boyutu. Vanilla güneş dokusunun bu kadar kısmı parlaktır. */
	public static final double SUN_HALF_TAN = 0.13;
	/** Hiçbir parça karenin bu kadar dışına çıkmaz (kopan parçacıklar hariç): kenar gerçekten sönmüş görünsün. */
	public static final float BODY_LIMIT = 1.04F;
	/** Kopan parçaların (güneşten uzaklaşan karanlık kırıntılar) en uzak mesafesi. */
	public static final float FRAGMENT_LIMIT = 2.4F;

	public static Piece[] build(int variant, long seed) {
		SplittableRandom r = new SplittableRandom(seed ^ 0x5DEECE66DL);
		List<Piece> out = new ArrayList<>();
		switch (variant) {
			case SunAnomalyLogic.PARTIAL -> {
				// Bir köşesi eksik, kenarları düzensiz kopmuş; kopan kısım karanlık.
				int corner = r.nextInt(4);
				missingCorner(out, r, corner, 0.55 + r.nextDouble() * 0.30);
				edgeNotches(out, r, 2 + r.nextInt(2), corner);
				fragments(out, r, corner, 4 + r.nextInt(3), 1.25, 0.10);
			}
			case SunAnomalyLogic.CRACKED -> {
				// Yüzeyinde devasa çatlaklar; bazı bölgeler parlaklığını kaybetmiş.
				cracks(out, r, 8 + r.nextInt(3), 0.045, 0.075);
				dimPatches(out, r, 3 + r.nextInt(2));
				edgeNotches(out, r, 1, -1);
			}
			case SunAnomalyLogic.SHATTERED -> {
				// Ağır parçalanma: önemli bir bölümü kopmuş, karanlık ve düzensiz.
				int corner = r.nextInt(4);
				missingCorner(out, r, corner, 1.05 + r.nextDouble() * 0.35);
				missingCorner(out, r, (corner + 2) % 4, 0.45 + r.nextDouble() * 0.25);
				cracks(out, r, 5, 0.05, 0.08);
				dimPatches(out, r, 3);
				edgeNotches(out, r, 3, corner);
				fragments(out, r, corner, 7 + r.nextInt(3), 1.2, 0.14);
				fragments(out, r, (corner + 2) % 4, 3, 1.2, 0.09);
			}
			case SunAnomalyLogic.SCAR -> {
				// Önceki günün izi: yüzünde çok hafif tek bir çatlak (neredeyse fark edilmez).
				double a = r.nextDouble() * 2.0 * Math.PI;
				float[] scar = OmenShapes.crack(Math.cos(a) * 0.98, Math.sin(a) * 0.98, a + Math.PI + (r.nextDouble() - 0.5) * 0.5,
						1.1 + r.nextDouble() * 0.5, 0.025, r);
				clampBody(scar);
				out.add(new Piece(0.55f, false, scar));
			}
			default -> {
			}
		}
		return out.toArray(new Piece[0]);
	}

	/** Karenin bir köşesi kopmuş: köşeden iki kenara uzanan, tırtıklı bir kesikle ayrılmış üçgensi bölge. */
	private static void missingCorner(List<Piece> out, SplittableRandom r, int corner, double reach) {
		float sx = (corner & 1) == 0 ? 1.0F : -1.0F;
		float sy = (corner & 2) == 0 ? 1.0F : -1.0F;
		double a = Math.min(1.9, reach * (0.85 + r.nextDouble() * 0.3)); // yatay kenar boyunca ne kadar
		double b = Math.min(1.9, reach * (0.85 + r.nextDouble() * 0.3)); // dikey kenar boyunca ne kadar
		int n = 18;
		float[] xy = new float[(n + 4) * 2];
		int k = 0;
		// Kopma çizgisi: dikey kenar üzerindeki (1, 1-b) noktasından yatay kenar üzerindeki (1-a, 1) noktasına, tırtıklı
		double ph1 = r.nextDouble() * 6.28;
		double ph2 = r.nextDouble() * 6.28;
		for (int i = 0; i <= n; i++) {
			double t = i / (double) n;
			double px = 1.0 - a * t;
			double py = (1.0 - b) + b * t;
			double jag = 0.07 * Math.sin(t * 11.0 + ph1) + 0.04 * Math.sin(t * 27.0 + ph2) + 0.05 * (r.nextDouble() - 0.5);
			// Çizgiye dik (köşeden uzağa/yakına) kaydır: yönü (−1, −1)/√2 köşeye doğru
			px += jag * 0.7071;
			py += jag * 0.7071;
			xy[k++] = (float) (clampBody(px) * sx);
			xy[k++] = (float) (clampBody(py) * sy);
		}
		// Kopma çizgisinin iki ucundan karenin DIŞINA doğru kapat: kopan bölgenin kenarı gerçekten sönmüş görünsün.
		xy[k++] = (float) (clampBody(1.0 - a) * sx);
		xy[k++] = BODY_LIMIT * sy;
		xy[k++] = BODY_LIMIT * sx;
		xy[k++] = BODY_LIMIT * sy;
		xy[k++] = BODY_LIMIT * sx;
		xy[k++] = (float) (clampBody(1.0 - b) * sy);
		out.add(new Piece(0.97f, false, java.util.Arrays.copyOf(xy, k)));
	}

	/** Kenarlarda küçük, düzensiz kopma çentikleri. {@code avoidCorner}: o köşenin yakınına çentik açma (negatif: yok). */
	private static void edgeNotches(List<Piece> out, SplittableRandom r, int count, int avoidCorner) {
		for (int i = 0; i < count; i++) {
			int edge = r.nextInt(4); // 0 sağ, 1 üst, 2 sol, 3 alt
			double along = (r.nextDouble() * 2.0 - 1.0) * 0.8;
			double depth = 0.10 + r.nextDouble() * 0.18;
			double width = 0.10 + r.nextDouble() * 0.20;
			if (avoidCorner >= 0) {
				double cx = (avoidCorner & 1) == 0 ? 1.0 : -1.0;
				double cy = (avoidCorner & 2) == 0 ? 1.0 : -1.0;
				double ex = edge == 0 ? 1.0 : edge == 2 ? -1.0 : along;
				double ey = edge == 1 ? 1.0 : edge == 3 ? -1.0 : along;
				if (Math.hypot(ex - cx, ey - cy) < 0.9) {
					continue;
				}
			}
			float[] pts = {
					(float) (1.0 + 0.06), (float) (along - width), (float) (1.0 - depth * 0.4), (float) (along - width * 0.45),
					(float) (1.0 - depth), (float) (along + (r.nextDouble() - 0.5) * 0.06), (float) (1.0 - depth * 0.55), (float) (along + width * 0.5),
					(float) (1.0 + 0.06), (float) (along + width)};
			// Kenara göre döndür: (x,y) -> kenar yönüne
			float[] xy = new float[pts.length];
			for (int p = 0; p < pts.length; p += 2) {
				float u = pts[p];
				float v = pts[p + 1];
				switch (edge) {
					case 0 -> {
						xy[p] = u;
						xy[p + 1] = v;
					}
					case 1 -> {
						xy[p] = -v;
						xy[p + 1] = u;
					}
					case 2 -> {
						xy[p] = -u;
						xy[p + 1] = -v;
					}
					default -> {
						xy[p] = v;
						xy[p + 1] = -u;
					}
				}
			}
			out.add(new Piece(0.95f, false, xy));
		}
	}

	/** Güneşten kopup uzaklaşan, karanlık kırıntılar (kopan köşenin yönünde). */
	private static void fragments(List<Piece> out, SplittableRandom r, int corner, int count, double minDist, double baseSize) {
		double cx = (corner & 1) == 0 ? 1.0 : -1.0;
		double cy = (corner & 2) == 0 ? 1.0 : -1.0;
		for (int i = 0; i < count; i++) {
			double dist = minDist + r.nextDouble() * 0.9;
			double spread = (r.nextDouble() - 0.5) * 1.3;
			double dx = cx * 0.7071 * dist - cy * 0.7071 * spread;
			double dy = cy * 0.7071 * dist + cx * 0.7071 * spread;
			double size = baseSize * (0.5 + r.nextDouble() * 1.1);
			float[] shard = OmenShapes.blob(dx, dy, size, 0.45, 5 + r.nextInt(3), r);
			clampFragment(shard);
			out.add(new Piece(0.9f, false, shard));
		}
	}

	/** Yüzeyde ince, tırtıklı çatlaklar (merkeze yakın başlar, kenara doğru uzanır, kareyi aşmaz). */
	private static void cracks(List<Piece> out, SplittableRandom r, int count, double minWidth, double maxWidth) {
		for (int i = 0; i < count; i++) {
			double a = r.nextDouble() * 2.0 * Math.PI;
			double start = r.nextDouble() * 0.35;
			double length = 0.55 + r.nextDouble() * 0.6;
			float[] xy = OmenShapes.crack(Math.cos(a) * start, Math.sin(a) * start, a + (r.nextDouble() - 0.5) * 0.7, length,
					minWidth + r.nextDouble() * (maxWidth - minWidth), r);
			clampBody(xy);
			out.add(new Piece(0.93f, false, xy));
		}
	}

	/** Parlaklığını kaybetmiş sönük bölgeler: yüzeyin içinde, yarı saydam karartma. */
	private static void dimPatches(List<Piece> out, SplittableRandom r, int count) {
		for (int i = 0; i < count; i++) {
			double a = r.nextDouble() * 2.0 * Math.PI;
			double d = r.nextDouble() * 0.45;
			double size = 0.22 + r.nextDouble() * 0.30;
			float[] xy = OmenShapes.blob(Math.cos(a) * d, Math.sin(a) * d, size, 0.38, 16, r);
			clampBody(xy);
			out.add(new Piece(0.5f + (float) r.nextDouble() * 0.12f, true, xy));
		}
	}

	private static double clampBody(double v) {
		return Math.max(-BODY_LIMIT, Math.min(BODY_LIMIT, v));
	}

	private static void clampBody(float[] xy) {
		for (int i = 0; i < xy.length; i++) {
			xy[i] = Math.max(-BODY_LIMIT, Math.min(BODY_LIMIT, xy[i]));
		}
	}

	private static void clampFragment(float[] xy) {
		for (int i = 0; i < xy.length; i++) {
			xy[i] = Math.max(-FRAGMENT_LIMIT, Math.min(FRAGMENT_LIMIT, xy[i]));
		}
	}

	/**
	 * Güneş karesinin yerel eksenleri (vanilla'nın dönüş zinciriyle: {@code rotateY(-90) · rotateX(açı)}): {@code e1} sabit +Z,
	 * {@code e2} güneşin yolu boyunca. Güneş yönü {@code s = (-sin t, cos t, 0)}, {@code t = 2π · celestial}. Döndürülen dizi
	 * {@code {s0,s1,s2, e1_0,e1_1,e1_2, e2_0,e2_1,e2_2}}.
	 */
	public static double[] frame(double celestial) {
		double t = 2.0 * Math.PI * celestial;
		return new double[] {-Math.sin(t), Math.cos(t), 0.0, 0.0, 0.0, 1.0, -Math.cos(t), -Math.sin(t), 0.0};
	}
}
