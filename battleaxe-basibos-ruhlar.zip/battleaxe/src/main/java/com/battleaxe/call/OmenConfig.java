package com.battleaxe.call;

/**
 * Baltanın Çağrısı - Öncü Belirtiler ayarları (mod, ayarlarını Java sabitlerinde tutar; yeni yapılandırma
 * sistemi eklenmedi). Süreler tick'tir: 20 tick = 1 sn, 1200 tick = 1 dk, 24000 tick = 1 oyun günü.
 *
 * <p><b>Oyun içinde denemek için:</b> {@link #TEST_MODE} = true yap. Bekleme süreleri kısalır ve her denetimde
 * olay güvenceye alınır; ancak baltayı edinmiş oyuncuya yine HİÇBİR ŞEY gösterilmez (susturma test modunda da geçerlidir).
 * Üretim sürümünde false kalmalıdır.
 */
public final class OmenConfig {
	private OmenConfig() {
	}

	/** false yaparsan tüm öncü belirtiler kapanır (mesaj/ay/demir sesi {@link CallConfig} ile ayrıca yönetilir). Sunucu tarafı. */
	public static final boolean ENABLED = true;

	/** Hızlı deneme kipi. Üretimde false. */
	public static final boolean TEST_MODE = false;

	/** Dört olay tek tek kapatılabilir. */
	public static final boolean SKY_AXE_ENABLED = true;
	public static final boolean WATCHER_EYE_ENABLED = true;
	public static final boolean HORIZON_COLOSSUS_ENABLED = true;
	public static final boolean IMPOSSIBLE_STRUCTURE_ENABLED = true;

	// ------------------------------------------------------------------
	// KOZMİK ANOMALİLER (Öncü Belirtiler'in genişlemesi; aynı yönetici, aynı ritim kuralları)
	// ------------------------------------------------------------------

	/** false yaparsan yalnızca YENİ anomaliler (İkinci Ay, Halkalar, Monolith, Bütün Canlılar, Parçalanmış Güneş) kapanır; eski dört belirti etkilenmez. */
	public static final boolean ANOMALIES_ENABLED = true;
	/**
	 * Yeni anomaliler baltayı edinmiş oyuncularda da sürer (dünya, balta elde olsa da susmaz). Eski dört Öncü Belirti, lore gereği,
	 * baltanın edinilmesiyle kalıcı susmaya devam eder. false yaparsan yeni anomaliler de balta sonrası susar.
	 */
	public static final boolean ANOMALIES_AFTER_AXE = true;
	/** Balta sonrası oyuncularda genel kurulma olasılığı çarpanı (olaylar yine nadirdir, biraz daha seyrektir). */
	public static final double POST_AXE_CHANCE_MULTIPLIER = 0.75;

	public static final boolean SECOND_MOON_ENABLED = true;
	public static final boolean IMPOSSIBLE_RINGS_ENABLED = true;
	public static final boolean MONOLITH_ENABLED = true;
	public static final boolean ALL_WATCHING_ENABLED = true;
	public static final boolean FRACTURED_SUN_ENABLED = true;

	/** Aynı türün bir oyuncuya (oturum içinde) yeniden gösterilmesi için en kısa süre. Büyük olaylar arası {@link #MIN_GAP_TICKS} ayrıca geçerlidir. */
	public static final long SECOND_MOON_COOLDOWN_TICKS = TEST_MODE ? 400L : 36000L;
	public static final long IMPOSSIBLE_RINGS_COOLDOWN_TICKS = TEST_MODE ? 400L : 30000L;
	public static final long MONOLITH_COOLDOWN_TICKS = TEST_MODE ? 400L : 24000L;
	public static final long ALL_WATCHING_COOLDOWN_TICKS = TEST_MODE ? 400L : 48000L;

	/** Süreler (tick): görünme süresi [en az, en çok]. Kayboluş bunun içindedir. */
	public static final int SECOND_MOON_MIN_TICKS = 1500;
	public static final int SECOND_MOON_MAX_TICKS = 2600;
	public static final int RINGS_MIN_TICKS = 1400;
	public static final int RINGS_MAX_TICKS = 2400;
	public static final int MONOLITH_MIN_TICKS = 1800;
	public static final int MONOLITH_MAX_TICKS = 3200;
	public static final int ALL_WATCHING_MIN_TICKS = 100;
	public static final int ALL_WATCHING_MAX_TICKS = 160;

	/** Monolith: oyuncu bu kadar blok yürüyünce (ya da bu kadar yaklaşınca) yapının gerçek bir konumu olmadığı anlaşılır ve söner. */
	public static final double MONOLITH_VANISH_TRAVEL_BLOCKS = 150.0;
	public static final double MONOLITH_VANISH_APPROACH_BLOCKS = 70.0;
	/** Yaklaşma bu kadar bloğu geçince perspektif belli belirsiz bozulmaya başlar (sezdirir; sonsuz yürümeye zorlamaz). */
	public static final double MONOLITH_WARP_APPROACH_BLOCKS = 28.0;

	/** Bütün Canlılar Sana Bakıyor: yarıçap (blok), en çok/en az etkilenen mob, mobların dönmeye başlama dağılımı ve dönüş hızı. */
	public static final double ALL_WATCHING_RADIUS = 22.0;
	public static final int ALL_WATCHING_MAX_MOBS = 24;
	public static final int ALL_WATCHING_MIN_MOBS = 3;
	public static final int ALL_WATCHING_STAGGER_TICKS = 28;
	public static final float ALL_WATCHING_TURN_STEP_DEGREES = 22.0F;
	/** Mesaj, olay başladıktan bu kadar tick sonra (moblar dönmüşken) belirir. */
	public static final int ALL_WATCHING_MESSAGE_DELAY_TICKS = 36;

	/**
	 * Parçalanmış Güneş: günlük, DETERMİNİSTİK seçim (dünya tohumu + gün sayısı; kayıt gerekmez, çok oyunculu tutarlıdır).
	 * Olay günü olasılığı, iki olay arası en az gün ve ilk sakin günler. Ertesi gün (varsa) çok hafif bir "iz" kalır.
	 */
	public static final double FRACTURED_SUN_DAY_CHANCE = TEST_MODE ? 0.6 : 0.045;
	public static final int FRACTURED_SUN_SPACING_DAYS = TEST_MODE ? 2 : 6;
	public static final int FRACTURED_SUN_MIN_DAY = TEST_MODE ? 0 : 3;
	/** Sunucu, güneş durumunu istemciye bu aralıkla (tick) tazeler (istemci arada kendi saatiyle ilerletir). */
	public static final int FRACTURED_SUN_RESYNC_TICKS = 200;

	// ------------------------------------------------------------------
	// Baltanın edinilmesinin güvenilir tespiti
	// ------------------------------------------------------------------

	/** Envanter/imleç/istatistik denetimi aralığı: balta kısa süre bile elde edilse kaçırılmaz (0.2 sn). */
	public static final int ACQUIRE_CHECK_TICKS = 4;

	// ------------------------------------------------------------------
	// Ritim ve sessizlik
	// ------------------------------------------------------------------

	/** Yeni bir olayın "kurulup kurulmayacağına" karar verilen denetim aralığı (5 sn). */
	public static final int CHECK_INTERVAL_TICKS = 100;
	/** Kurulmuş (hazır) bir olayın başlatılabilirlik denetimi aralığı (1 sn). */
	public static final int LAUNCH_INTERVAL_TICKS = 20;
	/** Kurulmuş bir olay bu süre içinde başlatılamazsa (oyuncu uygun yöne bakmadı...) iptal edilir (90 sn). */
	public static final long ARMED_TTL_TICKS = TEST_MODE ? 3600L : 1800L;

	/** Oyuna girişten sonra sessizlik ve herhangi iki çağrı olayı arası en kısa süre. */
	public static final long INITIAL_QUIET_TICKS = TEST_MODE ? 200L : CallConfig.INITIAL_QUIET_TICKS;
	public static final long GLOBAL_GAP_TICKS = TEST_MODE ? 100L : CallConfig.GLOBAL_EVENT_GAP_TICKS;
	/** Dünya bu yaştan önce öncü belirti çıkmaz (ilk oyun günü sakin geçer). */
	public static final long MIN_WORLD_AGE_TICKS = TEST_MODE ? 0L : 24000L;

	/** İki büyük olay arasındaki en kısa süre (12 dk). Aynı tür art arda gelmediği için aynı tür en az iki aralık sonra döner. */
	public static final long MIN_GAP_TICKS = TEST_MODE ? 400L : 14400L;
	/** Bir oyun oturumunda (giriş-çıkış) en çok kaç büyük olay. */
	public static final int PER_SESSION = TEST_MODE ? 99 : 2;
	/** Etkin bir olayın bitiminden sonra eklenen güvenlik payı. */
	public static final long END_PADDING_TICKS = 60L;
	/** Oyuncu hasar aldıktan sonra bu kadar tick olay kurulmaz/başlatılmaz (20 sn). */
	public static final long QUIET_AFTER_DAMAGE_TICKS = TEST_MODE ? 20L : 400L;

	/**
	 * Her 5 sn'lik denetimde olay kurulma olasılığı. Uygunluk koşulları (gece, açık gökyüzü...) bu zardan SONRA
	 * değerlendirilir; yani bu sayı "uygun anlarda" beklenen sıklığı değil, genel ritmi belirler. Taban 0.0016 gündüz
	 * ~1 saatlik oyunda bir kurulum demektir; geceler 1.8 kat olaylıdır ({@link OmenLogic#toneChanceMultiplier}). İlerleme ve "uzun süredir görmedi" payı çarpan olarak eklenir.
	 */
	public static final double BASE_CHANCE = TEST_MODE ? 1.0 : 0.0016;
	public static final double CHANCE_PER_PROGRESS = 0.20;
	/** Son olaydan beri bu kadar tick geçtiğinde şans payı tavana ulaşır (1 saat) ve tavan çarpanı. */
	public static final long PITY_FULL_TICKS = 72000L;
	public static final double PITY_MAX_MULTIPLIER = 3.0;

	// ------------------------------------------------------------------
	// Uygunluk
	// ------------------------------------------------------------------

	/** Ufuktaki Dev ve Olmaması Gereken Yapı "keşif" ister: kurulumdan beri bu kadar blok yürümüş olmalı. */
	public static final double COLOSSUS_MIN_TRAVEL_BLOCKS = TEST_MODE ? 0.0 : 160.0;
	public static final double STRUCTURE_MIN_TRAVEL_BLOCKS = TEST_MODE ? 0.0 : 260.0;
	/** Tek denetimde sayılan en büyük yürüyüş (ışınlanma/boyut atlaması keşif sayılmasın). */
	public static final double TRAVEL_STEP_CAP_BLOCKS = 48.0;

	/** Gökyüzü olayları (Balta, Göz) için oyuncu en az bu kadar yukarı (derece) bakmalı. */
	public static final double SKY_LOOK_MIN_UP_DEGREES = 14.0;
	/** Ufuk olayları için bakış eğimi aralığı (derece; pozitif = aşağı). */
	public static final double HORIZON_LOOK_MIN_PITCH = -22.0;
	public static final double HORIZON_LOOK_MAX_PITCH = 28.0;

	/** Ay ile bir gökyüzü olayı arasındaki en küçük açı (derece): ay silueti ve balta üst üste binmesin. */
	public static final double MOON_CLEARANCE_DEGREES = 32.0;

	// ------------------------------------------------------------------
	// Süreler (tick) - [en az, en çok]
	// ------------------------------------------------------------------

	public static final int SKY_AXE_MIN_TICKS = 180;
	public static final int SKY_AXE_MAX_TICKS = 300;
	public static final int EYE_MIN_TICKS = 160;
	public static final int EYE_MAX_TICKS = 300;
	public static final int COLOSSUS_MIN_TICKS = 700;
	public static final int COLOSSUS_MAX_TICKS = 1500;
	public static final int STRUCTURE_MIN_TICKS = 1500;
	public static final int STRUCTURE_MAX_TICKS = 3600;

	// ------------------------------------------------------------------
	// "YILDIZI BUL!" mesajı: tek, hatırlanır bir karşılaşma
	// ------------------------------------------------------------------

	/** İlk balta tezahüründe (Nether Yıldızı henüz yokken) mesaj kesin gelir; sonrakilerde bu olasılık ve en az bu aralıkla. */
	public static final double STAR_MESSAGE_REPEAT_CHANCE = 0.30;
	public static final long STAR_MESSAGE_MIN_GAP_TICKS = TEST_MODE ? 200L : 96000L;

	// ------------------------------------------------------------------
	// Ses
	// ------------------------------------------------------------------

	/** Uzaktan metalik yankı (yalnızca yakınında başka oyuncu yokken; bkz. CallConfig.FORGE_PRIVACY_RADIUS). */
	public static final boolean ECHO_ENABLED = true;
	public static final float ECHO_VOLUME = 0.16F;
	public static final float ECHO_PITCH = 0.50F;
}
