package com.battleaxe.call;

import java.util.HashMap;
import java.util.Map;
import java.util.OptionalLong;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.random.RandomGenerator;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.chain.ChainWhisperLogic;
import com.battleaxe.soul.SoulManager;

/**
 * <b>Baltanın Çağrısı - Öncü Belirtiler</b>: oyuncu baltayı edinmeden önce yaşadığı dört gök/ufuk tezahürünün
 * SUNUCU tarafı (uygunluk, seçim, bekleme, çakışma önleme, oyuncu başına durum, paket gönderimi).
 *
 * <ul>
 *   <li>Mevcut {@link CallManager} her oyuncu tick'inde (balta edinilmemişse) {@link #tick} çağırır: susturma,
 *       oturum sayaçları ve {@code F_AXE} bayrağı orada yönetilir; burada ikinci bir mimari yoktur.</li>
 *   <li>İki aşamalı ritim: seyrek bir zar ve uygunluk ile olay <i>kurulur</i> ("armed"); oyuncu uygun yöne bakınca
 *       (gökyüzü olayları için yukarı, ufuk olayları için ufka) 1 sn'lik denetimle <i>başlatılır</i>. Böylece tezahür
 *       oyuncu bakarken, görüş alanının yakınında doğar; denetimler ucuzdur (çoğu tick'te hiçbir iş yapılmaz).</li>
 *   <li>Her şey yalnızca bu oyuncunun istemcisine gönderilen {@link OmenPayload} ile olur: dünyada varlık, blok,
 *       yapı ya da kalıcı değişiklik yoktur. Boyut değişimi, yeniden doğma, ölüm ve baltanın edinilmesi etkin olayı
 *       {@link OmenPayload#end()} ile sonlandırır.</li>
 * </ul>
 */
public final class OmenManager {
	private OmenManager() {
	}

	/** Oyun oturumuna özgü, kalıcı olmayan durum. */
	private static final class State {
		ServerPlayer ref;
		ResourceKey<Level> dimension;

		int omens;
		long busyUntil;
		boolean active;

		OmenKind armedKind;
		long armedUntil;

		double travel;
		double lastX;
		double lastZ;
		boolean hasLast;

		float lastHealth = -1.0F;
		long lastDamage;

		long echoDue;

		/** Şu an etkin olayın türü (eski belirtiler baltanın edinilmesiyle biter; yeni anomaliler bitmez). */
		OmenKind activeKind;
		/** Bu oyuncu durumunun kurulduğu oyun zamanı: balta sonrası oyuncularda oturum başlangıcı yerine geçer. */
		long sessionStart = -1L;
		/** Her türün bu oturumda son gösterildiği oyun zamanı (tür başına bekleme için; kalıcı değildir). */
		final long[] lastShown = new long[OmenKind.COUNT];
		/** Baltanın anomaliye tepkisi: söylenecek tür ve zamanı (yalnızca baltayı edinmiş oyuncularda). */
		OmenKind whisperKind;
		long whisperDue;
		int whisperBand;
	}

	/** Parçalanmış Güneş'in oyuncuya en son bildirilen durumu (aynı durumu gereksiz yere yeniden yollamamak için). */
	private record SunSent(long day, long tick, int state) {
	}

	private static final Map<UUID, SunSent> SUN_SENT = new HashMap<>();

	private static final Map<UUID, State> STATES = new HashMap<>();

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(OmenPayload.TYPE, OmenPayload.CODEC);
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			STATES.remove(handler.getPlayer().getUUID());
			SUN_SENT.remove(handler.getPlayer().getUUID());
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			STATES.clear();
			SUN_SENT.clear();
		});
		// Parçalanmış Güneş: günlük, deterministik dünya olayı; durumu her oyuncuya tazeler (çizelgeden bağımsızdır).
		ServerTickEvents.END_SERVER_TICK.register(OmenManager::tickSun);
		AllWatching.initialize();
	}

	// ------------------------------------------------------------------
	// CallManager'ın kullandığı küçük giriş noktaları
	// ------------------------------------------------------------------

	/** Etkin bir öncü belirti sürerken diğer çağrı işaretleri (mesaj, ay, demir sesi) beklesin. */
	static boolean isBusy(ServerPlayer player, long now) {
		State st = STATES.get(player.getUUID());
		return st != null && now < st.busyUntil;
	}

	/**
	 * Baltanın edinilmesi: ESKİ dört Öncü Belirti kalıcı susar (etkin olan sessizce biter, kurulu olan düşer). YENİ Kozmik Anomaliler
	 * susmaz (dünya, balta elde olsa da susmaz): durum korunur ve {@link #tickAfterAxe} onları sürdürür. Her tick'te çağrılabilir; ucuzdur.
	 */
	static void silence(ServerPlayer player) {
		State st = STATES.get(player.getUUID());
		if (st == null) {
			return;
		}
		if (st.armedKind != null && st.armedKind.legacy()) {
			st.armedKind = null;
		}
		if (st.active && (st.activeKind == null || st.activeKind.legacy())) {
			sendEnd(player);
			st.active = false;
			st.busyUntil = 0L;
			st.activeKind = null;
			st.echoDue = 0L;
		}
	}

	/** Ölüm vb.: etkin olay biter; oturum sayaçları korunur. */
	static void interrupt(ServerPlayer player) {
		State st = STATES.get(player.getUUID());
		if (st != null) {
			if (st.active) {
				sendEnd(player);
			}
			st.active = false;
			st.busyUntil = 0L;
			st.armedKind = null;
			st.echoDue = 0L;
		}
	}

	private static void sendEnd(ServerPlayer player) {
		if (ServerPlayNetworking.canSend(player, OmenPayload.TYPE)) {
			ServerPlayNetworking.send(player, OmenPayload.end());
		}
	}

	// ------------------------------------------------------------------
	// Oyuncu başına tick
	// ------------------------------------------------------------------

	/**
	 * @return bu tick'te yeni bir olay başlatıldıysa true (çağıran diğer çağrı olaylarının bekleme saatini işletir)
	 */
	static boolean tick(ServerLevel level, ServerPlayer player, CallData data, long now, long sessionStart,
			long lastCallEvent, boolean otherBusy) {
		return tick(level, player, data, now, sessionStart, lastCallEvent, otherBusy, false);
	}

	/**
	 * Balta SONRASI: eski belirtiler susmuştur ama Kozmik Anomaliler sürer ({@link OmenConfig#ANOMALIES_AFTER_AXE}). Aynı durum, aynı ritim
	 * kuralları; yalnızca yeni türler uygundur ve genel olasılık biraz daha seyrektir. Oturum başlangıcı bu durumun kurulduğu andır.
	 */
	static void tickAfterAxe(ServerLevel level, ServerPlayer player, CallData data) {
		if (!OmenConfig.ANOMALIES_AFTER_AXE || !OmenConfig.ANOMALIES_ENABLED) {
			return;
		}
		long now = level.getGameTime();
		State st = STATES.computeIfAbsent(player.getUUID(), id -> new State());
		if (st.sessionStart < 0L) {
			st.sessionStart = now;
		}
		tick(level, player, data, now, st.sessionStart, 0L, false, true);
	}

	private static boolean tick(ServerLevel level, ServerPlayer player, CallData data, long now, long sessionStart,
			long lastCallEvent, boolean otherBusy, boolean postAxe) {
		if (!OmenConfig.ENABLED) {
			return false;
		}
		State st = STATES.computeIfAbsent(player.getUUID(), id -> new State());
		if (st.sessionStart < 0L) {
			st.sessionStart = now;
		}
		speakIfDue(player, st, now);

		// Yeniden doğma (yeni oyuncu nesnesi) ya da boyut değişimi: etkin/kurulu olay hemen biter, yanlış boyutta görüntü kalmaz.
		if (st.ref != player || st.dimension != level.dimension()) {
			if (st.active) {
				sendEnd(player);
			}
			st.ref = player;
			st.dimension = level.dimension();
			st.active = false;
			st.activeKind = null;
			st.busyUntil = 0L;
			st.armedKind = null;
			st.echoDue = 0L;
			st.hasLast = false;
			st.lastHealth = -1.0F;
		}

		// Hasar takibi (savaşın ortasında olay kurulmaz/başlatılmaz).
		float health = player.getHealth();
		if (st.lastHealth >= 0.0F && health < st.lastHealth - 0.01F) {
			st.lastDamage = now;
		}
		st.lastHealth = health;

		if (st.active && now >= st.busyUntil) {
			st.active = false;
		}
		if (st.echoDue > 0L && now >= st.echoDue) {
			st.echoDue = 0L;
			echo(level, player);
		}

		int slot = player.tickCount + player.getId();
		boolean started = false;
		if (st.armedKind != null && slot % OmenConfig.LAUNCH_INTERVAL_TICKS == 0) {
			started = tryLaunch(level, player, st, data, now, sessionStart, lastCallEvent, otherBusy, postAxe);
		}
		if (slot % OmenConfig.CHECK_INTERVAL_TICKS == 0) {
			updateTravel(st, player);
			if (!started && st.armedKind == null && !st.active) {
				maybeArm(level, player, st, data, now, sessionStart, lastCallEvent, otherBusy, postAxe);
			}
		}
		return started;
	}

	private static void updateTravel(State st, ServerPlayer player) {
		double x = player.getX();
		double z = player.getZ();
		if (st.hasLast) {
			double dx = x - st.lastX;
			double dz = z - st.lastZ;
			st.travel += Math.min(OmenConfig.TRAVEL_STEP_CAP_BLOCKS, Math.sqrt(dx * dx + dz * dz));
		}
		st.lastX = x;
		st.lastZ = z;
		st.hasLast = true;
	}

	private static boolean playerCalm(ServerPlayer player) {
		return !player.isSleeping() && player.hurtTime <= 0 && !BerserkerManager.isActive(player);
	}

	/** Ucuz önkoşullar + seyrek zar; geçerse uygun türlerden biri KURULUR (henüz gösterilmez). */
	private static void maybeArm(ServerLevel level, ServerPlayer player, State st, CallData data, long now,
			long sessionStart, long lastCallEvent, boolean otherBusy, boolean postAxe) {
		if (otherBusy || !playerCalm(player)
				|| !OmenLogic.mayArm(now, sessionStart, level.getGameTime(), st.omens, data.lastOmen(), lastCallEvent, st.busyUntil, st.lastDamage)) {
			return;
		}
		int progress = CallLogic.progress(data.flags());
		long since = data.lastOmen() > 0L ? now - data.lastOmen() : now - sessionStart;
		RandomGenerator random = ThreadLocalRandom.current();
		OmenLogic.Env env = env(level, player, st);
		double multiplier = postAxe ? OmenConfig.POST_AXE_CHANCE_MULTIPLIER : 1.0;
		if (random.nextDouble() >= OmenLogic.chance(progress, since) * OmenLogic.toneChanceMultiplier(env.tone()) * multiplier) {
			return; // Çoğu denetimde hiçbir şey olmaz.
		}
		int mask = readyMask(st, availableMask(env, postAxe), now);
		OmenKind kind = mask == 0 ? null : OmenLogic.choose(random, mask, progress, data.omenSeen(), data.lastOmenKind());
		if (kind == OmenKind.ALL_WATCHING && !AllWatching.hasAudience(level, player)) {
			return; // Etrafta yeterince canlı yok: olay anlamsız olurdu; hiçbir şey tüketilmez.
		}
		if (kind != null) {
			st.armedKind = kind;
			st.armedUntil = now + OmenConfig.ARMED_TTL_TICKS;
		}
	}

	private static OmenLogic.Env env(ServerLevel level, ServerPlayer player, State st) {
		boolean overworld = level.dimension() == Level.OVERWORLD;
		if (!overworld) {
			return new OmenLogic.Env(false, false, false, OmenLogic.TONE_UNKNOWN, st.travel);
		}
		OptionalLong dayTime = SkyProbe.dayTime(level);
		int tone = dayTime.isPresent() ? OmenLogic.toneOf(dayTime.getAsLong()) : OmenLogic.TONE_UNKNOWN;
		return new OmenLogic.Env(true, level.canSeeSky(player.blockPosition()), SkyProbe.precipitating(level), tone, st.travel);
	}

	/**
	 * Baltayı edinmiş oyuncuda bir anomali başlayınca, bir süre sonra balta rütbesiyle tek bir söz söyleyebilir ({@link AnomalyWhisperLogic}).
	 * Rütbe şimdi (balta elde değilse 0) okunur ve sözün tonu bu anda sabitlenir. Hiçbir şey açıklanmaz.
	 */
	private static void scheduleWhisper(ServerPlayer player, State st, OmenKind kind, long now, boolean postAxe) {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		if (!postAxe || !AnomalyWhisperLogic.shouldSpeak(kind, random.nextDouble())) {
			return;
		}
		st.whisperKind = kind;
		st.whisperDue = now + AnomalyWhisperLogic.delay(random.nextDouble());
		st.whisperBand = ChainWhisperLogic.band(SoulManager.rankOf(player.getMainHandItem()));
	}

	private static void speakIfDue(ServerPlayer player, State st, long now) {
		if (st.whisperKind == null || now < st.whisperDue) {
			return;
		}
		String key = AnomalyWhisperLogic.key(st.whisperKind, st.whisperBand);
		st.whisperKind = null;
		if (key != null && player.isAlive()) {
			player.sendSystemMessage(Component.translatable(key, player.getName()).withStyle(ChatFormatting.LIGHT_PURPLE)
					.withStyle(ChatFormatting.ITALIC), true);
		}
	}

	/** Bu ortamda uygun türler: balta öncesi eski + yeni; balta sonrası yalnızca yeni (eski belirtiler susmuştur). */
	private static int availableMask(OmenLogic.Env env, boolean postAxe) {
		return postAxe ? OmenLogic.anomalyMask(env) : OmenLogic.eligibleMask(env) | OmenLogic.anomalyMask(env);
	}

	/** Maskeden, tür başına bekleme süresi dolmamış olanları çıkarır. */
	private static int readyMask(State st, int mask, long now) {
		int ready = 0;
		for (OmenKind kind : OmenKind.values()) {
			if ((mask & kind.bit()) != 0 && OmenLogic.kindReady(kind, st.lastShown[kind.id()], now)) {
				ready |= kind.bit();
			}
		}
		return ready;
	}

	/** Kurulu olay: koşullar hâlâ sağlanıyorsa ve oyuncu uygun yöne bakıyorsa BAŞLAT. */
	private static boolean tryLaunch(ServerLevel level, ServerPlayer player, State st, CallData data, long now,
			long sessionStart, long lastCallEvent, boolean otherBusy, boolean postAxe) {
		if (now > st.armedUntil) {
			st.armedKind = null; // Oyuncu uygun yöne bakmadı: bu kurulum sessizce düşer.
			return false;
		}
		OmenKind kind = st.armedKind;
		if (otherBusy || !playerCalm(player) || st.active
				|| !OmenLogic.mayArm(now, sessionStart, level.getGameTime(), st.omens, data.lastOmen(), lastCallEvent, st.busyUntil, st.lastDamage)
				|| !OmenLogic.lookAllows(kind, player.getXRot())) {
			return false;
		}
		OmenLogic.Env env = env(level, player, st);
		if ((availableMask(env, postAxe) & kind.bit()) == 0) {
			return false;
		}
		// Gösterimden hemen önce son bir kez: balta edinilmişse ESKİ belirtiler gösterilmez ve kalıcı kapanır. Yeni anomaliler bundan
		// etkilenmez (zaten balta sonrası da sürer): balta edinmiş oyuncuya yeni anomali gösterilebilir.
		if (!postAxe && (AxeAcquisition.holdsNow(player) || AxeAcquisition.recordedByStats(player))) {
			CallManager.onAxeAcquired(player);
			if (kind.legacy()) {
				return false;
			}
		}
		// Küçük, görüntüsüz olay: Bütün Canlılar Sana Bakıyor (paket yok; büyük olay sayacını ve aralığını tüketmez).
		if (kind == OmenKind.ALL_WATCHING) {
			st.armedKind = null;
			if (!AllWatching.start(level, player)) {
				return false; // yeterli canlı yok / zaten bir olay var: hiçbir şey tüketilmez
			}
			st.lastShown[kind.id()] = now;
			return false; // 'started' yalnızca büyük (çağrı ritmini işleten) olaylar için true döner
		}
		if (!ServerPlayNetworking.canSend(player, OmenPayload.TYPE)) {
			st.armedKind = null;
			st.omens = OmenConfig.PER_SESSION; // İstemci paketi alamaz: bu oturumda tekrar denenmez.
			return false;
		}

		RandomGenerator random = ThreadLocalRandom.current();
		double[] moon = null;
		if (env.tone() == OmenLogic.TONE_NIGHT) {
			OptionalLong dayTime = SkyProbe.dayTime(level);
			if (dayTime.isPresent()) {
				double celestial = CallMoon.celestialAngle(dayTime.getAsLong());
				if (CallMoon.moonElevationSin(celestial) > 0.0) {
					moon = CallMoon.moonDirection(celestial);
				}
			}
		}
		OmenLogic.Placement placement = OmenLogic.place(random, kind, player.getYRot(), player.getXRot(), moon);
		int variant = OmenLogic.makeVariant(random, kind);
		int ticks = OmenLogic.duration(random, kind);
		int progress = CallLogic.progress(data.flags());
		boolean message = kind == OmenKind.SKY_AXE
				&& OmenLogic.starMessage(random, progress, data.omenSeen(), now, data.lastStarMsg());
		int flags = (message ? OmenLogic.FLAG_MESSAGE : 0)
				| (kind == OmenKind.HORIZON_COLOSSUS && (OmenLogic.lowBits(variant) & 16) != 0 ? OmenLogic.FLAG_TREMOR : 0);

		ServerPlayNetworking.send(player, new OmenPayload(kind.id(), random.nextInt() & 0x7FFFFFFF,
				OmenLogic.pack(variant, env.tone(), flags), (float) placement.azimuth(), (float) placement.elevation(), ticks));

		st.active = true;
		st.activeKind = kind;
		st.lastShown[kind.id()] = now;
		scheduleWhisper(player, st, kind, now, postAxe);
		st.busyUntil = now + ticks + OmenConfig.END_PADDING_TICKS;
		st.armedKind = null;
		st.omens++;
		st.travel = 0.0; // Bir sonraki "keşif" olayı için yeniden yol yürümek gerekir.
		// Kaybolurken uzaktan tek bir yankı (yalnızca ufuk/yapı olaylarında); Gökteki Balta belirirken bir yankı verir.
		st.echoDue = kind == OmenKind.HORIZON_COLOSSUS || kind == OmenKind.IMPOSSIBLE_STRUCTURE ? now + Math.max(40, ticks - 40) : 0L;
		if (kind == OmenKind.SKY_AXE) {
			echo(level, player);
		}
		CallData fresh = player.getAttachedOrElse(CallAttachments.DATA, CallData.EMPTY);
		player.setAttached(CallAttachments.DATA, fresh.withOmen(now, kind, message));
		return true;
	}

	// ------------------------------------------------------------------
	// Parçalanmış Güneş (günlük, deterministik, dünya çapında)
	// ------------------------------------------------------------------

	/**
	 * Güneşin o günkü durumu {@link SunAnomalyLogic} ile DÜNYA TOHUMU ve GÜN SAYISINDAN türetilir: kayıt gerekmez, sunucu yeniden
	 * başlasa da aynı sonucu verir ve aynı dünyadaki bütün oyuncular aynı güneşi görür. Her oyuncuya yalnızca durum DEĞİŞİRSE (ve olay
	 * günü boyunca seyrek aralıklarla, istemci saatini tazelemek için) küçük bir paket gider. Ana dünya dışında güneş normaldir.
	 */
	private static void tickSun(MinecraftServer server) {
		if (!OmenConfig.ENABLED || !OmenConfig.ANOMALIES_ENABLED || !OmenConfig.FRACTURED_SUN_ENABLED) {
			return;
		}
		ServerLevel overworld = server.overworld();
		if (overworld == null || overworld.getGameTime() % 20L != 0L) {
			return;
		}
		OptionalLong dayTime = SkyProbe.dayTime(overworld);
		if (dayTime.isEmpty()) {
			return;
		}
		long time = dayTime.getAsLong();
		long day = SunAnomalyLogic.dayOf(time);
		long worldSeed = overworld.getSeed();
		int state = SunAnomalyLogic.stateForDay(true, worldSeed, day, OmenConfig.FRACTURED_SUN_DAY_CHANCE,
				OmenConfig.FRACTURED_SUN_SPACING_DAYS, OmenConfig.FRACTURED_SUN_MIN_DAY);
		long now = overworld.getGameTime();
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (!ServerPlayNetworking.canSend(player, OmenPayload.TYPE)) {
				continue;
			}
			int wanted = player.level().dimension() == Level.OVERWORLD ? state : SunAnomalyLogic.NONE;
			SunSent last = SUN_SENT.get(player.getUUID());
			boolean changed = last == null
					? wanted != SunAnomalyLogic.NONE
					: last.state() != wanted || (wanted != SunAnomalyLogic.NONE
							&& (last.day() != day || now - last.tick() >= OmenConfig.FRACTURED_SUN_RESYNC_TICKS));
			if (!changed) {
				continue;
			}
			SUN_SENT.put(player.getUUID(), new SunSent(day, now, wanted));
			// Yükseklik alanı gün içi zamanı taşır (istemci güneşin gökteki yerini bununla kendisi ilerletir; ay efektiyle aynı yöntem).
			ServerPlayNetworking.send(player, new OmenPayload(OmenKind.FRACTURED_SUN.id(), SunAnomalyLogic.visualSeed(worldSeed, day),
					OmenLogic.pack(wanted, OmenLogic.TONE_UNKNOWN, 0), 0.0F, (float) SunAnomalyLogic.timeOfDay(time),
					wanted == SunAnomalyLogic.NONE ? 1 : OmenConfig.FRACTURED_SUN_RESYNC_TICKS * 2));
		}
	}

	/** Çok uzaktan, kısık metalik bir yankı: yalnızca yakınında başka oyuncu yokken (ses konum tabanlıdır). */
	private static void echo(ServerLevel level, ServerPlayer player) {
		if (!OmenConfig.ECHO_ENABLED || !aloneNearby(level, player)) {
			return;
		}
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.AMBIENT,
				OmenConfig.ECHO_VOLUME, OmenConfig.ECHO_PITCH);
	}

	private static boolean aloneNearby(ServerLevel level, ServerPlayer player) {
		double radiusSq = CallConfig.FORGE_PRIVACY_RADIUS * CallConfig.FORGE_PRIVACY_RADIUS;
		for (ServerPlayer other : level.getServer().getPlayerList().getPlayers()) {
			if (other != player && other.level() == level && other.distanceToSqr(player) <= radiusSq) {
				return false;
			}
		}
		return true;
	}
}
