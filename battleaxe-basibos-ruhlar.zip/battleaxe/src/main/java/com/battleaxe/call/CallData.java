package com.battleaxe.call;

/**
 * Bir oyuncunun Baltanın Çağrısı ilerlemesi (kalıcı, OYUNCUYA bağlı; baltaya ya da dünyaya değil).
 *
 * @param flags         {@link CallLogic#F_NETHER} vb. bayraklar (bir kez yanar, geri dönmez; {@link CallLogic#F_AXE} sistemi kalıcı susturur)
 * @param milestones    mesajı gösterilmiş dönüm noktası bayrakları
 * @param seenMask      gösterilmiş mesajların bit maskesi ({@link CallLogic#TABLE} sırasıyla)
 * @param lastPick      en son gösterilen mesaj (-1 = yok)
 * @param lastMessage   son mesajın oyun zamanı (0 = hiç)
 * @param lastMoon      son ay işaretinin oyun zamanı (0 = hiç)
 * @param lastForge     son demir sesi işaretinin oyun zamanı (0 = hiç)
 * @param lastOmen      son öncü belirtinin (büyük gök olayı) oyun zamanı (0 = hiç)
 * @param omenSeen      gösterilmiş öncü belirti türlerinin bit maskesi ({@link OmenKind#bit()})
 * @param lastOmenKind  en son gösterilen öncü belirti türü (-1 = yok); aynı tür art arda seçilmez
 * @param lastStarMsg   son "YILDIZI BUL!" mesajının oyun zamanı (0 = hiç)
 */
public record CallData(int flags, int milestones, long seenMask, int lastPick, long lastMessage, long lastMoon, long lastForge,
		long lastOmen, int omenSeen, int lastOmenKind, long lastStarMsg) {
	public static final CallData EMPTY = new CallData(0, 0, 0L, -1, 0L, 0L, 0L, 0L, 0, -1, 0L);

	public CallData withFlags(int newFlags) {
		return new CallData(newFlags, milestones, seenMask, lastPick, lastMessage, lastMoon, lastForge, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	public CallData withMilestones(int newMilestones) {
		return new CallData(flags, newMilestones, seenMask, lastPick, lastMessage, lastMoon, lastForge, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	public CallData withMessage(long newSeenMask, int pick, long now) {
		return new CallData(flags, milestones, newSeenMask, pick, now, lastMoon, lastForge, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	/** Dönüm noktası mesajı: son mesaj zamanını günceller ama "seçilen mesaj" kaydını değiştirmez. */
	public CallData withMilestoneShown(int newMilestones, long now) {
		return new CallData(flags, newMilestones, seenMask, lastPick, now, lastMoon, lastForge, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	public CallData withMoon(long now) {
		return new CallData(flags, milestones, seenMask, lastPick, lastMessage, now, lastForge, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	public CallData withForge(long now) {
		return new CallData(flags, milestones, seenMask, lastPick, lastMessage, lastMoon, now, lastOmen, omenSeen, lastOmenKind, lastStarMsg);
	}

	/**
	 * Bir öncü belirti başlatıldı: zamanı, türü ve gösterilen türler maskesini kaydeder.
	 *
	 * @param starMessage "YILDIZI BUL!" bu olayla birlikte gösterildiyse true (zamanı kaydedilir)
	 */
	public CallData withOmen(long now, OmenKind kind, boolean starMessage) {
		return new CallData(flags, milestones, seenMask, lastPick, lastMessage, lastMoon, lastForge,
				now, omenSeen | kind.bit(), kind.id(), starMessage ? now : lastStarMsg);
	}
}
