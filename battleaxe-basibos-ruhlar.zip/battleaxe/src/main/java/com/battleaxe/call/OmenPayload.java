package com.battleaxe.call;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucu -> yalnızca ilgili oyuncunun istemcisi: bir öncü belirtinin başlatılması ya da sonlandırılması.
 * Yalnızca GÖRSEL bir tezahürü tarif eder; dünyada hiçbir şey oluşturmaz. İstemci bu paket gelmeden hiçbir
 * öncü belirti üretmez.
 *
 * @param kind      {@link OmenKind#id()}; {@link #KIND_END} = etkin olayı sessizce sonlandır (balta edinildi, ölüm vb.)
 * @param seed      şekil tohumu (31 bit)
 * @param packed    {@link OmenLogic#pack}: varyant, gökyüzü tonu, bayraklar (mesaj, hafif titreme)
 * @param azimuth   sabit yön açısı (Minecraft yaw, derece)
 * @param elevation ufuktan yükseklik (derece)
 * @param ticks     toplam görünme süresi
 */
public record OmenPayload(int kind, int seed, int packed, float azimuth, float elevation, int ticks) implements CustomPacketPayload {
	public static final int KIND_END = -1;

	public static final CustomPacketPayload.Type<OmenPayload> TYPE = new CustomPacketPayload.Type<>(BattleAxeMod.id("call_omen"));

	public static final StreamCodec<RegistryFriendlyByteBuf, OmenPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, OmenPayload::kind,
			ByteBufCodecs.VAR_INT, OmenPayload::seed,
			ByteBufCodecs.VAR_INT, OmenPayload::packed,
			ByteBufCodecs.FLOAT, OmenPayload::azimuth,
			ByteBufCodecs.FLOAT, OmenPayload::elevation,
			ByteBufCodecs.VAR_INT, OmenPayload::ticks,
			OmenPayload::new);

	/** Etkin olayı sonlandır. */
	public static OmenPayload end() {
		return new OmenPayload(KIND_END, 0, 0, 0.0F, 0.0F, 0);
	}

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
