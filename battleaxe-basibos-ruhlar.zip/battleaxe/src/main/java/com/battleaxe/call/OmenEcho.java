package com.battleaxe.call;

import java.util.OptionalLong;
import java.util.concurrent.ThreadLocalRandom;
import java.util.random.RandomGenerator;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

/**
 * Öncü Belirtiler'in "Sana Bakan Şey"ini, normal çizelgenin DIŞINDA tek seferlik gönderir (Kıyım Zinciri'nin Gözün Yankısı için).
 * Mevcut {@link OmenPayload} ve istemci çizimi aynen kullanılır; yeni görsel kod yoktur. Dünyada hiçbir şey oluşturmaz.
 *
 * <p>Uygunluk normal kurallarla aynıdır ({@link OmenLogic#eligibleMask}): ana dünya, gece, açık gökyüzü, yağış yok, göz tezahürü
 * ayarlardan açık. Uygun değilse hiçbir şey gönderilmez ve {@code 0} döner (çağıran hiçbir şeyi tüketmez). Çağrı sunucu
 * durum makinesine ({@link OmenManager}) dokunmaz; balta edinildikten sonra o sistem zaten kalıcı olarak susmuştur.
 */
public final class OmenEcho {
	private OmenEcho() {
	}

	/** Gözü bu oyuncuya gönderir; görünme süresini (tick) döndürür, gönderilmediyse 0. */
	public static int sendEye(ServerLevel level, ServerPlayer player) {
		if (level.dimension() != Level.OVERWORLD || !ServerPlayNetworking.canSend(player, OmenPayload.TYPE)) {
			return 0;
		}
		OptionalLong dayTime = SkyProbe.dayTime(level);
		int tone = dayTime.isPresent() ? OmenLogic.toneOf(dayTime.getAsLong()) : OmenLogic.TONE_UNKNOWN;
		OmenLogic.Env env = new OmenLogic.Env(true, level.canSeeSky(player.blockPosition()), SkyProbe.precipitating(level), tone, 0.0);
		if ((OmenLogic.eligibleMask(env) & OmenKind.WATCHER_EYE.bit()) == 0) {
			return 0;
		}

		RandomGenerator random = ThreadLocalRandom.current();
		double[] moon = null;
		if (tone == OmenLogic.TONE_NIGHT && dayTime.isPresent()) {
			double celestial = CallMoon.celestialAngle(dayTime.getAsLong());
			if (CallMoon.moonElevationSin(celestial) > 0.0) {
				moon = CallMoon.moonDirection(celestial);
			}
		}
		OmenLogic.Placement placement = OmenLogic.place(random, OmenKind.WATCHER_EYE, player.getYRot(), player.getXRot(), moon);
		int variant = OmenLogic.makeVariant(random, OmenKind.WATCHER_EYE);
		int ticks = OmenLogic.duration(random, OmenKind.WATCHER_EYE);
		ServerPlayNetworking.send(player, new OmenPayload(OmenKind.WATCHER_EYE.id(), random.nextInt() & 0x7FFFFFFF,
				OmenLogic.pack(variant, tone, 0), (float) placement.azimuth(), (float) placement.elevation(), ticks));
		return ticks;
	}
}
