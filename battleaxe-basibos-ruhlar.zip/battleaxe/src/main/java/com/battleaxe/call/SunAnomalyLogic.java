package com.battleaxe.call;

/**
 * <b>Parçalanmış Güneş</b>'in SAF karar mantığı (Minecraft'a bağımlı değildir; test: tools/test/AnomalyLogicTest.java).
 *
 * <p>Bu olay çizelgeyle seçilmez: hangi günün anomali günü olduğu DÜNYA TOHUMU ve GÜN SAYISINDAN deterministik olarak türetilir.
 * Bu yüzden hiçbir şey kaydedilmez, sunucu yeniden başlasa da aynı gün aynı sonucu verir ve aynı dünyadaki bütün oyuncular aynı
 * güneşi görür (çok oyunculu tutarlılık). Gerçek gündüz-gece döngüsü, ışık ve bloklar etkilenmez; yalnızca istemcide güneşin üstüne
 * bir parçalanma görüntüsü çizilir.
 *
 * <ul>
 *   <li>Varyasyon A: kısmi parçalanma (köşesi eksik, kenarları düzensiz kopmuş).</li>
 *   <li>Varyasyon B: büyük çatlaklar (yüzeyi çatlamış, bazı bölgeleri sönmüş).</li>
 *   <li>Varyasyon C: ağır parçalanma (önemli bir bölümü kopmuş, karanlık ve düzensiz).</li>
 *   <li>İz (yalnızca olay gününden SONRAKİ gün, bazen): güneşin yüzünde çok hafif tek bir çatlak.</li>
 * </ul>
 */
public final class SunAnomalyLogic {
	private SunAnomalyLogic() {
	}

	public static final int NONE = 0;
	public static final int PARTIAL = 1;
	public static final int CRACKED = 2;
	public static final int SHATTERED = 3;
	public static final int SCAR = 4;

	/** Bir günün (tohum, gün) 0-1 arası kararlı karması. SplitMix64 türevi; aynı girdi her zaman aynı sonucu verir. */
	public static double hash(long worldSeed, long day, int salt) {
		long z = worldSeed + day * 0x9E3779B97F4A7C15L + salt * 0xBF58476D1CE4E5B9L;
		z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
		z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
		z = z ^ (z >>> 31);
		return (z >>> 11) * 0x1.0p-53;
	}

	/**
	 * Bu gün anomali günü mü? Koşullar: (1) günün karması olasılığın altında, (2) komşu {@code spacing} gün içinde bu günün karması en
	 * düşük (yerel en küçük): böylece iki olay arasında en az {@code spacing} gün vardır ve hesap özyinelemesizdir (kayıt gerekmez).
	 * İlk {@code minDay} gün sakin geçer.
	 */
	public static boolean isEventDay(long worldSeed, long day, double chance, int spacing, int minDay) {
		if (day < minDay || !(chance > 0.0)) {
			return false;
		}
		double mine = hash(worldSeed, day, 1);
		if (!(mine < chance)) {
			return false;
		}
		for (int k = 1; k <= Math.max(0, spacing - 1); k++) {
			if (hash(worldSeed, day - k, 1) < mine && day - k >= minDay) {
				return false;
			}
			if (hash(worldSeed, day + k, 1) <= mine) {
				return false;
			}
		}
		return true;
	}

	/** Olay günü varyasyonu: A %45, B %33, C %22 (ağır parçalanma en nadir). */
	public static int variantOfEvent(long worldSeed, long day) {
		double r = hash(worldSeed, day, 2);
		return r < 0.45 ? PARTIAL : r < 0.78 ? CRACKED : SHATTERED;
	}

	/**
	 * Bu gün güneşin durumu: olay günüyse varyasyon (1-3); olay gününden SONRAki gündeyse yarı olasılıkla {@link #SCAR}; aksi halde {@link #NONE}.
	 * {@code enabled=false} her zaman {@link #NONE}.
	 */
	public static int stateForDay(boolean enabled, long worldSeed, long day, double chance, int spacing, int minDay) {
		if (!enabled) {
			return NONE;
		}
		if (isEventDay(worldSeed, day, chance, spacing, minDay)) {
			return variantOfEvent(worldSeed, day);
		}
		if (isEventDay(worldSeed, day - 1, chance, spacing, minDay) && hash(worldSeed, day, 3) < 0.5) {
			return SCAR;
		}
		return NONE;
	}

	/** Gün sayısı (negatif zaman sarılır: -1 tick de bir önceki günün sonudur). */
	public static long dayOf(long dayTimeTicks) {
		return Math.floorDiv(dayTimeTicks, 24000L);
	}

	/** Gün içindeki zaman (0..23999). */
	public static long timeOfDay(long dayTimeTicks) {
		return Math.floorMod(dayTimeTicks, 24000L);
	}

	/** Bu gün adı için kararlı görsel tohum (31 bit; pakette gönderilir, çokoyunculu aynı şekli verir). */
	public static int visualSeed(long worldSeed, long day) {
		return (int) (Double.doubleToLongBits(hash(worldSeed, day, 4)) >>> 1) & 0x7FFFFFFF;
	}

	/** Güneş yönü (birim vektör): ayın tam karşısı. */
	public static double[] sunDirection(double celestial) {
		double[] moon = CallMoon.moonDirection(celestial);
		return new double[] {-moon[0], -moon[1], -moon[2]};
	}

	/** Güneşin ufuktan yüksekliği (derece). */
	public static double sunElevationDegrees(double celestial) {
		return Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, -CallMoon.moonElevationSin(celestial)))));
	}
}
