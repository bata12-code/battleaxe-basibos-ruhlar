package com.battleaxe.call;

/**
 * Öncü belirtilerin gök geometrisi (SAF mantık; Minecraft'a bağımlı değildir, hem sunucuda hem istemcide kullanılır).
 *
 * <p>Her tezahür dünyada SABİT bir yöne (yön açısı + yükseklik açısı) bağlıdır: oyuncu yürüse de gökyüzündeki
 * bir cisim gibi yerinde durur (paralaks yoktur; bu, aşırı uzaklık hissini verir). Şekiller bu yönün çevresinde
 * "görünür açı (derece)" cinsinden tanımlanır ve köşe köşe ekrana izdüşürülür; böylece kamera döndükçe doğru
 * perspektifle kayarlar ve ekrana yapıştırılmış düz bir resim gibi durmazlar.
 */
public final class OmenGeometry {
	private OmenGeometry() {
	}

	/** Yön açısı (Minecraft yaw: 0 = güney +Z, 90 = batı -X) ve ufuktan yükseklik (derece, yukarı pozitif) için birim yön. */
	public static double[] direction(double azimuthDeg, double elevationDeg) {
		return CallMoon.lookVector(azimuthDeg, -elevationDeg);
	}

	/**
	 * Merkez yönünün çevresinde, görünür açı cinsinden (dx sağa, dy yukarı; derece) bir köşenin yönü. Yön açısındaki
	 * kayma yükseklik arttıkça büyür (kutba doğru meridyenler birleşir): 1/cos(yükseklik) ile telafi edilir.
	 * Yön açısı arttıkça görüntü ekranda SAĞA gider (yaw 0'dan 90'a: güneyden batıya; güneye bakana batı sağdadır).
	 */
	public static double[] vertexDirection(double azimuthDeg, double elevationDeg, double dx, double dy) {
		double el = Math.max(-80.0, Math.min(80.0, elevationDeg));
		double scale = 1.0 / Math.max(0.2, Math.cos(Math.toRadians(el)));
		double elV = Math.max(-89.0, Math.min(89.0, elevationDeg + dy));
		return direction(azimuthDeg + dx * scale, elV);
	}

	/**
	 * {@link CallMoon#project} ile aynı kamera modeli; ancak kameranın arkasındaki ya da çok yan açıdaki köşeler
	 * atılmaz, ekran dışına itilir. Böylece büyük bir şekil görüş alanının kenarında ani yok olmaz.
	 *
	 * @return {ekranX, ekranY, pikselBaşınaTanjant, önde(1)/arkada(0)}
	 */
	public static double[] projectClamped(double[] dir, double yawDeg, double pitchDeg, double fovDeg, double width, double height) {
		double yaw = Math.toRadians(yawDeg);
		double pitch = Math.toRadians(pitchDeg);
		double sy = Math.sin(yaw);
		double cy = Math.cos(yaw);
		double sp = Math.sin(pitch);
		double cp = Math.cos(pitch);

		double fx = -sy * cp, fy = -sp, fz = cy * cp;
		double rx = -cy, rz = -sy;
		double ux = -sy * sp, uy = cp, uz = cy * sp;

		double zc = dir[0] * fx + dir[1] * fy + dir[2] * fz;
		double xc = dir[0] * rx + dir[2] * rz;
		double yc = dir[0] * ux + dir[1] * uy + dir[2] * uz;
		boolean front = zc >= 0.05;
		double z = Math.max(zc, 0.12);

		double tanHalf = Math.tan(Math.toRadians(fovDeg) / 2.0);
		double pxPerTan = (height / 2.0) / tanHalf;
		double sx = width / 2.0 + (xc / z) * pxPerTan;
		double sYpx = height / 2.0 - (yc / z) * pxPerTan;
		return new double[] {sx, sYpx, pxPerTan, front ? 1.0 : 0.0};
	}

	/** İki birim yön arasındaki açı (derece). */
	public static double angleDegrees(double[] a, double[] b) {
		return CallMoon.angleBetweenDegrees(a, b);
	}

	/** Dereceyi (-180, 180] aralığına sarar. */
	public static double wrap180(double degrees) {
		double d = degrees % 360.0;
		if (d > 180.0) {
			d -= 360.0;
		} else if (d <= -180.0) {
			d += 360.0;
		}
		return d;
	}
}
