package com.battleaxe.call;

import java.util.ArrayList;
import java.util.List;

import com.battleaxe.chain.ChainWhisperLogic;

/**
 * Baltayı edinmiş oyuncuya, bir Kozmik Anomali başladıktan bir süre sonra baltanın TEK bir sözü (SAF mantık; test: AnomalyLogicTest).
 * Balta rütbesine göre üç tonda konuşur ({@link ChainWhisperLogic#band}: mesafeli / susamış / sadık); hiçbir şey açıklamaz. Yalnızca baltalı
 * oyuncular duyar: Öncü Belirtiler baltayı edinince kalıcı susar, ama dünya susmaz ve balta bunu fark eder.
 */
public final class AnomalyWhisperLogic {
	private AnomalyWhisperLogic() {
	}

	/** Söz söylenme olasılığı (her anomalide değil, çoğunda). */
	public static final double CHANCE = 0.60;
	/** Anomali başladıktan sonra sözün gecikmesi (tick): oyuncu önce görsün. */
	public static final int MIN_DELAY_TICKS = 140;
	public static final int MAX_DELAY_TICKS = 280;

	private static final String PREFIX = "message.battleaxe.anomaly.whisper.";

	/** Bu tür için baltanın sözü var mı? (Yalnızca gökyüzü/ufuk anomalileri; Bütün Canlılar ve Güneş kendi yazısına/sessizliğine sahiptir.) */
	public static boolean hasLine(OmenKind kind) {
		return kind == OmenKind.SECOND_MOON || kind == OmenKind.IMPOSSIBLE_RINGS || kind == OmenKind.MONOLITH;
	}

	/** Gecikme: {@code roll} (0-1) ile aralığa eşlenir. */
	public static int delay(double roll) {
		double r = Double.isNaN(roll) ? 0.0 : Math.max(0.0, Math.min(1.0, roll));
		return MIN_DELAY_TICKS + (int) (r * (MAX_DELAY_TICKS - MIN_DELAY_TICKS));
	}

	/** Söylensin mi? {@code roll}: 0-1 rastgele. */
	public static boolean shouldSpeak(OmenKind kind, double roll) {
		return hasLine(kind) && roll < CHANCE;
	}

	/** Dil anahtarı; sözü olmayan tür için {@code null}. */
	public static String key(OmenKind kind, int band) {
		if (!hasLine(kind)) {
			return null;
		}
		String name = switch (kind) {
			case SECOND_MOON -> "second_moon";
			case IMPOSSIBLE_RINGS -> "rings";
			default -> "monolith";
		};
		return PREFIX + name + "." + Math.max(0, Math.min(ChainWhisperLogic.BANDS - 1, band));
	}

	/** Tüm dil anahtarları (çeviri bütünlüğü testi için). */
	public static List<String> allKeys() {
		List<String> keys = new ArrayList<>();
		for (OmenKind kind : OmenKind.values()) {
			if (hasLine(kind)) {
				for (int band = 0; band < ChainWhisperLogic.BANDS; band++) {
					keys.add(key(kind, band));
				}
			}
		}
		return keys;
	}
}
