package com.battleaxe.call;

/**
 * Kozmik Anomaliler'in teknik kategorileri (oyuncuya gösterilen isimler DEĞİLDİR; yalnızca mantığı düzenler ve testlerde
 * "her kategori temsil edilir" denetimini sağlar).
 */
public enum OmenCategory {
	/** Gökyüzü ve gök cisimleri. */
	CELESTIAL,
	/** Ufukta görülen devasa oluşumlar. */
	HORIZON,
	/** Perspektif ve gerçeklik bozulmaları. */
	REALITY,
	/** Oyuncuyu izleyen ya da ona tepki veren olaylar. */
	OBSERVER,
	/** Daha uzun süre devam eden dünya çapındaki değişimler. */
	WORLD
}
