package com.battleaxe.call;

import java.util.ArrayList;
import java.util.List;
import java.util.random.RandomGenerator;

/**
 * Baltanın Çağrısı'nın SAF karar mantığı: ilerleme düzeyi, mesaj tablosu ve seçimi, bekleme denetimleri.
 * Minecraft'a bağımlı değildir (test: tools/test/CallLogicTest.java). Metinler dil dosyalarındadır;
 * burada yalnızca hangi mesajın hangi ilerlemede/bağlamda çıkabileceği yazar.
 */
public final class CallLogic {
	private CallLogic() {
	}

	// ------------------------------------------------------------------
	// Kalıcı bayraklar (oyuncuya bağlı; bir kez yanınca geri dönmez)
	// ------------------------------------------------------------------

	/** Oyuncu Nether'da bulundu. */
	public static final int F_NETHER = 1;
	/** Bir Wither'ın doğuşuna/varlığına tanık oldu. */
	public static final int F_WITHER_SEEN = 2;
	/** Bir Wither'ın ölümüne tanık oldu / öldürdü. */
	public static final int F_WITHER_DEFEATED = 4;
	/** Envanterinde Nether Yıldızı bulundu. */
	public static final int F_STAR = 8;
	/** Savaş Baltası'nı edindi (ya da edinmiş olduğu anlaşıldı): Çağrı sonsuza dek susar. */
	public static final int F_AXE = 16;

	/** Dönüm noktası bayrakları (ilerleme sırasıyla; alt bitler önceki aşamalardır). */
	public static final int MILESTONE_MASK = F_NETHER | F_WITHER_SEEN | F_WITHER_DEFEATED | F_STAR;

	/** Ilerleme düzeyi: 0 hiçbiri, 1 Nether, 2 Wither görüldü, 3 Wither yenildi, 4 Nether Yıldızı edinildi. */
	public static int progress(int flags) {
		if ((flags & F_STAR) != 0) {
			return 4;
		}
		if ((flags & F_WITHER_DEFEATED) != 0) {
			return 3;
		}
		if ((flags & F_WITHER_SEEN) != 0) {
			return 2;
		}
		if ((flags & F_NETHER) != 0) {
			return 1;
		}
		return 0;
	}

	/** Baltayı edinmiş oyuncuya hiçbir şey gösterilmez. */
	public static boolean silenced(int flags) {
		return (flags & F_AXE) != 0;
	}

	/**
	 * Henüz mesajı gösterilmemiş EN YÜKSEK dönüm noktası bayrağını verir (yoksa 0). Daha düşük aşamalar
	 * için ayrıca mesaj gösterilmez; çağıran onları da "gösterildi" sayar ({@link #milestonesCovered}).
	 */
	public static int pendingMilestone(int flags, int shown) {
		for (int bit = F_STAR; bit >= F_NETHER; bit >>= 1) {
			if ((flags & bit) != 0 && (shown & bit) == 0) {
				return bit;
			}
		}
		return 0;
	}

	/** Bu bayrağın ve altındaki tüm aşamaların maskesi. */
	public static int milestonesCovered(int bit) {
		return ((bit << 1) - 1) & MILESTONE_MASK;
	}

	/** Dönüm noktası bayrağının dil anahtarı numarası (1..4). */
	public static int milestoneNumber(int bit) {
		return Integer.numberOfTrailingZeros(bit) + 1;
	}

	// ------------------------------------------------------------------
	// Bağlam
	// ------------------------------------------------------------------

	public static final int C_ANY = 1;
	public static final int C_NIGHT = 2;
	public static final int C_UNDERGROUND = 4;
	public static final int C_NETHER = 8;
	public static final int C_END = 16;

	public static int context(boolean nether, boolean end, boolean night, boolean underground) {
		int ctx = C_ANY;
		if (nether) {
			ctx |= C_NETHER;
		}
		if (end) {
			ctx |= C_END;
		}
		if (night) {
			ctx |= C_NIGHT;
		}
		if (underground) {
			ctx |= C_UNDERGROUND;
		}
		return ctx;
	}

	// ------------------------------------------------------------------
	// Mesaj tablosu
	// ------------------------------------------------------------------

	public enum Kind {
		/** Aşama 1: Fısıltı. */
		WHISPER,
		/** Aşama 3: Tanınma (ilerlemeye bağlı). */
		RECOGNITION
	}

	/** @param key dil anahtarı; @param minProgress en düşük ilerleme düzeyi; @param contexts hangi bağlamlarda çıkabilir (bit maskesi) */
	public record Entry(String key, Kind kind, int minProgress, int contexts) {
	}

	private static final int ANY = C_ANY;
	private static final int NIGHT = C_NIGHT;
	private static final int DEEP = C_UNDERGROUND;
	private static final int NETHER = C_NETHER;

	/**
	 * Mesaj tablosu. Dizin = kimlik (seenMask bitinin sırası); EN ÇOK 64 girdi. Sırayı DEĞİŞTİRME, yalnızca sona ekle
	 * (kayıtlı "görüldü" bitleri sıraya bağlıdır). Dil anahtarları: call.whisper.N ve call.recognition.N.
	 */
	public static final Entry[] TABLE = {
			// ---- Fısıltı (ilerleme 0'dan itibaren) ----
			new Entry("call.whisper.1", Kind.WHISPER, 0, ANY),            // Yıldız...
			new Entry("call.whisper.2", Kind.WHISPER, 0, ANY),            // Yıldızı bulmalısın.
			new Entry("call.whisper.3", Kind.WHISPER, 0, ANY),            // Henüz değil.
			new Entry("call.whisper.4", Kind.WHISPER, 0, ANY),            // Beni duydun mu?
			new Entry("call.whisper.5", Kind.WHISPER, 0, DEEP | NETHER),  // Demir soğuyor.
			new Entry("call.whisper.6", Kind.WHISPER, 0, DEEP),           // Bir şey seni bekliyor.
			new Entry("call.whisper.7", Kind.WHISPER, 0, NIGHT),          // Bu dünya sessiz kalmayacak.
			new Entry("call.whisper.8", Kind.WHISPER, 0, ANY),            // Savaş henüz bitmedi.
			new Entry("call.whisper.9", Kind.WHISPER, 0, NETHER),         // Kor sönmedi.
			new Entry("call.whisper.10", Kind.WHISPER, 0, NETHER),        // Örs hâlâ sıcak.
			new Entry("call.whisper.11", Kind.WHISPER, 0, ANY),           // Kara demirin hafızası var.
			new Entry("call.whisper.12", Kind.WHISPER, 0, NIGHT),         // Gölgen ağırlaşıyor.
			new Entry("call.whisper.13", Kind.WHISPER, 0, ANY),           // Seni ben çağırdım.
			new Entry("call.whisper.14", Kind.WHISPER, 0, ANY),           // Ruhlar kalabalık.
			new Entry("call.whisper.15", Kind.WHISPER, 0, DEEP),          // Taş hatırlar.
			new Entry("call.whisper.16", Kind.WHISPER, 0, ANY),           // Kapı hep açıktı.
			// ---- Tanınma (ilerlemeye bağlı) ----
			new Entry("call.recognition.1", Kind.RECOGNITION, 1, ANY),    // Bu sıcaklığı tanıyorum.
			new Entry("call.recognition.2", Kind.RECOGNITION, 1, NETHER), // Kor seni tanıyor.
			new Entry("call.recognition.3", Kind.RECOGNITION, 2, ANY),    // Üç göz sana bakıyor.
			new Entry("call.recognition.4", Kind.RECOGNITION, 2, ANY),    // Uyandırdığın şey beni de uyandırdı.
			new Entry("call.recognition.5", Kind.RECOGNITION, 3, ANY),    // Yıldız yerde kaldı.
			new Entry("call.recognition.6", Kind.RECOGNITION, 3, NIGHT),  // Üç baş sustu. Sıra bende.
			new Entry("call.recognition.7", Kind.RECOGNITION, 4, ANY),    // O beni hatırlıyor.
			new Entry("call.recognition.8", Kind.RECOGNITION, 4, ANY),    // Beni henüz taşıyamazsın.
			new Entry("call.recognition.9", Kind.RECOGNITION, 4, NIGHT),  // Yıldız ağırlaştı. Elin hazır mı?
	};

	/** Dönüm noktası mesajlarının sayısı (call.milestone.1..4). */
	public static final int MILESTONE_COUNT = 4;

	/** Önbelleksiz, sıfır tahsisli bayrak denetimi. */
	private static boolean eligible(Entry e, Kind kind, int progress, int ctx) {
		return e.kind() == kind && e.minProgress() <= progress && (e.contexts() & ctx) != 0;
	}

	/**
	 * Uygun mesajlar arasından birini seçer; uygun mesaj yoksa -1 (SESSİZLİK). Önce hangi türün (fısıltı/tanınma)
	 * seçileceğine ilerleme düzeyiyle orantılı olasılıkla karar verilir; o türde uygun mesaj yoksa diğerine bakılır.
	 *
	 * @param seenMask    daha önce gösterilen mesajların bit maskesi
	 * @param lastPick    en son gösterilen mesaj (art arda aynı mesaj gelmesin), yoksa -1
	 * @param allowRepeat true ise gösterilmiş mesajlar da aday olur (yalnızca tümü tükenmişse ve uzun süre geçmişse)
	 */
	public static int choose(RandomGenerator random, int progress, int ctx, long seenMask, int lastPick, boolean allowRepeat) {
		double share = progress <= 0 ? 0.0
				: Math.min(CallConfig.RECOGNITION_SHARE_MAX, CallConfig.RECOGNITION_SHARE_PER_PROGRESS * progress);
		Kind first = random.nextDouble() < share ? Kind.RECOGNITION : Kind.WHISPER;
		Kind second = first == Kind.RECOGNITION ? Kind.WHISPER : Kind.RECOGNITION;
		int pick = pickOf(random, first, progress, ctx, seenMask, lastPick, allowRepeat);
		if (pick < 0) {
			pick = pickOf(random, second, progress, ctx, seenMask, lastPick, allowRepeat);
		}
		return pick;
	}

	private static int pickOf(RandomGenerator random, Kind kind, int progress, int ctx, long seenMask, int lastPick, boolean allowRepeat) {
		List<Integer> candidates = new ArrayList<>(TABLE.length);
		for (int i = 0; i < TABLE.length; i++) {
			if (i == lastPick || !eligible(TABLE[i], kind, progress, ctx)) {
				continue;
			}
			boolean seen = (seenMask & (1L << i)) != 0;
			if (!seen || allowRepeat) {
				candidates.add(i);
			}
		}
		return candidates.isEmpty() ? -1 : candidates.get(random.nextInt(candidates.size()));
	}

	/** Bu bağlam ve ilerlemede gösterilmemiş (yeni) uygun mesaj kaldı mı? */
	public static boolean hasUnseen(int progress, int ctx, long seenMask, int lastPick) {
		for (int i = 0; i < TABLE.length; i++) {
			if (i != lastPick && (seenMask & (1L << i)) == 0
					&& TABLE[i].minProgress() <= progress && (TABLE[i].contexts() & ctx) != 0) {
				return true;
			}
		}
		return false;
	}

	/** Tekrar izni verildiğinde tüm mesajların "görüldü" bitlerini temizler; yalnızca seçilen mesaj "görüldü" kalır. */
	public static long resetSeen(long seenMask, int keepIndex) {
		long cleared = 0L;
		for (int i = 0; i < TABLE.length; i++) {
			cleared |= 1L << i;
		}
		long keep = seenMask & ~cleared;
		return keep | (keepIndex >= 0 ? 1L << keepIndex : 0L);
	}

	// ------------------------------------------------------------------
	// Bekleme / olasılık
	// ------------------------------------------------------------------

	/**
	 * Son olaydan beri yeterince zaman geçti mi? {@code last <= 0} "hiç olmadı" demektir; {@code now < last}
	 * (örn. veri başka bir dünyadan taşındı) bekleme süresi dolmuş sayılır, böylece sistem takılı kalmaz.
	 */
	public static boolean ready(long now, long last, long gap) {
		if (last <= 0L || now < last) {
			return true;
		}
		return now - last >= gap;
	}

	/** Bir denetimde mesaj olasılığı (ilerledikçe biraz artar). */
	public static double messageChance(int progress) {
		return CallConfig.MESSAGE_CHANCE_BASE + CallConfig.MESSAGE_CHANCE_PER_PROGRESS * Math.max(0, Math.min(4, progress));
	}

	/** Ay silüetinin süresi (ilerledikçe biraz uzar). */
	public static int moonDuration(int progress) {
		return CallConfig.MOON_DURATION_TICKS + CallConfig.MOON_DURATION_PER_PROGRESS * Math.max(0, Math.min(4, progress));
	}

	/** Ay silüeti yoğunluğu (0..2): ilerledikçe silüet biraz daha belirgin olur. */
	public static int moonIntensity(int progress) {
		return progress >= 3 ? 2 : progress >= 1 ? 1 : 0;
	}
}
