package com.battleaxe.call;

import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;

/**
 * Öncü belirtilerin şekilleri: {@link OmenKind} + varyant + tohumdan DETERMİNİST üretilen çokgen kümeleri.
 * SAF mantıktır (Minecraft'a bağımlı değildir; test: tools/test/OmenLogicTest.java). İstemci bunları
 * {@link OmenGeometry} ile köşe köşe ekrana izdüşürüp çizer.
 *
 * <p>Koordinatlar "görünür açı"dır (derece): x sağa, y YUKARI. Tezahürün sabit yönü merkezdir ({@code (0,0)}):
 * gökteki cisimlerde şeklin ortası, ufuktaki cisimlerde (Dev, Yapı) şeklin TABANI (y = 0 ufuk çizgisidir; taban
 * biraz altına iner ve arazi tarafından örtülür).
 *
 * <p>Hiçbiri gerçek bir model, varlık ya da dünya nesnesi değildir. Şekiller bilerek simetrik ve "tam" değildir:
 * Dev'in uzuvları fazladır, Yapı'nın kemerleri birbirine bağlanmaz, Gözün bebeği insansı değildir.
 */
public final class OmenShapes {
	private OmenShapes() {
	}

	/** Katman/boya stilleri: renk ve temel saydamlık istemcide (OmenCanvas) belirlenir. */
	public static final int S_AURA = 0;
	public static final int S_BODY = 1;
	public static final int S_MID = 2;
	public static final int S_DEEP = 3;
	public static final int S_GLINT = 4;
	/** Saf karanlık: gece gökyüzünü (ve yıldızları) örter. İkinci Ay'ın çevresindeki "yıldızsız boşluk", gözü yutan gölge. */
	public static final int S_VOID = 5;
	/** Ufuk sisi: istemcide gün zamanına göre renklenir (gündüz soluk gri-mavi, gece koyu lacivert). Atmosferik perspektif içindir. */
	public static final int S_HAZE = 6;
	/** Koyu kızıl kor: İkinci Ay'ın kızıl kenarı gibi ince vurgular. */
	public static final int S_EMBER = 7;
	/** Geçerli en büyük stil kimliği (testler ve istemci paleti için). */
	public static final int MAX_STYLE = S_EMBER;

	/** Üst sınırlar (çizim maliyetini sınırlar; testle doğrulanır). */
	public static final int MAX_POLYS = 96;
	public static final int MAX_POINTS_PER_POLY = 128;

	/**
	 * @param x,y     köşeler (derece)
	 * @param style   {@code S_*}
	 * @param alpha   stilin temel saydamlığına çarpan (0..1)
	 * @param outline kenarı ince kızıl bir çizgiyle vurgulanır
	 * @param group   0 = sabit; 1 = "bebek" grubu (Göz bakışı takip ederken birlikte kayar)
	 */
	public record Poly(float[] x, float[] y, int style, float alpha, boolean outline, int group) {
	}

	/** @param glints (x, y, faz) üçlüleri: kenarlardaki seyrek beyaz kıvılcımlar */
	public record Scene(Poly[] polys, float[] glints, float halfWidth, float halfHeight) {
	}

	/** Varyantın düşük bitlerinden türe özgü alan ({@link OmenLogic#makeVariant} düzeni). */
	public static Scene build(OmenKind kind, int variant, long seed) {
		SplittableRandom rnd = new SplittableRandom(seed * 0x9E3779B97F4A7C15L + kind.id() * 7919L + variant);
		Builder b = new Builder(rnd);
		int low = OmenLogic.lowBits(variant);
		switch (kind) {
			case SKY_AXE -> skyAxe(b, (low & 4) != 0 ? 1 : -1);
			case WATCHER_EYE -> eyeComposed(b, low & 1, (low >> 2) & 3, (low & 16) != 0, (low & 32) != 0);
			case HORIZON_COLOSSUS -> colossus(b, low & 3);
			case IMPOSSIBLE_STRUCTURE -> structure(b, low & 3);
			case SECOND_MOON -> secondMoon(b, low & 3, Math.min(2, (low >> 2) & 3), (low & 16) != 0);
			case IMPOSSIBLE_RINGS -> rings(b, 3 + ((low >> 3) & 1), (low & 4) != 0);
			case MONOLITH -> monolith(b, low & 3);
			case ALL_WATCHING, FRACTURED_SUN -> {
				// görüntü yok: davranış (Bütün Canlılar) ya da kendi sahnesi (Parçalanmış Güneş: SunAnomalyShapes)
			}
		}
		return b.finish();
	}

	// ==================================================================
	// 1) Gökteki devasa balta
	// ==================================================================

	private static void skyAxe(Builder b, int tiltSign) {
		double tilt = tiltSign * (14.0 + b.rnd.nextDouble() * 16.0);
		double scale = 0.78 + b.rnd.nextDouble() * 0.22;
		addAxe(b, tilt, scale, 0.0, 0.0, true);
	}

	/** Savaş baltası: bükülmüş uzun sap, iri hilal ağız, küçük ikinci ağız, tepe mızrağı ve kanca. */
	private static void addAxe(Builder b, double tiltDeg, double scale, double tx, double ty, boolean aura) {
		int from = b.polys.size();
		int gFrom = b.glints.size();
		double phase = b.rnd.nextDouble() * 6.28;

		if (aura) {
			// Yumuşak karanlık hâle: üç eş merkezli, çok soluk elips.
			for (int k = 0; k < 3; k++) {
				b.add(ellipse(2, 4, 27 + 7 * k, 42 + 8 * k, 0, 28), OmenShapes.S_AURA, 0.55f, false, 0);
			}
		}

		// Sap
		int n = 12;
		float[] haft = new float[n * 4];
		for (int i = 0; i < n; i++) {
			double y = 29.0 - i * (59.0 / (n - 1));
			double w = 1.1 + 0.4 * (29.0 - y) / 59.0;
			double bend = 0.9 * Math.sin(y * 0.11 + phase);
			haft[i * 2] = (float) (bend + w);
			haft[i * 2 + 1] = (float) y;
			haft[(2 * n - 1 - i) * 2] = (float) (bend - w);
			haft[(2 * n - 1 - i) * 2 + 1] = (float) y;
		}
		b.add(haft, OmenShapes.S_BODY, 0.95f, false, 0);

		// Sap halkaları
		for (double yc : new double[] {6.0, -3.0, -12.0}) {
			double bend = 0.9 * Math.sin(yc * 0.11 + phase);
			b.add(new float[] {
					(float) (bend - 2.3), (float) (yc + 0.7), (float) (bend + 2.3), (float) (yc + 0.7),
					(float) (bend + 2.3), (float) (yc - 0.7), (float) (bend - 2.3), (float) (yc - 0.7)},
					OmenShapes.S_BODY, 1.0f, false, 0);
		}

		// Ana ağız (sağ): iki boynuzlu, yanları oyuk, kesici kenarı basamaklı köşeli bir savaş baltası ağzı
		float[] blade = {
				1.0f, 26.0f, 7.0f, 28.5f, 14.0f, 31.5f, 22.0f, 35.0f, 18.5f, 25.5f, 17.0f, 21.0f, 20.5f, 15.0f,
				17.0f, 8.5f, 18.0f, 4.0f, 23.5f, -3.5f, 12.5f, 2.0f, 5.5f, 7.5f, 1.0f, 10.5f};
		b.add(blade, OmenShapes.S_BODY, 1.0f, true, 0);

		// Sırt mızrağı (sol): aşağı kıvrılan uzun, sivri bir kanca
		b.add(new float[] {-1.0f, 24.5f, -8.0f, 26.0f, -17.0f, 23.5f, -26.0f, 15.5f, -16.5f, 19.5f, -8.0f, 20.5f, -1.0f, 19.0f},
				OmenShapes.S_BODY, 1.0f, true, 0);

		// Tepe mızrağı ve alt kanca
		b.add(new float[] {-1.0f, 28.5f, 0.2f, 39.0f, 1.3f, 28.5f}, OmenShapes.S_BODY, 1.0f, true, 0);
		b.add(new float[] {-0.9f, -29.0f, 2.2f, -33.0f, 5.0f, -34.5f, 3.8f, -31.5f, 1.6f, -28.0f}, OmenShapes.S_BODY, 1.0f, false, 0);

		// Kenar kıvılcımları: ağız boynuzları ve sırt mızrağının ucu
		b.glint(22.0f, 35.0f);
		b.glint(23.5f, -3.5f);
		b.glint(-26.0f, 15.5f);

		b.xform(from, gFrom, tiltDeg, scale, tx, ty);
	}

	// ==================================================================
	// 2) Sana bakan şey
	// ==================================================================

	private static void eye(Builder b, int shape) {
		SplittableRandom r = b.rnd;
		// Dışa yayılan karanlık ışınlar (gözü çevreleyen "çatlak")
		int spikes = shape == 0 ? 9 : 6;
		for (int k = 0; k < spikes; k++) {
			double a = Math.toRadians(k * (360.0 / spikes) + (r.nextDouble() - 0.5) * 22.0 + (shape == 1 ? 15.0 : 0.0));
			double r0 = 9.0;
			double len = 12.0 + r.nextDouble() * 15.0;
			double ca = Math.cos(a);
			double sa = Math.sin(a);
			double px = -sa * 0.7;
			double py = ca * 0.7;
			b.add(new float[] {
					(float) (ca * r0 + px), (float) (sa * r0 * 0.7 + py),
					(float) (ca * (r0 + len)), (float) (sa * (r0 + len) * 0.7),
					(float) (ca * r0 - px), (float) (sa * r0 * 0.7 - py)},
					OmenShapes.S_AURA, 0.7f, false, 0);
		}
		// Hâle
		for (int k = 0; k < 2; k++) {
			b.add(ellipse(0, 0, 17 + 5 * k, 10 + 3.5 * k, 0, 28), OmenShapes.S_AURA, 0.55f, false, 0);
		}

		if (shape == 0) {
			// Badem biçimli göz kapağı: kenarı hafif düzensiz
			int n = 26;
			float[] lid = new float[n * 4];
			for (int i = 0; i < n; i++) {
				double t = i / (double) (n - 1);
				double s = Math.sin(Math.PI * t);
				double jag = (r.nextDouble() - 0.5) * 0.55 * s;
				double jag2 = (r.nextDouble() - 0.5) * 0.55 * s;
				double x = -14.0 + 28.0 * t;
				lid[i * 2] = (float) x;
				lid[i * 2 + 1] = (float) (7.2 * Math.pow(s, 0.85) + jag);
				lid[(2 * n - 1 - i) * 2] = (float) x;
				lid[(2 * n - 1 - i) * 2 + 1] = (float) (-5.6 * Math.pow(s, 0.9) + jag2);
			}
			b.add(lid, OmenShapes.S_BODY, 0.97f, true, 0);
			// Bebek grubu: eş merkezli halkalar, düzensiz dikey yarık
			b.add(ellipse(0, 0.6, 4.8, 4.8, 0, 26), OmenShapes.S_MID, 0.9f, false, 1);
			b.add(ellipse(0, 0.6, 3.7, 3.7, 0, 26), OmenShapes.S_BODY, 1.0f, false, 1);
			b.add(ellipse(0, 0.6, 2.6, 2.6, 0, 22), OmenShapes.S_MID, 0.8f, false, 1);
			b.add(new float[] {0.0f, -3.0f, 0.75f, 0.2f, 0.1f, 3.6f, -0.65f, 0.5f}, OmenShapes.S_DEEP, 1.0f, false, 1);
			b.add(arc(0, 0.6, 4.2, 3.6, 105, 158, 8), OmenShapes.S_GLINT, 0.5f, false, 1);
		} else {
			// Mercek biçimli göz: iki ucu sivri, geometrik
			int n = 24;
			float[] lens = new float[n * 4];
			for (int i = 0; i < n; i++) {
				double t = i / (double) (n - 1);
				double q = 1.0 - Math.pow(Math.abs(2.0 * t - 1.0), 1.7);
				double x = -14.0 + 28.0 * t;
				lens[i * 2] = (float) x;
				lens[i * 2 + 1] = (float) (8.0 * q);
				lens[(2 * n - 1 - i) * 2] = (float) x;
				lens[(2 * n - 1 - i) * 2 + 1] = (float) (-6.5 * q);
			}
			b.add(lens, OmenShapes.S_BODY, 0.97f, true, 0);
			// Bebek grubu: eş merkezli elmaslar, yatay yarık
			b.add(diamond(0, 0.5, 5.3), OmenShapes.S_MID, 0.9f, false, 1);
			b.add(diamond(0, 0.5, 4.0), OmenShapes.S_BODY, 1.0f, false, 1);
			b.add(diamond(0, 0.5, 2.7), OmenShapes.S_MID, 0.8f, false, 1);
			b.add(new float[] {-3.0f, 0.5f, 0.0f, 1.1f, 3.0f, 0.5f, 0.0f, -0.1f}, OmenShapes.S_DEEP, 1.0f, false, 1);
			b.add(diamond(-1.7, 2.0, 0.55), OmenShapes.S_GLINT, 0.5f, false, 1);
		}
		b.glint(-14.0f, 0.0f);
		b.glint(14.0f, 0.0f);
	}

	// ==================================================================
	// 3) Ufuktaki dev
	// ==================================================================

	private static void colossus(Builder b, int shape) {
		switch (shape) {
			case 0 -> colossusThreeHeaded(b);
			case 1 -> {
				double tilt = (b.rnd.nextBoolean() ? 1 : -1) * (3.0 + b.rnd.nextDouble() * 5.0);
				double scale = 0.70 + b.rnd.nextDouble() * 0.25;
				// Hâle baltanın ARKASINA çizilir (üstüne değil)
				b.add(ellipse(0, 24 * scale, 20, 30 * scale, 0, 26), OmenShapes.S_AURA, 0.5f, false, 0);
				addAxe(b, tilt, scale, 0.0, 30.0 * scale - 4.0, false);
			}
			default -> colossusFaceless(b);
		}
		// Tabandaki sis: gövdenin ayakları ufuk sisinde kaybolur (gövdenin ÜSTÜNE çizilir)
		b.add(ellipse(0, 0.5, 34, 7.5, 0, 26), OmenShapes.S_AURA, 0.9f, false, 0);
		b.add(ellipse(0, 0.0, 26, 4.5, 0, 22), OmenShapes.S_AURA, 0.9f, false, 0);
		// Atmosferik perspektif: tabana doğru giderek kalınlaşan ufuk sisi (düz ovada da "çok uzakta ve çok büyük" hissi verir).
		addHaze(b, 34.0, 24.0);
	}

	/** Wither'ı andıran ama ona benzemeyen: üç başlı, kaburgalı, fazla uzuvlu, asimetrik. */
	private static void colossusThreeHeaded(Builder b) {
		SplittableRandom r = b.rnd;
		int from = b.polys.size();
		int gFrom = b.glints.size();
		// Ölçek: çoğu zaman çok büyük, bazen o kadar büyük ki başları görüş alanının dışında kalır (en çok ~1.9x).
		double scale = 1.0 + r.nextDouble() * 0.30 + (r.nextDouble() < 0.30 ? 0.25 + r.nextDouble() * 0.35 : 0.0);

		b.add(ellipse(0, 26, 24, 38, 0, 26), OmenShapes.S_AURA, 0.45f, false, 0);

		// Omurga: tabandan omuzlara incelen, hafif dalgalı
		int n = 10;
		float[] spine = new float[n * 4];
		double wob = r.nextDouble() * 6.0;
		for (int i = 0; i < n; i++) {
			double y = -3.0 + i * (37.0 / (n - 1));
			double w = 2.7 - 1.4 * (y + 3.0) / 37.0;
			double bend = 0.8 * Math.sin(y * 0.2 + wob);
			spine[i * 2] = (float) (bend + w);
			spine[i * 2 + 1] = (float) y;
			spine[(2 * n - 1 - i) * 2] = (float) (bend - w);
			spine[(2 * n - 1 - i) * 2 + 1] = (float) y;
		}
		b.add(spine, OmenShapes.S_BODY, 0.97f, false, 0);

		// Kaburgalar: aşağı doğru kısalan sivri kemikler (iki taraf farklı uzunlukta)
		for (int i = 0; i < 5; i++) {
			double y = 30.5 - i * 3.9;
			double len = 7.4 - i * 1.05;
			b.add(rib(y, len * (0.85 + r.nextDouble() * 0.3), 1), OmenShapes.S_BODY, 0.97f, false, 0);
			b.add(rib(y, len * (0.85 + r.nextDouble() * 0.3), -1), OmenShapes.S_BODY, 0.97f, false, 0);
		}

		// Omuz çubuğu: uçları pürüzlü, altında dişler
		b.add(new float[] {-13.8f, 34.4f, -12.0f, 36.0f, 12.2f, 35.8f, 13.9f, 34.2f, 12.6f, 33.1f, -12.8f, 33.2f},
				OmenShapes.S_BODY, 0.97f, true, 0);
		for (double x = -5.0; x <= 5.0; x += 2.5) {
			b.add(new float[] {(float) (x - 0.7), 33.2f, (float) (x + 0.3 + r.nextDouble() * 0.5), (float) (30.4 + r.nextDouble() * 1.2), (float) (x + 0.7), 33.2f},
					OmenShapes.S_BODY, 0.97f, false, 0);
		}

		// Üç baş (bloklu, tepelerinde çıkıntılar; yüz çizgisi yok) ve boyunlar
		double[][] heads = {{0.0, 40.8, 5.0, 4.4}, {-11.8 + r.nextDouble(), 38.6 + r.nextDouble(), 4.0, 3.6}, {11.8 - r.nextDouble(), 38.9 + r.nextDouble(), 4.2, 3.7}};
		for (double[] h : heads) {
			double rot = (r.nextDouble() - 0.5) * 16.0;
			b.add(rotate(headBlock(h[2], h[3]), h[0], h[1], rot), OmenShapes.S_BODY, 1.0f, true, 0);
			b.add(new float[] {(float) (h[0] * 0.5 - 0.6), 34.5f, (float) (h[0] - 0.55), (float) (h[1] - h[3] * 0.4), (float) (h[0] + 0.55), (float) (h[1] - h[3] * 0.4), (float) (h[0] * 0.5 + 0.6), 34.5f},
					OmenShapes.S_BODY, 0.97f, false, 0);
		}

		// Kollar: fazla eklemli, yere kadar sarkar; biri diğerinden uzun. Üçüncü, "yanlış" bir uzuv omurgadan çıkar.
		b.add(limb(13.0, 34.0, new double[] {-18, 8, -6}, new double[] {9, 10, 11}, 1.0, 0.45), OmenShapes.S_BODY, 0.97f, false, 0);
		b.add(limb(-13.0, 34.0, new double[] {18, -9, 7}, new double[] {10, 11.5, 12.5}, 1.0, 0.4), OmenShapes.S_BODY, 0.97f, false, 0);
		b.add(limb(1.0, 20.0, new double[] {-72, 25, -10}, new double[] {8, 8.5, 9}, 0.8, 0.35), OmenShapes.S_BODY, 0.97f, false, 0);

		b.glint(0.0f, 43.2f);
		b.glint(-13.9f, 34.2f);
		b.glint(13.9f, 34.2f);

		b.xform(from, gFrom, 0.0, scale, 0.0, -0.5);
	}

	/** Başı ve uzuvları seçilemeyen, yüzsüz, hafif eğik tek bir sütun; üstünde sarkan ve yükselen sarmaşıklar. */
	private static void colossusFaceless(Builder b) {
		SplittableRandom r = b.rnd;
		int from = b.polys.size();
		int gFrom = b.glints.size();
		double scale = 0.78 + r.nextDouble() * 0.22;
		double height = 56.0;

		b.add(ellipse(1, 30, 18, 38, 0, 26), OmenShapes.S_AURA, 0.45f, false, 0);

		int n = 30;
		float[] body = new float[n * 4];
		double p1 = r.nextDouble() * 6.0;
		double p2 = r.nextDouble() * 6.0;
		double leanDir = r.nextBoolean() ? 1.0 : -1.0;
		for (int i = 0; i < n; i++) {
			double y = -3.0 + i * ((height + 3.0) / (n - 1));
			double f = (y + 3.0) / (height + 3.0);
			double hw = (3.4 * Math.pow(1.0 - f, 0.7) + 1.0) * (1.0 + 0.18 * Math.sin(y * 0.37 + p1));
			double hw2 = (3.4 * Math.pow(1.0 - f, 0.7) + 1.0) * (1.0 + 0.18 * Math.sin(y * 0.31 + p2));
			double lean = leanDir * 4.5 * f * f;
			body[i * 2] = (float) (lean + hw);
			body[i * 2 + 1] = (float) y;
			body[(2 * n - 1 - i) * 2] = (float) (lean - hw2);
			body[(2 * n - 1 - i) * 2 + 1] = (float) y;
		}
		b.add(body, OmenShapes.S_BODY, 0.96f, true, 0);

		// Tepede üç eşit olmayan çıkıntı; yüz yok
		double topLean = leanDir * 4.5;
		for (int k = 0; k < 3; k++) {
			double bx = topLean + (k - 1) * 0.7;
			b.add(new float[] {(float) (bx - 0.6), (float) (height - 1.0), (float) (bx + (r.nextDouble() - 0.5) * 1.6), (float) (height + 2.0 + r.nextDouble() * 5.0), (float) (bx + 0.6), (float) (height - 1.0)},
					OmenShapes.S_BODY, 0.96f, false, 0);
		}

		// Sarmaşıklar: gövdenin üst yarısından dışa uzanan, bazıları sarkan bazıları yükselen ince uzuvlar
		for (int k = 0; k < 6; k++) {
			double y0 = height * (0.45 + 0.5 * r.nextDouble());
			double f = (y0 + 3.0) / (height + 3.0);
			double side = k % 2 == 0 ? 1.0 : -1.0;
			double x0 = leanDir * 4.5 * f * f + side * 2.0;
			double base = side * (20.0 + r.nextDouble() * 70.0);
			b.add(limb(x0, y0, new double[] {base, base * -0.4, base * 0.3}, new double[] {5.0 + r.nextDouble() * 5.0, 5.0 + r.nextDouble() * 4.0, 4.0 + r.nextDouble() * 4.0}, 0.7, 0.2),
					OmenShapes.S_BODY, 0.96f, false, 0);
		}

		b.glint((float) topLean, (float) (height + 3.0));
		b.xform(from, gFrom, 0.0, scale, 0.0, 0.0);
	}

	// ==================================================================
	// 4) Olmaması gereken yapı
	// ==================================================================

	private static void structure(Builder b, int shape) {
		SplittableRandom r = b.rnd;
		// Üst hâle ve taban sisi
		b.add(ellipse(0, 24, 52, 38, 0, 28), OmenShapes.S_AURA, 0.35f, false, 0);
		switch (shape) {
			case 0 -> structureArches(b);
			case 1 -> structureColumns(b);
			case 2 -> structureRings(b);
			default -> structureMonolith(b);
		}
		b.add(ellipse(0, 0.5, 54, 7.0, 0, 28), OmenShapes.S_AURA, 0.9f, false, 0);
		b.add(ellipse(0, 0.0, 40, 4.0, 0, 24), OmenShapes.S_AURA, 0.9f, false, 0);
		b.glint((float) (-40 + r.nextInt(80)), (float) (20 + r.nextInt(25)));
	}

	/** Birbirine bağlanmayan siyah kemerler: zirveleri açık, tabanları farklı yükseklikte ve eğik. */
	private static void structureArches(Builder b) {
		SplittableRandom r = b.rnd;
		int count = 4 + r.nextInt(2);
		for (int k = 0; k < count; k++) {
			double cx = -42.0 + (k + 0.5) * (84.0 / count) + (r.nextDouble() - 0.5) * 8.0;
			double a = 7.0 + r.nextDouble() * 11.0;
			double bh = 24.0 + r.nextDouble() * 30.0;
			double t = 2.4 + r.nextDouble() * 2.0;
			double by = -2.0 + (r.nextDouble() < 0.35 ? r.nextDouble() * 12.0 : 0.0);
			double tilt = (r.nextDouble() - 0.5) * 18.0;
			double gap = Math.toRadians(5.0 + r.nextDouble() * 6.0);
			for (int side = 0; side < 2; side++) {
				double th0 = side == 0 ? 0.0 : Math.PI / 2.0 + gap;
				double th1 = side == 0 ? Math.PI / 2.0 - gap : Math.PI;
				int steps = 14;
				float[] leg = new float[(steps + 1) * 4];
				for (int i = 0; i <= steps; i++) {
					double th = th0 + (th1 - th0) * i / steps;
					leg[i * 2] = (float) (cx + (a + t) * Math.cos(th));
					leg[i * 2 + 1] = (float) (by + (bh + t) * Math.sin(th));
					leg[(2 * (steps + 1) - 1 - i) * 2] = (float) (cx + a * Math.cos(th));
					leg[(2 * (steps + 1) - 1 - i) * 2 + 1] = (float) (by + bh * Math.sin(th));
				}
				b.add(rotate(leg, 0.0, 0.0, 0.0, cx, by, tilt), OmenShapes.S_BODY, 0.97f, true, 0);
			}
		}
	}

	/** Perspektif kurallarına uymayan sütunlar: tabana göre tepede GENİŞLEYEN, farklı noktalara eğilen gövdeler. */
	private static void structureColumns(Builder b) {
		SplittableRandom r = b.rnd;
		int count = 7 + r.nextInt(2);
		for (int k = 0; k < count; k++) {
			double cx = -44.0 + (k + 0.5) * (88.0 / count) + (r.nextDouble() - 0.5) * 6.0;
			boolean broken = r.nextDouble() < 0.25;
			double top = broken ? 14.0 + r.nextDouble() * 10.0 : 40.0 + r.nextDouble() * 32.0;
			double wb = 1.2 + r.nextDouble() * 0.9;
			double wt = broken ? wb : 0.6 + r.nextDouble() * 3.0;
			double lean = (r.nextDouble() - 0.5) * 28.0;
			float[] col = broken
					? new float[] {(float) (cx - wb), -3.0f, (float) (cx - wb), (float) (top * 0.6), (float) (cx - wb * 0.4), (float) top,
							(float) (cx + wb * 0.3), (float) (top - 2.5), (float) (cx + wb), (float) (top * 0.7), (float) (cx + wb), -3.0f}
					: new float[] {(float) (cx - wb), -3.0f, (float) (cx - wt), (float) top, (float) (cx + wt), (float) top, (float) (cx + wb), -3.0f};
			b.add(rotate(col, 0.0, 0.0, 0.0, cx, -3.0, lean), OmenShapes.S_BODY, 0.97f, true, 0);
		}
	}

	/** Birbirinin içinden geçen geometrik halkalar. */
	private static void structureRings(Builder b) {
		SplittableRandom r = b.rnd;
		double[] rots = {0.0, 62.0, -57.0};
		for (int k = 0; k < 3; k++) {
			double rx = 22.0 + r.nextDouble() * 8.0;
			double ry = 5.5 + r.nextDouble() * 3.5;
			double th = 1.4 + r.nextDouble() * 0.8;
			b.add(annulus((r.nextDouble() - 0.5) * 8.0, 24.0 + (r.nextDouble() - 0.5) * 6.0, rx, ry, th, rots[k] + (r.nextDouble() - 0.5) * 12.0, 30),
					k == 1 ? OmenShapes.S_MID : OmenShapes.S_BODY, k == 1 ? 0.85f : 0.97f, true, 0);
		}
		// Halkaları taşıyormuş gibi görünen ama onlara değmeyen ince bir ışın
		b.add(new float[] {-0.5f, -3.0f, 0.5f, -3.0f, 0.25f, 46.0f, -0.25f, 46.0f}, OmenShapes.S_BODY, 0.9f, false, 0);
	}

	/** Baltayı belli belirsiz andıran ama balta olmayan anıt: sap + iki kopuk levha + yüzen halka ve kırıklar. */
	private static void structureMonolith(Builder b) {
		SplittableRandom r = b.rnd;
		double lean = (r.nextDouble() - 0.5) * 8.0;
		b.add(rotate(new float[] {-1.4f, -3.0f, -1.1f, 54.0f, 1.1f, 54.0f, 1.4f, -3.0f}, 0.0, 0.0, 0.0, 0.0, -3.0, lean), OmenShapes.S_BODY, 0.97f, true, 0);
		b.add(rotate(new float[] {5.5f, 31.0f, 25.0f, 37.0f, 22.0f, 49.0f, 5.5f, 45.0f}, 0.0, 0.0, 0.0, 0.0, -3.0, lean), OmenShapes.S_BODY, 0.97f, true, 0);
		b.add(rotate(new float[] {-4.5f, 30.0f, -15.0f, 33.0f, -17.0f, 41.0f, -4.5f, 40.0f}, 0.0, 0.0, 0.0, 0.0, -3.0, lean), OmenShapes.S_BODY, 0.97f, true, 0);
		b.add(annulus(0.0, 22.0, 12.0, 3.0, 1.1, lean * 2.0, 26), OmenShapes.S_MID, 0.85f, true, 0);
		for (int k = 0; k < 4; k++) {
			double sx = (r.nextDouble() - 0.5) * 50.0;
			double sy = 8.0 + r.nextDouble() * 40.0;
			double s = 0.8 + r.nextDouble() * 1.6;
			b.add(rotate(new float[] {0.0f, (float) s, (float) (s * 0.7), (float) (-s * 0.6), (float) (-s * 0.8), (float) (-s * 0.4)}, sx, sy, r.nextDouble() * 360.0),
					OmenShapes.S_BODY, 0.95f, false, 0);
		}
	}

	// ==================================================================
	// Kozmik Anomaliler
	// ==================================================================

	/** İkinci Ay'ın açısal yarıçapları (derece): gerçek ay ~5 derece; bunlar 2-4 kat büyüktür. */
	private static final double[] SECOND_MOON_RADII = {11.0, 15.5, 21.0};

	/**
	 * Gökyüzündeki ikinci, karanlık gök cismi. {@code shape}: 0 simsiyah, 1 çatlaklı/düzensiz yüzeyli, 2 yalnızca bir bölümü görünen
	 * (hilal), 3 kızıl kenarlı. {@code voidHalo}: çevresinde yıldızsız boşluk (yıldızların bir kısmı eksik).
	 */
	private static void secondMoon(Builder b, int shape, int sizeIdx, boolean voidHalo) {
		SplittableRandom r = b.rnd;
		double radius = SECOND_MOON_RADII[Math.max(0, Math.min(2, sizeIdx))];
		if (voidHalo) {
			b.add(blob((r.nextDouble() - 0.5) * 3.0, (r.nextDouble() - 0.5) * 3.0, radius * 2.1, 0.16, 44, r), OmenShapes.S_VOID, 0.32f, false, 0);
			b.add(blob(0.0, 0.0, radius * 1.55, 0.10, 44, r), OmenShapes.S_VOID, 0.48f, false, 0);
		}
		b.add(ellipse(0.0, 0.0, radius * 1.22, radius * 1.22, 0.0, 52), OmenShapes.S_AURA, 0.9f, false, 0);
		switch (shape) {
			case 1 -> {
				b.add(blob(0.0, 0.0, radius, 0.014, 60, r), OmenShapes.S_DEEP, 1.0f, false, 0);
				// Belli belirsiz düzensiz lekeler ve çatlaklar
				for (int k = 0; k < 3; k++) {
					double a = r.nextDouble() * 2.0 * Math.PI;
					double d = radius * (0.15 + r.nextDouble() * 0.5);
					b.add(blob(Math.cos(a) * d, Math.sin(a) * d, radius * (0.10 + r.nextDouble() * 0.16), 0.35, 14, r), OmenShapes.S_MID, 0.32f, false, 0);
				}
				int cracks = 5 + r.nextInt(3);
				for (int k = 0; k < cracks; k++) {
					double a = r.nextDouble() * 2.0 * Math.PI;
					b.add(crack(Math.cos(a) * radius * 0.97, Math.sin(a) * radius * 0.97, a + Math.PI + (r.nextDouble() - 0.5) * 0.9,
							radius * (0.30 + r.nextDouble() * 0.55), 0.16 + r.nextDouble() * 0.2, r), OmenShapes.S_MID, 0.9f, false, 0);
				}
			}
			case 2 -> {
				// Yalnızca bir bölümü görünür: gerçek bir cismin gölgede kalan tarafı yoktur, hilalin içbükey kenarı keskindir.
				double phi = r.nextDouble() * 2.0 * Math.PI;
				b.add(crescent(radius, radius * (0.82 + r.nextDouble() * 0.12), radius * (0.38 + r.nextDouble() * 0.32), phi),
						OmenShapes.S_DEEP, 1.0f, false, 0);
			}
			case 3 -> {
				b.add(blob(0.0, 0.0, radius, 0.010, 60, r), OmenShapes.S_DEEP, 1.0f, false, 0);
				b.add(annulus(0.0, 0.0, radius * 0.955, radius * 0.955, radius * 0.045, 0.0, 60), OmenShapes.S_EMBER, 0.85f, false, 0);
				b.add(ellipse(0.0, 0.0, radius * 1.1, radius * 1.1, 0.0, 52), OmenShapes.S_EMBER, 0.18f, false, 0);
			}
			default -> b.add(blob(0.0, 0.0, radius, 0.006, 60, r), OmenShapes.S_DEEP, 1.0f, false, 0); // simsiyah: kenar neredeyse kusursuz
		}
	}

	/**
	 * İmkânsız Halkalar: birbirinin içinden geçen 3-4 devasa halka. Üst-alt ilişkisi DÖNGÜSELDİR (0, 1'in üstünde; 1, 2'nin üstünde; ...;
	 * sonuncu, 0'ın üstünde): gerçek üç boyutta mümkün olmayan bir bağ. Çizim sırası sonuncuyu en üste koyar; geri kalan her halka
	 * kesişimlerinde kendi parçasını yeniden çizerek komşusunun ÜSTÜNE çıkar. Hiçbir şey saf rastgele değildir: aynı tohum aynı şekli verir.
	 */
	private static void rings(Builder b, int count, boolean withEye) {
		SplittableRandom r = b.rnd;
		int n = Math.max(3, Math.min(4, count));
		double baseR = 20.0 + r.nextDouble() * 8.0;
		double[][] ring = new double[n][];
		for (int i = 0; i < n; i++) {
			double rx = baseR * (0.85 + r.nextDouble() * 0.40);
			double ry = rx * (0.28 + r.nextDouble() * 0.50);
			double rot = (180.0 / n) * i + (r.nextDouble() - 0.5) * 24.0;
			double cx = (r.nextDouble() - 0.5) * 0.35 * baseR;
			double cy = (r.nextDouble() - 0.5) * 0.35 * baseR;
			double thick = 1.1 + r.nextDouble() * 1.3;
			ring[i] = new double[] {cx, cy, rx, ry, rot, thick};
		}
		// Soluk hale (halkaların arkasında)
		for (int i = 0; i < n; i++) {
			double[] c = ring[i];
			b.add(annulus(c[0], c[1], c[2] - 0.8, c[3] - 0.6, c[5] + 1.8, c[4], 44), OmenShapes.S_AURA, 0.5f, false, 0);
		}
		// Gövdeler: indeks sırasıyla (sonraki, öncekinin üstüne biner)
		for (int i = 0; i < n; i++) {
			double[] c = ring[i];
			b.add(annulus(c[0], c[1], c[2], c[3], c[5], c[4], 44), ringStyle(i), ringAlpha(i), true, 0);
		}
		// Döngüsel düzeltme: i, i+1'in kesişimlerinde kendi yayını tekrar çizer (i üstte olur). Sonuncu zaten 0'ın üstündedir.
		for (int i = 0; i < n - 1; i++) {
			double[] a = ring[i];
			double[] c = ring[i + 1];
			double half = clamp((3.2 * (a[5] + c[5])) / ((a[2] + a[3]) / 2.0), 0.10, 0.45);
			for (double t : crossings(a, c)) {
				b.add(annulusSector(a[0], a[1], a[2], a[3], a[5], a[4], t - half, t + half, 8), ringStyle(i), ringAlpha(i), true, 0);
			}
		}
		if (withEye) {
			// Gökyüzünün Hafızası: halkaların merkezinde, yavaşça bakan küçük bir göz (bebeği oyuncuyu çok yavaş izler).
			int from = b.polys.size();
			int gFrom = b.glints.size();
			eye(b, 0);
			b.xform(from, gFrom, 0.0, 0.42, 0.0, 0.0);
		}
		// Bazı bölgeleri yutan karanlık (halkanın bir kısmı karanlıkta kaybolur; yıldızlar da örtülür)
		for (int k = 0; k < 2; k++) {
			double a = r.nextDouble() * 2.0 * Math.PI;
			b.add(blob(Math.cos(a) * baseR * 0.95, Math.sin(a) * baseR * 0.55, baseR * (0.32 + r.nextDouble() * 0.2), 0.3, 22, r),
					OmenShapes.S_VOID, 0.72f, false, 0);
		}
	}

	private static int ringStyle(int i) {
		return i % 2 == 0 ? OmenShapes.S_BODY : OmenShapes.S_MID;
	}

	private static float ringAlpha(int i) {
		return i % 2 == 0 ? 0.97f : 0.88f;
	}

	/**
	 * İmkânsız Monolith: ufuktan göğe uzanan, siyah, yekpare, özelliksiz bir levha. Dikey kenarlar yukarı doğru birbirine YAKINSAR
	 * (gerçek üç boyutlu perspektif: gerçekten çok yüksek ve çok uzak); tabanı ufuk sisinde silinir. Pencere, kapı, yazı, ışık yoktur.
	 * {@code lean}: 0 dik, 1 sağa, 2 sola (üst uç hafifçe kayar), 3 dik.
	 */
	private static void monolith(Builder b, int lean) {
		SplittableRandom r = b.rnd;
		double height = 74.0 + r.nextDouble() * 14.0;
		double bw = 1.7 + r.nextDouble() * 1.0;
		double tw = bw * (0.30 + r.nextDouble() * 0.15);
		double shift = lean == 1 ? 2.2 : lean == 2 ? -2.2 : 0.0;
		b.add(new float[] {(float) (-bw - 1.6), -3.0f, (float) (bw + 1.6), -3.0f, (float) (tw + shift + 0.9), (float) height,
				(float) (-tw + shift - 0.9), (float) height}, OmenShapes.S_AURA, 0.9f, false, 0);
		b.add(new float[] {(float) -bw, -3.0f, (float) bw, -3.0f, (float) (tw + shift), (float) height, (float) (-tw + shift), (float) height},
				OmenShapes.S_DEEP, 0.99f, false, 0);
		// Çok ince, soluk bir kenar parıltısı: hacim hissi (ışık bir yönden gelir)
		double e0 = 0.84;
		b.add(new float[] {(float) (bw * e0), -3.0f, (float) bw, -3.0f, (float) (tw + shift), (float) (height * 0.94),
				(float) (tw * e0 + shift), (float) (height * 0.94)}, OmenShapes.S_MID, 0.5f, false, 0);
		addHaze(b, bw * 2.3, 26.0);
	}

	/**
	 * Ufuk sisi: tabandan yukarı doğru azalan, üst üste biner saydam bantlar. Taban en yoğun sisle örtülür, tepeye doğru açılır
	 * (atmosferik perspektif). Renk istemcide gün zamanına göre belirlenir ({@link #S_HAZE}).
	 */
	private static void addHaze(Builder b, double halfWidth, double height) {
		int bands = 6;
		for (int k = 0; k < bands; k++) {
			double y = height * (1.0 - k / (double) bands);
			double w = halfWidth * (1.0 + 0.25 * k / bands);
			b.add(new float[] {(float) -w, -3.0f, (float) w, -3.0f, (float) w, (float) y, (float) -w, (float) y}, OmenShapes.S_HAZE, 0.14f, false, 0);
		}
	}

	/** Göz: boyut ({@code sizeIdx}: 0 küçük .. 3 çok büyük), çevresinde atmosfer dalgalanması, karanlığın kısmen yuttuğu varyasyonlar. */
	private static void eyeComposed(Builder b, int shape, int sizeIdx, boolean shroud, boolean mostlyHidden) {
		SplittableRandom r = b.rnd;
		double[] sizes = {0.75, 1.0, 1.35, 1.8};
		double scale = sizes[Math.max(0, Math.min(3, sizeIdx))];
		int from = b.polys.size();
		int gFrom = b.glints.size();
		eye(b, shape);
		// Gözün çevresindeki atmosferik alan hafifçe bozulur: seyrek, ince, eşmerkezli dalgalar.
		for (int k = 0; k < 3; k++) {
			double rad = 15.0 + k * 6.5;
			b.add(annulus(0.0, 0.0, rad, rad * 0.62, 0.55, (r.nextDouble() - 0.5) * 16.0, 40), OmenShapes.S_AURA, 0.42f - 0.1f * k, false, 0);
		}
		b.xform(from, gFrom, 0.0, scale, 0.0, 0.0);
		if (shroud || mostlyHidden) {
			// Karanlığın içinde kısmen kaybolma: gözün bir yanını koyu bir kütle yutar.
			double side = r.nextBoolean() ? 1.0 : -1.0;
			double cover = mostlyHidden ? 0.55 : 0.30;
			b.add(blob(side * 9.0 * scale * (1.0 - cover), -2.0 * scale, 16.0 * scale, 0.28, 30, r), OmenShapes.S_VOID, mostlyHidden ? 0.92f : 0.7f, false, 0);
			b.add(blob(side * 18.0 * scale * (1.0 - cover), 5.0 * scale, 10.0 * scale, 0.3, 24, r), OmenShapes.S_VOID, 0.6f, false, 0);
		}
	}

	// ==================================================================
	// Geometri yardımcıları
	// ==================================================================

	/** Düzensiz, kapalı bir kütle (karanlık bulutu, leke). {@code noise}: yarıçapın oransal dalgalanması. */
	static float[] blob(double cx, double cy, double radius, double noise, int n, SplittableRandom r) {
		float[] out = new float[n * 2];
		double phase1 = r.nextDouble() * 6.28;
		double phase2 = r.nextDouble() * 6.28;
		for (int i = 0; i < n; i++) {
			double a = 2.0 * Math.PI * i / n;
			double wobble = 1.0 + noise * (0.6 * Math.sin(a * 3.0 + phase1) + 0.4 * Math.sin(a * 5.0 + phase2) + 0.25 * (r.nextDouble() - 0.5));
			out[i * 2] = (float) (cx + Math.cos(a) * radius * wobble);
			out[i * 2 + 1] = (float) (cy + Math.sin(a) * radius * wobble);
		}
		return out;
	}

	/** İnce, tırtıklı çatlak: kenardan içeri doğru rastgele yürüyen bir çizgi, kalın bir çokgen olarak. */
	static float[] crack(double x0, double y0, double angle, double length, double width, SplittableRandom r) {
		int steps = 7;
		double[] px = new double[steps + 1];
		double[] py = new double[steps + 1];
		px[0] = x0;
		py[0] = y0;
		double a = angle;
		double seg = length / steps;
		for (int i = 1; i <= steps; i++) {
			a += (r.nextDouble() - 0.5) * 0.9;
			px[i] = px[i - 1] + Math.cos(a) * seg;
			py[i] = py[i - 1] + Math.sin(a) * seg;
		}
		float[] out = new float[(steps + 1) * 4];
		for (int i = 0; i <= steps; i++) {
			int prev = Math.max(0, i - 1);
			int next = Math.min(steps, i + 1);
			double tx = px[next] - px[prev];
			double ty = py[next] - py[prev];
			double len = Math.max(1.0E-6, Math.hypot(tx, ty));
			double nx = -ty / len;
			double ny = tx / len;
			double w = width * (1.0 - 0.8 * i / steps) * 0.5; // uca doğru incelir
			out[i * 2] = (float) (px[i] + nx * w);
			out[i * 2 + 1] = (float) (py[i] + ny * w);
			out[(2 * (steps + 1) - 1 - i) * 2] = (float) (px[i] - nx * w);
			out[(2 * (steps + 1) - 1 - i) * 2 + 1] = (float) (py[i] - ny * w);
		}
		return out;
	}

	/** Elips halkanın {@code t0..t1} (parametrik, radyan) aralığındaki kesiti. Halkanın kendisiyle aynı parametrizasyonu kullanır. */
	private static float[] annulusSector(double cx, double cy, double rx, double ry, double thick, double rotDeg, double t0, double t1, int steps) {
		double rot = Math.toRadians(rotDeg);
		double cr = Math.cos(rot);
		double sr = Math.sin(rot);
		float[] out = new float[(steps + 1) * 4];
		for (int i = 0; i <= steps; i++) {
			double t = t0 + (t1 - t0) * i / steps;
			double ox = (rx + thick) * Math.cos(t);
			double oy = (ry + thick) * Math.sin(t);
			double ix = rx * Math.cos(t);
			double iy = ry * Math.sin(t);
			out[i * 2] = (float) (cx + ox * cr - oy * sr);
			out[i * 2 + 1] = (float) (cy + ox * sr + oy * cr);
			int j = 2 * (steps + 1) - 1 - i;
			out[j * 2] = (float) (cx + ix * cr - iy * sr);
			out[j * 2 + 1] = (float) (cy + ix * sr + iy * cr);
		}
		return out;
	}

	/**
	 * İki elips halkanın (orta çizgi yarıçapı {@code r + thick/2}) kesiştiği, {@code a} halkasındaki parametrik açılar (en çok 4).
	 * Örnekleyerek işaret değişimini arar; gerçek kesişim yoksa boş döner.
	 */
	private static double[] crossings(double[] a, double[] c) {
		int samples = 240;
		double[] hits = new double[4];
		int found = 0;
		double prevF = ringImplicit(a, c, 0.0);
		for (int i = 1; i <= samples && found < 4; i++) {
			double t = 2.0 * Math.PI * i / samples;
			double f = ringImplicit(a, c, t);
			if ((prevF < 0.0) != (f < 0.0)) {
				double t0 = 2.0 * Math.PI * (i - 1) / samples;
				double w = Math.abs(prevF) / Math.max(1.0E-12, Math.abs(prevF) + Math.abs(f));
				hits[found++] = t0 + (t - t0) * w;
			}
			prevF = f;
		}
		return java.util.Arrays.copyOf(hits, found);
	}

	/** {@code a} halkasının {@code t} noktasının {@code c} halkasının örtük denklemindeki değeri (içte < 0, dışta > 0). */
	private static double ringImplicit(double[] a, double[] c, double t) {
		double rotA = Math.toRadians(a[4]);
		double ex = (a[2] + a[5] / 2.0) * Math.cos(t);
		double ey = (a[3] + a[5] / 2.0) * Math.sin(t);
		double px = a[0] + ex * Math.cos(rotA) - ey * Math.sin(rotA);
		double py = a[1] + ex * Math.sin(rotA) + ey * Math.cos(rotA);
		double rotC = Math.toRadians(c[4]);
		double dx = px - c[0];
		double dy = py - c[1];
		double u = dx * Math.cos(rotC) + dy * Math.sin(rotC);
		double v = -dx * Math.sin(rotC) + dy * Math.cos(rotC);
		double rx = c[2] + c[5] / 2.0;
		double ry = c[3] + c[5] / 2.0;
		return (u / rx) * (u / rx) + (v / ry) * (v / ry) - 1.0;
	}

	/**
	 * Hilal: {@code r} yarıçaplı diskten, merkezi {@code d} uzaklıkta ve {@code phi} yönünde olan {@code rb} yarıçaplı diskin çıkarılmış hâli.
	 * İki daire kesişmezse tam disk döner. Kenarlar analitik (iki dairenin kesişim noktaları) hesaplanır; eğriler örneklenir.
	 */
	private static float[] crescent(double r, double rb, double d, double phi) {
		if (d <= 1.0E-6 || d >= r + rb || d <= Math.abs(r - rb)) {
			return ellipse(0.0, 0.0, r, r, 0.0, 48);
		}
		double cx = Math.cos(phi) * d;
		double cy = Math.sin(phi) * d;
		double beta = Math.acos(clamp((r * r - rb * rb + d * d) / (2.0 * d * r), -1.0, 1.0));
		int m = 22;
		double a0 = phi + beta;
		double a1 = phi + 2.0 * Math.PI - beta;
		float[] outer = new float[(m + 1) * 2];
		for (int i = 0; i <= m; i++) {
			double t = a0 + (a1 - a0) * i / m;
			outer[i * 2] = (float) (r * Math.cos(t));
			outer[i * 2 + 1] = (float) (r * Math.sin(t));
		}
		// B dairesinin A'nın içinde kalan yayı: son kesişim noktasından ilk kesişim noktasına
		double psi1 = Math.atan2(r * Math.sin(a1) - cy, r * Math.cos(a1) - cx);
		double psi2 = Math.atan2(r * Math.sin(a0) - cy, r * Math.cos(a0) - cx);
		double sweep = psi2 - psi1;
		while (sweep < 0.0) {
			sweep += 2.0 * Math.PI;
		}
		double midX = cx + rb * Math.cos(psi1 + sweep / 2.0);
		double midY = cy + rb * Math.sin(psi1 + sweep / 2.0);
		if (Math.hypot(midX, midY) >= r) {
			sweep -= 2.0 * Math.PI; // ters yönde dolaş: ortası A'nın içinde kalan yay
		}
		float[] out = new float[(2 * (m + 1)) * 2];
		System.arraycopy(outer, 0, out, 0, outer.length);
		for (int i = 0; i <= m; i++) {
			double t = psi1 + sweep * i / m;
			out[(m + 1 + i) * 2] = (float) (cx + rb * Math.cos(t));
			out[(m + 1 + i) * 2 + 1] = (float) (cy + rb * Math.sin(t));
		}
		return out;
	}

	private static double clamp(double v, double lo, double hi) {
		return Math.max(lo, Math.min(hi, v));
	}

	private static float[] ellipse(double cx, double cy, double rx, double ry, double rotDeg, int n) {
		float[] out = new float[n * 2];
		double rot = Math.toRadians(rotDeg);
		double cr = Math.cos(rot);
		double sr = Math.sin(rot);
		for (int i = 0; i < n; i++) {
			double a = 2.0 * Math.PI * i / n;
			double ex = rx * Math.cos(a);
			double ey = ry * Math.sin(a);
			out[i * 2] = (float) (cx + ex * cr - ey * sr);
			out[i * 2 + 1] = (float) (cy + ex * sr + ey * cr);
		}
		return out;
	}

	/** Dış ve iç yay arasında ince bir hilal. Açılar derece. */
	private static float[] arc(double cx, double cy, double rOuter, double rInner, double a0, double a1, int steps) {
		float[] out = new float[(steps + 1) * 4];
		for (int i = 0; i <= steps; i++) {
			double a = Math.toRadians(a0 + (a1 - a0) * i / steps);
			out[i * 2] = (float) (cx + rOuter * Math.cos(a));
			out[i * 2 + 1] = (float) (cy + rOuter * Math.sin(a));
			out[(2 * (steps + 1) - 1 - i) * 2] = (float) (cx + rInner * Math.cos(a));
			out[(2 * (steps + 1) - 1 - i) * 2 + 1] = (float) (cy + rInner * Math.sin(a));
		}
		return out;
	}

	private static float[] diamond(double cx, double cy, double r) {
		return new float[] {(float) cx, (float) (cy + r), (float) (cx + r), (float) cy, (float) cx, (float) (cy - r), (float) (cx - r), (float) cy};
	}

	/** Delikli halka (tek çokgen; köprü kenarları çift-tek dolgusunda birbirini götürür). */
	private static float[] annulus(double cx, double cy, double rx, double ry, double thick, double rotDeg, int n) {
		float[] outer = ellipse(cx, cy, rx + thick, ry + thick, rotDeg, n);
		float[] inner = ellipse(cx, cy, rx, ry, rotDeg, n);
		float[] out = new float[(2 * n + 3) * 2];
		int p = 0;
		for (int i = 0; i < n; i++) {
			out[p++] = outer[i * 2];
			out[p++] = outer[i * 2 + 1];
		}
		out[p++] = outer[0];
		out[p++] = outer[1];
		out[p++] = inner[0];
		out[p++] = inner[1];
		for (int i = n - 1; i >= 1; i--) {
			out[p++] = inner[i * 2];
			out[p++] = inner[i * 2 + 1];
		}
		out[p++] = inner[0];
		out[p++] = inner[1];
		return out;
	}

	/** Kaburga: omurgadan dışa çıkıp aşağı kıvrılan sivri kemik (side = +1 sağ, -1 sol). */
	private static float[] rib(double y, double len, int side) {
		double s = side;
		return new float[] {
				(float) (s * 1.1), (float) (y + 0.6), (float) (s * (len * 0.55 + 1.1)), (float) (y + 1.1),
				(float) (s * (len + 1.1)), (float) (y - 3.4), (float) (s * (len * 0.6 + 1.1)), (float) (y - 0.9),
				(float) (s * 1.1), (float) (y - 0.6)};
	}

	/** Bloklu baş: iki yanı düz, çenesi ve tepesi çentikli. Merkez (0,0). */
	private static float[] headBlock(double w, double h) {
		double hw = w / 2.0;
		double hh = h / 2.0;
		return new float[] {
				(float) -hw, (float) -hh, (float) -hw, (float) hh, (float) (-hw * 0.5), (float) (hh + 1.3), (float) 0.0, (float) hh,
				(float) (hw * 0.5), (float) (hh + 1.5), (float) hw, (float) hh, (float) hw, (float) -hh, (float) (hw * 0.5), (float) (-hh - 0.4),
				(float) (-hw * 0.5), (float) (-hh - 0.4)};
	}

	/** Eklemli uzuv: başlangıçtan, açılar (aşağıdan derece) ve uzunluklarla çizilen incelen şerit. */
	private static float[] limb(double x0, double y0, double[] angles, double[] lengths, double w0, double w1) {
		int segs = angles.length;
		double[] px = new double[segs + 1];
		double[] py = new double[segs + 1];
		px[0] = x0;
		py[0] = y0;
		double dirDeg = 0.0;
		for (int i = 0; i < segs; i++) {
			dirDeg += angles[i];
			double a = Math.toRadians(dirDeg);
			// 0 derece = aşağı; pozitif açı sağa döner.
			px[i + 1] = px[i] + Math.sin(a) * lengths[i];
			py[i + 1] = py[i] - Math.cos(a) * lengths[i];
		}
		float[] out = new float[(segs + 1) * 4];
		for (int i = 0; i <= segs; i++) {
			int a = Math.max(0, i - 1);
			int c = Math.min(segs, i + 1);
			double dx = px[c] - px[a];
			double dy = py[c] - py[a];
			double len = Math.max(1e-6, Math.hypot(dx, dy));
			double w = w0 + (w1 - w0) * i / (double) segs;
			double nx = -dy / len * w;
			double ny = dx / len * w;
			out[i * 2] = (float) (px[i] + nx);
			out[i * 2 + 1] = (float) (py[i] + ny);
			out[(2 * (segs + 1) - 1 - i) * 2] = (float) (px[i] - nx);
			out[(2 * (segs + 1) - 1 - i) * 2 + 1] = (float) (py[i] - ny);
		}
		return out;
	}

	private static float[] rotate(float[] xy, double tx, double ty, double deg) {
		return rotate(xy, tx, ty, deg, 0.0, 0.0, 0.0);
	}

	/**
	 * Köşeleri önce (px, py) çevresinde {@code pivotDeg} döndürür, sonra {@code deg} kadar orijin çevresinde
	 * döndürüp (tx, ty) kadar öteler. Kısa biçim: yalnızca orijin çevresinde döndür + ötele.
	 */
	private static float[] rotate(float[] xy, double tx, double ty, double deg, double px, double py, double pivotDeg) {
		float[] out = new float[xy.length];
		double pr = Math.toRadians(pivotDeg);
		double cp = Math.cos(pr);
		double sp = Math.sin(pr);
		double r = Math.toRadians(deg);
		double c = Math.cos(r);
		double s = Math.sin(r);
		for (int i = 0; i < xy.length; i += 2) {
			double x = xy[i] - px;
			double y = xy[i + 1] - py;
			double x1 = px + x * cp - y * sp;
			double y1 = py + x * sp + y * cp;
			out[i] = (float) (x1 * c - y1 * s + tx);
			out[i + 1] = (float) (x1 * s + y1 * c + ty);
		}
		return out;
	}

	// ==================================================================
	// İnşa aracı
	// ==================================================================

	private static final class Builder {
		final SplittableRandom rnd;
		final List<Poly> polys = new ArrayList<>();
		final List<float[]> glints = new ArrayList<>();

		Builder(SplittableRandom rnd) {
			this.rnd = rnd;
		}

		void add(float[] xy, int style, float alpha, boolean outline, int group) {
			int n = xy.length / 2;
			float[] x = new float[n];
			float[] y = new float[n];
			for (int i = 0; i < n; i++) {
				x[i] = xy[i * 2];
				y[i] = xy[i * 2 + 1];
			}
			polys.add(new Poly(x, y, style, alpha, outline, group));
		}

		void glint(float x, float y) {
			glints.add(new float[] {x, y, (float) (rnd.nextDouble() * 6.28)});
		}

		/** {@code from} dizininden sonraki çokgen ve kıvılcımları döndürür, ölçekler, öteler. */
		void xform(int from, int gFrom, double deg, double scale, double tx, double ty) {
			double r = Math.toRadians(deg);
			double c = Math.cos(r) * scale;
			double s = Math.sin(r) * scale;
			for (int i = from; i < polys.size(); i++) {
				Poly p = polys.get(i);
				float[] x = new float[p.x().length];
				float[] y = new float[p.y().length];
				for (int k = 0; k < x.length; k++) {
					x[k] = (float) (p.x()[k] * c - p.y()[k] * s + tx);
					y[k] = (float) (p.x()[k] * s + p.y()[k] * c + ty);
				}
				polys.set(i, new Poly(x, y, p.style(), p.alpha(), p.outline(), p.group()));
			}
			for (int i = gFrom; i < glints.size(); i++) {
				float[] g = glints.get(i);
				glints.set(i, new float[] {(float) (g[0] * c - g[1] * s + tx), (float) (g[0] * s + g[1] * c + ty), g[2]});
			}
		}

		Scene finish() {
			double hw = 1.0;
			double hh = 1.0;
			for (Poly p : polys) {
				if (p.style() == S_AURA) {
					continue;
				}
				for (int i = 0; i < p.x().length; i++) {
					hw = Math.max(hw, Math.abs(p.x()[i]));
					hh = Math.max(hh, Math.abs(p.y()[i]));
				}
			}
			float[] g = new float[glints.size() * 3];
			for (int i = 0; i < glints.size(); i++) {
				System.arraycopy(glints.get(i), 0, g, i * 3, 3);
			}
			return new Scene(polys.toArray(new Poly[0]), g, (float) hw, (float) hh);
		}
	}
}
