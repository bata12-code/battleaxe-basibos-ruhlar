package com.battleaxe.call;

/**
 * Baltanın Çağrısı - Öncü Belirtiler ve Kozmik Anomaliler: atmosferik tezahürler. Hiçbiri varlık, blok ya da yapı değildir;
 * yalnızca ilgili oyuncunun istemcisinde çizilen görüntülerdir (ya da, {@link #ALL_WATCHING} için, çok kısa süreli bir
 * davranış anomalisidir). Kimlikler pakette ve kayıtlı "görüldü" maskesinde kullanılır: sırayı DEĞİŞTİRME, yalnızca sona ekle.
 *
 * <p>Kimlik 0-3: baltayı edinmeden önceki ESKİ Öncü Belirtiler (baltanın edinilmesiyle kalıcı susar). Kimlik 4 ve sonrası:
 * Kozmik Anomaliler; baltayı edinmiş oyuncularda da sürer (dünya, balta elde olsa da susmaz).
 */
public enum OmenKind {
	/** Gece gökyüzünde beliren devasa balta silueti; fark edilirse "YILDIZI BUL!". */
	SKY_AXE(0, OmenCategory.CELESTIAL, true),
	/** Gökyüzünün bir köşesinden bakan yabancı, devasa göz. */
	WATCHER_EYE(1, OmenCategory.OBSERVER, true),
	/** Ufkun ardında duran, ölçeği anlaşılamayan dev siluet. */
	HORIZON_COLOSSUS(2, OmenCategory.HORIZON, true),
	/** Ufukta/gökte görünen, olmaması gereken imkânsız mimari. */
	IMPOSSIBLE_STRUCTURE(3, OmenCategory.REALITY, true),
	/** Gökyüzünde olağanüstü büyüklükte, açıklanamayan ikinci bir karanlık gök cismi. */
	SECOND_MOON(4, OmenCategory.CELESTIAL, true),
	/** Gökyüzünde birbirinin içinden geçen, geometrisi anlaşılamayan devasa halkalar. */
	IMPOSSIBLE_RINGS(5, OmenCategory.REALITY, true),
	/** Ufukta, gündüz ya da gece, hiç yaklaşılamayan imkânsız uzunlukta siyah yekpare yapı. */
	MONOLITH(6, OmenCategory.HORIZON, true),
	/** Çevredeki bütün canlıların bir anda oyuncuya yönelip durması (yalnızca sunucuda; görüntü paketi yoktur). */
	ALL_WATCHING(7, OmenCategory.OBSERVER, false),
	/** Bir gün boyunca süren, güneşin parçalanmış göründüğü dünya çapında gökyüzü anomalisi (günlük, kayıtsız; çizelgeyle seçilmez). */
	FRACTURED_SUN(8, OmenCategory.WORLD, true);

	public static final int COUNT = 9;
	/** Eski Öncü Belirtiler: kimlik 0-3 (baltayı edinince susar). */
	public static final int LEGACY_COUNT = 4;

	private final int id;
	private final OmenCategory category;
	private final boolean visual;

	OmenKind(int id, OmenCategory category, boolean visual) {
		this.id = id;
		this.category = category;
		this.visual = visual;
	}

	public int id() {
		return id;
	}

	public int bit() {
		return 1 << id;
	}

	public OmenCategory category() {
		return category;
	}

	/** İstemcide çizilen bir görüntü mü? (false: yalnızca sunucu davranışı.) */
	public boolean visual() {
		return visual;
	}

	/** Eski dört Öncü Belirti'den biri mi? Balta edinilince bunlar kalıcı susar; yenileri susmaz. */
	public boolean legacy() {
		return id < LEGACY_COUNT;
	}

	/** Çizelgeyle (arm/launch) seçilen bir tür mü? Parçalanmış Güneş günlük ve deterministiktir, çizelgeye girmez. */
	public boolean scheduled() {
		return this != FRACTURED_SUN;
	}

	/** Büyük (uzun süreli, ekrana hükmeden) olay mı? Küçük olaylar büyük bir olayla birlikte gerçekleşebilir. */
	public boolean major() {
		return this != ALL_WATCHING && this != FRACTURED_SUN;
	}

	/** Eski dört türün kimlik maskesi. */
	public static final int LEGACY_MASK = 0b1111;

	/** Kimlikten tür; geçersiz kimlik için {@code null}. */
	public static OmenKind byId(int id) {
		for (OmenKind kind : values()) {
			if (kind.id == id) {
				return kind;
			}
		}
		return null;
	}
}
