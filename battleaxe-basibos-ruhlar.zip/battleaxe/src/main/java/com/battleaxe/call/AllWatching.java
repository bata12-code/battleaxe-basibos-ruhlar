package com.battleaxe.call;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/**
 * <b>Bütün Canlılar Sana Bakıyor</b> (Gözlemci Anomalisi; mantık {@link AllWatchingLogic}'te): oyuncunun çevresindeki uygun moblar,
 * kendi küçük gecikmeleriyle mevcut davranışlarını bırakır, oyuncuya doğru döner ve birkaç saniye bakar; ekranın altında
 * "Ensende bir soğukluk hissediyorsun." belirir; olay bitince hepsi normal davranışına döner. Savaş başlatmaz, hasar vermez.
 *
 * <h3>Güvenlik</h3>
 * <ul>
 *   <li>Yalnızca {@code minecraft:} mobları; boss, mod mobları ve başka bir sistem tarafından donmuş ({@code isNoAi}) moblar atlanır.</li>
 *   <li>Binek/yolcu ve zaten bir olaydaki moblara dokunulmaz.</li>
 *   <li>Dondurma {@code setNoAi} ile yapılır ve mob KALICI etiketle işaretlenir; sunucu kapanır, oyuncu çıkar/ölür, boyut değişir ya da
 *       chunk yüklenirken olay sürmüyorsa etiketli mob otomatik serbest bırakılır (Execution'daki kalıpla aynı onarım).</li>
 *   <li>Olay oyuncu başınadır: yalnızca o oyuncunun çevresini etkiler ve yalnızca ona mesaj gider.</li>
 * </ul>
 */
public final class AllWatching {
	private AllWatching() {
	}

	private static final class Watcher {
		final UUID id;
		final int delay;
		final int jitter;
		boolean frozen;
		boolean finished;

		Watcher(UUID id, int delay, int jitter) {
			this.id = id;
			this.delay = delay;
			this.jitter = jitter;
		}
	}

	private static final class Event {
		final UUID player;
		final ServerLevel level;
		final long startTick;
		final int duration;
		final List<Watcher> watchers;
		boolean messaged;

		Event(UUID player, ServerLevel level, long startTick, int duration, List<Watcher> watchers) {
			this.player = player;
			this.level = level;
			this.startTick = startTick;
			this.duration = duration;
			this.watchers = watchers;
		}
	}

	/** Oyuncu -> etkin olay (oyuncu başına en çok bir). */
	private static final Map<UUID, Event> EVENTS = new HashMap<>();
	/** Şu an bir olaya katılan moblar (aynı mob iki olayda olmasın; yükleme onarımı bunları atlar). */
	private static final Set<UUID> WATCHED = new HashSet<>();

	public static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(AllWatching::tick);

		// Çökme/yüklenme sonrası takılı kalmış (dondurulmuş) mobları onar: etiket silinirse mob dondurulmuş kaydedilmişti.
		ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
			if (entity instanceof Mob mob && !WATCHED.contains(mob.getUUID()) && mob.removeTag(AllWatchingLogic.TAG)) {
				mob.setNoAi(false);
			}
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> abortOf(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> releaseAll());
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			EVENTS.clear();
			WATCHED.clear();
		});
	}

	/**
	 * Oyuncunun çevresinde olayı başlatır. Yeterince uygun canlı yoksa ya da oyuncunun zaten bir olayı varsa false döner ve hiçbir şey değişmez.
	 * Çağıran, başarısızlıkta hiçbir şey tüketmemelidir.
	 */
	public static boolean start(ServerLevel level, ServerPlayer player) {
		if (EVENTS.containsKey(player.getUUID())) {
			return false;
		}
		List<Mob> mobs = candidates(level, player);
		if (!AllWatchingLogic.enoughMobs(mobs.size())) {
			return false;
		}
		mobs.sort(Comparator.comparingDouble(mob -> mob.distanceToSqr(player)));
		if (mobs.size() > OmenConfig.ALL_WATCHING_MAX_MOBS) {
			mobs = mobs.subList(0, OmenConfig.ALL_WATCHING_MAX_MOBS);
		}

		ThreadLocalRandom random = ThreadLocalRandom.current();
		List<Watcher> watchers = new ArrayList<>(mobs.size());
		for (Mob mob : mobs) {
			watchers.add(new Watcher(mob.getUUID(), AllWatchingLogic.startDelay(random.nextDouble()),
					AllWatchingLogic.releaseJitter(random.nextDouble())));
			WATCHED.add(mob.getUUID());
		}
		int duration = OmenConfig.ALL_WATCHING_MIN_TICKS
				+ random.nextInt(Math.max(1, OmenConfig.ALL_WATCHING_MAX_TICKS - OmenConfig.ALL_WATCHING_MIN_TICKS + 1));
		EVENTS.put(player.getUUID(), new Event(player.getUUID(), level, level.getGameTime(), duration, watchers));
		return true;
	}

	/** Etrafta olayı anlamlı kılacak kadar uygun canlı var mı? (Kurulumdan önce ucuz bir ön denetim; hiçbir şeyi değiştirmez.) */
	public static boolean hasAudience(ServerLevel level, ServerPlayer player) {
		return !EVENTS.containsKey(player.getUUID()) && AllWatchingLogic.enoughMobs(candidates(level, player).size());
	}

	private static List<Mob> candidates(ServerLevel level, ServerPlayer player) {
		double radius = OmenConfig.ALL_WATCHING_RADIUS;
		double radiusSqr = radius * radius;
		return new ArrayList<>(level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(radius), mob -> eligible(mob, player, radiusSqr)));
	}

	/** Bu moba dokunabilir miyiz? Boss/mod mobu, binek, başka sistem tarafından dondurulmuş ya da zaten olaydaki moblar atlanır. */
	private static boolean eligible(Mob mob, ServerPlayer player, double radiusSqr) {
		if (!mob.isAlive() || mob.isRemoved() || mob.isNoAi() || mob.isPassenger() || mob.isVehicle() || WATCHED.contains(mob.getUUID())
				|| mob.distanceToSqr(player) > radiusSqr) {
			return false;
		}
		var key = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
		return key != null && AllWatchingLogic.eligibleType(key.toString());
	}

	private static void tick(MinecraftServer server) {
		if (EVENTS.isEmpty()) {
			return;
		}
		for (Event event : new ArrayList<>(EVENTS.values())) {
			ServerPlayer player = server.getPlayerList().getPlayer(event.player);
			if (player == null || !player.isAlive() || player.level() != event.level) {
				end(event);
				continue;
			}
			int elapsed = (int) (event.level.getGameTime() - event.startTick);
			boolean pending = false;
			for (Watcher watcher : event.watchers) {
				if (watcher.finished) {
					continue;
				}
				Entity entity = event.level.getEntity(watcher.id);
				if (!(entity instanceof Mob mob) || !mob.isAlive()) {
					finish(watcher); // öldü ya da yüklenmedi: dokunacak bir şey kalmadı
					continue;
				}
				switch (AllWatchingLogic.phase(elapsed, watcher.delay, event.duration, watcher.jitter)) {
					case WAIT -> pending = true;
					case WATCH -> {
						pending = true;
						watch(mob, watcher, player);
					}
					case DONE -> {
						release(mob);
						finish(watcher);
					}
				}
			}
			if (AllWatchingLogic.messageDue(elapsed, event.messaged)) {
				event.messaged = true;
				player.sendSystemMessage(Component.translatable("message.battleaxe.anomaly.all_watching"), true);
			}
			if (!pending) {
				end(event);
			}
		}
	}

	/** Mobu (ilk kez ise) dondurur ve kendi hızıyla oyuncuya doğru çevirir. */
	private static void watch(Mob mob, Watcher watcher, ServerPlayer player) {
		if (!watcher.frozen) {
			if (mob.isNoAi()) {
				finish(watcher); // bu arada başka bir sistem dondurdu (örn. bir bitirici): karışma
				return;
			}
			mob.setNoAi(true);
			mob.addTag(AllWatchingLogic.TAG);
			watcher.frozen = true;
		}
		double dx = player.getX() - mob.getX();
		double dz = player.getZ() - mob.getZ();
		double dy = player.getEyeY() - mob.getEyeY();
		float step = OmenConfig.ALL_WATCHING_TURN_STEP_DEGREES;
		float yaw = AllWatchingLogic.turnToward(mob.getYRot(), AllWatchingLogic.yawTo(dx, dz), step);
		mob.setYRot(yaw);
		mob.setYHeadRot(AllWatchingLogic.turnToward(mob.getYHeadRot(), AllWatchingLogic.yawTo(dx, dz), step * 1.5F));
		mob.setXRot(AllWatchingLogic.turnToward(mob.getXRot(), AllWatchingLogic.pitchTo(dy, Math.hypot(dx, dz)), step));
	}

	/** Mobu bırakır: yapay zekâ geri gelir, etiket silinir. Yalnızca BİZİM dondurduğumuz moblar için çağrılır. */
	private static void release(Mob mob) {
		if (mob.removeTag(AllWatchingLogic.TAG)) {
			mob.setNoAi(false);
		}
	}

	private static void finish(Watcher watcher) {
		watcher.finished = true;
		WATCHED.remove(watcher.id);
	}

	private static void end(Event event) {
		for (Watcher watcher : event.watchers) {
			if (!watcher.finished) {
				if (watcher.frozen && event.level.getEntity(watcher.id) instanceof Mob mob) {
					release(mob);
				}
				finish(watcher);
			}
		}
		EVENTS.remove(event.player);
	}

	private static void abortOf(UUID playerId) {
		Event event = EVENTS.get(playerId);
		if (event != null) {
			end(event);
		}
	}

	/** Sunucu kapanırken bütün olaylar serbest bırakılır (moblar dondurulmuş kaydedilmesin). */
	private static void releaseAll() {
		for (Event event : new ArrayList<>(EVENTS.values())) {
			end(event);
		}
	}

	/** Bu oyuncunun etkin bir olayı var mı? (Çizelge aynı anda ikinci olayı başlatmasın.) */
	public static boolean active(UUID playerId) {
		return EVENTS.containsKey(playerId);
	}
}
