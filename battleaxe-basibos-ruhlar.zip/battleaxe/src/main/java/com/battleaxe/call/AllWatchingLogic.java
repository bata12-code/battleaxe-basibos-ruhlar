package com.battleaxe.call;

import java.util.Set;

/**
 * <b>Bütün Canlılar Sana Bakıyor</b>'un SAF mantığı (Minecraft'a bağımlı değildir; test: tools/test/AnomalyLogicTest.java).
 *
 * <p>Akış: çevredeki uygun moblar, her biri KENDİ kısa gecikmesiyle (kusursuz senkron değil) mevcut davranışını bırakır, oyuncuya
 * doğru yavaşça döner ve bir süre öylece bakar; olay bitince her biri küçük bir farkla serbest kalır ve normal davranışına döner.
 * Hiçbir şey saldırmaz, hasar vermez; olay bir savaş başlatmaz. Boss ve mod mobları hiç etkilenmez.
 */
public final class AllWatchingLogic {
	private AllWatchingLogic() {
	}

	/** Dondurulmuş mobu kalıcı kayıtta işaretler: çökme/yüklenme sonrası onarım için (Execution'daki kalıpla aynı). */
	public static final String TAG = "battleaxe_all_watching";

	/** Serbest kalma gecikmesinin üst sınırı (tick): her mob farklı anda normale döner. */
	public static final int RELEASE_JITTER_TICKS = 14;

	/** Bir mobun şu anki aşaması. */
	public enum Phase {
		/** Henüz sırası gelmedi: normal davranışını sürdürür. */
		WAIT,
		/** Dondurulmuş, oyuncuya bakıyor. */
		WATCH,
		/** Olay bitti: serbest. */
		DONE
	}

	/**
	 * Etkilenmeyecek türler (boss ve özel davranışlı). Kimlik "minecraft:" ile başlamıyorsa (mod mobları, Kara Körük dâhil)
	 * tür HİÇ uygun değildir: davranışları bozulabilir.
	 */
	private static final Set<String> EXCLUDED = Set.of(
			"minecraft:ender_dragon", "minecraft:wither", "minecraft:warden", "minecraft:elder_guardian", "minecraft:creaking",
			"minecraft:player", "minecraft:armor_stand", "minecraft:iron_golem", "minecraft:snow_golem", "minecraft:wandering_trader");

	/** Bu kayıt kimliğindeki mob olaya katılabilir mi? */
	public static boolean eligibleType(String id) {
		return id != null && id.startsWith("minecraft:") && id.length() > "minecraft:".length() && !EXCLUDED.contains(id);
	}

	/** Olay yalnızca yeterince çok canlı varsa anlamlıdır. */
	public static boolean enoughMobs(int eligibleCount) {
		return eligibleCount >= OmenConfig.ALL_WATCHING_MIN_MOBS;
	}

	/** Bir mobun dönmeye başlama gecikmesi (0..STAGGER-1 tick); {@code roll}: 0-1 rastgele. */
	public static int startDelay(double roll) {
		double clamped = Double.isNaN(roll) ? 0.0 : Math.max(0.0, Math.min(0.999999, roll));
		return (int) (clamped * OmenConfig.ALL_WATCHING_STAGGER_TICKS);
	}

	/** Serbest kalma farkı (0..RELEASE_JITTER_TICKS-1). */
	public static int releaseJitter(double roll) {
		double clamped = Double.isNaN(roll) ? 0.0 : Math.max(0.0, Math.min(0.999999, roll));
		return (int) (clamped * RELEASE_JITTER_TICKS);
	}

	/** Mobun aşaması: {@code elapsed}: olayın başlangıcından beri tick. */
	public static Phase phase(int elapsed, int startDelay, int duration, int releaseJitter) {
		if (elapsed < startDelay) {
			return Phase.WAIT;
		}
		return elapsed < duration + Math.max(0, releaseJitter) ? Phase.WATCH : Phase.DONE;
	}

	/** Mesaj bir kez, moblar dönmeye başladıktan sonra gösterilir. */
	public static boolean messageDue(int elapsed, boolean alreadySent) {
		return !alreadySent && elapsed >= OmenConfig.ALL_WATCHING_MESSAGE_DELAY_TICKS;
	}

	/** Açıyı (-180, 180] aralığına sarar. */
	public static float wrapDegrees(float degrees) {
		if (Float.isNaN(degrees) || Float.isInfinite(degrees)) {
			return 0.0F;
		}
		float d = degrees % 360.0F;
		if (d > 180.0F) {
			d -= 360.0F;
		} else if (d <= -180.0F) {
			d += 360.0F;
		}
		return d;
	}

	/** {@code current} açısını {@code target}'e EN KISA yoldan, tick başına en çok {@code maxStep} derece döndürür. */
	public static float turnToward(float current, float target, float maxStep) {
		float delta = wrapDegrees(target - current);
		float step = Math.max(0.0F, maxStep);
		return current + Math.max(-step, Math.min(step, delta));
	}

	/** Minecraft yatay bakış açısı (derece): +Z yönü 0, +X yönü -90. */
	public static float yawTo(double dx, double dz) {
		return (float) Math.toDegrees(Math.atan2(-dx, dz));
	}

	/** Minecraft dikey bakış açısı (derece): yukarı negatiftir. {@code dy}: hedef - kendi göz yüksekliği. */
	public static float pitchTo(double dy, double horizontalDistance) {
		return (float) -Math.toDegrees(Math.atan2(dy, Math.max(1.0E-6, horizontalDistance)));
	}
}
