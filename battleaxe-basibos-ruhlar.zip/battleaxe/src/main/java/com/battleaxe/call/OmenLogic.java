package com.battleaxe.call;

import java.util.random.RandomGenerator;

/**
 * Öncü belirtilerin SAF karar mantığı: uygunluk, olay seçimi, bekleme/çakışma denetimi, yerleşim ve parametreler.
 * Minecraft'a bağımlı değildir (test: tools/test/OmenLogicTest.java). Sunucu yöneticisi ({@link OmenManager}) yalnızca
 * dünya durumunu okuyup buraya sayı olarak verir.
 *
 * <p><b>Gizli ağırlıklandırma:</b> anlatı sırası zorunlu değildir (oyuncu olayları herhangi bir sırayla görebilir,
 * bazılarını hiç görmeyebilir); yalnızca eğilim vardır: yeni oyuncuya önce ÖLÇEK (ufuk, yapı), ilerledikçe ÇAĞRI
 * (gökteki balta), çağrıyı gördükten sonra İZLENME (göz) daha olasıdır. Görülmemiş bir tür 2 kat ağırlık alır.
 */
public final class OmenLogic {
	private OmenLogic() {
	}

	// ------------------------------------------------------------------
	// Gökyüzü tonu
	// ------------------------------------------------------------------

	public static final int TONE_UNKNOWN = -1;
	public static final int TONE_NIGHT = 0;
	public static final int TONE_TWILIGHT = 1;
	public static final int TONE_DAY = 2;

	/** Gün zamanından ton: gece / alacakaranlık / gündüz. */
	public static int toneOf(long dayTime) {
		long t = Math.floorMod(dayTime, 24000L);
		if (t >= 13800L && t <= 22200L) {
			return TONE_NIGHT;
		}
		if ((t >= 12000L && t < 13800L) || (t > 22200L && t < 23800L)) {
			return TONE_TWILIGHT;
		}
		return TONE_DAY;
	}

	// ------------------------------------------------------------------
	// Uygunluk
	// ------------------------------------------------------------------

	/** Sunucunun dünyadan okuduğu özet. {@code travelBlocks}: son kurulumdan beri yürünen yatay mesafe. */
	public record Env(boolean overworld, boolean canSeeSky, boolean precipitating, int tone, double travelBlocks) {
	}

	/** Ayar anahtarı açık mı? */
	public static boolean enabled(OmenKind kind) {
		return OmenConfig.ENABLED && switch (kind) {
			case SKY_AXE -> OmenConfig.SKY_AXE_ENABLED;
			case WATCHER_EYE -> OmenConfig.WATCHER_EYE_ENABLED;
			case HORIZON_COLOSSUS -> OmenConfig.HORIZON_COLOSSUS_ENABLED;
			case IMPOSSIBLE_STRUCTURE -> OmenConfig.IMPOSSIBLE_STRUCTURE_ENABLED;
			case SECOND_MOON -> OmenConfig.ANOMALIES_ENABLED && OmenConfig.SECOND_MOON_ENABLED;
			case IMPOSSIBLE_RINGS -> OmenConfig.ANOMALIES_ENABLED && OmenConfig.IMPOSSIBLE_RINGS_ENABLED;
			case MONOLITH -> OmenConfig.ANOMALIES_ENABLED && OmenConfig.MONOLITH_ENABLED;
			case ALL_WATCHING -> OmenConfig.ANOMALIES_ENABLED && OmenConfig.ALL_WATCHING_ENABLED;
			case FRACTURED_SUN -> OmenConfig.ANOMALIES_ENABLED && OmenConfig.FRACTURED_SUN_ENABLED;
		};
	}

	/**
	 * Bu ortamda gösterilebilecek türlerin bit maskesi.
	 * <ul>
	 *   <li>Gökteki Balta ve Göz: yalnızca Overworld'de, açık gökyüzünün altında, yağmursuz ve KESİN gece.</li>
	 *   <li>Ufuktaki Dev ve Yapı: açık gökyüzü ve yağmursuzluk; gece, alacakaranlık ve gündüz (gündüz daha silik çizilir);
	 *       gün zamanı okunamıyorsa da çıkabilir. Oyuncu yeterince yol yürümüş ("keşfediyor") olmalı.</li>
	 * </ul>
	 */
	public static int eligibleMask(Env env) {
		if (env == null || !env.overworld() || !env.canSeeSky() || env.precipitating()) {
			return 0;
		}
		int mask = 0;
		if (env.tone() == TONE_NIGHT) {
			if (enabled(OmenKind.SKY_AXE)) {
				mask |= OmenKind.SKY_AXE.bit();
			}
			if (enabled(OmenKind.WATCHER_EYE)) {
				mask |= OmenKind.WATCHER_EYE.bit();
			}
		}
		if (enabled(OmenKind.HORIZON_COLOSSUS) && env.travelBlocks() >= OmenConfig.COLOSSUS_MIN_TRAVEL_BLOCKS) {
			mask |= OmenKind.HORIZON_COLOSSUS.bit();
		}
		if (enabled(OmenKind.IMPOSSIBLE_STRUCTURE) && env.travelBlocks() >= OmenConfig.STRUCTURE_MIN_TRAVEL_BLOCKS) {
			mask |= OmenKind.IMPOSSIBLE_STRUCTURE.bit();
		}
		return mask;
	}

		/**
	 * Yeni Kozmik Anomalilerden (kimlik 4+) bu ortamda UYGUN olanların maskesi. {@link #eligibleMask} yalnızca eski dört belirtiyi
	 * kapsar (anlamı değişmedi); çizelge ikisini birleştirir (balta öncesi) ya da yalnızca bunu kullanır (balta sonrası).
	 * <ul>
	 *   <li>İkinci Ay: gece, açık gökyüzü, yağış yok.</li>
	 *   <li>İmkânsız Halkalar: gece ya da alacakaranlık, açık gökyüzü, yağış yok.</li>
	 *   <li>Monolith: gece ya da gündüz (gündüz özellikle), açık gökyüzü, yağış yok.</li>
	 *   <li>Bütün Canlılar Sana Bakıyor: ana dünya (gökyüzü ve gün zamanı önemli değil; mağarada da olur).</li>
	 * </ul>
	 * Parçalanmış Güneş çizelgeyle seçilmez (günlük, deterministiktir; bkz. {@link SunAnomalyLogic}).
	 */
	public static int anomalyMask(Env env) {
		if (env == null || !env.overworld()) {
			return 0;
		}
		int mask = 0;
		if (enabled(OmenKind.ALL_WATCHING)) {
			mask |= OmenKind.ALL_WATCHING.bit();
		}
		if (!env.canSeeSky() || env.precipitating()) {
			return mask;
		}
		boolean night = env.tone() == TONE_NIGHT;
		boolean dusk = env.tone() == TONE_TWILIGHT;
		if (night && enabled(OmenKind.SECOND_MOON)) {
			mask |= OmenKind.SECOND_MOON.bit();
		}
		if ((night || dusk) && enabled(OmenKind.IMPOSSIBLE_RINGS)) {
			mask |= OmenKind.IMPOSSIBLE_RINGS.bit();
		}
		if (enabled(OmenKind.MONOLITH)) {
			mask |= OmenKind.MONOLITH.bit();
		}
		return mask;
	}

	/** Bu türün oturum içi bekleme süresi (tick); bekleme tanımsız türler için 0. */
	public static long kindCooldown(OmenKind kind) {
		return switch (kind) {
			case SECOND_MOON -> OmenConfig.SECOND_MOON_COOLDOWN_TICKS;
			case IMPOSSIBLE_RINGS -> OmenConfig.IMPOSSIBLE_RINGS_COOLDOWN_TICKS;
			case MONOLITH -> OmenConfig.MONOLITH_COOLDOWN_TICKS;
			case ALL_WATCHING -> OmenConfig.ALL_WATCHING_COOLDOWN_TICKS;
			default -> 0L;
		};
	}

	/** Bu tür, son gösterimden bu yana yeterince beklediyse hazırdır. {@code lastShown <= 0} = hiç gösterilmedi. */
	public static boolean kindReady(OmenKind kind, long lastShown, long now) {
		long cooldown = kindCooldown(kind);
		return cooldown <= 0L || lastShown <= 0L || now < lastShown || now - lastShown >= cooldown;
	}

/**
	 * Yeni bir olay KURULABİLİR mi? (Ucuz, dünya sorgusu yapmayan koşullar.) Hepsi sağlanmalı: giriş sessizliği,
	 * dünya yaşı, oturum sınırı, olaylar arası bekleme, diğer çağrı olaylarıyla bekleme, etkin olay yokluğu, hasar sonrası sessizlik.
	 * {@code last*} değerleri 0 = "hiç olmadı".
	 */
	public static boolean mayArm(long now, long sessionStart, long worldAge, int omensThisSession, long lastOmen,
			long lastCallEvent, long busyUntil, long lastDamage) {
		return now - sessionStart >= OmenConfig.INITIAL_QUIET_TICKS
				&& worldAge >= OmenConfig.MIN_WORLD_AGE_TICKS
				&& omensThisSession < OmenConfig.PER_SESSION
				&& now >= busyUntil
				&& CallLogic.ready(now, lastOmen, OmenConfig.MIN_GAP_TICKS)
				&& CallLogic.ready(now, lastCallEvent, OmenConfig.GLOBAL_GAP_TICKS)
				&& CallLogic.ready(now, lastDamage, OmenConfig.QUIET_AFTER_DAMAGE_TICKS);
	}

	/**
	 * Bir denetimde olay kurulma olasılığı: taban x (1 + ilerleme payı) x "uzun süredir görmedi" payı. Üst sınırı vardır;
	 * hiçbir zaman 1'i aşmaz (test kipi hariç taban zaten çok küçüktür).
	 *
	 * @param ticksSinceLast son büyük olaydan beri geçen süre (hiç olmadıysa oturum süresi verilir)
	 */
	public static double chance(int progress, long ticksSinceLast) {
		int p = Math.max(0, Math.min(4, progress));
		double pity = 1.0 + (OmenConfig.PITY_MAX_MULTIPLIER - 1.0) * Math.max(0.0, Math.min(1.0, ticksSinceLast / (double) OmenConfig.PITY_FULL_TICKS));
		return Math.min(1.0, OmenConfig.BASE_CHANCE * (1.0 + OmenConfig.CHANCE_PER_PROGRESS * p) * pity);
	}

	/**
	 * Gökyüzü tonunun kurulma olasılığına çarpanı: geceler daha olaylı (en ikonik iki olay yalnızca geceleri mümkün),
	 * gündüz ve bilinmeyen zaman daha sakin.
	 */
	public static double toneChanceMultiplier(int tone) {
		return switch (tone) {
			case TONE_NIGHT -> 1.8;
			case TONE_TWILIGHT -> 1.0;
			default -> 0.7;
		};
	}

	// ------------------------------------------------------------------
	// Seçim
	// ------------------------------------------------------------------

	/** Bir türün ağırlığı (0 = seçilemez). */
	public static double weight(OmenKind kind, int progress, int seenMask) {
		int p = Math.max(0, Math.min(4, progress));
		double w = switch (kind) {
			case HORIZON_COLOSSUS -> 3.0;
			case IMPOSSIBLE_STRUCTURE -> 2.0;
			case SKY_AXE -> 3.0 + 1.0 * p;
			case WATCHER_EYE -> 1.0 + 0.6 * p + ((seenMask & OmenKind.SKY_AXE.bit()) != 0 ? 1.5 : 0.0);
			// Kozmik Anomaliler: farklı sıklıklar. Monolith ve Bütün Canlılar biraz erişilebilir; İkinci Ay ve Halkalar nadir.
			case MONOLITH -> 2.6;
			case ALL_WATCHING -> 2.0;
			case SECOND_MOON -> 1.4;
			case IMPOSSIBLE_RINGS -> 1.1;
			case FRACTURED_SUN -> 0.0; // çizelgeyle seçilmez
		};
		if ((seenMask & kind.bit()) == 0) {
			w *= 2.0;
		}
		return w;
	}

		/**
	 * <b>Gökyüzünün Hafızası</b>: bazı anomaliler aynı gizemli kaynağa aitmiş gibi birbirini hafifçe çağırır. En son görülen tür
	 * {@code lastKindId} ise {@code kind}'in ağırlığı bu çarpanla büyür (ya da 1.0 kalır). ZORUNLU zincir DEĞİLDİR: yalnızca ihtimali artırır.
	 * Örn. İkinci Ay'dan sonra Halkalar ve Göz, Monolith'ten sonra İkinci Ay biraz daha olasıdır.
	 */
	public static double memoryBoost(int lastKindId, OmenKind kind) {
		OmenKind last = OmenKind.byId(lastKindId);
		if (last == null || last == kind) {
			return 1.0;
		}
		return switch (last) {
			case SECOND_MOON -> kind == OmenKind.IMPOSSIBLE_RINGS ? 2.2 : kind == OmenKind.WATCHER_EYE ? 1.8 : 1.0;
			case IMPOSSIBLE_RINGS -> kind == OmenKind.WATCHER_EYE ? 2.0 : kind == OmenKind.SECOND_MOON ? 1.5 : 1.0;
			case MONOLITH -> kind == OmenKind.SECOND_MOON ? 1.6 : kind == OmenKind.HORIZON_COLOSSUS ? 1.5 : 1.0;
			case HORIZON_COLOSSUS -> kind == OmenKind.MONOLITH ? 1.6 : 1.0;
			case WATCHER_EYE -> kind == OmenKind.ALL_WATCHING ? 1.7 : 1.0;
			default -> 1.0;
		};
	}

/**
	 * Uygun türler arasından ağırlıklı birini seçer. {@code lastKindId} (en son gösterilen) seçilmez: aynı olay art arda
	 * gelmez. Uygun tür yoksa {@code null} (SESSİZLİK).
	 */
	public static OmenKind choose(RandomGenerator random, int eligibleMask, int progress, int seenMask, int lastKindId) {
		double total = 0.0;
		double[] weights = new double[OmenKind.COUNT];
		for (OmenKind kind : OmenKind.values()) {
			if ((eligibleMask & kind.bit()) != 0 && kind.id() != lastKindId) {
				weights[kind.id()] = weight(kind, progress, seenMask) * memoryBoost(lastKindId, kind);
				total += weights[kind.id()];
			}
		}
		if (total <= 0.0) {
			return null;
		}
		double roll = random.nextDouble() * total;
		for (OmenKind kind : OmenKind.values()) {
			roll -= weights[kind.id()];
			if (weights[kind.id()] > 0.0 && roll < 0.0) {
				return kind;
			}
		}
		// Kayan nokta artığı: son uygun türü ver.
		for (int i = OmenKind.COUNT - 1; i >= 0; i--) {
			if (weights[i] > 0.0) {
				return OmenKind.byId(i);
			}
		}
		return null;
	}

	// ------------------------------------------------------------------
	// Süre, varyant, yerleşim
	// ------------------------------------------------------------------

	/** Toplam görünme süresi (tick). Rastgelelik tür kimliğini bozmayacak aralıktadır. */
	public static int duration(RandomGenerator random, OmenKind kind) {
		int min;
		int max;
		switch (kind) {
			case SKY_AXE -> {
				min = OmenConfig.SKY_AXE_MIN_TICKS;
				max = OmenConfig.SKY_AXE_MAX_TICKS;
			}
			case WATCHER_EYE -> {
				min = OmenConfig.EYE_MIN_TICKS;
				max = OmenConfig.EYE_MAX_TICKS;
			}
			case HORIZON_COLOSSUS -> {
				min = OmenConfig.COLOSSUS_MIN_TICKS;
				max = OmenConfig.COLOSSUS_MAX_TICKS;
			}
			case SECOND_MOON -> {
				min = OmenConfig.SECOND_MOON_MIN_TICKS;
				max = OmenConfig.SECOND_MOON_MAX_TICKS;
			}
			case IMPOSSIBLE_RINGS -> {
				min = OmenConfig.RINGS_MIN_TICKS;
				max = OmenConfig.RINGS_MAX_TICKS;
			}
			case MONOLITH -> {
				min = OmenConfig.MONOLITH_MIN_TICKS;
				max = OmenConfig.MONOLITH_MAX_TICKS;
			}
			case ALL_WATCHING -> {
				min = OmenConfig.ALL_WATCHING_MIN_TICKS;
				max = OmenConfig.ALL_WATCHING_MAX_TICKS;
			}
			default -> {
				min = OmenConfig.STRUCTURE_MIN_TICKS;
				max = OmenConfig.STRUCTURE_MAX_TICKS;
			}
		}
		return min + random.nextInt(max - min + 1);
	}

	// Varyant düzeni: bit 0-7 türe özgü, bit 8-9 örtü düzeyi (0-3), bit 10 örtü üstten mi.
	public static final int VARIANT_COVER_SHIFT = 8;
	public static final int VARIANT_COVER_TOP = 1 << 10;
	public static final int VARIANT_MASK = 0x7FF;

	public static int coverLevel(int variant) {
		return (variant >> VARIANT_COVER_SHIFT) & 3;
	}

	public static boolean coverFromTop(int variant) {
		return (variant & VARIANT_COVER_TOP) != 0;
	}

	/** Türe özgü alt bitler ({@link #VARIANT_COVER_SHIFT} altı). */
	public static int lowBits(int variant) {
		return variant & 0xFF;
	}

	/**
	 * Varyantı üretir (görünüm/kaybolma biçimi). Düzen:
	 * <ul>
	 *   <li>SKY_AXE: bit0-1 kaybolma (0 sönme, 1 kararsız, 2 batma), bit2 eğim yönü.</li>
	 *   <li>WATCHER_EYE: bit0 şekil (0 badem, 1 mercek), bit1 "bakış kaçınca kaybolur".</li>
	 *   <li>HORIZON_COLOSSUS: bit0-1 şekil (0 üç başlı, 1 balta, 2 yüzsüz), bit2-3 kaybolma (0 sönme, 1 batma, 2 bakış kaçınca), bit4 hafif titreme.</li>
	 *   <li>IMPOSSIBLE_STRUCTURE: bit0-1 şekil (0 kemerler, 1 sütunlar, 2 halkalar, 3 anıt), bit2-3 kaybolma (0 sönme, 1 perspektif bozulması, 2 karanlığa batma).</li>
	 * </ul>
	 */
	public static int makeVariant(RandomGenerator random, OmenKind kind) {
		int low;
		int cover = 0;
		boolean top = false;
		switch (kind) {
			case SKY_AXE -> {
				low = random.nextInt(3) | (random.nextBoolean() ? 4 : 0);
				cover = random.nextDouble() < 0.35 ? 1 + random.nextInt(2) : 0;
				top = random.nextBoolean();
			}
			case WATCHER_EYE -> {
				// bit 0: biçim; bit 1: bakış kaçınca kaybolur; bit 2-3: boyut (0 küçük .. 3 çok büyük); bit 4: karanlık bir yanını yutar;
				// bit 5: büyük kısmı karanlıkta (yalnızca bir bölümü görünür). Boyut çoğu zaman normal, bazen çok büyüktür.
				double sz = random.nextDouble();
				int sizeIdx = sz < 0.20 ? 0 : sz < 0.60 ? 1 : sz < 0.88 ? 2 : 3;
				low = random.nextInt(2) | (random.nextDouble() < 0.40 ? 2 : 0) | (sizeIdx << 2)
						| (random.nextDouble() < 0.25 ? 16 : 0) | (random.nextDouble() < 0.10 ? 32 : 0);
				cover = random.nextDouble() < 0.55 ? 1 + random.nextInt(3) : 0;
				top = random.nextBoolean();
			}
			case HORIZON_COLOSSUS -> {
				double s = random.nextDouble();
				int shape = s < 0.40 ? 0 : s < 0.65 ? 1 : 2;
				// bit 4: tek seferlik alçak titreme (FLAG_TREMOR); bit 5: yalnızca başları ufkun üstünde görünür (gövde arazinin arkasında)
				low = shape | (random.nextInt(3) << 2) | (random.nextDouble() < 0.40 ? 16 : 0) | (random.nextDouble() < 0.22 ? 32 : 0);
			}
			case SECOND_MOON -> {
				// bit 0-1: görünüm (0 simsiyah, 1 çatlaklı, 2 yalnızca bir bölümü, 3 kızıl kenarlı); bit 2-3: boyut (0-2);
				// bit 4: çevresinde "yıldızsız boşluk"; bit 5-6: kayboluş (0 solma, 1 karanlığa gömülme, 2 ufka batma)
				low = random.nextInt(4) | (random.nextInt(3) << 2) | (random.nextDouble() < 0.65 ? 16 : 0) | (random.nextInt(3) << 5);
			}
			case IMPOSSIBLE_RINGS -> {
				// bit 0-1: hareket (0 hareketsiz, 1 yavaş sağa, 2 yavaş sola, 3 hareketsiz); bit 2: bir göz de belirir ("Hafıza");
				// bit 3-4: halka sayısı - 3 (0-2 -> 3..5 değil: 0 -> 3, 1 -> 4); bit 5-6: kayboluş
				low = random.nextInt(4) | (random.nextDouble() < 0.22 ? 4 : 0) | (random.nextInt(2) << 3) | (random.nextInt(3) << 5);
			}
			case MONOLITH -> {
				// bit 0-1: eğim (0 dik, 1 sağa, 2 sola, 3 dik); bit 2-3: sönüş biçimi (0 solma, 1 perspektif bozulması, 2 sisin içinde silinme);
				// bit 4: gökyüzünü hafifçe karartır
				low = random.nextInt(4) | (random.nextInt(3) << 2) | (random.nextDouble() < 0.5 ? 16 : 0);
			}
			case ALL_WATCHING, FRACTURED_SUN -> low = 0;
			default -> low = random.nextInt(4) | (random.nextInt(3) << 2);
		}
		return low | (cover << VARIANT_COVER_SHIFT) | (top ? VARIANT_COVER_TOP : 0);
	}

	/** Oyuncu bu türü başlatmak için uygun yöne bakıyor mu? (pitch: Minecraft kuralı, pozitif = aşağı.) */
	/**
	 * Ufuk tezahürlerinin taban yüksekliği (derece). Düz bir ovada gerçek ufuk çizgisi göz hizasından yaklaşık -0.5 derece aşağıdadır;
	 * tabanın tam orada bitmesi, figürün "ufukta durduğu" hissini verir (eskiden -2 idi: taban yakın zemin üzerine biniyordu).
	 */
	public static final double COLOSSUS_BASE_ELEVATION = -0.6;
	public static final double MONOLITH_BASE_ELEVATION = -0.6;

	/** İkinci Ay, ayın yerine göre gökyüzünün alçağında da doğabilir: bakışın biraz yukarıda olması yeter. */
	public static final double SECOND_MOON_LOOK_MIN_UP_DEGREES = 8.0;

	public static boolean lookAllows(OmenKind kind, double pitchDeg) {
		return switch (kind) {
			case SKY_AXE, WATCHER_EYE -> -pitchDeg >= OmenConfig.SKY_LOOK_MIN_UP_DEGREES;
			case HORIZON_COLOSSUS, IMPOSSIBLE_STRUCTURE, MONOLITH ->
					pitchDeg >= OmenConfig.HORIZON_LOOK_MIN_PITCH && pitchDeg <= OmenConfig.HORIZON_LOOK_MAX_PITCH;
			case SECOND_MOON -> -pitchDeg >= SECOND_MOON_LOOK_MIN_UP_DEGREES;
			case IMPOSSIBLE_RINGS -> -pitchDeg >= OmenConfig.SKY_LOOK_MIN_UP_DEGREES;
			case ALL_WATCHING, FRACTURED_SUN -> true;
		};
	}

	/** Gökteki yön: yön açısı ve ufuktan yükseklik (derece). */
	public record Placement(double azimuth, double elevation) {
	}

	/**
	 * Oyuncunun bakışına göre yerleşim: tezahür oyuncunun görüş alanına yakın doğar ("bakarken belirir"). Gökyüzü
	 * olayları aya (biliniyorsa; {@code moonDir}) en az {@link OmenConfig#MOON_CLEARANCE_DEGREES} uzak tutulur.
	 *
	 * @param yawDeg   oyuncunun yaw'ı; @param pitchDeg pitch'i (pozitif = aşağı)
	 * @param moonDir  ayın birim yönü (gece, görünürken) ya da {@code null}
	 */
	public static Placement place(RandomGenerator random, OmenKind kind, double yawDeg, double pitchDeg, double[] moonDir) {
		double up = Math.max(0.0, -pitchDeg);
		for (int attempt = 0; attempt < 10; attempt++) {
			double az;
			double el;
			switch (kind) {
				case SKY_AXE -> {
					az = yawDeg + uniform(random, -40.0, 40.0);
					el = clamp(up + uniform(random, -6.0, 10.0), 32.0, 66.0);
				}
				case WATCHER_EYE -> {
					az = yawDeg + uniform(random, -55.0, 55.0);
					el = clamp(up + uniform(random, -4.0, 8.0), 26.0, 54.0);
				}
				case HORIZON_COLOSSUS -> {
					az = yawDeg + uniform(random, -45.0, 45.0);
					el = COLOSSUS_BASE_ELEVATION;
				}
				case SECOND_MOON -> {
					// %40: gerçek ayın yakınında (ona kıyasla çok daha büyük, onu gölgede bırakır); aksi halde gökyüzünün başka bir yerinde.
					if (moonDir != null && random.nextDouble() < 0.40) {
						double moonAz = Math.toDegrees(Math.atan2(-moonDir[0], moonDir[2]));
						double moonEl = Math.toDegrees(Math.asin(clamp(moonDir[1], -1.0, 1.0)));
						az = moonAz + uniform(random, 16.0, 30.0) * (random.nextBoolean() ? 1.0 : -1.0);
						el = clamp(moonEl + uniform(random, -8.0, 12.0), 18.0, 62.0);
					} else {
						az = yawDeg + uniform(random, -60.0, 60.0);
						el = clamp(up + uniform(random, -4.0, 14.0), 20.0, 58.0);
					}
				}
				case IMPOSSIBLE_RINGS -> {
					az = yawDeg + uniform(random, -50.0, 50.0);
					el = clamp(up + uniform(random, -4.0, 12.0), 30.0, 62.0);
				}
				case MONOLITH -> {
					az = yawDeg + uniform(random, -55.0, 55.0);
					el = MONOLITH_BASE_ELEVATION;
				}
				case ALL_WATCHING, FRACTURED_SUN -> {
					az = yawDeg;
					el = 0.0;
				}
				default -> {
					az = yawDeg + uniform(random, -50.0, 50.0);
					el = uniform(random, -2.0, 9.0);
				}
			}
			boolean sky = kind == OmenKind.SKY_AXE || kind == OmenKind.WATCHER_EYE || kind == OmenKind.IMPOSSIBLE_RINGS;
			if (!sky || moonDir == null
					|| OmenGeometry.angleDegrees(OmenGeometry.direction(az, el), moonDir) >= OmenConfig.MOON_CLEARANCE_DEGREES) {
				return new Placement(az, el);
			}
		}
		// Ay yönünün ters tarafı: ay ne kadar yüksekte olursa olsun balta/göz ayın yakınına binmez.
		double moonAz = moonDir == null ? yawDeg : Math.toDegrees(Math.atan2(-moonDir[0], moonDir[2]));
		return new Placement(moonAz + 180.0 + uniform(random, -25.0, 25.0), kind == OmenKind.SKY_AXE ? 48.0 : 38.0);
	}

	// ------------------------------------------------------------------
	// "YILDIZI BUL!" mesajı
	// ------------------------------------------------------------------

	/**
	 * Balta tezahürüyle birlikte "YILDIZI BUL!" gösterilsin mi? Mesaj Nether Yıldızı'na bir çağrıdır: oyuncunun zaten
	 * yıldızı varsa (ilerleme 4) hiç gösterilmez. İlk balta tezahüründe kesin; sonrakilerde seyrek ve uzun aralıkla.
	 */
	public static boolean starMessage(RandomGenerator random, int progress, int seenMask, long now, long lastStarMessage) {
		if (progress >= 4) {
			return false;
		}
		if ((seenMask & OmenKind.SKY_AXE.bit()) == 0) {
			return true;
		}
		return CallLogic.ready(now, lastStarMessage, OmenConfig.STAR_MESSAGE_MIN_GAP_TICKS)
				&& random.nextDouble() < OmenConfig.STAR_MESSAGE_REPEAT_CHANCE;
	}

	// ------------------------------------------------------------------
	// Paket sıkıştırma ve zarf
	// ------------------------------------------------------------------

	public static final int FLAG_MESSAGE = 1;
	public static final int FLAG_TREMOR = 2;

	/** variant (11 bit) | ton+1 (2 bit) << 11 | bayraklar << 13. */
	public static int pack(int variant, int tone, int flags) {
		return (variant & VARIANT_MASK) | (((tone + 1) & 3) << 11) | ((flags & 0xFF) << 13);
	}

	public static int unpackVariant(int packed) {
		return packed & VARIANT_MASK;
	}

	public static int unpackTone(int packed) {
		return ((packed >> 11) & 3) - 1;
	}

	public static int unpackFlags(int packed) {
		return (packed >> 13) & 0xFF;
	}

	/** 0..1 yumuşak adım. */
	public static double smooth(double v) {
		double c = Math.max(0.0, Math.min(1.0, v));
		return c * c * (3.0 - 2.0 * c);
	}

	/** Belirme ve kaybolma zarfı (0..1): yumuşak girer, yumuşak çıkar. Süreler tick (ya da aynı birim). */
	public static double envelope(double elapsed, double total, double fadeIn, double fadeOut) {
		return smooth(elapsed / Math.max(1e-6, fadeIn)) * smooth((total - elapsed) / Math.max(1e-6, fadeOut));
	}

	private static double uniform(RandomGenerator random, double lo, double hi) {
		return lo + random.nextDouble() * (hi - lo);
	}

	private static double clamp(double v, double lo, double hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
