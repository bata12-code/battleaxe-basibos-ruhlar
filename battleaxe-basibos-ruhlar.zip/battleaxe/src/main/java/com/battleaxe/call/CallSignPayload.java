package com.battleaxe.call;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan YALNIZCA ilgili oyuncunun kendi istemcisine: "ayın önünden geçen balta silüetini çiz".
 * Yalnızca görseldir; oyun durumunu değiştirmez. Gök açısı sunucudan gelir, böylece istemci gün-zamanı
 * API'sine ihtiyaç duymaz ve iki taraf aynı ay konumunda buluşur.
 *
 * @param kind      işaret türü ({@link #KIND_MOON_AXE})
 * @param celestial gök açısı (0..1) başlangıç anında; istemci süre boyunca ayın yavaş kaymasını kendisi ekler
 * @param ticks     silüetin toplam süresi
 * @param intensity 0..2: ilerledikçe silüet biraz daha belirgin
 */
public record CallSignPayload(int kind, float celestial, int ticks, int intensity) implements CustomPacketPayload {
	public static final int KIND_MOON_AXE = 0;

	public static final CustomPacketPayload.Type<CallSignPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("call_sign"));

	public static final StreamCodec<RegistryFriendlyByteBuf, CallSignPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, CallSignPayload::kind,
			ByteBufCodecs.FLOAT, CallSignPayload::celestial,
			ByteBufCodecs.VAR_INT, CallSignPayload::ticks,
			ByteBufCodecs.VAR_INT, CallSignPayload::intensity,
			CallSignPayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
