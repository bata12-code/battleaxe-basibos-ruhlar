package com.battleaxe.call;

import java.lang.reflect.Method;
import java.util.OptionalLong;

import net.minecraft.world.level.Level;

import com.battleaxe.BattleAxeMod;

/**
 * Gün zamanı ve hava durumunu okuyan TEK yer.
 *
 * <p>Minecraft 26.x "dünya saatleri" getirdi ve bu okumaların yöntem adları sürümler arasında değişebiliyor.
 * Burada bu iki okuma, derleme zamanında bir yöntem adına bağlanmak yerine çalışma anında adaylar sırayla
 * denenerek yapılır (26.x'te Minecraft'ın sınıf/yöntem adları çalışma anında da Mojang adlarıdır). Hiçbir aday
 * bulunmazsa YALNIZCA ay işareti ve "gece" bağlamı sessizce devre dışı kalır (bir kez günlüğe yazılır);
 * oyun, mesajlar ve diğer işaretler etkilenmez. Sonuç önbelleğe alınır.
 */
final class SkyProbe {
	private SkyProbe() {
	}

	private static final String[] DAY_TIME_CANDIDATES = {"getDayTime", "getDefaultClockTime", "getOverworldClockTime"};

	private static Method dayTimeMethod;
	private static boolean dayTimeResolved;
	private static Method rainMethod;
	private static Method thunderMethod;
	private static boolean weatherResolved;

	/** Overworld'ün gün zamanı (tick); okunamazsa boş. */
	static OptionalLong dayTime(Level level) {
		if (!dayTimeResolved) {
			dayTimeResolved = true;
			for (String name : DAY_TIME_CANDIDATES) {
				Method method = find(level, name, long.class, Long.class);
				if (method != null) {
					dayTimeMethod = method;
					break;
				}
			}
			if (dayTimeMethod == null) {
				BattleAxeMod.LOGGER.warn("Baltanın Çağrısı: gün zamanı okunamadı; ay işareti ve gece bağlamı devre dışı.");
			}
		}
		if (dayTimeMethod == null) {
			return OptionalLong.empty();
		}
		try {
			Object value = dayTimeMethod.invoke(level);
			return value instanceof Number number ? OptionalLong.of(number.longValue()) : OptionalLong.empty();
		} catch (ReflectiveOperationException | RuntimeException e) {
			dayTimeMethod = null;
			BattleAxeMod.LOGGER.warn("Baltanın Çağrısı: gün zamanı okunurken hata; ay işareti devre dışı.", e);
			return OptionalLong.empty();
		}
	}

	/** Yağmur ya da fırtına var mı? Okunamazsa {@code false} (ay işareti yine de ay-bakışı koşuluna bağlıdır). */
	static boolean precipitating(Level level) {
		if (!weatherResolved) {
			weatherResolved = true;
			rainMethod = find(level, "isRaining", boolean.class, Boolean.class);
			thunderMethod = find(level, "isThundering", boolean.class, Boolean.class);
		}
		return invokeBoolean(rainMethod, level) || invokeBoolean(thunderMethod, level);
	}

	private static boolean invokeBoolean(Method method, Level level) {
		if (method == null) {
			return false;
		}
		try {
			return Boolean.TRUE.equals(method.invoke(level));
		} catch (ReflectiveOperationException | RuntimeException e) {
			return false;
		}
	}

	private static Method find(Level level, String name, Class<?> primitive, Class<?> boxed) {
		try {
			Method method = level.getClass().getMethod(name);
			Class<?> type = method.getReturnType();
			if (type == primitive || type == boxed) {
				return method;
			}
		} catch (NoSuchMethodException | SecurityException ignored) {
			// Bu aday yok; sıradakine bakılır.
		}
		return null;
	}
}
