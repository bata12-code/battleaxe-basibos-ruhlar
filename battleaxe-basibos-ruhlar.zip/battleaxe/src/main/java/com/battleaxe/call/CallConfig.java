package com.battleaxe.call;

/**
 * "Baltanın Çağrısı" ayarları. Oyuncu baltayı edinmeden ÖNCE onu hissettiren seyrek mesaj ve işaretlerin
 * sıklığı, bekleme süreleri ve sınırları buradadır (mod, ayarlarını Java sabitlerinde tutar; yeni bir
 * yapılandırma sistemi eklenmedi). Süreler tick'tir: 20 tick = 1 sn, 1200 tick = 1 dk.
 *
 * <p>Sistem hiçbir zaman zorunlu değildir: hiçbir tarifi, eşyayı, ilerlemeyi ya da boss'u kilitlemez/değiştirmez.
 */
public final class CallConfig {
	private CallConfig() {
	}

	/** false yaparsan Baltanın Çağrısı (mesaj, ay silueti, demir sesi) tamamen kapanır. Sunucu tarafı. */
	public static final boolean ENABLED = true;

	/** Alt ayarlar: tek tek kapatılabilir. */
	public static final boolean MESSAGES_ENABLED = true;
	public static final boolean MOON_SIGN_ENABLED = true;
	public static final boolean FORGE_SIGN_ENABLED = true;

	// ------------------------------------------------------------------
	// Genel denetim ritmi (pahalı iş yapılmaz: oyuncu başına nadiren çalışır)
	// ------------------------------------------------------------------

	/** Mesaj / ilerleme / demir sesi denetimi aralığı (10 sn). Oyuncular kimliklerine göre dağıtılır. */
	public static final int CHECK_INTERVAL_TICKS = 200;
	/** Ay bakışı denetimi aralığı (1 sn). Yalnızca gece, açık gökyüzü ve bekleme süresi dolmuşken çalışır. */
	public static final int GAZE_INTERVAL_TICKS = 20;

	// ------------------------------------------------------------------
	// Sessizlik: sistemin en önemli parçası
	// ------------------------------------------------------------------

	/** Oyuna girdikten sonra bu süre boyunca hiçbir şey olmaz (5 dk). */
	public static final long INITIAL_QUIET_TICKS = 6000L;
	/** Herhangi iki çağrı olayı (mesaj/işaret) arasındaki en kısa süre (1 dk): olaylar üst üste binmez. */
	public static final long GLOBAL_EVENT_GAP_TICKS = 1200L;
	/** Oyuncu hasar yediği/uyuduğu sırada olay üretilmez; hasar sonrası bu kadar tick beklenir. */
	public static final int QUIET_AFTER_HURT_TICKS = 100;

	// ------------------------------------------------------------------
	// Fısıltı / Tanınma mesajları
	// ------------------------------------------------------------------

	/** İki mesaj arasındaki en kısa süre (15 dk). */
	public static final long MESSAGE_MIN_GAP_TICKS = 18000L;
	/** Bir oyun oturumunda (giriş-çıkış) en çok kaç mesaj. */
	public static final int MESSAGES_PER_SESSION = 3;
	/** Her denetimde mesaj olasılığı: taban + ilerleme düzeyi başına artış. */
	public static final double MESSAGE_CHANCE_BASE = 0.025;
	public static final double MESSAGE_CHANCE_PER_PROGRESS = 0.010;
	/** Tüm uygun mesajlar gösterildiyse tekrar için gereken en kısa süre (3 saat). */
	public static final long MESSAGE_REPEAT_GAP_TICKS = 216000L;
	/** Tanınma (ilerlemeye bağlı) mesajlarının seçilme payı: ilerleme düzeyi başına artar, üst sınırı vardır. */
	public static final double RECOGNITION_SHARE_PER_PROGRESS = 0.25;
	public static final double RECOGNITION_SHARE_MAX = 0.80;
	/** Bir dönüm noktası (ilk Nether, Wither, Nether Yıldızı) mesajının gecikmesi: taban + rastgele ek. */
	public static final int MILESTONE_DELAY_BASE_TICKS = 60;
	public static final int MILESTONE_DELAY_RANDOM_TICKS = 100;
	/** Dönüm noktası mesajı için son olaydan beri gereken en kısa süre (kısa, çünkü her biri yalnızca bir kez). */
	public static final long MILESTONE_MIN_GAP_TICKS = 1200L;

	// ------------------------------------------------------------------
	// İşaret: ayın önünden geçen balta silueti (yalnızca bakan oyuncuya, istemcide çizilir)
	// ------------------------------------------------------------------

	/** İki ay işareti arasındaki en kısa süre (30 dk) ve oturum başına üst sınır. */
	public static final long MOON_MIN_GAP_TICKS = 36000L;
	public static final int MOON_SIGNS_PER_SESSION = 1;
	/** Oyuncu aya bakarken her saniyelik denetimde olasılık: ~80 sn kesintisiz bakışta bir kez. */
	public static final double MOON_CHANCE_PER_GAZE_CHECK = 0.012;
	/** Bakış yönü ile ay arasındaki en büyük açı (derece). */
	public static final double MOON_GAZE_DEGREES = 22.0;
	/** Ayın ufuktan en az bu yükseklikte (sin açısı; 0.25 = ~14.5 derece) olması gerekir. */
	public static final double MOON_MIN_ELEVATION_SIN = 0.25;
	/** Silüetin süresi (tick) ve ilerleme düzeyine göre ek süre. */
	public static final int MOON_DURATION_TICKS = 70;
	public static final int MOON_DURATION_PER_PROGRESS = 8;

	// ------------------------------------------------------------------
	// İşaret: Nether'da uzaktan gelen örs / demir dövme sesi (yalnızca o oyuncuya)
	// ------------------------------------------------------------------

	public static final long FORGE_MIN_GAP_TICKS = 30000L;
	public static final int FORGE_SIGNS_PER_SESSION = 2;
	/** Her denetimde olasılık; Bazalt Deltaları'nda (Kara Demirhane'nin biyomu) çarpanla artar. */
	public static final double FORGE_CHANCE = 0.035;
	public static final double FORGE_CHANCE_BASALT_MULTIPLIER = 3.0;
	public static final int FORGE_STRIKES_MIN = 2;
	public static final int FORGE_STRIKES_MAX = 3;
	public static final int FORGE_STRIKE_SPACING_MIN_TICKS = 7;
	public static final int FORGE_STRIKE_SPACING_MAX_TICKS = 17;
	public static final float FORGE_VOLUME = 0.30F;
	public static final float FORGE_PITCH_MIN = 0.50F;
	public static final float FORGE_PITCH_MAX = 0.72F;
	/** Demir sesi, oyuncunun bu kadar yakınında (blok) başka oyuncu varsa planlanmaz: ses yalnızca o oyuncuya ait kalır. */
	public static final double FORGE_PRIVACY_RADIUS = 20.0;

	// ------------------------------------------------------------------
	// Bağlam eşikleri
	// ------------------------------------------------------------------

	/** Bu yüksekliğin altı "yeraltı" sayılır (yalnızca mesaj bağlamı için). */
	public static final double UNDERGROUND_Y = 40.0;
	/** Wither doğduğunda/öldüğünde bu mesafedeki (blok) oyuncular tanık sayılır. */
	public static final double WITHER_WITNESS_RADIUS = 48.0;
}
