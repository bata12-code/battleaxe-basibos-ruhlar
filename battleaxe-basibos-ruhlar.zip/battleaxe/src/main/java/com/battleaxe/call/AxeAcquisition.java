package com.battleaxe.call;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.item.ModItems;

/**
 * "Oyuncu Savaş Baltası'nı gerçekten edindi mi?" sorusunun TEK cevaplayıcısı.
 *
 * <p>Yalnızca "envanterde şu an balta var mı" bakmak yetmez: balta tezgâhtan imlece alınır (envanterde değildir),
 * {@code Ctrl+Q} ile doğrudan yere atılabilir ya da yerden alınıp aynı saniye bırakılabilir. Bu yüzden edinme
 * üç bağımsız kaynaktan izlenir ve herhangi biri yeterlidir:
 * <ol>
 *   <li>şu anki envanter + imleçte taşınan eşya ({@link #holdsNow});</li>
 *   <li>vanilla istatistikler: "üretildi" ve "yerden alındı" sayaçları ({@link #recordedByStats}). Bunlar oyuncunun
 *       kendi kayıt dosyasında KALICIDIR: balta sonradan kaybolsa, sandığa konsa, atılsa da sayaç düşmez;</li>
 *   <li>Ender sandığı ({@link #inEnderChest}, yavaş denetimde).</li>
 * </ol>
 * Edinme anında {@link CallManager#onAxeAcquired} {@link CallLogic#F_AXE} bayrağını OYUNCUNUN kalıcı verisine yazar;
 * ondan sonra bu sınıf bir daha sorulmaz.
 *
 * <p>Her sorgu kendi içinde bir hata olursa {@code false} döner (sistem baltasız sayılır ama çökmez; mevcut 10 sn'lik
 * envanter taraması ve {@code usedAxeBefore} yedek olarak çalışmaya devam eder).
 */
final class AxeAcquisition {
	private AxeAcquisition() {
	}

	/** Envanterde (zırh ve yan el dahil) ya da imleçte balta var mı? */
	static boolean holdsNow(ServerPlayer player) {
		Inventory inventory = player.getInventory();
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.getItem(i);
			if (!stack.isEmpty() && stack.is(ModItems.BATTLE_AXE)) {
				return true;
			}
		}
		return carried(player);
	}

	/** Tezgâhtan/menüden imlece alınmış ama henüz envantere konmamış balta. */
	private static boolean carried(ServerPlayer player) {
		try {
			ItemStack carried = player.containerMenu.getCarried();
			return !carried.isEmpty() && carried.is(ModItems.BATTLE_AXE);
		} catch (RuntimeException e) {
			return false;
		}
	}

	/** Vanilla istatistikleri: bu oyuncu baltayı hiç ürettiyse ya da yerden aldıysa true (kalıcı kayıt). */
	static boolean recordedByStats(ServerPlayer player) {
		try {
			return player.getStats().getValue(Stats.ITEM_CRAFTED.get(ModItems.BATTLE_AXE)) > 0
					|| player.getStats().getValue(Stats.ITEM_PICKED_UP.get(ModItems.BATTLE_AXE)) > 0;
		} catch (RuntimeException e) {
			return false;
		}
	}

	/** Ender sandığında balta var mı? (Yavaş denetim: envanteri boşaltmış ama baltayı saklamış oyuncular için.) */
	static boolean inEnderChest(ServerPlayer player) {
		try {
			var chest = player.getEnderChestInventory();
			for (int i = 0; i < chest.getContainerSize(); i++) {
				ItemStack stack = chest.getItem(i);
				if (!stack.isEmpty() && stack.is(ModItems.BATTLE_AXE)) {
					return true;
				}
			}
		} catch (RuntimeException e) {
			return false;
		}
		return false;
	}
}
