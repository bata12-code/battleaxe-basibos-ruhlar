package com.battleaxe.call;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

import com.battleaxe.BattleAxeMod;

/**
 * Baltanın Çağrısı'nın kalıcı verisi OYUNCUYA bağlıdır (dünya kaydıyla yazılır, ölünce kopyalanır; her
 * oyuncunun verisi ayrıdır). Alanlar isteğe bağlıdır: ileride alan eklenirse eski kayıtlar sorunsuz yüklenir.
 */
public final class CallAttachments {
	private CallAttachments() {
	}

	public static final Codec<CallData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.INT.optionalFieldOf("flags", 0).forGetter(CallData::flags),
			Codec.INT.optionalFieldOf("milestones", 0).forGetter(CallData::milestones),
			Codec.LONG.optionalFieldOf("seen", 0L).forGetter(CallData::seenMask),
			Codec.INT.optionalFieldOf("last_pick", -1).forGetter(CallData::lastPick),
			Codec.LONG.optionalFieldOf("last_message", 0L).forGetter(CallData::lastMessage),
			Codec.LONG.optionalFieldOf("last_moon", 0L).forGetter(CallData::lastMoon),
			Codec.LONG.optionalFieldOf("last_forge", 0L).forGetter(CallData::lastForge),
			Codec.LONG.optionalFieldOf("last_omen", 0L).forGetter(CallData::lastOmen),
			Codec.INT.optionalFieldOf("omen_seen", 0).forGetter(CallData::omenSeen),
			Codec.INT.optionalFieldOf("last_omen_kind", -1).forGetter(CallData::lastOmenKind),
			Codec.LONG.optionalFieldOf("last_star_msg", 0L).forGetter(CallData::lastStarMsg)
	).apply(instance, CallData::new));

	public static final AttachmentType<CallData> DATA = AttachmentRegistry.create(
			BattleAxeMod.id("call"),
			builder -> builder.persistent(CODEC).copyOnDeath()
	);
}
