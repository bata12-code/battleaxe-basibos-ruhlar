package com.battleaxe.evolution;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * İstemciden sunucuya: Berserker Evrimi isteği. Sunucu her alanı ve her kuralı doğrular.
 *
 * @param action 0 = durum iste, 1 = dal seç, 2 = Son Eşik'i başlat
 * @param arg    dal dizini (yalnızca action 1)
 */
public record EvolutionActionPayload(int action, int arg) implements CustomPacketPayload {
	public static final int SYNC = 0;
	public static final int SELECT_PATH = 1;
	public static final int FINAL_THRESHOLD = 2;

	public static final CustomPacketPayload.Type<EvolutionActionPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("evolution_action"));

	public static final StreamCodec<RegistryFriendlyByteBuf, EvolutionActionPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, EvolutionActionPayload::action,
			ByteBufCodecs.VAR_INT, EvolutionActionPayload::arg,
			EvolutionActionPayload::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
