package com.battleaxe.evolution;

import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

import com.battleaxe.berserker.BerserkerEffects;

/**
 * Berserker Evrimi'nin görsel/işitsel dili. Hasar, yangın veya blok değişimi YAPMAZ. Mevcut parçacık ve ses
 * altyapısı kullanılır (yeni asset yok). Aşamaya göre aralıklarla çalışır; her tick parçacık üretmez.
 *
 * <ul>
 *   <li>Kan Kasırgası: kırmızı, keskin (kritik kıvılcımları)</li>
 *   <li>Son Nefes: karanlık mor, nabız gibi atan (kalp atışı sesi)</li>
 *   <li>Ruh Yırtıcısı: spektral, ruh alevi</li>
 * </ul>
 */
final class EvolutionEffects {
	private EvolutionEffects() {
	}

	private static final DustColorTransitionOptions BLOOD = new DustColorTransitionOptions(0xFF1818, 0x300000, 0.9F);
	private static final DustColorTransitionOptions BREATH = new DustColorTransitionOptions(0xB04CFF, 0x12001A, 0.9F);
	private static final DustColorTransitionOptions SOUL = new DustColorTransitionOptions(0x59E6FF, 0x00202A, 0.9F);
	private static final DustColorTransitionOptions NEUTRAL = new DustColorTransitionOptions(0xFF8A2A, 0x200000, 0.8F);

	private static DustColorTransitionOptions dust(EvolutionPath path) {
		if (path == null) {
			return NEUTRAL;
		}
		return switch (path) {
			case BLOOD_WHIRL -> BLOOD;
			case LAST_BREATH -> BREATH;
			case SOUL_RENDER -> SOUL;
		};
	}

	/** Aşama atlandığı an: kısa patlama ve (Taşkınlıkta) hafif ekran titremesi. */
	static void stageEnter(ServerLevel level, ServerPlayer player, EvolutionPath path, int stage) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();
		level.sendParticles(dust(path), x, y, z, 10 + stage * 8, 0.5, 0.7, 0.5, 0.0);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F + 0.15F * stage, 0.5F + 0.2F * stage);
		if (stage >= EvolutionStage.SURGE.level) {
			level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 0.5F, 1.2F);
			BerserkerEffects.sendShake(player, 0.5F, 8);
		}
	}

	/** Aşamaya göre seyrek veya sık tazelenen aura. */
	static void aura(ServerLevel level, ServerPlayer player, EvolutionPath path, int stage, long now, double healthRatio) {
		int interval = switch (stage) {
			case 1 -> EvolutionConfig.AURA_INTERVAL_SPARK;
			case 2 -> EvolutionConfig.AURA_INTERVAL_AWAKENING;
			case 3 -> EvolutionConfig.AURA_INTERVAL_SURGE;
			default -> EvolutionConfig.AURA_INTERVAL_FINAL;
		};
		if (now % interval != 0) {
			return;
		}
		double x = player.getX();
		double y = player.getY(0.55);
		double z = player.getZ();
		int count = 1 + stage * 2;
		level.sendParticles(dust(path), x, y, z, count, 0.35 + 0.05 * stage, 0.6, 0.35 + 0.05 * stage, 0.0);
		if (path == null) {
			return;
		}
		ThreadLocalRandom random = ThreadLocalRandom.current();
		switch (path) {
			case BLOOD_WHIRL -> {
				if (stage >= EvolutionStage.AWAKENING.level && random.nextInt(3) == 0) {
					level.sendParticles(ParticleTypes.CRIT, x, y, z, stage, 0.4, 0.5, 0.4, 0.15);
				}
			}
			case LAST_BREATH -> {
				// Kalp atışı: can azaldıkça sıklaşır.
				if (stage >= EvolutionStage.AWAKENING.level) {
					int beat = healthRatio < 0.35 ? 20 : 40;
					if (now % beat == 0) {
						level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.25F, 0.5F);
						level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 2 + stage, 0.35, 0.6, 0.35, 0.01);
					}
				}
			}
			case SOUL_RENDER -> {
				if (stage >= EvolutionStage.AWAKENING.level) {
					level.sendParticles(ParticleTypes.SOUL, x, y, z, stage, 0.4, 0.7, 0.4, 0.02);
					if (stage >= EvolutionStage.SURGE.level && random.nextInt(2) == 0) {
						level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, player.getY(0.2), z, 2, 0.3, 0.1, 0.3, 0.02);
					}
				}
			}
		}
	}

	/** Dalın vuruş geri bildirimi (yalnızca aşama >= I iken). */
	static void hit(ServerLevel level, Entity target, EvolutionPath path, int momentum, boolean critical) {
		double x = target.getX();
		double y = target.getY(0.6);
		double z = target.getZ();
		switch (path) {
			case BLOOD_WHIRL -> level.sendParticles(BLOOD, x, y, z, 3 + momentum / 2, 0.25, 0.3, 0.25, 0.0);
			case LAST_BREATH -> level.sendParticles(BREATH, x, y, z, 4, 0.25, 0.3, 0.25, 0.0);
			case SOUL_RENDER -> level.sendParticles(ParticleTypes.SOUL, x, y, z, 3, 0.2, 0.3, 0.2, 0.03);
		}
	}

	static void finalStart(ServerLevel level, ServerPlayer player, EvolutionPath path) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();
		level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.3F, 0.6F);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 1.0F, 0.4F);
		for (int i = 0; i < 24; i++) {
			double angle = Math.PI * 2.0 * i / 24.0;
			level.sendParticles(dust(path), x + Math.cos(angle) * 1.8, y, z + Math.sin(angle) * 1.8, 2, 0.05, 0.4, 0.05, 0.0);
		}
		level.sendParticles(ParticleTypes.FLAME, x, y, z, 20, 0.5, 0.7, 0.5, 0.15);
		BerserkerEffects.sendShake(player, 1.0F, 16);
	}

	static void finalEnd(ServerLevel level, ServerPlayer player, EvolutionPath path) {
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.8F, 0.3F);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY(0.5), player.getZ(), 16, 0.5, 0.7, 0.5, 0.04);
	}

	static void recovery(ServerLevel level, ServerPlayer player, Recovery type) {
		level.sendParticles(ParticleTypes.LARGE_SMOKE, player.getX(), player.getY(0.8), player.getZ(),
				type == Recovery.BURNOUT ? 12 : 8, 0.4, 0.5, 0.4, 0.02);
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.4F, 0.35F);
	}

	static void defiance(ServerLevel level, ServerPlayer player) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();
		level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.0F, 0.5F);
		level.sendParticles(BREATH, x, y, z, 40, 0.5, 0.8, 0.5, 0.0);
		level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 30, 0.5, 0.8, 0.5, 0.1);
		BerserkerEffects.sendShake(player, 0.8F, 12);
	}
}
