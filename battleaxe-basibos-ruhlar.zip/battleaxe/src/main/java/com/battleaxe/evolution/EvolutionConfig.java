package com.battleaxe.evolution;

/**
 * Berserker Evrimi dengeleme ayarları. Dengelemek için yalnızca bu dosyayı değiştirmen yeterlidir.
 * Süreler tick cinsindendir (20 tick = 1 saniye).
 */
public final class EvolutionConfig {
	private EvolutionConfig() {
	}

	// ------------------------------------------------------------------
	// Savaş Özü
	// ------------------------------------------------------------------
	public static final double MAX_ESSENCE = 100.0;
	/** Son vuruş/hasardan sonra bu kadar süre "savaşta" sayılır. */
	public static final int COMBAT_WINDOW_TICKS = 100;
	/** Savaş bittikten bu kadar sonra öz azalmaya başlar; azalma hızı tick başına. */
	public static final int DECAY_DELAY_TICKS = 200;
	public static final double DECAY_PER_TICK = 0.075;
	/** KÖTÜYE KULLANIM KORUMASI: her pencerede (tick) kazanılabilecek en çok öz. */
	public static final int GAIN_WINDOW_TICKS = 20;
	public static final double GAIN_WINDOW_CAP = 14.0;

	/** Normal vuruş: temel kazanım. Saldırı gücü bunun altındaysa (kol sallama spam'i) hiç öz vermez. */
	public static final double MELEE_BASE = 3.0;
	public static final double MIN_STRENGTH = 0.4;
	/** Hedefin azami canına göre ağırlık: can / 20, bu aralığa sıkıştırılır. */
	public static final double TARGET_WEIGHT_MIN = 0.5;
	public static final double TARGET_WEIGHT_MAX = 2.5;
	/** Aynı hedefe art arda vuruş: her ek vuruş kazanımı düşürür (pencere içinde). */
	public static final int SAME_TARGET_WINDOW_TICKS = 100;
	public static final double SAME_TARGET_STEP = 0.2;
	public static final double SAME_TARGET_FLOOR = 0.25;
	/** Can bu oranın altındayken ("tehlikede savaşmak") kazanım çarpanı. */
	public static final double DANGER_RATIO = 0.5;
	public static final double DANGER_MULTIPLIER = 1.4;

	public static final double KILL_BASE = 4.0;
	public static final double KILL_STRONG_BONUS = 6.0;
	public static final double STRONG_ENEMY_HEALTH = 100.0;
	public static final double CLEAVE_HIT_GAIN = 2.5;
	public static final int CLEAVE_GAIN_MAX_TARGETS = 3;
	public static final double THROW_HIT_GAIN = 3.0;
	/**
	 * Kıyım Zinciri bir kademe atladığında kazanılan Savaş Özü, KADEME BAŞINA (kademe 1 = bu değer, kademe 4 = 4 katı).
	 * Normal kazanım sınırlayıcısından geçer; küçük tutulur çünkü zinciri besleyen öldürmeler zaten öz verir.
	 */
	public static final double CHAIN_TIER_ESSENCE = 2.0;
	/** Hasar alınca öz: hasar x çarpan, üst sınır, iki kazanım arası en az süre. */
	public static final double DAMAGED_FACTOR = 0.5;
	public static final double DAMAGED_CAP = 5.0;
	public static final int DAMAGED_MIN_INTERVAL_TICKS = 10;

	// ------------------------------------------------------------------
	// Aşama eşikleri (giriş / çıkış: histerezis, sınırda titreme olmasın)
	// ------------------------------------------------------------------
	public static final double SPARK_ENTER = 20.0;
	public static final double SPARK_EXIT = 8.0;
	public static final double AWAKENING_ENTER = 35.0;
	public static final double AWAKENING_EXIT = 20.0;
	public static final double SURGE_ENTER = 65.0;
	public static final double SURGE_EXIT = 40.0;
	/** Aşamanın saniyede Savaş Özü tüketimi. */
	public static final double AWAKENING_DRAIN_PER_SECOND = 0.5;
	public static final double SURGE_DRAIN_PER_SECOND = 2.0;

	// ------------------------------------------------------------------
	// Aşırı yüklenme
	// ------------------------------------------------------------------
	public static final double MAX_OVERLOAD = 100.0;
	public static final double SURGE_OVERLOAD_PER_SECOND = 5.0;
	public static final double AWAKENING_OVERLOAD_PER_SECOND = -1.0;
	public static final double IDLE_OVERLOAD_PER_SECOND = -10.0;
	/** Taşkınlık veya üstündeyken güçlü yetenek kullanımının aşırı yüklenme bedeli. */
	public static final double CLEAVE_OVERLOAD = 12.0;
	public static final double THROW_OVERLOAD = 8.0;
	public static final int OVERLOAD_RECOVERY_TICKS = 120;
	public static final double OVERLOAD_RESET_TO = 50.0;

	// ------------------------------------------------------------------
	// Son Eşik (Aşama IV)
	// ------------------------------------------------------------------
	public static final int FINAL_DURATION_TICKS = 160;
	public static final double FINAL_COST = 50.0;
	public static final int FINAL_COOLDOWN_TICKS = 3600;
	public static final double FINAL_MAX_OVERLOAD_TO_START = 80.0;
	public static final int BURNOUT_TICKS = 200;

	// ------------------------------------------------------------------
	// Toparlanma cezaları (adil: kilitleme yok, yalnızca geçici düşüş)
	// ------------------------------------------------------------------
	public static final double RECOVERY_DAMAGE_PENALTY = 10.0;
	public static final double RECOVERY_INCOMING_EXTRA = 10.0;
	public static final double OVERLOAD_ATTACK_SPEED_PENALTY = 8.0;
	public static final double BURNOUT_ATTACK_SPEED_PENALTY = 12.0;
	public static final double RECOVERY_MOVE_PENALTY = 10.0;

	// ------------------------------------------------------------------
	// Dal seçimi
	// ------------------------------------------------------------------
	/** İlk seçim ücretsiz; sonraki değişiklikler arasında en az bu kadar süre. */
	public static final int PATH_CHANGE_COOLDOWN_TICKS = 6000;

	// ------------------------------------------------------------------
	// Ustalık (dal ilerlemesi): kalıcı, dal başına
	// ------------------------------------------------------------------
	public static final int[] MASTERY_THRESHOLDS = {0, 150, 500, 1200, 2500};
	public static final double[] MASTERY_SCALE = {0.8, 0.9, 1.0, 1.1, 1.2};
	/** Pencere başına kazanılabilecek en çok ustalık puanı (hızlı farm engeli). */
	public static final int MASTERY_WINDOW_CAP = 3;

	// ------------------------------------------------------------------
	// Genel aşama bonusları (indeks = aşama 0..4). Dal bonusları buna EK gelir.
	// ------------------------------------------------------------------
	public static final double[] STAGE_DAMAGE_PCT = {0.0, 3.0, 7.0, 12.0, 20.0};
	public static final double[] STAGE_ATTACK_SPEED_PCT = {0.0, 2.0, 4.0, 7.0, 12.0};
	/** Eski Berserker (can <= %50) zaten +%35 hız veriyor: evrim hız bonusu bununla çarpılmasın diye bu oranda azalır. */
	public static final double LEGACY_ATTACK_SPEED_SCALE = 0.5;

	// ------------------------------------------------------------------
	// Üst sınırlar
	// ------------------------------------------------------------------
	public static final double OUTGOING_DAMAGE_PCT_MIN = -20.0;
	public static final double OUTGOING_DAMAGE_PCT_MAX = 45.0;
	/** Ruh Ağı ile birleşik toplam giden hasar, orijinalin en çok bu katı olabilir (infaz hariç). */
	public static final double COMBINED_OUTGOING_CAP = 2.6;
	/** Ruh Ağı ile birleşik gelen hasar, orijinalin en az bu oranı kalır (en çok %70 azalma). */
	public static final double MIN_INCOMING_RATIO = 0.30;
	public static final double ATTACK_SPEED_PCT_MIN = -15.0;
	public static final double ATTACK_SPEED_PCT_MAX = 30.0;

	// ------------------------------------------------------------------
	// Kan Kasırgası
	// ------------------------------------------------------------------
	public static final int MOMENTUM_MAX = 10;
	/** İvme bu kadar tick vuruş yoksa çözülmeye başlar; sonra her 12 tickte 1. */
	public static final int MOMENTUM_DECAY_DELAY_TICKS = 40;
	public static final int MOMENTUM_DECAY_INTERVAL_TICKS = 12;
	/** Vuruşun ivme saymasi için en düşük saldırı gücü (altı ivmeyi AZALTIR). */
	public static final double MOMENTUM_MIN_STRENGTH = 0.5;
	public static final double BLOOD_DAMAGE_PER_STACK = 1.5;
	public static final double BLOOD_DAMAGE_CAP = 30.0;
	public static final double BLOOD_ATTACK_SPEED_PER_STACK = 1.6;
	public static final double BLOOD_ATTACK_SPEED_CAP = 25.0;
	public static final double BLOOD_ESSENCE_PER_STACK = 0.04;
	public static final double BLOOD_ESSENCE_CAP = 0.4;
	/** Sınırlama: savunmasız kalır. */
	public static final double BLOOD_INCOMING_EXTRA = 6.0;
	public static final double BLOOD_INCOMING_EXTRA_CAP = 12.0;
	public static final int BLOOD_FINAL_MOMENTUM_FLOOR = 6;
	public static final double BLOOD_FINAL_DAMAGE_BONUS = 10.0;
	public static final int BLOOD_MASTERY_MIN_MOMENTUM = 5;

	// ------------------------------------------------------------------
	// Son Nefes
	// ------------------------------------------------------------------
	public static final double LAST_DAMAGE_PER_MISSING = 25.0;
	public static final double LAST_DAMAGE_CAP = 25.0;
	public static final double LAST_REDUCTION_PER_MISSING = 32.0;
	public static final double LAST_REDUCTION_CAP = 35.0;
	public static final double LAST_FINAL_REDUCTION = 35.0;
	public static final double LAST_FINAL_DAMAGE_BONUS = 10.0;
	public static final double LAST_ESSENCE_LOW_HEALTH_MULT = 1.5;
	public static final double LAST_FINAL_HEAL_PER_SECOND = 1.0;
	/** Ölümden kurtulma ("Son Nefes"): bekleme, öz bedeli, kurtulunca can oranı, kısa koruma. */
	public static final int DEFIANCE_COOLDOWN_TICKS = 6000;
	public static final double DEFIANCE_COST = 15.0;
	public static final double DEFIANCE_HEALTH_RATIO = 0.25;
	public static final int DEFIANCE_GRACE_TICKS = 60;
	public static final double DEFIANCE_GRACE_REDUCTION = 50.0;
	/** Hiçbir durumda toplam evrim hasar azaltması bunu aşmaz (ölümsüzlük yok). */
	public static final double INCOMING_REDUCTION_CAP = 60.0;

	// ------------------------------------------------------------------
	// Ruh Yırtıcısı
	// ------------------------------------------------------------------
	public static final double SOUL_CLEAVE_DAMAGE = 14.0;
	public static final double SOUL_THROW_DAMAGE = 15.0;
	public static final double SOUL_DAMAGE_CAP = 25.0;
	public static final double SOUL_FINAL_ABILITY_DAMAGE = 25.0;
	/** Sınırlama: sıradan yakın dövüş vuruşlarından daha az öz kazanır. */
	public static final double SOUL_MELEE_ESSENCE_MULT = 0.75;
	public static final double SOUL_CLEAVE_EXTRA_GAIN = 3.5;
	public static final double SOUL_THROW_EXTRA_GAIN = 4.0;
	public static final double SOUL_FINAL_COOLDOWN_REDUCTION = 40.0;
	/** Ruh ödülüne eklenen düz bonus (aynı kill olayının İÇİNE, ikinci ödül değil). */
	public static final int SOUL_BONUS_MIN_BASE_VALUE = 3;

	// ------------------------------------------------------------------
	// Ağ
	// ------------------------------------------------------------------
	public static final int ACTION_MIN_INTERVAL_TICKS = 4;
	public static final int SYNC_MIN_INTERVAL_TICKS = 5;
	/** Görsel efekt aralıkları (tick). */
	public static final int AURA_INTERVAL_SPARK = 10;
	public static final int AURA_INTERVAL_AWAKENING = 6;
	public static final int AURA_INTERVAL_SURGE = 4;
	public static final int AURA_INTERVAL_FINAL = 3;
	/** Kayıtlı özün yeniden yazılma aralığı (sıcak değer bellekte tutulur). */
	public static final int FLUSH_INTERVAL_TICKS = 100;
}
