package com.battleaxe.evolution;

import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.battleaxe.evolution.EvolutionLogic.WindowLimiter;

/**
 * Bir oyuncunun SUNUCU tarafındaki anlık (kaydedilmeyen) Berserker Evrimi durumu. Savaş Özü burada "sıcak"
 * değer olarak tutulur ve belirli aralıklarla kalıcı veriye yazılır. Yalnızca sunucu iş parçacığından kullanılır.
 */
final class EvolutionRuntime {
	EvolutionData data = EvolutionData.EMPTY;
	double essence;

	EvolutionStage stage = EvolutionStage.NONE;
	Recovery recovery = Recovery.NONE;
	long recoveryEnd;
	double overload;
	/** Son Eşik'in biteceği oyun zamanı; 0 = aktif değil. */
	long finalEnd;
	long graceEnd;

	boolean armed;
	boolean legacy;

	// Kan Kasırgası
	int momentum;
	long lastHitTick = -1000;

	long lastCombatTick = -100000;

	// Vuruş bağlamı
	long attackTick = -1;
	double attackStrength = 1.0;
	int attackTargetId = -1;
	long hitKeyTick = -1;
	int hitKeyTarget = -1;
	long lastDamagedGainTick = -1000;
	final Map<Integer, long[]> targetHits = new LinkedHashMap<>(16, 0.75F, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<Integer, long[]> eldest) {
			return size() > 8;
		}
	};
	final ArrayDeque<UUID> recentKills = new ArrayDeque<>();

	// Kötüye kullanım sınırlayıcıları
	final WindowLimiter essenceLimiter = new WindowLimiter(EvolutionConfig.GAIN_WINDOW_TICKS, EvolutionConfig.GAIN_WINDOW_CAP);
	final WindowLimiter masteryLimiter = new WindowLimiter(EvolutionConfig.GAIN_WINDOW_TICKS, EvolutionConfig.MASTERY_WINDOW_CAP);

	// Ağ / kayıt / öznitelik takibi
	long lastActionTick = -1000;
	long lastSyncTick = -1000;
	int lastSyncSignature = Integer.MIN_VALUE;
	boolean syncForced = true;
	long lastFlushTick;
	int attributeSignature = Integer.MIN_VALUE;

	EvolutionPath path() {
		return data.pathOrNull();
	}

	int masteryLevel() {
		EvolutionPath path = path();
		return EvolutionLogic.masteryLevel(data.masteryPoints(path));
	}

	boolean finalActive() {
		return finalEnd > 0;
	}

	boolean inCombat(long now) {
		return now - lastCombatTick <= EvolutionConfig.COMBAT_WINDOW_TICKS;
	}

	/** Aynı varlığın ölümü ikinci kez işlenmesin. */
	boolean markKill(UUID victim) {
		if (recentKills.contains(victim)) {
			return false;
		}
		recentKills.addLast(victim);
		while (recentKills.size() > 16) {
			recentKills.removeFirst();
		}
		return true;
	}
}
