package com.battleaxe.evolution;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;

import com.battleaxe.evolution.EvolutionLogic.DamageContext;
import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusCleave;
import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * Berserker Evrimi hasar kancası: Ruh Ağı'nın (NexusDamage) HEMEN ARDINDAN, aynı ham miktar üzerinde çalışır.
 * İki sistemin birleşik etkisi sınırlıdır: giden hasar orijinalin en çok {@link EvolutionConfig#COMBINED_OUTGOING_CAP}
 * katı olur (Ruh Ağı infazı hariç), gelen hasar en çok %70 azalır. Evrim, Ruh Ağı'nın verdiği hasarı asla düşürmez
 * (bonus ise yalnızca ekleyebilir; ceza durumlarında toparlanma etkisi uygulanır).
 */
public final class EvolutionDamage {
	private EvolutionDamage() {
	}

	/**
	 * @param original Ruh Ağı'ndan ÖNCEKİ ham miktar
	 * @param current  Ruh Ağı'ndan SONRAKİ miktar
	 */
	public static float modify(LivingEntity victim, DamageSource source, float original, float current) {
		float result = current;
		if (source.getEntity() instanceof ServerPlayer attacker && attacker != victim) {
			result = outgoing(attacker, victim, source, original, result);
		}
		if (victim instanceof ServerPlayer defender) {
			result = incoming(defender, source, original, result);
		}
		return result;
	}

	private static float outgoing(ServerPlayer attacker, LivingEntity victim, DamageSource source, float original, float current) {
		ThrownBattleAxe hit = ThrownBattleAxe.activeHit();
		boolean thrown = hit != null && source.is(DamageTypes.THROWN) && attacker.getUUID().equals(hit.getOwnerUuid());
		boolean melee = source.is(DamageTypes.PLAYER_ATTACK) && attacker.getMainHandItem().is(ModItems.BATTLE_AXE);
		if (!thrown && !melee) {
			return current;
		}

		EvolutionRuntime rt = EvolutionManager.runtime(attacker);
		boolean cleave = melee && NexusCleave.isCleaving(attacker);
		DamageContext context = new DamageContext(cleave, thrown, EvolutionManager.healthRatio(attacker), rt.momentum,
				rt.finalActive(), rt.recovery);
		double pct = EvolutionLogic.outgoingPct(rt.path(), rt.stage.level, rt.masteryLevel(), context);
		if (Math.abs(pct) < 1.0E-6) {
			return current;
		}

		float boosted = (float) (current * (1.0 + pct / 100.0));
		if (pct > 0.0) {
			// Birleşik tavan: Ruh Ağı + Evrim, orijinalin en çok COMBINED_OUTGOING_CAP katı. Ruh Ağı zaten daha
			// yüksek verdiyse (infaz gibi) onu düşürmeyiz.
			boosted = Math.min(boosted, Math.max(current, original * (float) EvolutionConfig.COMBINED_OUTGOING_CAP));
		}
		return boosted;
	}

	private static float incoming(ServerPlayer defender, DamageSource source, float original, float current) {
		if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || !defender.getMainHandItem().is(ModItems.BATTLE_AXE)) {
			return current;
		}
		EvolutionRuntime rt = EvolutionManager.runtime(defender);
		long now = defender.level().getGameTime();
		double healthRatio = EvolutionManager.healthRatio(defender);
		double reduction = EvolutionLogic.incomingReductionPct(rt.path(), rt.stage.level, rt.masteryLevel(), healthRatio,
				rt.finalActive(), EvolutionManager.graceActive(rt, now));
		double extra = EvolutionLogic.incomingExtraPct(rt.path(), rt.stage.level, rt.masteryLevel(), rt.recovery);
		double factor = (1.0 - reduction / 100.0) * (1.0 + extra / 100.0);
		if (Math.abs(factor - 1.0) < 1.0E-6) {
			return current;
		}
		float result = (float) (current * factor);
		if (factor < 1.0) {
			// Birleşik taban: Ruh Ağı + Evrim birlikte hasarı en çok %70 azaltabilir (ölümsüzlük yok).
			float floor = original * (float) EvolutionConfig.MIN_INCOMING_RATIO;
			result = Math.max(result, Math.min(current, floor));
		}
		return result;
	}
}
