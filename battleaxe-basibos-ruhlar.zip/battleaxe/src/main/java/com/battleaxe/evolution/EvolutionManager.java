package com.battleaxe.evolution;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.evolution.EvolutionLogic.FinalCheck;
import com.battleaxe.evolution.EvolutionLogic.MasteryEvent;
import com.battleaxe.evolution.EvolutionLogic.PathChange;
import com.battleaxe.evolution.EvolutionLogic.StageInputs;
import com.battleaxe.item.ModItems;
import com.battleaxe.thrown.ThrownAxeTracker;

/**
 * Berserker Evrimi'nin sunucu tarafı merkezi (otoriter): oyuncu durumları, aşama makinesi, Savaş Özü,
 * aşırı yüklenme/toparlanma, Son Eşik, dal seçimi, ölümden kurtulma, kalıcı veri ve istemci senkronu.
 *
 * <p>Mevcut Berserker (BerserkerManager) olduğu gibi çalışır; burası onun çıktısını ({@code isActive}) bir girdi olarak
 * okur ve üzerine evrimi kurar. Hiçbir mevcut sistemin durumu değiştirilmez.
 */
public final class EvolutionManager {
	private EvolutionManager() {
	}

	private static final Map<UUID, EvolutionRuntime> RUNTIMES = new HashMap<>();

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(EvolutionSyncPayload.TYPE, EvolutionSyncPayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(EvolutionActionPayload.TYPE, EvolutionActionPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(EvolutionActionPayload.TYPE,
				(payload, context) -> handleAction(context.player(), payload));

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tick(player);
			}
		});

		// Ölüm kuralı: dal, ustalık ve bekleme süreleri korunur; Savaş Özü savaş kaynağı olduğu için sıfırlanır.
		// (Çıkış dünyasından dönüş "alive" olarak gelir: orada öz korunur.)
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			RUNTIMES.remove(newPlayer.getUUID());
			if (!alive) {
				EvolutionData data = newPlayer.getAttachedOrElse(EvolutionAttachments.DATA, EvolutionData.EMPTY);
				newPlayer.setAttached(EvolutionAttachments.DATA, data.withEssence(0.0));
			}
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			EvolutionRuntime runtime = RUNTIMES.remove(handler.getPlayer().getUUID());
			if (runtime != null) {
				flush(handler.getPlayer(), runtime);
			}
		});
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				EvolutionRuntime runtime = RUNTIMES.get(player.getUUID());
				if (runtime != null) {
					flush(player, runtime);
				}
			}
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> RUNTIMES.clear());

		ServerLivingEntityEvents.AFTER_DAMAGE.register(EvolutionManager::afterDamage);
		ServerLivingEntityEvents.ALLOW_DEATH.register(EvolutionManager::allowDeath);
	}

	// ------------------------------------------------------------------
	// Durum erişimi
	// ------------------------------------------------------------------

	static EvolutionRuntime runtime(ServerPlayer player) {
		EvolutionRuntime runtime = RUNTIMES.get(player.getUUID());
		if (runtime == null) {
			runtime = new EvolutionRuntime();
			runtime.data = player.getAttachedOrElse(EvolutionAttachments.DATA, EvolutionData.EMPTY);
			runtime.essence = runtime.data.essence();
			runtime.lastFlushTick = player.level().getGameTime();
			RUNTIMES.put(player.getUUID(), runtime);
		}
		return runtime;
	}

	public static int stageLevel(ServerPlayer player) {
		return runtime(player).stage.level;
	}

	/** Sıcak özü ve veriyi kalıcı kayda yazar. */
	static void flush(ServerPlayer player, EvolutionRuntime runtime) {
		runtime.data = runtime.data.withEssence(runtime.essence);
		player.setAttached(EvolutionAttachments.DATA, runtime.data);
		runtime.lastFlushTick = player.level().getGameTime();
	}

	/** Verideki bir değişikliği (dal, ustalık, bekleme) hemen kalıcı yapar. */
	static void persist(ServerPlayer player, EvolutionRuntime runtime) {
		flush(player, runtime);
		runtime.syncForced = true;
	}

	// ------------------------------------------------------------------
	// Kaynak ve ustalık
	// ------------------------------------------------------------------

	static void addEssence(EvolutionRuntime runtime, double amount, long now) {
		double allowed = runtime.essenceLimiter.limit(amount, now);
		if (allowed > 0.0) {
			runtime.essence = Math.min(EvolutionConfig.MAX_ESSENCE, runtime.essence + allowed);
		}
	}

	static void addMastery(ServerPlayer player, EvolutionRuntime runtime, MasteryEvent event, double healthRatio, long now) {
		EvolutionPath path = runtime.path();
		int gain = EvolutionLogic.masteryGain(path, event, runtime.momentum, healthRatio, runtime.stage.level);
		if (gain <= 0) {
			return;
		}
		int allowed = (int) runtime.masteryLimiter.limit(gain, now);
		if (allowed > 0) {
			grantMastery(player, runtime, path, allowed);
		}
	}

	/** Ustalık puanını doğrudan ekler (sınırlayıcı dışı; yalnızca zaten bekleme süreli olaylar için). */
	static void grantMastery(ServerPlayer player, EvolutionRuntime runtime, EvolutionPath path, int points) {
		int before = runtime.data.masteryPoints(path);
		int levelBefore = EvolutionLogic.masteryLevel(before);
		runtime.data = runtime.data.withMastery(path, before + points);
		int levelAfter = EvolutionLogic.masteryLevel(before + points);
		if (levelAfter > levelBefore) {
			persist(player, runtime);
			player.sendSystemMessage(Component.translatable("evolution.msg.mastery_up",
					Component.translatable(path.nameKey()), levelAfter), true);
			if (player.level() instanceof ServerLevel level) {
				level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_LEVELUP,
						SoundSource.PLAYERS, 0.6F, 0.8F);
			}
		}
	}

	static double healthRatio(ServerPlayer player) {
		return player.getHealth() / Math.max(1.0F, player.getMaxHealth());
	}

	// ------------------------------------------------------------------
	// Tick
	// ------------------------------------------------------------------

	private static void tick(ServerPlayer player) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		EvolutionRuntime rt = runtime(player);
		long now = level.getGameTime();
		boolean alive = player.isAlive();
		boolean holding = player.getMainHandItem().is(ModItems.BATTLE_AXE);
		// Balta havadayken de "silahlı" sayılır: Son Eşik ve aşama fırlatma sırasında bozulmaz.
		boolean armed = holding || ThrownAxeTracker.hasActive(level.getServer(), player.getUUID());
		rt.armed = armed;
		rt.legacy = BerserkerManager.isActive(player);
		boolean combat = rt.inCombat(now);
		EvolutionPath path = rt.path();

		if (rt.finalEnd > 0 && (now >= rt.finalEnd || !armed || !alive)) {
			endFinal(level, player, rt, now);
		}
		if (rt.recovery != Recovery.NONE && now >= rt.recoveryEnd) {
			if (rt.recovery == Recovery.OVERLOAD) {
				rt.overload = EvolutionConfig.OVERLOAD_RESET_TO;
			}
			rt.recovery = Recovery.NONE;
			rt.syncForced = true;
		}

		EvolutionStage previous = rt.stage;
		EvolutionStage next = EvolutionLogic.nextStage(previous, new StageInputs(
				alive, armed, path != null, rt.legacy, combat, rt.essence, rt.recovery, rt.finalActive()));
		if (next != previous) {
			rt.stage = next;
			onStageChange(level, player, rt, previous, next);
		}

		rt.essence = EvolutionLogic.essenceAfterTick(rt.essence, next.level, combat, now - rt.lastCombatTick);
		rt.overload = EvolutionLogic.overloadAfterTick(rt.overload, next.level);
		if (rt.recovery == Recovery.NONE && next != EvolutionStage.FINAL_THRESHOLD
				&& rt.overload >= EvolutionConfig.MAX_OVERLOAD) {
			startRecovery(level, player, rt, Recovery.OVERLOAD, EvolutionConfig.OVERLOAD_RECOVERY_TICKS, now);
		}

		rt.momentum = path == EvolutionPath.BLOOD_WHIRL
				? EvolutionLogic.momentumAfterTick(rt.momentum, now, rt.lastHitTick, rt.finalActive()) : 0;

		if (rt.finalActive() && path == EvolutionPath.LAST_BREATH && now % 20 == 0 && alive) {
			player.heal((float) EvolutionConfig.LAST_FINAL_HEAL_PER_SECOND);
		}

		applyAttributes(player, rt);

		if (alive && rt.stage.level > 0) {
			EvolutionEffects.aura(level, player, path, rt.stage.level, now, healthRatio(player));
		}

		if (now - rt.lastFlushTick >= EvolutionConfig.FLUSH_INTERVAL_TICKS) {
			flush(player, rt);
		}
		syncIfChanged(player, rt, now);
	}

	private static void onStageChange(ServerLevel level, ServerPlayer player, EvolutionRuntime rt, EvolutionStage from,
			EvolutionStage to) {
		rt.syncForced = true;
		if (to.level > from.level && to != EvolutionStage.FINAL_THRESHOLD) {
			EvolutionEffects.stageEnter(level, player, rt.path(), to.level);
			if (to.level >= EvolutionStage.AWAKENING.level) {
				player.sendSystemMessage(Component.translatable("evolution.msg.stage_up", Component.translatable(to.nameKey())), true);
			}
		}
	}

	private static void startRecovery(ServerLevel level, ServerPlayer player, EvolutionRuntime rt, Recovery type, int ticks,
			long now) {
		rt.recovery = type;
		rt.recoveryEnd = now + ticks;
		rt.syncForced = true;
		player.sendSystemMessage(Component.translatable(type == Recovery.OVERLOAD
				? "evolution.msg.overload" : "evolution.msg.burnout"), true);
		EvolutionEffects.recovery(level, player, type);
	}

	private static void endFinal(ServerLevel level, ServerPlayer player, EvolutionRuntime rt, long now) {
		rt.finalEnd = 0;
		rt.syncForced = true;
		if (player.isAlive()) {
			EvolutionEffects.finalEnd(level, player, rt.path());
			startRecovery(level, player, rt, Recovery.BURNOUT, EvolutionConfig.BURNOUT_TICKS, now);
		}
	}

	// ------------------------------------------------------------------
	// Öznitelikler (saldırı hızı, hareket)
	// ------------------------------------------------------------------

	private static void applyAttributes(ServerPlayer player, EvolutionRuntime rt) {
		int signature = Objects.hash(rt.stage.level, rt.recovery.ordinal(), rt.momentum, rt.data.path(), rt.legacy,
				rt.masteryLevel());
		if (signature == rt.attributeSignature) {
			return;
		}
		rt.attributeSignature = signature;
		double speed = EvolutionLogic.attackSpeedPct(rt.path(), rt.stage.level, rt.masteryLevel(), rt.momentum,
				rt.recovery, rt.legacy);
		double move = EvolutionLogic.movementPct(rt.recovery);
		EvolutionAttributes.apply(player, speed / 100.0, move / 100.0);
	}

	// ------------------------------------------------------------------
	// Senkron
	// ------------------------------------------------------------------

	private static void syncIfChanged(ServerPlayer player, EvolutionRuntime rt, long now) {
		if (now - rt.lastSyncTick < EvolutionConfig.SYNC_MIN_INTERVAL_TICKS && !rt.syncForced) {
			return;
		}
		EvolutionSyncPayload payload = buildPayload(rt, now);
		int signature = Objects.hash(payload.core(), payload.mastery(), payload.timers().flags(),
				payload.timers().finalActiveLeft() > 0, payload.timers().finalCooldownLeft() > 0,
				payload.timers().pathCooldownLeft() > 0, payload.timers().recoveryLeft() > 0);
		if (signature == rt.lastSyncSignature && !rt.syncForced) {
			return;
		}
		sendSync(player, rt, payload, signature, now);
	}

	private static void sendSync(ServerPlayer player, EvolutionRuntime rt, EvolutionSyncPayload payload, int signature, long now) {
		if (ServerPlayNetworking.canSend(player, EvolutionSyncPayload.TYPE)) {
			ServerPlayNetworking.send(player, payload);
		}
		rt.lastSyncSignature = signature;
		rt.lastSyncTick = now;
		rt.syncForced = false;
	}

	private static EvolutionSyncPayload buildPayload(EvolutionRuntime rt, long now) {
		int flags = (rt.armed ? EvolutionSyncPayload.FLAG_ARMED : 0) | (rt.legacy ? EvolutionSyncPayload.FLAG_LEGACY : 0);
		return new EvolutionSyncPayload(
				new EvolutionSyncPayload.Core(rt.data.path(), rt.stage.level, (int) Math.round(rt.essence),
						(int) Math.round(rt.overload), rt.recovery.ordinal(), rt.momentum),
				new EvolutionSyncPayload.Timers(
						(int) Math.max(0L, rt.finalEnd - now),
						(int) Math.max(0L, rt.data.finalReadyTick() - now),
						(int) Math.max(0L, rt.data.pathChangeReadyTick() - now),
						(int) Math.max(0L, rt.recoveryEnd - now) * (rt.recovery == Recovery.NONE ? 0 : 1),
						flags),
				new EvolutionSyncPayload.Mastery(rt.data.mastery().get(0), rt.data.mastery().get(1), rt.data.mastery().get(2)));
	}

	// ------------------------------------------------------------------
	// İstemci istekleri
	// ------------------------------------------------------------------

	private static void handleAction(ServerPlayer player, EvolutionActionPayload payload) {
		int action = payload.action();
		if (action < EvolutionActionPayload.SYNC || action > EvolutionActionPayload.FINAL_THRESHOLD) {
			return; // geçersiz paket: yoksay
		}
		EvolutionRuntime rt = runtime(player);
		long now = player.level().getGameTime();
		if (now - rt.lastActionTick < EvolutionConfig.ACTION_MIN_INTERVAL_TICKS) {
			return;
		}
		rt.lastActionTick = now;

		if (action == EvolutionActionPayload.SYNC) {
			sendSync(player, rt, buildPayload(rt, now), rt.lastSyncSignature, now);
			return;
		}
		if (!player.isAlive() || player.isSpectator()) {
			return;
		}
		if (action == EvolutionActionPayload.SELECT_PATH) {
			selectPath(player, rt, payload.arg(), now);
		} else {
			startFinal(player, rt, now);
		}
	}

	private static void selectPath(ServerPlayer player, EvolutionRuntime rt, int newPath, long now) {
		PathChange result = EvolutionLogic.canChangePath(rt.data.path(), newPath, rt.stage, rt.inCombat(now), now,
				rt.data.pathChangeReadyTick());
		if (result != PathChange.OK) {
			player.sendSystemMessage(Component.translatable("evolution.msg.path." + result.name().toLowerCase(java.util.Locale.ROOT)), true);
			return;
		}
		boolean first = rt.data.path() < 0;
		EvolutionData next = rt.data.withPath(newPath);
		if (!first) {
			next = next.withPathChangeReady(now + EvolutionConfig.PATH_CHANGE_COOLDOWN_TICKS);
		}
		rt.data = next;
		rt.momentum = 0;
		rt.attributeSignature = Integer.MIN_VALUE;
		persist(player, rt);
		player.sendSystemMessage(Component.translatable("evolution.msg.path_selected",
				Component.translatable(EvolutionPath.byIndex(newPath).nameKey())), true);
	}

	private static void startFinal(ServerPlayer player, EvolutionRuntime rt, long now) {
		if (!(player.level() instanceof ServerLevel level)) {
			return;
		}
		FinalCheck check = EvolutionLogic.canStartFinal(rt.path() != null, player.getMainHandItem().is(ModItems.BATTLE_AXE),
				rt.stage, rt.essence, now, rt.data.finalReadyTick(), rt.recovery, rt.overload, rt.finalActive());
		if (check != FinalCheck.OK) {
			player.sendSystemMessage(Component.translatable("evolution.msg.final." + check.name().toLowerCase(java.util.Locale.ROOT)), true);
			return;
		}
		rt.essence = Math.max(0.0, rt.essence - EvolutionConfig.FINAL_COST);
		rt.finalEnd = now + EvolutionConfig.FINAL_DURATION_TICKS;
		rt.data = rt.data.withFinalReady(now + EvolutionConfig.FINAL_COOLDOWN_TICKS);
		if (rt.path() == EvolutionPath.BLOOD_WHIRL) {
			rt.momentum = Math.max(rt.momentum, EvolutionConfig.BLOOD_FINAL_MOMENTUM_FLOOR);
		}
		EvolutionStage previous = rt.stage;
		rt.stage = EvolutionStage.FINAL_THRESHOLD;
		persist(player, rt);
		onStageChange(level, player, rt, previous, rt.stage);
		EvolutionEffects.finalStart(level, player, rt.path());
		player.sendSystemMessage(Component.translatable("evolution.msg.final_started"), true);
	}

	// ------------------------------------------------------------------
	// Hasar olayları
	// ------------------------------------------------------------------

	private static void afterDamage(LivingEntity entity, DamageSource source, float baseDamageTaken, float damageTaken, boolean blocked) {
		if (!(entity instanceof ServerPlayer player) || damageTaken <= 0.0F) {
			return;
		}
		Entity attacker = source.getEntity();
		// Yalnızca düşman canlıların verdiği hasar (çevre/oyuncu hasarı "öz çiftliği" olamaz).
		if (!(attacker instanceof LivingEntity) || attacker instanceof Player) {
			return;
		}
		EvolutionRuntime rt = runtime(player);
		if (!rt.armed) {
			return;
		}
		long now = player.level().getGameTime();
		// Yalnızca zaten SAVAŞ içindeyken (yakın zamanda sen vurdun) hasar öz verir; sadece dayak yiyerek öz farmlanamaz.
		// Hasar savaş süresini UZATMAZ: savaşı yalnızca saldırılar canlı tutar.
		if (!rt.inCombat(now)) {
			return;
		}
		if (now - rt.lastDamagedGainTick >= EvolutionConfig.DAMAGED_MIN_INTERVAL_TICKS) {
			rt.lastDamagedGainTick = now;
			addEssence(rt, EvolutionLogic.damagedGain(damageTaken), now);
			addMastery(player, rt, MasteryEvent.DAMAGED, healthRatio(player), now);
		}
	}

	/** Son Nefes: ölümcül vuruşta, bekleme ve öz bedeliyle bir kez hayatta kalma. */
	private static boolean allowDeath(LivingEntity entity, DamageSource source, float amount) {
		if (!(entity instanceof ServerPlayer player) || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
				|| !(player.level() instanceof ServerLevel level)) {
			return true;
		}
		EvolutionRuntime rt = runtime(player);
		long now = level.getGameTime();
		if (!rt.armed || !EvolutionLogic.canDefy(rt.path(), rt.stage.level, rt.essence, now, rt.data.defianceReadyTick())) {
			return true;
		}

		rt.essence = Math.max(0.0, rt.essence - EvolutionConfig.DEFIANCE_COST);
		rt.data = rt.data.withDefianceReady(now + EvolutionConfig.DEFIANCE_COOLDOWN_TICKS);
		rt.graceEnd = now + EvolutionConfig.DEFIANCE_GRACE_TICKS;
		player.setHealth(Math.max(1.0F, player.getMaxHealth() * (float) EvolutionConfig.DEFIANCE_HEALTH_RATIO));
		grantMastery(player, rt, EvolutionPath.LAST_BREATH, EvolutionLogic.masteryGain(EvolutionPath.LAST_BREATH,
				MasteryEvent.DEFIANCE, rt.momentum, 0.0, rt.stage.level));
		persist(player, rt);
		player.sendSystemMessage(Component.translatable("evolution.msg.defiance"), true);
		EvolutionEffects.defiance(level, player);
		return false;
	}

	/** Kısa süreli "ölümden dönüş" korumasının hâlâ sürüp sürmediği. */
	static boolean graceActive(EvolutionRuntime rt, long now) {
		return now < rt.graceEnd;
	}
}
