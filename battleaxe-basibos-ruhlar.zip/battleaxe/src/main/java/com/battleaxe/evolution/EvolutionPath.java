package com.battleaxe.evolution;

/**
 * Berserker Evrimi dalları. Yeni dal eklemek: buraya bir sabit, {@link EvolutionLogic} içine etkilerini
 * ve dil dosyasına "evolution.path.&lt;id&gt;" anahtarlarını eklemek yeterlidir (kayıtlı veri sıraya değil
 * dizine bağlıdır, bu yüzden yeni dalları SONA ekle).
 */
public enum EvolutionPath {
	/** Saldırı temposu: kombo/ivme. */
	BLOOD_WHIRL("blood_whirl", 0xFF3A3A),
	/** Ölümün eşiği: düşük canda güçlenme ve hayatta kalma. */
	LAST_BREATH("last_breath", 0xB04CFF),
	/** Ruh sistemi ve özel saldırılar (Yar Geç, fırlatma). */
	SOUL_RENDER("soul_render", 0x59E6FF);

	public final String id;
	public final int rgb;

	EvolutionPath(String id, int rgb) {
		this.id = id;
		this.rgb = rgb;
	}

	public String nameKey() {
		return "evolution.path." + id;
	}

	public String descriptionKey() {
		return "evolution.path." + id + ".desc";
	}

	public String limitKey() {
		return "evolution.path." + id + ".limit";
	}

	/** Dizinden dal; geçersizse (örn. -1 = seçilmedi) null. */
	public static EvolutionPath byIndex(int index) {
		EvolutionPath[] values = values();
		return index >= 0 && index < values.length ? values[index] : null;
	}
}
