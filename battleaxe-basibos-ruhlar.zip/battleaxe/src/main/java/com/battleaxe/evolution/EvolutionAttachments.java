package com.battleaxe.evolution;

import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

import com.battleaxe.BattleAxeMod;

/**
 * Berserker Evrimi'nin kalıcı verisi OYUNCUYA bağlıdır (dünya kaydıyla yazılır, ölünce kopyalanır).
 * Alanlar isteğe bağlıdır: ileride yeni alan eklenirse eski kayıtlar sorunsuz yüklenir.
 */
public final class EvolutionAttachments {
	private EvolutionAttachments() {
	}

	public static final Codec<EvolutionData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Codec.INT.optionalFieldOf("path", -1).forGetter(EvolutionData::path),
			Codec.DOUBLE.optionalFieldOf("essence", 0.0).forGetter(EvolutionData::essence),
			Codec.INT.listOf().optionalFieldOf("mastery", List.of(0, 0, 0)).forGetter(EvolutionData::mastery),
			Codec.LONG.optionalFieldOf("final_ready", 0L).forGetter(EvolutionData::finalReadyTick),
			Codec.LONG.optionalFieldOf("path_change_ready", 0L).forGetter(EvolutionData::pathChangeReadyTick),
			Codec.LONG.optionalFieldOf("defiance_ready", 0L).forGetter(EvolutionData::defianceReadyTick)
	).apply(instance, EvolutionData::new));

	public static final AttachmentType<EvolutionData> DATA = AttachmentRegistry.create(
			BattleAxeMod.id("evolution"),
			builder -> builder.persistent(CODEC).copyOnDeath()
	);
}
