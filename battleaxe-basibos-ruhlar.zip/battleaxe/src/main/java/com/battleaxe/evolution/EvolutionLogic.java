package com.battleaxe.evolution;

/**
 * Berserker Evrimi'nin SAF mantığı: aşama geçişleri, Savaş Özü kazanım/tüketim hesapları, aşırı yüklenme,
 * ustalık, hasar formülleri ve kural denetimleri. Minecraft'a bağımlı değildir (sadece sayı ve enum alır),
 * böylece oyun olmadan test edilebilir (bkz. tools/test/EvolutionLogicTest.java).
 */
public final class EvolutionLogic {
	private EvolutionLogic() {
	}

	// ------------------------------------------------------------------
	// Aşama geçişi
	// ------------------------------------------------------------------

	/**
	 * @param legacyActive mevcut (eski) Berserker aktif mi (can <= %50 durumu)
	 * @param combat       yakın zamanda savaşılmış mı
	 */
	public record StageInputs(boolean alive, boolean holding, boolean hasPath, boolean legacyActive, boolean combat,
			double essence, Recovery recovery, boolean finalActive) {
	}

	/**
	 * Bir sonraki aşamayı hesaplar. Aşama yalnızca cana bağlı değildir: eski Berserker, Savaş Özü, savaş durumu,
	 * seçili dal ve toparlanma birlikte değerlendirilir. Girişler yüksek, çıkışlar daha düşük eşiktedir (histerezis).
	 * Son Eşik (IV) buradan KENDİLİĞİNDEN açılmaz; yalnızca açık bir eylemle ({@code finalActive}) görülür.
	 */
	public static EvolutionStage nextStage(EvolutionStage previous, StageInputs in) {
		if (!in.alive() || !in.holding()) {
			return EvolutionStage.NONE;
		}
		if (in.finalActive() && in.recovery() == Recovery.NONE) {
			return EvolutionStage.FINAL_THRESHOLD;
		}

		int prev = previous == EvolutionStage.FINAL_THRESHOLD ? 3 : previous.level;
		double e = in.essence();
		int level = 0;

		boolean spark = in.legacyActive()
				|| (in.hasPath() && e >= (prev >= 1 ? EvolutionConfig.SPARK_EXIT : EvolutionConfig.SPARK_ENTER)
						&& (in.combat() || prev >= 1));
		if (spark) {
			level = 1;
		}
		if (level >= 1 && in.hasPath()
				&& e >= (prev >= 2 ? EvolutionConfig.AWAKENING_EXIT : EvolutionConfig.AWAKENING_ENTER)
				&& (in.combat() || prev >= 2)) {
			level = 2;
		}
		if (level >= 2 && e >= (prev >= 3 ? EvolutionConfig.SURGE_EXIT : EvolutionConfig.SURGE_ENTER)
				&& (in.combat() || prev >= 3)) {
			level = 3;
		}

		if (in.recovery() == Recovery.BURNOUT) {
			level = 0;
		} else if (in.recovery() == Recovery.OVERLOAD) {
			level = Math.min(level, 1);
		}
		return EvolutionStage.byLevel(level);
	}

	// ------------------------------------------------------------------
	// Savaş Özü
	// ------------------------------------------------------------------

	/** Bir tick sonraki öz: aşama tüketimi ve savaş dışı doğal azalma. Asla negatif veya MAX üstü olmaz. */
	public static double essenceAfterTick(double essence, int stageLevel, boolean combat, long ticksSinceCombat) {
		double e = essence;
		if (stageLevel == EvolutionStage.AWAKENING.level) {
			e -= EvolutionConfig.AWAKENING_DRAIN_PER_SECOND / 20.0;
		} else if (stageLevel == EvolutionStage.SURGE.level) {
			e -= EvolutionConfig.SURGE_DRAIN_PER_SECOND / 20.0;
		}
		if (!combat && ticksSinceCombat > EvolutionConfig.DECAY_DELAY_TICKS) {
			e -= EvolutionConfig.DECAY_PER_TICK;
		}
		return clamp(e, 0.0, EvolutionConfig.MAX_ESSENCE);
	}

	/** Normal vuruşun özü. Zayıf (düşük şarjlı) vuruş spam'i hiç öz vermez. */
	public static double meleeGain(double strength, double targetMaxHealth, int sameTargetPriorHits,
			double dangerMultiplier, double pathMultiplier) {
		if (strength < EvolutionConfig.MIN_STRENGTH) {
			return 0.0;
		}
		double factor = clamp((strength - EvolutionConfig.MIN_STRENGTH) / (1.0 - EvolutionConfig.MIN_STRENGTH), 0.0, 1.0);
		double weight = clamp(targetMaxHealth / 20.0, EvolutionConfig.TARGET_WEIGHT_MIN, EvolutionConfig.TARGET_WEIGHT_MAX);
		double repeat = Math.max(EvolutionConfig.SAME_TARGET_FLOOR,
				1.0 - EvolutionConfig.SAME_TARGET_STEP * Math.max(0, sameTargetPriorHits));
		return EvolutionConfig.MELEE_BASE * factor * weight * repeat * dangerMultiplier * pathMultiplier;
	}

	public static double killGain(double victimMaxHealth) {
		return EvolutionConfig.KILL_BASE
				+ (victimMaxHealth >= EvolutionConfig.STRONG_ENEMY_HEALTH ? EvolutionConfig.KILL_STRONG_BONUS : 0.0);
	}

	/** Kıyım Zinciri kademe atlama ödülü: kademe başına sabit miktar. Geçersiz kademe öz vermez; en çok 4. kademe sayılır. */
	public static double chainEssence(int tier) {
		return tier <= 0 ? 0.0 : EvolutionConfig.CHAIN_TIER_ESSENCE * Math.min(tier, 4);
	}

	public static double damagedGain(double damage) {
		return Math.min(EvolutionConfig.DAMAGED_CAP, Math.max(0.0, damage) * EvolutionConfig.DAMAGED_FACTOR);
	}

	/** Tehlikede savaşma çarpanı. Son Nefes dalı bunu kendi çarpanıyla DEĞİŞTİRİR (üst üste binmez). */
	public static double dangerMultiplier(EvolutionPath path, double healthRatio) {
		if (healthRatio >= EvolutionConfig.DANGER_RATIO) {
			return 1.0;
		}
		return path == EvolutionPath.LAST_BREATH ? EvolutionConfig.LAST_ESSENCE_LOW_HEALTH_MULT
				: EvolutionConfig.DANGER_MULTIPLIER;
	}

	/** Dalın öz kazanımı çarpanı. */
	public static double pathEssenceMultiplier(EvolutionPath path, int momentum, boolean melee) {
		if (path == EvolutionPath.BLOOD_WHIRL) {
			return 1.0 + Math.min(EvolutionConfig.BLOOD_ESSENCE_CAP, momentum * EvolutionConfig.BLOOD_ESSENCE_PER_STACK);
		}
		if (path == EvolutionPath.SOUL_RENDER && melee) {
			return EvolutionConfig.SOUL_MELEE_ESSENCE_MULT;
		}
		return 1.0;
	}

	/** Kazanım/ustalık hız sınırlayıcısı: sabit pencerede en çok {@code cap} kadar. */
	public static final class WindowLimiter {
		private final int windowTicks;
		private final double cap;
		private long windowStart = Long.MIN_VALUE / 2;
		private double used;

		public WindowLimiter(int windowTicks, double cap) {
			this.windowTicks = windowTicks;
			this.cap = cap;
		}

		/** İstenen miktardan izin verilen kısmı döndürür ve kullanılan toplamı günceller. */
		public double limit(double wanted, long now) {
			if (now - windowStart >= windowTicks) {
				windowStart = now;
				used = 0.0;
			}
			double allowed = Math.max(0.0, Math.min(wanted, cap - used));
			used += allowed;
			return allowed;
		}
	}

	// ------------------------------------------------------------------
	// Aşırı yüklenme
	// ------------------------------------------------------------------

	public static double overloadAfterTick(double overload, int stageLevel) {
		double perSecond;
		if (stageLevel == EvolutionStage.SURGE.level) {
			perSecond = EvolutionConfig.SURGE_OVERLOAD_PER_SECOND;
		} else if (stageLevel == EvolutionStage.AWAKENING.level) {
			perSecond = EvolutionConfig.AWAKENING_OVERLOAD_PER_SECOND;
		} else if (stageLevel == EvolutionStage.FINAL_THRESHOLD.level) {
			perSecond = 0.0;
		} else {
			perSecond = EvolutionConfig.IDLE_OVERLOAD_PER_SECOND;
		}
		return clamp(overload + perSecond / 20.0, 0.0, EvolutionConfig.MAX_OVERLOAD);
	}

	/** Güçlü yetenek (Yar Geç/fırlatma) bedeli: yalnızca Taşkınlık ve üstünde işler. */
	public static double abilityOverload(int stageLevel, double cost) {
		return stageLevel >= EvolutionStage.SURGE.level ? cost : 0.0;
	}

	// ------------------------------------------------------------------
	// Ustalık
	// ------------------------------------------------------------------

	/** Ustalık seviyesi 1..5. */
	public static int masteryLevel(int points) {
		int level = 1;
		for (int i = 1; i < EvolutionConfig.MASTERY_THRESHOLDS.length; i++) {
			if (points >= EvolutionConfig.MASTERY_THRESHOLDS[i]) {
				level = i + 1;
			}
		}
		return level;
	}

	public static double masteryScale(int level) {
		int index = (int) clamp(level - 1, 0, EvolutionConfig.MASTERY_SCALE.length - 1);
		return EvolutionConfig.MASTERY_SCALE[index];
	}

	/** Bir sonraki seviyeye ilerleme 0..1 (son seviyede 1). */
	public static double masteryProgress(int points) {
		int level = masteryLevel(points);
		if (level >= EvolutionConfig.MASTERY_THRESHOLDS.length) {
			return 1.0;
		}
		int low = EvolutionConfig.MASTERY_THRESHOLDS[level - 1];
		int high = EvolutionConfig.MASTERY_THRESHOLDS[level];
		return clamp((points - low) / (double) (high - low), 0.0, 1.0);
	}

	/** Bir sonraki ustalık eşiği; son seviyedeyse -1. */
	public static int nextMasteryThreshold(int points) {
		int level = masteryLevel(points);
		return level >= EvolutionConfig.MASTERY_THRESHOLDS.length ? -1 : EvolutionConfig.MASTERY_THRESHOLDS[level];
	}

	public enum MasteryEvent {
		MELEE_HIT, DAMAGED, DEFIANCE, CLEAVE_HIT, THROW_HIT, STRONG_KILL
	}

	/** Ustalık yalnızca dalın kendi oynanışı için ve aşama >= I iken kazanılır. */
	public static int masteryGain(EvolutionPath path, MasteryEvent event, int momentum, double healthRatio, int stageLevel) {
		if (path == null || stageLevel < 1) {
			return 0;
		}
		return switch (path) {
			case BLOOD_WHIRL -> event == MasteryEvent.MELEE_HIT && momentum >= EvolutionConfig.BLOOD_MASTERY_MIN_MOMENTUM ? 1 : 0;
			case LAST_BREATH -> event == MasteryEvent.DEFIANCE ? 10
					: event == MasteryEvent.DAMAGED && healthRatio < EvolutionConfig.DANGER_RATIO ? 1 : 0;
			case SOUL_RENDER -> switch (event) {
				case CLEAVE_HIT -> 1;
				case THROW_HIT -> 2;
				case STRONG_KILL -> 3;
				default -> 0;
			};
		};
	}

	// ------------------------------------------------------------------
	// Dal etkileri (saf formüller)
	// ------------------------------------------------------------------

	public record DamageContext(boolean cleave, boolean thrown, double healthRatio, int momentum, boolean finalActive,
			Recovery recovery) {
	}

	/** Giden hasar yüzdesi (Ruh Ağı'ndan BAĞIMSIZ, ek). [MIN, MAX] arasına sıkıştırılır. */
	public static double outgoingPct(EvolutionPath path, int stageLevel, int masteryLevel, DamageContext c) {
		double pct = 0.0;
		if (path != null && stageLevel > 0) {
			double mastery = masteryScale(masteryLevel);
			double s = EvolutionStage.byLevel(stageLevel).factor * mastery;
			pct += EvolutionConfig.STAGE_DAMAGE_PCT[stageLevel] * mastery;
			switch (path) {
				case BLOOD_WHIRL -> pct += Math.min(EvolutionConfig.BLOOD_DAMAGE_CAP,
						c.momentum() * EvolutionConfig.BLOOD_DAMAGE_PER_STACK * s);
				case LAST_BREATH -> pct += Math.min(EvolutionConfig.LAST_DAMAGE_CAP,
						missing(c.healthRatio()) * EvolutionConfig.LAST_DAMAGE_PER_MISSING * s);
				case SOUL_RENDER -> {
					if (c.cleave()) {
						pct += Math.min(EvolutionConfig.SOUL_DAMAGE_CAP, EvolutionConfig.SOUL_CLEAVE_DAMAGE * s);
					} else if (c.thrown()) {
						pct += Math.min(EvolutionConfig.SOUL_DAMAGE_CAP, EvolutionConfig.SOUL_THROW_DAMAGE * s);
					}
				}
			}
			if (c.finalActive()) {
				switch (path) {
					case BLOOD_WHIRL -> pct += EvolutionConfig.BLOOD_FINAL_DAMAGE_BONUS;
					case LAST_BREATH -> pct += EvolutionConfig.LAST_FINAL_DAMAGE_BONUS;
					case SOUL_RENDER -> pct += (c.cleave() || c.thrown()) ? EvolutionConfig.SOUL_FINAL_ABILITY_DAMAGE : 0.0;
				}
			}
		}
		if (c.recovery() != Recovery.NONE) {
			pct -= EvolutionConfig.RECOVERY_DAMAGE_PENALTY;
		}
		return clamp(pct, EvolutionConfig.OUTGOING_DAMAGE_PCT_MIN, EvolutionConfig.OUTGOING_DAMAGE_PCT_MAX);
	}

	/** Gelen hasar azaltması (%), en çok {@link EvolutionConfig#INCOMING_REDUCTION_CAP}. */
	public static double incomingReductionPct(EvolutionPath path, int stageLevel, int masteryLevel, double healthRatio,
			boolean finalActive, boolean graceActive) {
		double reduction = 0.0;
		if (path == EvolutionPath.LAST_BREATH && stageLevel > 0) {
			double s = EvolutionStage.byLevel(stageLevel).factor * masteryScale(masteryLevel);
			reduction += Math.min(EvolutionConfig.LAST_REDUCTION_CAP,
					missing(healthRatio) * EvolutionConfig.LAST_REDUCTION_PER_MISSING * s);
			if (finalActive) {
				reduction += EvolutionConfig.LAST_FINAL_REDUCTION;
			}
		}
		if (graceActive) {
			reduction += EvolutionConfig.DEFIANCE_GRACE_REDUCTION;
		}
		return Math.min(reduction, EvolutionConfig.INCOMING_REDUCTION_CAP);
	}

	/** Gelen hasara EK yüzde (sınırlamalar: Kan Kasırgası savunmasızlığı, toparlanma). */
	public static double incomingExtraPct(EvolutionPath path, int stageLevel, int masteryLevel, Recovery recovery) {
		double extra = 0.0;
		if (path == EvolutionPath.BLOOD_WHIRL && stageLevel > 0) {
			double s = EvolutionStage.byLevel(stageLevel).factor * masteryScale(masteryLevel);
			extra += Math.min(EvolutionConfig.BLOOD_INCOMING_EXTRA_CAP, EvolutionConfig.BLOOD_INCOMING_EXTRA * s);
		}
		if (recovery != Recovery.NONE) {
			extra += EvolutionConfig.RECOVERY_INCOMING_EXTRA;
		}
		return extra;
	}

	/** Saldırı hızı yüzdesi (özniteliğe yazılır). */
	public static double attackSpeedPct(EvolutionPath path, int stageLevel, int masteryLevel, int momentum, Recovery recovery,
			boolean legacyActive) {
		double pct = 0.0;
		if (path != null && stageLevel > 0) {
			double mastery = masteryScale(masteryLevel);
			double s = EvolutionStage.byLevel(stageLevel).factor * mastery;
			pct += EvolutionConfig.STAGE_ATTACK_SPEED_PCT[stageLevel] * mastery;
			if (path == EvolutionPath.BLOOD_WHIRL) {
				pct += Math.min(EvolutionConfig.BLOOD_ATTACK_SPEED_CAP, momentum * EvolutionConfig.BLOOD_ATTACK_SPEED_PER_STACK * s);
			}
			if (legacyActive) {
				pct *= EvolutionConfig.LEGACY_ATTACK_SPEED_SCALE;
			}
		}
		if (recovery == Recovery.OVERLOAD) {
			pct -= EvolutionConfig.OVERLOAD_ATTACK_SPEED_PENALTY;
		} else if (recovery == Recovery.BURNOUT) {
			pct -= EvolutionConfig.BURNOUT_ATTACK_SPEED_PENALTY;
		}
		return clamp(pct, EvolutionConfig.ATTACK_SPEED_PCT_MIN, EvolutionConfig.ATTACK_SPEED_PCT_MAX);
	}

	public static double movementPct(Recovery recovery) {
		return recovery == Recovery.NONE ? 0.0 : -EvolutionConfig.RECOVERY_MOVE_PENALTY;
	}

	/** Ruh Yırtıcısı: kill'in ruh ödülüne EKLENEN düz bonus (ayrı bir ödül değildir). */
	public static int soulBonus(EvolutionPath path, int stageLevel, int baseValue) {
		if (path != EvolutionPath.SOUL_RENDER || baseValue < EvolutionConfig.SOUL_BONUS_MIN_BASE_VALUE) {
			return 0;
		}
		if (stageLevel >= EvolutionStage.SURGE.level) {
			return 2;
		}
		return stageLevel >= EvolutionStage.AWAKENING.level ? 1 : 0;
	}

	/** Ruh Yırtıcısı Son Eşik'i: Yar Geç beklemesi kısalır. Asla {@code minTicks} altına ve asla başlangıçtan uzuna çıkmaz. */
	public static int cleaveCooldownTicks(int ticks, EvolutionPath path, boolean finalActive, int minTicks) {
		if (path != EvolutionPath.SOUL_RENDER || !finalActive) {
			return ticks;
		}
		int reduced = (int) Math.round(ticks * (1.0 - EvolutionConfig.SOUL_FINAL_COOLDOWN_REDUCTION / 100.0));
		return Math.max(Math.min(ticks, minTicks), reduced);
	}

	/** Kan Kasırgası ivmesinin aldığı yeni değer. {@code hit}: vuruş isabetli mi; {@code strength}: saldırı gücü. */
	public static int momentumAfterHit(int momentum, double strength) {
		if (strength >= EvolutionConfig.MOMENTUM_MIN_STRENGTH) {
			return Math.min(EvolutionConfig.MOMENTUM_MAX, momentum + 1);
		}
		return Math.max(0, momentum - 1);
	}

	/** İvmenin zamanla çözülmesi: son vuruştan gecikme sonra her aralıkta 1 azalır; Son Eşik'te taban korunur. */
	public static int momentumAfterTick(int momentum, long now, long lastHitTick, boolean finalActive) {
		int floor = finalActive ? EvolutionConfig.BLOOD_FINAL_MOMENTUM_FLOOR : 0;
		if (momentum <= floor) {
			return Math.max(momentum, finalActive ? floor : momentum);
		}
		long idle = now - lastHitTick;
		if (idle > EvolutionConfig.MOMENTUM_DECAY_DELAY_TICKS && now % EvolutionConfig.MOMENTUM_DECAY_INTERVAL_TICKS == 0) {
			return Math.max(floor, momentum - 1);
		}
		return momentum;
	}

	// ------------------------------------------------------------------
	// Kurallar
	// ------------------------------------------------------------------

	public enum FinalCheck {
		OK, NO_PATH, NOT_HOLDING, STAGE_TOO_LOW, NOT_ENOUGH_ESSENCE, COOLDOWN, RECOVERING, OVERLOADED, ALREADY_ACTIVE
	}

	/** Son Eşik'in başlatılabilmesi için tüm açık koşullar. */
	public static FinalCheck canStartFinal(boolean hasPath, boolean holding, EvolutionStage stage, double essence, long now,
			long readyTick, Recovery recovery, double overload, boolean alreadyActive) {
		if (alreadyActive) {
			return FinalCheck.ALREADY_ACTIVE;
		}
		if (!hasPath) {
			return FinalCheck.NO_PATH;
		}
		if (!holding) {
			return FinalCheck.NOT_HOLDING;
		}
		if (recovery != Recovery.NONE) {
			return FinalCheck.RECOVERING;
		}
		if (stage.level < EvolutionStage.SURGE.level) {
			return FinalCheck.STAGE_TOO_LOW;
		}
		if (now < readyTick) {
			return FinalCheck.COOLDOWN;
		}
		if (essence < EvolutionConfig.FINAL_COST) {
			return FinalCheck.NOT_ENOUGH_ESSENCE;
		}
		if (overload > EvolutionConfig.FINAL_MAX_OVERLOAD_TO_START) {
			return FinalCheck.OVERLOADED;
		}
		return FinalCheck.OK;
	}

	public enum PathChange {
		OK, SAME, IN_USE, COMBAT, COOLDOWN, INVALID
	}

	/** Dal değişikliği kuralları: ilk seçim serbest; sonrası aşama dışında, savaş dışında ve bekleme sonrası. */
	public static PathChange canChangePath(int currentPath, int newPath, EvolutionStage stage, boolean combat, long now,
			long readyTick) {
		if (EvolutionPath.byIndex(newPath) == null) {
			return PathChange.INVALID;
		}
		if (newPath == currentPath) {
			return PathChange.SAME;
		}
		if (currentPath < 0) {
			return PathChange.OK;
		}
		if (stage != EvolutionStage.NONE) {
			return PathChange.IN_USE;
		}
		if (combat) {
			return PathChange.COMBAT;
		}
		return now < readyTick ? PathChange.COOLDOWN : PathChange.OK;
	}

	/** Son Nefes'in ölümden kurtarması mümkün mü? (Sınırsız ölümsüzlük yok: bekleme + öz bedeli.) */
	public static boolean canDefy(EvolutionPath path, int stageLevel, double essence, long now, long readyTick) {
		return path == EvolutionPath.LAST_BREATH && stageLevel >= 1 && essence >= EvolutionConfig.DEFIANCE_COST
				&& now >= readyTick;
	}

	// ------------------------------------------------------------------

	private static double missing(double healthRatio) {
		return clamp(1.0 - healthRatio, 0.0, 1.0);
	}

	public static double clamp(double value, double min, double max) {
		return Math.max(min, Math.min(max, value));
	}
}
