package com.battleaxe.evolution;

/** Berserker Evrimi aşamaları. {@code factor}: dal etkilerinin aşamaya göre ölçeği. */
public enum EvolutionStage {
	NONE(0, 0.0),
	/** Aşama I - Kıvılcım */
	SPARK(1, 0.5),
	/** Aşama II - Uyanış */
	AWAKENING(2, 1.0),
	/** Aşama III - Taşkınlık */
	SURGE(3, 1.6),
	/** Aşama IV - Son Eşik */
	FINAL_THRESHOLD(4, 2.4);

	public final int level;
	public final double factor;

	EvolutionStage(int level, double factor) {
		this.level = level;
		this.factor = factor;
	}

	public String nameKey() {
		return "evolution.stage." + level;
	}

	public static EvolutionStage byLevel(int level) {
		for (EvolutionStage stage : values()) {
			if (stage.level == level) {
				return stage;
			}
		}
		return NONE;
	}
}
