package com.battleaxe.evolution;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan oyuncunun KENDİ istemcisine: HUD ve ekran için Berserker Evrimi özeti (yalnızca gösterim).
 * Alanlar, sıkıştırılmış kodek sınırlarını aşmamak için üç küçük kayıtta gruplanır.
 * Süreler tick cinsinden KALAN değerlerdir; istemci geri sayımı kendisi sürdürür.
 */
public record EvolutionSyncPayload(Core core, Timers timers, Mastery mastery) implements CustomPacketPayload {
	public static final int FLAG_ARMED = 1;
	public static final int FLAG_LEGACY = 2;

	public record Core(int path, int stage, int essence, int overload, int recovery, int momentum) {
		public static final StreamCodec<io.netty.buffer.ByteBuf, Core> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, Core::path,
				ByteBufCodecs.VAR_INT, Core::stage,
				ByteBufCodecs.VAR_INT, Core::essence,
				ByteBufCodecs.VAR_INT, Core::overload,
				ByteBufCodecs.VAR_INT, Core::recovery,
				ByteBufCodecs.VAR_INT, Core::momentum,
				Core::new);
	}

	public record Timers(int finalActiveLeft, int finalCooldownLeft, int pathCooldownLeft, int recoveryLeft, int flags) {
		public static final StreamCodec<io.netty.buffer.ByteBuf, Timers> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, Timers::finalActiveLeft,
				ByteBufCodecs.VAR_INT, Timers::finalCooldownLeft,
				ByteBufCodecs.VAR_INT, Timers::pathCooldownLeft,
				ByteBufCodecs.VAR_INT, Timers::recoveryLeft,
				ByteBufCodecs.VAR_INT, Timers::flags,
				Timers::new);
	}

	public record Mastery(int blood, int breath, int soul) {
		public static final StreamCodec<io.netty.buffer.ByteBuf, Mastery> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, Mastery::blood,
				ByteBufCodecs.VAR_INT, Mastery::breath,
				ByteBufCodecs.VAR_INT, Mastery::soul,
				Mastery::new);

		public int of(EvolutionPath path) {
			return switch (path) {
				case BLOOD_WHIRL -> blood;
				case LAST_BREATH -> breath;
				case SOUL_RENDER -> soul;
			};
		}
	}

	public static final CustomPacketPayload.Type<EvolutionSyncPayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("evolution_sync"));

	public static final StreamCodec<RegistryFriendlyByteBuf, EvolutionSyncPayload> CODEC = StreamCodec.composite(
			Core.CODEC, EvolutionSyncPayload::core,
			Timers.CODEC, EvolutionSyncPayload::timers,
			Mastery.CODEC, EvolutionSyncPayload::mastery,
			EvolutionSyncPayload::new);

	public boolean armed() {
		return (timers.flags() & FLAG_ARMED) != 0;
	}

	public boolean legacy() {
		return (timers.flags() & FLAG_LEGACY) != 0;
	}

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
