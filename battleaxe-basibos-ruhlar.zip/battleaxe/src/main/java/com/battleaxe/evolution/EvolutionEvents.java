package com.battleaxe.evolution;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;

import com.battleaxe.evolution.EvolutionLogic.MasteryEvent;
import com.battleaxe.nexus.NexusConfig;

/**
 * Mevcut sistemlerin (vanilla saldırı, Yar Geç, fırlatma, ruh kazanımı) Berserker Evrimi'ne bağlandığı
 * küçük, genel API. Her olay kendi kaynağında TEK SEFER çağrılır; burada ayrıca kopya olaylar (aynı hedef,
 * aynı tick) elenir. Hiçbir hasar tetiklenmez, hiçbir ruh/XP ödülü burada verilmez.
 */
public final class EvolutionEvents {
	private EvolutionEvents() {
	}

	/** Savaş Özü / ustalık kazandıran düşman mı? (yalnızca canavar kategorisi; oyuncular ve evcil hayvanlar değil.) */
	public static boolean isEnemy(Entity entity) {
		return entity instanceof LivingEntity && !(entity instanceof Player)
				&& entity.getType().getCategory() == MobCategory.MONSTER;
	}

	/** PlayerMixin#attack başında: bu saldırının şarj durumunu kaydeder (zayıf vuruş spam'i öz vermez). */
	public static void beginAttack(ServerPlayer player, Entity target) {
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		rt.attackTick = player.level().getGameTime();
		rt.attackTargetId = target.getId();
		rt.attackStrength = player.getAttackStrengthScale(0.5F);
	}

	/** Başarılı yakın dövüş vuruşu (vanilla'nın saldırı efekti çağrısı = vuruş isabet etti). */
	public static void onMeleeHit(ServerPlayer player, Entity target, boolean critical) {
		if (!isEnemy(target)) {
			return;
		}
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		long now = player.level().getGameTime();
		if (rt.hitKeyTick == now && rt.hitKeyTarget == target.getId()) {
			return; // aynı tick'te aynı hedefe ikinci işleme
		}
		rt.hitKeyTick = now;
		rt.hitKeyTarget = target.getId();
		rt.lastCombatTick = now;

		double strength = rt.attackTick == now && rt.attackTargetId == target.getId() ? rt.attackStrength : 1.0;

		long[] record = rt.targetHits.get(target.getId());
		int prior = record != null && now - record[1] <= EvolutionConfig.SAME_TARGET_WINDOW_TICKS ? (int) record[0] : 0;
		rt.targetHits.put(target.getId(), new long[] {prior + 1, now});

		EvolutionPath path = rt.path();
		if (path == EvolutionPath.BLOOD_WHIRL) {
			rt.momentum = EvolutionLogic.momentumAfterHit(rt.momentum, strength);
			rt.lastHitTick = now;
		}

		double healthRatio = EvolutionManager.healthRatio(player);
		double gain = EvolutionLogic.meleeGain(strength, ((LivingEntity) target).getMaxHealth(), prior,
				EvolutionLogic.dangerMultiplier(path, healthRatio),
				EvolutionLogic.pathEssenceMultiplier(path, rt.momentum, true));
		EvolutionManager.addEssence(rt, gain, now);
		EvolutionManager.addMastery(player, rt, MasteryEvent.MELEE_HIT, healthRatio, now);

		if (path != null && rt.stage.level > 0 && player.level() instanceof ServerLevel level) {
			EvolutionEffects.hit(level, target, path, rt.momentum, critical);
		}
	}

	/**
	 * Yar Geç bitti. {@code enemyHits}: vurulan DÜŞMAN (canavar) sayısı; pasif hayvanlara vurmak öz/ustalık vermez.
	 * Aşırı yüklenme bedeli, isabet olsun olmasın yeteneğin kullanımına bağlıdır.
	 */
	public static void onCleave(ServerPlayer player, int enemyHits) {
		int hits = enemyHits;
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		long now = player.level().getGameTime();
		rt.overload = Math.min(EvolutionConfig.MAX_OVERLOAD, rt.overload
				+ EvolutionLogic.abilityOverload(rt.stage.level, EvolutionConfig.CLEAVE_OVERLOAD));
		if (hits <= 0) {
			return;
		}
		rt.lastCombatTick = now;
		boolean soul = rt.path() == EvolutionPath.SOUL_RENDER;
		int counted = Math.min(hits, EvolutionConfig.CLEAVE_GAIN_MAX_TARGETS);
		EvolutionManager.addEssence(rt, counted * (EvolutionConfig.CLEAVE_HIT_GAIN
				+ (soul ? EvolutionConfig.SOUL_CLEAVE_EXTRA_GAIN : 0.0)), now);
		for (int i = 0; i < counted; i++) {
			EvolutionManager.addMastery(player, rt, MasteryEvent.CLEAVE_HIT, EvolutionManager.healthRatio(player), now);
		}
	}

	/** Balta fırlatıldı. */
	public static void onThrow(ServerPlayer player) {
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		rt.overload = Math.min(EvolutionConfig.MAX_OVERLOAD, rt.overload
				+ EvolutionLogic.abilityOverload(rt.stage.level, EvolutionConfig.THROW_OVERLOAD));
	}

	/** Fırlatılan balta bir düşmana hasar verdi (balta başına tek hasar: ThrownBattleAxe#dealtDamage). */
	public static void onThrowHit(ServerPlayer player, Entity target) {
		if (!isEnemy(target)) {
			return;
		}
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		long now = player.level().getGameTime();
		rt.lastCombatTick = now;
		boolean soul = rt.path() == EvolutionPath.SOUL_RENDER;
		EvolutionManager.addEssence(rt, EvolutionConfig.THROW_HIT_GAIN
				+ (soul ? EvolutionConfig.SOUL_THROW_EXTRA_GAIN : 0.0), now);
		EvolutionManager.addMastery(player, rt, MasteryEvent.THROW_HIT, EvolutionManager.healthRatio(player), now);
	}

	/**
	 * Ruh kazanımına EKLENECEK düz bonus (SoulManager, ruh ağı bonusuyla aynı kill olayında çağırır):
	 * ayrı bir ödül değil, aynı ödülün içindeki ek miktardır.
	 */
	public static int soulBonus(ServerPlayer player, LivingEntity victim, int baseValue) {
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		return rt.armed ? EvolutionLogic.soulBonus(rt.path(), rt.stage.level, baseValue) : 0;
	}

	/** Öldürme tamamlandı (ruh ödülü verildi). Aynı varlık yalnızca bir kez işlenir. */
	public static void onKill(ServerPlayer player, LivingEntity victim, int baseValue) {
		if (!isEnemy(victim)) {
			return;
		}
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		if (!rt.markKill(victim.getUUID())) {
			return;
		}
		long now = player.level().getGameTime();
		rt.lastCombatTick = now;
		EvolutionManager.addEssence(rt, EvolutionLogic.killGain(victim.getMaxHealth()), now);
		if (victim.getMaxHealth() >= EvolutionConfig.STRONG_ENEMY_HEALTH) {
			EvolutionManager.addMastery(player, rt, MasteryEvent.STRONG_KILL, EvolutionManager.healthRatio(player), now);
		}
	}

	/**
	 * Kıyım Zinciri bir kademe atladı (ChainManager çağırır): kademe başına küçük bir Savaş Özü. Normal kazanım
	 * sınırlayıcısından geçer; savaşta sayılır (öz hemen azalmaya başlamaz). Hiçbir hasar/ruh/XP ödülü vermez.
	 */
	public static void onChainTierUp(ServerPlayer player, int tier) {
		double gain = EvolutionLogic.chainEssence(tier);
		if (gain <= 0.0) {
			return;
		}
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		long now = player.level().getGameTime();
		rt.lastCombatTick = now;
		EvolutionManager.addEssence(rt, gain, now);
	}

	/** Eski Berserker yıldırımını evrim aşamasıyla güçlendirir (yalnızca olasılık bonusu). */
	public static double lightningChanceBonus(ServerPlayer player) {
		return 0.05 * EvolutionManager.stageLevel(player);
	}

	/** Yar Geç bekleme süresi için son düzeltme (Ruh Yırtıcısı Son Eşik'i). Asla minimumun altına inmez. */
	public static int adjustCleaveCooldown(ServerPlayer player, int ticks) {
		EvolutionRuntime rt = EvolutionManager.runtime(player);
		return EvolutionLogic.cleaveCooldownTicks(ticks, rt.path(), rt.finalActive(), NexusConfig.CLEAVE_MIN_COOLDOWN_TICKS);
	}
}
