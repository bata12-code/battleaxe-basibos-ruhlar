package com.battleaxe.evolution;

import java.util.ArrayList;
import java.util.List;

/**
 * Bir OYUNCUNUN kalıcı Berserker Evrimi verisi (değişmez kayıt). Ruh Ağı gibi baltaya değil oyuncuya bağlıdır:
 * balta el değiştirse ya da çoğalsa bile ilerleme çoğalmaz.
 *
 * @param path               seçili dal dizini (-1 = seçilmedi)
 * @param essence            Savaş Özü (0..MAX)
 * @param mastery            dal başına ustalık puanı (EvolutionPath sırasıyla; hiç azalmaz)
 * @param finalReadyTick     Son Eşik'in yeniden kullanılabileceği oyun zamanı
 * @param pathChangeReadyTick dal değişikliğinin yeniden yapılabileceği oyun zamanı
 * @param defianceReadyTick  Son Nefes ölümden kurtulmasının yeniden kullanılabileceği oyun zamanı
 */
public record EvolutionData(int path, double essence, List<Integer> mastery, long finalReadyTick,
		long pathChangeReadyTick, long defianceReadyTick) {
	public static final EvolutionData EMPTY = new EvolutionData(-1, 0.0, List.of(0, 0, 0), 0L, 0L, 0L);

	public EvolutionData {
		path = EvolutionPath.byIndex(path) == null ? -1 : path;
		essence = Double.isFinite(essence) ? Math.max(0.0, Math.min(EvolutionConfig.MAX_ESSENCE, essence)) : 0.0;
		List<Integer> fixed = new ArrayList<>(EvolutionPath.values().length);
		for (int i = 0; i < EvolutionPath.values().length; i++) {
			int value = i < mastery.size() && mastery.get(i) != null ? mastery.get(i) : 0;
			fixed.add(Math.max(0, value));
		}
		mastery = List.copyOf(fixed);
		finalReadyTick = Math.max(0L, finalReadyTick);
		pathChangeReadyTick = Math.max(0L, pathChangeReadyTick);
		defianceReadyTick = Math.max(0L, defianceReadyTick);
	}

	public EvolutionPath pathOrNull() {
		return EvolutionPath.byIndex(path);
	}

	public int masteryPoints(EvolutionPath p) {
		return p == null ? 0 : mastery.get(p.ordinal());
	}

	public EvolutionData withPath(int newPath) {
		return new EvolutionData(newPath, essence, mastery, finalReadyTick, pathChangeReadyTick, defianceReadyTick);
	}

	public EvolutionData withEssence(double value) {
		return new EvolutionData(path, value, mastery, finalReadyTick, pathChangeReadyTick, defianceReadyTick);
	}

	public EvolutionData withMastery(EvolutionPath p, int points) {
		List<Integer> next = new ArrayList<>(mastery);
		next.set(p.ordinal(), points);
		return new EvolutionData(path, essence, next, finalReadyTick, pathChangeReadyTick, defianceReadyTick);
	}

	public EvolutionData withFinalReady(long tick) {
		return new EvolutionData(path, essence, mastery, tick, pathChangeReadyTick, defianceReadyTick);
	}

	public EvolutionData withPathChangeReady(long tick) {
		return new EvolutionData(path, essence, mastery, finalReadyTick, tick, defianceReadyTick);
	}

	public EvolutionData withDefianceReady(long tick) {
		return new EvolutionData(path, essence, mastery, finalReadyTick, pathChangeReadyTick, tick);
	}
}
