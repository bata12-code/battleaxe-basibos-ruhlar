package com.battleaxe.evolution;

/** Toparlanma türü: aşırı yüklenme sonrası veya Son Eşik sonrası. */
public enum Recovery {
	NONE,
	/** Aşırı yüklenme sınırına ulaşıldı: aşama en fazla I'e iner. */
	OVERLOAD,
	/** Son Eşik bitti: geçici güç düşüşü, evrim bonusu yok. */
	BURNOUT;

	public static Recovery byOrdinal(int ordinal) {
		Recovery[] values = values();
		return ordinal >= 0 && ordinal < values.length ? values[ordinal] : NONE;
	}
}
