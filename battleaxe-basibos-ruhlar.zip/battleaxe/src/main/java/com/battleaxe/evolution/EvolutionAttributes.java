package com.battleaxe.evolution;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import com.battleaxe.BattleAxeMod;

/**
 * Berserker Evrimi'nin öznitelik etkileri (saldırı hızı, hareket). Sabit kimlikli geçici modifier'lar:
 * birikmez, kayda yazılmaz. Yalnızca durum değiştiğinde çağrılır.
 */
final class EvolutionAttributes {
	private EvolutionAttributes() {
	}

	private static final Identifier ATTACK_SPEED = BattleAxeMod.id("evolution_attack_speed");
	private static final Identifier MOVE_SPEED = BattleAxeMod.id("evolution_move_speed");

	/** @param attackSpeed oran (0.1 = +%10, negatif ceza); @param move oran */
	static void apply(ServerPlayer player, double attackSpeed, double move) {
		set(player.getAttribute(Attributes.ATTACK_SPEED), ATTACK_SPEED, attackSpeed);
		set(player.getAttribute(Attributes.MOVEMENT_SPEED), MOVE_SPEED, move);
	}

	private static void set(AttributeInstance attribute, Identifier id, double amount) {
		if (attribute == null) {
			return;
		}
		AttributeModifier existing = attribute.getModifier(id);
		if (Math.abs(amount) < 1.0E-9) {
			if (existing != null) {
				attribute.removeModifier(id);
			}
			return;
		}
		if (existing != null) {
			if (Math.abs(existing.amount() - amount) < 1.0E-9) {
				return;
			}
			attribute.removeModifier(id);
		}
		attribute.addTransientModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
	}
}
