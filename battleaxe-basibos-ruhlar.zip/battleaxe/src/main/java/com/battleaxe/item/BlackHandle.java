package com.battleaxe.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.util.Unit;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.component.ModComponents;

/** Kara Çubuk sap yükseltmesi: görünüm bayrağı + gerçek kırılmazlık (vanilla UNBREAKABLE). */
public final class BlackHandle {
	private BlackHandle() {
	}

	public static boolean isUpgraded(ItemStack stack) {
		return stack.has(ModComponents.BLACK_HANDLE);
	}

	/** Mevcut baltanın TÜM bileşenlerini (ruh, rütbe, büyü, ad...) koruyarak yükseltilmiş bir kopya döndürür. */
	public static ItemStack upgraded(ItemStack axe) {
		ItemStack result = axe.copy();
		result.setCount(1);
		result.set(ModComponents.BLACK_HANDLE, Boolean.TRUE);
		result.set(DataComponents.UNBREAKABLE, Unit.INSTANCE);
		return result;
	}

	/** Yükseltilmiş balta kırılmazlığını kaybetmişse geri verir; zaten doğruysa hiçbir şey yazmaz. */
	public static void ensureUnbreakable(ItemStack stack) {
		if (isUpgraded(stack) && !stack.has(DataComponents.UNBREAKABLE)) {
			stack.set(DataComponents.UNBREAKABLE, Unit.INSTANCE);
		}
	}
}
