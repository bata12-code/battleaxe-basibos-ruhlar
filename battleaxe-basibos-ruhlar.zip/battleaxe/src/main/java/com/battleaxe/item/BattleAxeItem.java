package com.battleaxe.item;

import java.util.Locale;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.component.ModComponents;
import com.battleaxe.nexus.NexusSoul;
import com.battleaxe.soul.RankAppearance;
import com.battleaxe.soul.SoulLogic;
import com.battleaxe.soul.SoulText;
import com.battleaxe.yargec.YarGec;
import com.battleaxe.yargec.YarGecAttack;
import com.battleaxe.yargec.YarGecConfig;
import com.battleaxe.yargec.YarGecEffects;

/**
 * Savaş Baltası. Normal özellikleri (hasar, hız, kılıç davranışı) ModItems'taki Item.Properties'ten gelir.
 * Bu sınıf yalnızca "Yar Geç" büyülü balta için sağ tık şarj saldırısını ekler; büyü yoksa
 * davranış tamamen vanilla kalır.
 */
public class BattleAxeItem extends Item {
	public BattleAxeItem(Properties properties) {
		super(properties);
	}

	/** Sağ tık basıldı: Yar Geç varsa şarjı başlat (yay çekmek gibi). */
	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (YarGec.has(stack, level)) {
			player.startUsingItem(hand);
			return InteractionResult.CONSUME;
		}
		return super.use(level, player, hand);
	}

	@Override
	public int getUseDuration(ItemStack stack, LivingEntity entity) {
		return YarGec.has(stack, entity.level()) ? YarGecConfig.USE_DURATION_TICKS : super.getUseDuration(stack, entity);
	}

	@Override
	public ItemUseAnimation getUseAnimation(ItemStack stack) {
		// Şarj sırasında baltayı kaldırılmış tutma pozu.
		return ItemUseAnimation.BLOCK;
	}

	/** Şarj sürerken (her tick): sunucu, şarjla yoğunlaşan parçacıkları gönderir. */
	@Override
	public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int ticksRemaining) {
		if (level instanceof ServerLevel serverLevel && entity instanceof ServerPlayer player) {
			int used = getUseDuration(stack, entity) - ticksRemaining;
			YarGecEffects.charging(serverLevel, player, used);
		}
	}

	/** Sağ tık bırakıldı: saldırı bir kez gerçekleşir. */
	@Override
	public boolean releaseUsing(ItemStack stack, Level level, LivingEntity entity, int ticksRemaining) {
		if (level instanceof ServerLevel serverLevel && entity instanceof ServerPlayer player) {
			int used = getUseDuration(stack, entity) - ticksRemaining;
			return YarGecAttack.perform(serverLevel, player, stack, used);
		}
		return false;
	}

	/**
	 * Tooltip: epik hikâye metni, baltanın rütbeye göre değişen sesi, "Ruh Bağı" rütben, ruhdaşının adı,
	 * rütbe gücü ve yetenek ipuçları. Tüm metinler dil dosyalarındadır (assets/battleaxe/lang).
	 */
	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay display,
			Consumer<Component> lines, TooltipFlag flag) {
		super.appendHoverText(stack, context, display, lines, flag);

		int souls = stack.getOrDefault(ModComponents.SOULS, 0);
		int rank = SoulLogic.rank(souls);
		int next = SoulLogic.nextThreshold(souls);

		lines.accept(Component.empty());
		for (int i = 1; i <= 3; i++) {
			lines.accept(Component.translatable("item.battleaxe.battle_axe.lore." + i)
					.withStyle(ChatFormatting.DARK_PURPLE).withStyle(ChatFormatting.ITALIC));
		}
		if (stack.has(ModComponents.BLACK_HANDLE)) {
			lines.accept(Component.translatable("item.battleaxe.battle_axe.black_handle")
					.withStyle(ChatFormatting.DARK_GRAY).withStyle(ChatFormatting.ITALIC));
		}
		// Baltanın sana karşı tavrı rütbeyle değişir: yabancıdan ruh eşine.
		lines.accept(Component.translatable("item.battleaxe.battle_axe.whisper." + rank)
				.withStyle(SoulText.rankColor(rank)).withStyle(ChatFormatting.ITALIC));

		lines.accept(Component.empty());
		String progress = next < 0 ? "(" + souls + " ruh)" : "(" + souls + "/" + next + ")";
		lines.accept(Component.translatable("item.battleaxe.battle_axe.souls",
				SoulText.rankName(rank),
				Component.literal(progress).withStyle(ChatFormatting.DARK_GRAY)).withStyle(ChatFormatting.GRAY));

		String owner = stack.get(ModComponents.OWNER);
		if (rank >= 1 && owner != null) {
			lines.accept(Component.translatable("item.battleaxe.battle_axe.owner",
					Component.literal(owner).withStyle(SoulText.rankColor(rank))).withStyle(ChatFormatting.GRAY));
		}
		if (rank >= 1) {
			lines.accept(Component.translatable("item.battleaxe.battle_axe.power",
					String.format(Locale.ROOT, "%.1f", SoulLogic.damageBonus(rank)),
					String.format(Locale.ROOT, "%d", Math.round(SoulLogic.attackSpeedBonus(rank) * 100.0)))
					.withStyle(ChatFormatting.DARK_GREEN));
		}

		lines.accept(Component.empty());
		lines.accept(Component.translatable("item.battleaxe.battle_axe.berserk").withStyle(ChatFormatting.DARK_RED));
		lines.accept(Component.translatable("item.battleaxe.battle_axe.cleave").withStyle(ChatFormatting.DARK_GRAY));
		lines.accept(Component.translatable("item.battleaxe.battle_axe.throw").withStyle(ChatFormatting.DARK_GRAY));
		lines.accept(Component.translatable("item.battleaxe.battle_axe.shunpo").withStyle(ChatFormatting.DARK_GRAY));
		lines.accept(Component.translatable("item.battleaxe.battle_axe.nexus", Component.keybind("key.battleaxe.nexus"))
				.withStyle(ChatFormatting.DARK_AQUA));
	}

	/**
	 * Berserker aktifken ve balta ana eldeyken eşyaya görünüm bayrağı ekler, aksi halde kaldırır.
	 * Item modeli bu bayrağa göre alevli modele geçer. Bayrak yoksa/varsa tekrar tekrar yazılmaz.
	 */
	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);

		// Rütbeye göre görünüm (model) ve ad; zaten doğruysa hiçbir şey yazılmaz.
		RankAppearance.sync(stack, SoulLogic.rank(stack.getOrDefault(ModComponents.SOULS, 0)));

		// Kara Çubuk yükseltmesi kalıcıdır: kırılmazlık bir şekilde silindiyse geri yazılır.
		BlackHandle.ensureUnbreakable(stack);

		// Ruh Ağı: baltanın eski ruhları, balta başına bir kez oyuncunun ağ defterine işlenir.
		if (entity instanceof ServerPlayer owner && !stack.has(ModComponents.NEXUS_CLAIMED)) {
			NexusSoul.claimLegacy(owner, stack);
		}

		boolean berserk = slot == EquipmentSlot.MAINHAND
				&& entity instanceof ServerPlayer player
				&& BerserkerManager.isActive(player);

		if (berserk != stack.has(ModComponents.BERSERK)) {
			if (berserk) {
				stack.set(ModComponents.BERSERK, Boolean.TRUE);
			} else {
				stack.remove(ModComponents.BERSERK);
			}
		}
	}
}
