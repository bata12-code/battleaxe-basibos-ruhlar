package com.battleaxe.item;

import java.util.function.Function;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.block.Block;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

import com.battleaxe.BattleAxeMod;

public final class ModItems {
	private ModItems() {
	}

	// ------------------------------------------------------------------
	// AYARLAR - baltayı dengelemek için sadece bu değerleri değiştir
	// ------------------------------------------------------------------

	/** Tooltip'te görünen TOPLAM hasar (oyuncunun 1 puanlık yumruk hasarı dahil). */
	public static final float ATTACK_DAMAGE = 16.0F;

	/**
	 * Saniyedeki saldırı sayısı. Referans: vanilla kılıç 1.6, netherit balta 1.0.
	 * Değer düştükçe balta yavaşlar (0.8 = tam güçte vuruş için yaklaşık 1.25 sn).
	 */
	public static final float ATTACK_SPEED = 0.8F;

	/** Dayanıklılık (netherit kılıç: 2031). */
	public static final int DURABILITY = 2500;

	// ------------------------------------------------------------------
	// Tag'ler (içerikleri data/battleaxe/tags/ altındaki JSON dosyalarında)
	// ------------------------------------------------------------------

	/** Bu bloklar baltayla kırılınca eşya düşürmez. Şu an netherit ile aynı (hepsi düşer). */
	public static final TagKey<Block> INCORRECT_FOR_BATTLE_AXE = TagKey.create(
			Registries.BLOCK, BattleAxeMod.id("incorrect_for_battle_axe"));

	/** Örste baltayı onarabilen eşyalar (şu an: obsidyen). */
	public static final TagKey<Item> REPAIRS_BATTLE_AXE = TagKey.create(
			Registries.ITEM, BattleAxeMod.id("repairs_battle_axe"));

	// ------------------------------------------------------------------
	// Malzeme ve eşya
	// ------------------------------------------------------------------

	public static final ToolMaterial BATTLE_AXE_MATERIAL = new ToolMaterial(
			INCORRECT_FOR_BATTLE_AXE, // eşya düşürmeyen bloklar
			DURABILITY,               // dayanıklılık
			9.0F,                     // kazma hızı (kılıç tipi eşyalarda kullanılmaz)
			0.0F,                     // ek hasar: hasarı aşağıda sword() ile veriyoruz
			15,                       // büyü değeri (netherit ile aynı)
			REPAIRS_BATTLE_AXE        // onarım malzemesi
	);

	public static final ResourceKey<Item> BATTLE_AXE_KEY = ResourceKey.create(
			Registries.ITEM, BattleAxeMod.id("battle_axe"));

	// sword(): kılıç gibi davranmasını sağlar (kılıç hasar/hız özellikleri, ağ kesme, süpürme vuruşu).
	// Ayrıca data/minecraft/tags/item/swords.json içinde "kılıç" olarak etiketlendi; böylece
	// Keskinlik, Alev, Yağma gibi kılıç büyüleri de uygulanabilir.
	// İstersen lavda yanmaması için sonuna .fireResistant() ekleyebilirsin.
	public static final Item BATTLE_AXE = register(
			BATTLE_AXE_KEY,
			BattleAxeItem::new,
			new Item.Properties().rarity(Rarity.EPIC).sword(
					BATTLE_AXE_MATERIAL,
					ATTACK_DAMAGE - 1.0F, // oyuncunun taban hasarı 1 olduğu için çıkarıyoruz
					ATTACK_SPEED - 4.0F   // oyuncunun taban saldırı hızı 4.0 olduğu için çıkarıyoruz
			).fireResistant() // yerdeyken lavda/ateşte yanmaz: fırlatılan balta hiçbir durumda kaybolmasın
	);

	public static final ResourceKey<Item> KARA_CUBUK_KEY = ResourceKey.create(
			Registries.ITEM, BattleAxeMod.id("kara_cubuk"));

	/** Kara Körük'ün ganimeti: baltanın sapını kalıcı olarak dönüştüren özel malzeme. */
	public static final Item KARA_CUBUK = register(
			KARA_CUBUK_KEY,
			Item::new,
			new Item.Properties().rarity(Rarity.EPIC).stacksTo(16).fireResistant()
	);

	private static Item register(ResourceKey<Item> key, Function<Item.Properties, Item> factory, Item.Properties properties) {
		Item item = factory.apply(properties.setId(key));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		return item;
	}

	public static void initialize() {
		// Yaratıcı moddaki "Savaş" sekmesine ekle.
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)
				.register(tab -> {
					tab.accept(BATTLE_AXE);
					tab.accept(KARA_CUBUK);
				});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS)
				.register(tab -> tab.accept(com.battleaxe.block.ModBlocks.KARA_KORUK_ORS_ITEM));
	}
}
