package com.battleaxe.yargec;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

import com.battleaxe.shunpo.vfx.RiftPalette;
import com.battleaxe.soul.RankStyle;
import com.battleaxe.soul.SoulLogic;

/**
 * Yar Geç'in görsel ve işitsel geri bildirimi. Sadece parçacık ve ses; hasar vermez.
 * Şarj arttıkça (seviye 1 -> 2 -> 3) parçacıklar yoğunlaşır ve renkleri sertleşir.
 */
public final class YarGecEffects {
	private YarGecEffects() {
	}

	/** Seviye 1: hafif turuncu kıvılcım. */
	private static final DustColorTransitionOptions LOW =
			new DustColorTransitionOptions(0xFFB347, 0xE05A00, 0.7F);
	/** Seviye 2: kırmızı kor. */
	private static final DustColorTransitionOptions MID =
			new DustColorTransitionOptions(0xFF5A30, 0x8A0000, 0.85F);
	/** Seviye 3 (tam şarj): beyaz -> mor, elektrik. */
	private static final DustColorTransitionOptions MAX =
			new DustColorTransitionOptions(0xFFFFFF, 0x9A4DFF, 1.0F);

	private static DustColorTransitionOptions dust(int tier) {
		return tier >= 3 ? MAX : tier == 2 ? MID : LOW;
	}

	/** Oyuncunun baktığı yön (yatay birim vektör). */
	public static double[] forward(ServerPlayer player) {
		float yaw = player.getYRot() * Mth.DEG_TO_RAD;
		return new double[] {-Mth.sin(yaw), Mth.cos(yaw)};
	}

	/**
	 * Şarj sürerken her tick çağrılır: baltanın önünde şarjla yoğunlaşan parçacıklar ve
	 * seviye atlama sesleri.
	 */
	public static void charging(ServerLevel level, ServerPlayer player, int usedTicks) {
		float ratio = YarGecLogic.chargeRatio(usedTicks);
		int tier = YarGecLogic.tier(ratio);

		// Seviye atlama sesleri: tam o tick'te bir kez.
		if (usedTicks == YarGecLogic.tier2Ticks()) {
			level.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.5F, 1.7F);
		}
		if (usedTicks == YarGecConfig.MAX_CHARGE_TIME) {
			level.playSound(null, player.getX(), player.getY(), player.getZ(),
					SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.8F, 2.0F);
			double[] f = forward(player);
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
					player.getX() + f[0] * 0.7, player.getY(0.7), player.getZ() + f[1] * 0.7, 14, 0.3, 0.3, 0.3, 0.3);
		}

		// Parçacıklar: ilk birkaç tick sessiz, sonra 2 tick'te bir.
		if (usedTicks < 3 || usedTicks % 2 != 0) {
			return;
		}

		double[] f = forward(player);
		double x = player.getX() + f[0] * 0.7;
		double y = player.getY(0.75);
		double z = player.getZ() + f[1] * 0.7;
		int count = 1 + Math.round(ratio * 5.0F); // 1 .. 6

		level.sendParticles(dust(tier), x, y, z, count, 0.18, 0.22, 0.18, 0.0);
		if (tier >= 2) {
			level.sendParticles(ParticleTypes.FLAME, x, y, z, tier == 2 ? 1 : 2, 0.15, 0.15, 0.15, 0.02);
		}
		if (tier >= 3) {
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 2, 0.25, 0.25, 0.25, 0.1);
		}
	}

	/** Saldırı bırakıldığı an: ses, yelpaze boyunca süpürme parçacıkları. */
	public static void release(ServerLevel level, ServerPlayer player, int tier, double reach, double halfAngleDeg, int rank) {
		double px = player.getX();
		double pz = player.getZ();
		double[] f = forward(player);

		level.playSound(null, px, player.getY(), pz, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS,
				1.0F, tier >= 3 ? 0.55F : tier == 2 ? 0.7F : 0.85F);
		if (tier >= 2) {
			level.playSound(null, px, player.getY(), pz, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS,
					0.7F, tier >= 3 ? 0.5F : 0.65F);
		}

		// Süpürme çizgileri yelpaze boyunca dizilir; seviye yükseldikçe sayısı ve sıra sayısı artar.
		int slashes = (tier >= 3 ? 9 : tier == 2 ? 5 : 3) + rank / 3 * 2; // rütbe yükseldikçe daha çok çizgi
		int rows = (tier >= 3 ? 2 : 1) + (rank >= 6 ? 1 : 0);
		double halfAngle = Math.toRadians(halfAngleDeg);

		for (int row = 0; row < rows; row++) {
			double distance = reach * (row == 0 ? 0.6 : row == 1 ? 0.92 : 0.78);
			for (int i = 0; i < slashes; i++) {
				double t = slashes == 1 ? 0.5 : (double) i / (slashes - 1);
				double angle = -halfAngle + 2.0 * halfAngle * t;
				double dirX = f[0] * Math.cos(angle) - f[1] * Math.sin(angle);
				double dirZ = f[0] * Math.sin(angle) + f[1] * Math.cos(angle);
				double x = px + dirX * distance;
				double z = pz + dirZ * distance;
				double y = player.getY(0.65);

				level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0.0, 0.0, 0.0, 0.0);
				level.sendParticles(dust(tier), x, y, z, tier * 2, 0.25, 0.2, 0.25, 0.0);
				if (rank > 0) {
					level.sendParticles(RankStyle.dust(rank), x, y, z, 1 + rank / 2, 0.25, 0.2, 0.25, 0.0);
				}
			}
		}

		// Tam şarjda ekstra: önde patlama parçacıkları.
		if (tier >= 3) {
			for (int i = -1; i <= 1; i++) {
				double angle = i * halfAngle * 0.5;
				double dirX = f[0] * Math.cos(angle) - f[1] * Math.sin(angle);
				double dirZ = f[0] * Math.sin(angle) + f[1] * Math.cos(angle);
				level.sendParticles(ParticleTypes.EXPLOSION,
						px + dirX * reach * 0.75, player.getY(0.6), pz + dirZ * reach * 0.75, 1, 0.0, 0.0, 0.0, 0.0);
			}
		}
	}

	/** Vurulan her düşmanın üzerinde küçük bir isabet efekti. */
	public static void impact(ServerLevel level, LivingEntity target, int tier, int rank) {
		double x = target.getX();
		double y = target.getY(0.5);
		double z = target.getZ();

		level.sendParticles(dust(tier), x, y, z, 4 + tier * 3, 0.3, 0.4, 0.3, 0.0);
		if (tier >= 2) {
			level.sendParticles(ParticleTypes.FLAME, x, y, z, tier, 0.2, 0.3, 0.2, 0.06);
		}
		if (tier >= 3) {
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 6, 0.3, 0.4, 0.3, 0.25);
		}
		// Shunpo yarıklarıyla ortak renk dili (koyu kızıl/mor); az sayıda, bütçeyi şişirmez.
		if (tier >= 2) {
			level.sendParticles(RiftPalette.CRIMSON, x, y, z, 1 + tier, 0.3, 0.4, 0.3, 0.0);
		}
		if (tier >= 3) {
			level.sendParticles(RiftPalette.PURPLE, x, y, z, 3, 0.3, 0.4, 0.3, 0.0);
		}
		if (rank > 0) {
			level.sendParticles(RankStyle.dust(rank), x, y, z, SoulLogic.scaled(4, rank), 0.3, 0.4, 0.3, 0.0);
		}
	}
}
