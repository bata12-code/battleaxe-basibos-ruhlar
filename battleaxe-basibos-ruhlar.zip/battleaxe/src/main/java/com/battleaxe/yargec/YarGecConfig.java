package com.battleaxe.yargec;

/**
 * "Yar Geç" büyüsü ve sağ tık saldırısının dengeleme ayarları. Dengelemek için sadece bu dosyayı
 * değiştirmen yeterli. Süreler tick cinsindendir (20 tick = 1 saniye).
 */
public final class YarGecConfig {
	private YarGecConfig() {
	}

	// ------------------------------------------------------------------
	// Şarj
	// ------------------------------------------------------------------

	/** Maksimum şarj süresi. Bundan sonra basılı tutmak saldırıyı daha da güçlendirmez. (40 = 2 sn) */
	public static final int MAX_CHARGE_TIME = 40;

	/** Bundan kısa basışlar (kazara sağ tık) saldırıyı tetiklemez. (4 = 0.2 sn) */
	public static final int MIN_CHARGE_TIME = 4;

	/**
	 * Şarj oranının (0-1) bu değere ulaşmasıyla "orta" seviye (2) başlar.
	 * Seviye 1 = hafif, seviye 2 = güçlü, seviye 3 = tam şarj (maksimum, en vahşi).
	 */
	public static final double TIER_2_RATIO = 0.40;

	// ------------------------------------------------------------------
	// Hasar ve etki alanı: şarj oranına göre MIN -> MAX arası doğrusal artar.
	// Her etkilenen düşmana ayrı ayrı, TEK SEFER uygulanır.
	// ------------------------------------------------------------------

	/** En kısa (minimum şarj) ve en uzun (tam şarj) saldırının hasarı. Normal balta vuruşu 16'dır. */
	public static final float MIN_DAMAGE = 6.0F;
	public static final float MAX_DAMAGE = 24.0F;

	/** Saldırının ileriye doğru menzili (blok). */
	public static final double MIN_REACH = 3.0;
	public static final double MAX_REACH = 6.0;

	/** Baktığın yönün her iki yanına doğru açı (derece). Toplam yelpaze genişliği = 2 x bu değer. */
	public static final double MIN_HALF_ANGLE_DEGREES = 40.0;
	public static final double MAX_HALF_ANGLE_DEGREES = 80.0;

	/** Aynı anda etkilenebilecek en çok düşman sayısı. */
	public static final int MIN_TARGETS = 3;
	public static final int MAX_TARGETS = 12;

	/** Dikey tolerans (blok): oyuncunun gövde hizasından bu kadar yukarı/aşağı hedefler etkilenir. */
	public static final double VERTICAL_RANGE = 2.0;

	/** Geri itme gücü (vanilla süpürme vuruşu 0.4). */
	public static final double MIN_KNOCKBACK = 0.4;
	public static final double MAX_KNOCKBACK = 1.3;

	// ------------------------------------------------------------------
	// Diğer
	// ------------------------------------------------------------------

	/** Saldırıdan sonra tekrar şarj edebilmek için beklenecek süre. (30 = 1.5 sn) */
	public static final int COOLDOWN_TICKS = 30;

	/** Her saldırıda baltanın kaybettiği dayanıklılık. */
	public static final int DURABILITY_COST = 2;

	/** Kullanım süresi üst sınırı (yay gibi). Oyuncu bırakana kadar sürer; değiştirmene gerek yok. */
	public static final int USE_DURATION_TICKS = 72000;
}
