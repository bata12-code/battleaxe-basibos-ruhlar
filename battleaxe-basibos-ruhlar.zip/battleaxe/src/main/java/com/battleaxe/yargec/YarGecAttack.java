package com.battleaxe.yargec;

import java.util.Comparator;
import java.util.List;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.evolution.EvolutionEvents;
import com.battleaxe.nexus.NexusCleave;
import com.battleaxe.soul.SoulLogic;
import com.battleaxe.soul.SoulManager;

/**
 * Yar Geç'in sağ tık bırakıldığında gerçekleşen alan saldırısı. SUNUCUDA, bırakıldığı anda
 * TEK SEFER çalışır; hasar tick tick uygulanmaz.
 */
public final class YarGecAttack {
	private YarGecAttack() {
	}

	/**
	 * Saldırıyı gerçekleştirir.
	 *
	 * @param usedTicks sağ tık tuşunun basılı tutulduğu süre (tick)
	 * @return saldırı gerçekleştiyse true (çok kısa basışlarda false: kazara tıklama)
	 */
	public static boolean perform(ServerLevel level, ServerPlayer player, ItemStack stack, int usedTicks) {
		if (!YarGecLogic.canRelease(usedTicks) || !player.isAlive() || player.isSpectator()) {
			return false;
		}

		// Şarj oranı MAX_CHARGE_TIME'da sınırlanır: fazla beklemek gücü artırmaz.
		float ratio = YarGecLogic.chargeRatio(usedTicks);
		int tier = YarGecLogic.tier(ratio);

		// Rütbe: balta ne kadar ruh topladıysa Yar Geç biraz daha sert vurur ve efektleri zenginleşir.
		int rank = SoulManager.rankOf(stack);

		// Ruh Ağı (Yarık Gezgini): aynı Yar Geç, düğümlerle derinleşir. Değerler sınırlıdır ve bekleme süresi
		// asla sıfırlanmaz (bkz. NexusCleave).
		NexusCleave.Mods nexus = NexusCleave.mods(player, tier);
		float damage = (float) (YarGecLogic.damage(ratio) * SoulLogic.cleaveMultiplier(rank) * nexus.damageMultiplier());
		double reach = YarGecLogic.reach(ratio) * nexus.reachMultiplier();
		double halfAngle = YarGecLogic.halfAngleDegrees(ratio) + nexus.extraAngleDegrees() * 0.5;
		int maxTargets = YarGecLogic.maxTargets(ratio) + nexus.extraTargets();
		double knockback = YarGecLogic.knockback(ratio) * nexus.knockbackMultiplier();

		double[] forward = YarGecEffects.forward(player);
		DamageSource source = player.damageSources().source(DamageTypes.PLAYER_ATTACK, player);

		// Adaylar: oyuncunun çevresindeki kutu; sonra yelpaze testi ve en yakından başlayarak sınır.
		var box = player.getBoundingBox().inflate(reach + 1.0, YarGecConfig.VERTICAL_RANGE, reach + 1.0);
		List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class, box,
				entity -> isValidTarget(player, entity));
		candidates.sort(Comparator.comparingDouble(entity -> player.distanceToSqr(entity)));

		int hits = 0;
		int enemyHits = 0;
		NexusCleave.begin(player);
		try {
			for (LivingEntity target : candidates) {
				if (hits >= maxTargets) {
					break;
				}

				double dx = target.getX() - player.getX();
				double dz = target.getZ() - player.getZ();
				if (!YarGecLogic.isInSector(dx, dz, forward[0], forward[1], reach, halfAngle, target.getBbWidth() * 0.5)) {
					continue;
				}
				if (Math.abs(target.getY(0.5) - player.getY(0.5)) > YarGecConfig.VERTICAL_RANGE + target.getBbHeight() * 0.5) {
					continue;
				}

				if (target.hurtServer(level, source, damage)) {
					// Oyuncudan dışarı doğru it (vanilla knockback, direnç/zırh dikkate alınır).
					target.knockback(knockback, player.getX() - target.getX(), player.getZ() - target.getZ(), source, damage);
					YarGecEffects.impact(level, target, tier, rank);
					hits++;
					NexusCleave.onTargetHit(player, hits);
				if (EvolutionEvents.isEnemy(target)) {
					enemyHits++;
				}
				}
			}
		} finally {
			NexusCleave.end(player);
		}

		// Efektler isabet olsun olmasın oynar: baltayı savurdun.
		YarGecEffects.release(level, player, tier, reach, halfAngle, rank);
		InteractionHand hand = player.getUsedItemHand();
		player.swing(hand, true);

		// Dayanıklılık ve bekleme süresi.
		if (!NexusCleave.skipDurability(player)) {
			stack.hurtAndBreak(YarGecConfig.DURABILITY_COST, player,
					hand == InteractionHand.OFF_HAND ? EquipmentSlot.OFFHAND : EquipmentSlot.MAINHAND);
		}
		int cooldown = EvolutionEvents.adjustCleaveCooldown(player, NexusCleave.cooldownTicks(player, YarGecConfig.COOLDOWN_TICKS));
		player.getCooldowns().addCooldown(stack, cooldown);
		NexusCleave.afterCleave(level, player, hits, tier, reach);
		EvolutionEvents.onCleave(player, enemyHits);
		return true;
	}

	private static boolean isValidTarget(ServerPlayer player, LivingEntity entity) {
		return entity != player
				&& entity.isAlive()
				&& !entity.isSpectator()
				&& entity.isAttackable()
				&& !player.isAlliedTo(entity);
	}
}
