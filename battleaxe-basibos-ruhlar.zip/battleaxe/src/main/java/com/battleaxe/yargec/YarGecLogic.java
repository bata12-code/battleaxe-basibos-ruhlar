package com.battleaxe.yargec;

/**
 * Yar Geç'in saf hesaplamaları (şarj oranı, seviye, hasar, alan, hedef testi).
 * Minecraft'a bağımlı değildir; böylece oyun olmadan test edilebilir.
 */
public final class YarGecLogic {
	private YarGecLogic() {
	}

	/** Basılı tutulan süreden 0-1 arası şarj oranı. MAX_CHARGE_TIME'dan sonra 1'de sabit kalır. */
	public static float chargeRatio(float usedTicks) {
		if (usedTicks <= 0.0F) {
			return 0.0F;
		}
		return Math.min(1.0F, usedTicks / YarGecConfig.MAX_CHARGE_TIME);
	}

	/** Saldırının tetiklenebilmesi için yeterince uzun basılmış mı? */
	public static boolean canRelease(int usedTicks) {
		return usedTicks >= YarGecConfig.MIN_CHARGE_TIME;
	}

	/** 1 = hafif, 2 = güçlü, 3 = tam şarj (maksimum). */
	public static int tier(float ratio) {
		if (ratio >= 1.0F) {
			return 3;
		}
		return ratio >= YarGecConfig.TIER_2_RATIO ? 2 : 1;
	}

	/** Orta seviyenin başladığı tick. */
	public static int tier2Ticks() {
		return (int) Math.ceil(YarGecConfig.MAX_CHARGE_TIME * YarGecConfig.TIER_2_RATIO);
	}

	public static float damage(float ratio) {
		return (float) lerp(YarGecConfig.MIN_DAMAGE, YarGecConfig.MAX_DAMAGE, ratio);
	}

	public static double reach(float ratio) {
		return lerp(YarGecConfig.MIN_REACH, YarGecConfig.MAX_REACH, ratio);
	}

	public static double halfAngleDegrees(float ratio) {
		return lerp(YarGecConfig.MIN_HALF_ANGLE_DEGREES, YarGecConfig.MAX_HALF_ANGLE_DEGREES, ratio);
	}

	public static int maxTargets(float ratio) {
		return (int) Math.round(lerp(YarGecConfig.MIN_TARGETS, YarGecConfig.MAX_TARGETS, ratio));
	}

	public static double knockback(float ratio) {
		return lerp(YarGecConfig.MIN_KNOCKBACK, YarGecConfig.MAX_KNOCKBACK, ratio);
	}

	/**
	 * Hedef, oyuncunun önündeki yelpazenin içinde mi? (yatay düzlemde)
	 *
	 * @param dx             hedefin oyuncuya göre X farkı
	 * @param dz             hedefin oyuncuya göre Z farkı
	 * @param forwardX       oyuncunun baktığı yönün X bileşeni (birim vektör)
	 * @param forwardZ       oyuncunun baktığı yönün Z bileşeni (birim vektör)
	 * @param reach          yelpazenin menzili
	 * @param halfAngleDeg   yelpazenin yarım açısı (derece)
	 * @param targetHalfWidth hedefin yarı genişliği (iri mobları kenardan da vurabilmek için)
	 */
	public static boolean isInSector(
			double dx, double dz,
			double forwardX, double forwardZ,
			double reach, double halfAngleDeg,
			double targetHalfWidth
	) {
		double distance = Math.sqrt(dx * dx + dz * dz);
		if (distance > reach + targetHalfWidth) {
			return false;
		}
		// Neredeyse üst üste duran hedefler açıdan bağımsız her zaman isabet alır.
		if (distance <= targetHalfWidth + 0.6) {
			return true;
		}

		double cos = (dx * forwardX + dz * forwardZ) / distance;
		double angleDeg = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, cos))));
		// Hedefin genişliği kadar açısal tolerans tanı (yakın ve iri hedeflerde daha fazla).
		double toleranceDeg = Math.toDegrees(Math.atan2(targetHalfWidth, distance));
		return angleDeg <= halfAngleDeg + toleranceDeg;
	}

	private static double lerp(double min, double max, float ratio) {
		float t = Math.max(0.0F, Math.min(1.0F, ratio));
		return min + (max - min) * t;
	}
}
