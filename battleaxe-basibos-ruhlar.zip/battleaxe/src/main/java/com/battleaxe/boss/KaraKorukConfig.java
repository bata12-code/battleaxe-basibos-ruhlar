package com.battleaxe.boss;

/**
 * Kara Körük'ün dengeleme ayarları (TEK MERKEZ). Süreler tick cinsindendir (20 tick = 1 saniye),
 * mesafeler bloktur. Mevcut kayıtlı boss'lar yüklenirken bu değerlere yükseltilir (bkz. KaraKorukEntity).
 */
public final class KaraKorukConfig {
	private KaraKorukConfig() {
	}

	// ---- Temel özellikler (referans: Wither 300 can, Ender Ejderhası 200 can)
	public static final double MAX_HEALTH = 1200.0;
	public static final double ATTACK_DAMAGE = 24.0;
	public static final double MOVEMENT_SPEED = 0.36;
	public static final double FOLLOW_RANGE = 64.0;
	public static final double KNOCKBACK_RESISTANCE = 1.0;
	public static final double ARMOR = 16.0;
	/** Yakın dövüş takibinde hareket hızı çarpanı (MeleeAttackGoal). 1.0 = öznitelik hızı. */
	public static final double MELEE_SPEED_MODIFIER = 1.0;
	/**
	 * Baltayla öldürülünce Ruh Bağı'na verdiği ruh. Eski sistemde 400 can / 20 = 20 idi; can artınca
	 * formül (sınır 25) bunu değiştireceği için mevcut etkileşim burada sabitlenir.
	 */
	public static final int SOUL_VALUE = 20;

	// ---- Saldırılar arası öncelik / boşluk
	/** Herhangi bir ağır saldırı bittikten sonra bir sonrakine kadar en az bekleme. */
	public static final int GLOBAL_GAP_TICKS = 30;
	/** Hedef yeniden seçme aralığı (birden fazla oyuncu). */
	public static final int RETARGET_INTERVAL_TICKS = 20;

	// ---- Dövme Darbesi (çekiçle ağır, önceden belli olan alan saldırısı)
	/** Hedef bu mesafeye (blok) girince darbe hazırlanır. */
	public static final double SLAM_TRIGGER_RANGE = 4.5;
	/** Darbenin etki yarıçapı (blok). Hazırlık sırasında bu halka alevlerle gösterilir. */
	public static final double SLAM_RADIUS = 5.0;
	public static final float SLAM_DAMAGE = 30.0F;
	public static final double SLAM_KNOCKBACK = 1.4;
	/** Hazırlık süresi: çekiç kalkar, halka dolar (oyuncuya kaçma şansı). */
	public static final int SLAM_WINDUP_TICKS = 26;
	/** Darbe sonrası çekicin yere indiği, boss'un savunmasız kaldığı süre. */
	public static final int SLAM_RECOVER_TICKS = 12;
	public static final int SLAM_COOLDOWN_TICKS = 120;
	public static final int SLAM_INITIAL_COOLDOWN_TICKS = 60;

	// ---- Kor Mermisi (menzilli)
	public static final double EMBER_MIN_RANGE = 8.0;
	public static final double EMBER_MAX_RANGE = 24.0;
	public static final float EMBER_DAMAGE = 18.0F;
	/** İsabette küçük alan etkisi: BLOK HASARI YOK, yalnızca yakındaki diğer oyunculara. */
	public static final double EMBER_BLAST_RADIUS = 2.5;
	public static final float EMBER_BLAST_DAMAGE = 8.0F;
	public static final int EMBER_WINDUP_TICKS = 22;
	public static final int EMBER_SWING_TICKS = 8;
	/** Savurmanın kaçıncı tick'inde mermi çıkar (çekiç ileri gelince). */
	public static final int EMBER_LAUNCH_DELAY_TICKS = 3;
	public static final int EMBER_COOLDOWN_TICKS = 160;
	public static final int EMBER_INITIAL_COOLDOWN_TICKS = 70;
	/** Mermi hızı (blok/tick). 1.15 = 23 blok/sn: hızlı ama dönüp kaçınılabilir (hazırlık uyarısı + yan hareket). */
	public static final double EMBER_SPEED = 1.15;
	public static final int EMBER_MAX_AGE_TICKS = 45;
	public static final double EMBER_HIT_RADIUS = 0.9;
	/** Hedefin hareketine karşı ne kadar önden nişan alınır (1 = tam; <1 kaçınılmaz olmasın). */
	public static final double EMBER_LEAD_FACTOR = 0.5;
	public static final int EMBER_MAX_LEAD_TICKS = 14;

	// ---- Demirci Hücumu (mesafe kapatma; navigasyonla, duvar/ışınlanma yok)
	public static final double CHARGE_MIN_RANGE = 11.0;
	public static final double CHARGE_MAX_RANGE = 28.0;
	/** Bu mesafeden uzakta hedef için hücum, Kor Mermisi'ne tercih edilir. */
	public static final double CHARGE_PREFER_DISTANCE = 16.0;
	public static final int CHARGE_WINDUP_TICKS = 18;
	public static final int CHARGE_MAX_TICKS = 32;
	/** Hücum sırasında hareket hızına eklenen çarpan (ADD_MULTIPLIED_TOTAL): 1.0 = iki katı hız. */
	public static final double CHARGE_SPEED_BONUS = 1.0;
	public static final int CHARGE_COOLDOWN_TICKS = 240;
	public static final int CHARGE_INITIAL_COOLDOWN_TICKS = 100;
	public static final int CHARGE_RECOVER_TICKS = 12;
	/** Hedefe bu kadar yaklaşınca hücum biter ve yakın dövüş sürer. */
	public static final double CHARGE_END_DISTANCE = 3.0;
	/** Hücum başlamadan önce hedefle boss arasındaki en çok yükseklik farkı. */
	public static final double CHARGE_MAX_VERTICAL = 3.0;
	public static final float CHARGE_IMPACT_DAMAGE = 10.0F;
	/** Yatay itme (dikey itme yok: oyuncu havaya savrulmaz). */
	public static final double CHARGE_IMPACT_KNOCKBACK = 0.9;

	// ---- İkinci savaş aşaması (tek seferlik, geri dönüşsüz)
	public static final double PHASE2_HEALTH_RATIO = 0.5;
	public static final double PHASE2_COOLDOWN_SCALE = 0.70;
	public static final double PHASE2_WINDUP_SCALE = 0.85;
	/** Kaçılabilirlik için hazırlık süreleri bunların altına inmez. */
	public static final int PHASE2_MIN_SLAM_WINDUP_TICKS = 20;
	public static final int PHASE2_MIN_EMBER_WINDUP_TICKS = 16;
	public static final int PHASE2_MIN_CHARGE_WINDUP_TICKS = 14;
	public static final int PHASE2_GLOBAL_GAP_TICKS = 20;
	/** Sınırsız artış yok: tek seferlik küçük artışlar. */
	public static final double PHASE2_SPEED_BONUS = 0.10;
	public static final double PHASE2_DAMAGE_BONUS = 0.10;
	/** Orta mesafede hem mermi hem hücum uygunsa hücum seçme olasılığı. */
	public static final double CHARGE_CHANCE = 0.30;
	public static final double PHASE2_CHARGE_CHANCE = 0.40;
}
