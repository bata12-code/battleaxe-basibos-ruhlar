package com.battleaxe.boss;

/**
 * Kara Körük'ün savaş mantığı: SAF (Minecraft'tan bağımsız), test edilebilir bir durum makinesi.
 *
 * <p>Tek bir {@link Attack} durumu vardır; bu yüzden iki ağır saldırı aynı anda yürümez. Her tick'te en çok BİR olay
 * döner. Bekleme süreleri yalnızca saldırı BİTTİĞİNDE kurulur ve her tick yalnızca azalır; hiçbir yol bunları
 * yanlışlıkla sıfırlamaz. İkinci aşama tek yönlü bir mandaldır (can iyileşse bile geri dönmez).
 *
 * <p>Öncelik: Dövme Darbesi (yakın) > Demirci Hücumu (uzak) / Kor Mermisi (orta-uzak). Saldırılar arasında
 * {@link KaraKorukConfig#GLOBAL_GAP_TICKS} kadar nefes boşluğu bulunur.
 */
public final class KaraKorukLogic {
	private KaraKorukLogic() {
	}

	/** Boss'un anlık saldırı durumu (istemciye de bu sıra numarasıyla senkronlanır; SIRAYI DEĞİŞTİRME). */
	public enum Attack {
		IDLE,
		SLAM_WINDUP,
		SLAM_RECOVER,
		EMBER_WINDUP,
		EMBER_SWING,
		CHARGE_WINDUP,
		CHARGING,
		CHARGE_RECOVER;

		public static Attack byOrdinal(int ordinal) {
			Attack[] values = values();
			return ordinal >= 0 && ordinal < values.length ? values[ordinal] : IDLE;
		}
	}

	/** Bir tick'te olan olay (varlık bunlara yanıt verir: ses, hasar, mermi...). */
	public enum Event {
		NONE,
		SLAM_WINDUP_START,
		SLAM_STRIKE,
		EMBER_WINDUP_START,
		EMBER_LAUNCH,
		CHARGE_WINDUP_START,
		CHARGE_BEGIN,
		CHARGE_END
	}

	/**
	 * @param hasTarget       geçerli, yaşayan bir hedef var mı
	 * @param distance        hedefe yatay-uzay mesafesi (hedef yoksa önemsiz)
	 * @param lineOfSight     hedefi görüyor mu (mermi için)
	 * @param canCharge       hücum için yol var mı (sunucu navigasyondan hesaplar)
	 * @param chargeShouldEnd şu an hücumdaysa: hedefe ulaşıldı / takıldı / hedef geçersiz
	 * @param healthRatio     can oranı 0-1
	 * @param roll            0-1 arası rastgele sayı (test edilebilirlik için dışarıdan gelir)
	 */
	public record Inputs(boolean hasTarget, double distance, boolean lineOfSight, boolean canCharge,
			boolean chargeShouldEnd, double healthRatio, double roll) {
	}

	public static final class Brain {
		private Attack attack = Attack.IDLE;
		private int ticksLeft;
		private int phaseTotal;
		private int slamCooldown = KaraKorukConfig.SLAM_INITIAL_COOLDOWN_TICKS;
		private int emberCooldown = KaraKorukConfig.EMBER_INITIAL_COOLDOWN_TICKS;
		private int chargeCooldown = KaraKorukConfig.CHARGE_INITIAL_COOLDOWN_TICKS;
		private int globalGap;
		private boolean phaseTwo;

		public Attack attack() {
			return attack;
		}

		public boolean isIdle() {
			return attack == Attack.IDLE;
		}

		public boolean phaseTwo() {
			return phaseTwo;
		}

		/** Kayıttan yüklerken: can zaten eşiğin altındaysa ikinci aşama doğrudan açık başlar. */
		public void restorePhaseTwo(boolean value) {
			this.phaseTwo = this.phaseTwo || value;
		}

		/** Mevcut aşamanın ilerlemesi 0-1 (animasyon için). */
		public float progress() {
			if (phaseTotal <= 0 || attack == Attack.IDLE) {
				return 0.0F;
			}
			return clamp(1.0F - (float) ticksLeft / phaseTotal);
		}

		/** Boss öldü/hedef yok vb. durumlarda saldırıyı güvenle sonlandırır. Bekleme süreleri KORUNUR. */
		public void abort() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
		}

		public int slamCooldown() {
			return slamCooldown;
		}

		public int emberCooldown() {
			return emberCooldown;
		}

		public int chargeCooldown() {
			return chargeCooldown;
		}

		public int globalGap() {
			return globalGap;
		}

		/** Her tick bir kez çağrılır. */
		public Event step(Inputs in) {
			if (!phaseTwo && in.healthRatio() <= KaraKorukConfig.PHASE2_HEALTH_RATIO) {
				phaseTwo = true; // tek yönlü mandal
			}
			slamCooldown = Math.max(0, slamCooldown - 1);
			emberCooldown = Math.max(0, emberCooldown - 1);
			chargeCooldown = Math.max(0, chargeCooldown - 1);
			globalGap = Math.max(0, globalGap - 1);

			switch (attack) {
				case SLAM_WINDUP -> {
					if (--ticksLeft <= 0) {
						// Hedef uzaklaşmış olsa bile darbe vurulur (önceden belli olan, kaçılabilir saldırı).
						slamCooldown = cooldown(KaraKorukConfig.SLAM_COOLDOWN_TICKS);
						begin(Attack.SLAM_RECOVER, KaraKorukConfig.SLAM_RECOVER_TICKS);
						return Event.SLAM_STRIKE;
					}
					return Event.NONE;
				}
				case SLAM_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				case EMBER_WINDUP -> {
					if (--ticksLeft <= 0) {
						emberCooldown = cooldown(KaraKorukConfig.EMBER_COOLDOWN_TICKS);
						begin(Attack.EMBER_SWING, KaraKorukConfig.EMBER_SWING_TICKS);
					}
					return Event.NONE;
				}
				case EMBER_SWING -> {
					int before = ticksLeft;
					ticksLeft--;
					Event event = Event.NONE;
					if (before == KaraKorukConfig.EMBER_SWING_TICKS - KaraKorukConfig.EMBER_LAUNCH_DELAY_TICKS) {
						event = Event.EMBER_LAUNCH;
					}
					if (ticksLeft <= 0) {
						finish();
					}
					return event;
				}
				case CHARGE_WINDUP -> {
					if (--ticksLeft <= 0) {
						begin(Attack.CHARGING, KaraKorukConfig.CHARGE_MAX_TICKS);
						return Event.CHARGE_BEGIN;
					}
					return Event.NONE;
				}
				case CHARGING -> {
					if (--ticksLeft <= 0 || in.chargeShouldEnd() || !in.hasTarget()) {
						chargeCooldown = cooldown(KaraKorukConfig.CHARGE_COOLDOWN_TICKS);
						begin(Attack.CHARGE_RECOVER, KaraKorukConfig.CHARGE_RECOVER_TICKS);
						return Event.CHARGE_END;
					}
					return Event.NONE;
				}
				case CHARGE_RECOVER -> {
					if (--ticksLeft <= 0) {
						finish();
					}
					return Event.NONE;
				}
				default -> {
					return chooseAttack(in);
				}
			}
		}

		private Event chooseAttack(Inputs in) {
			if (!in.hasTarget() || globalGap > 0) {
				return Event.NONE;
			}
			double d = in.distance();

			if (d <= KaraKorukConfig.SLAM_TRIGGER_RANGE && slamCooldown == 0) {
				begin(Attack.SLAM_WINDUP, windup(KaraKorukConfig.SLAM_WINDUP_TICKS, KaraKorukConfig.PHASE2_MIN_SLAM_WINDUP_TICKS));
				return Event.SLAM_WINDUP_START;
			}
			// Dövme Darbesi menzilindeyken (bekleme sürerken) mermi/hücum seçilmez: yakın dövüş sürer.
			if (d <= KaraKorukConfig.SLAM_TRIGGER_RANGE) {
				return Event.NONE;
			}

			boolean ember = emberCooldown == 0 && in.lineOfSight()
					&& d >= KaraKorukConfig.EMBER_MIN_RANGE && d <= KaraKorukConfig.EMBER_MAX_RANGE;
			boolean charge = chargeCooldown == 0 && in.canCharge()
					&& d >= KaraKorukConfig.CHARGE_MIN_RANGE && d <= KaraKorukConfig.CHARGE_MAX_RANGE;
			if (!ember && !charge) {
				return Event.NONE;
			}

			boolean pickCharge;
			if (ember && charge) {
				double chance = phaseTwo ? KaraKorukConfig.PHASE2_CHARGE_CHANCE : KaraKorukConfig.CHARGE_CHANCE;
				pickCharge = d >= KaraKorukConfig.CHARGE_PREFER_DISTANCE || in.roll() < chance;
			} else {
				pickCharge = charge;
			}

			if (pickCharge) {
				begin(Attack.CHARGE_WINDUP, windup(KaraKorukConfig.CHARGE_WINDUP_TICKS, KaraKorukConfig.PHASE2_MIN_CHARGE_WINDUP_TICKS));
				return Event.CHARGE_WINDUP_START;
			}
			begin(Attack.EMBER_WINDUP, windup(KaraKorukConfig.EMBER_WINDUP_TICKS, KaraKorukConfig.PHASE2_MIN_EMBER_WINDUP_TICKS));
			return Event.EMBER_WINDUP_START;
		}

		private void begin(Attack next, int ticks) {
			attack = next;
			ticksLeft = Math.max(1, ticks);
			phaseTotal = ticksLeft;
		}

		/** Saldırı bitişi: kısa bir nefes boşluğu bırakır. */
		private void finish() {
			attack = Attack.IDLE;
			ticksLeft = 0;
			phaseTotal = 0;
			globalGap = Math.max(globalGap, phaseTwo ? KaraKorukConfig.PHASE2_GLOBAL_GAP_TICKS : KaraKorukConfig.GLOBAL_GAP_TICKS);
		}

		private int cooldown(int base) {
			return phaseTwo ? (int) Math.round(base * KaraKorukConfig.PHASE2_COOLDOWN_SCALE) : base;
		}

		private int windup(int base, int phaseTwoMin) {
			if (!phaseTwo) {
				return base;
			}
			return Math.max(phaseTwoMin, (int) Math.round(base * KaraKorukConfig.PHASE2_WINDUP_SCALE));
		}
	}

	/** Eski API (renderer/animasyon uyumu): Dövme Darbesi hazırlığının ilerlemesi 0-1. */
	public static float slamWindupProgress(Attack attack, float progress) {
		return attack == Attack.SLAM_WINDUP ? clamp(progress) : 0.0F;
	}

	private static float clamp(float value) {
		return Math.max(0.0F, Math.min(1.0F, value));
	}
}
