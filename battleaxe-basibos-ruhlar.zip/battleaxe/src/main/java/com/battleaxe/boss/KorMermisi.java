package com.battleaxe.boss;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Kor Mermisi: Kara Körük'ün çekiçle savurduğu kızgın metal parçası.
 *
 * <p>Ayrı bir varlık DEĞİLDİR: boss'un içinde sunucuda simüle edilen hafif bir nesnedir (varlık kaydı, istemci
 * renderer'ı ve ağ paketi gerektirmez; boss ölünce/kaldırılınca listesiyle birlikte yok olur). Çarpışma ve hasar
 * kararları yalnızca sunucudadır; istemci parçacıkları görür. Her adımda 3 alt adımla ilerler (tünelleme olmaz).
 * Mermi hedefi takip ETMEZ: düz uçar, bu yüzden hedef kaybolsa/ölse de güvenle sonlanır.
 */
final class KorMermisi {
	enum Outcome {
		FLYING, HIT_PLAYER, HIT_BLOCK, EXPIRED, LOST
	}

	private static final int SUBSTEPS = 3;

	private Vec3 position;
	private final Vec3 velocity;
	private int age;

	/** Sonuç HIT_* ise çarpma noktası; HIT_PLAYER ise vurulan oyuncu. */
	private Vec3 impact;
	private Player victim;

	KorMermisi(Vec3 start, Vec3 velocity) {
		this.position = start;
		this.velocity = velocity;
	}

	Vec3 impact() {
		return impact;
	}

	Player victim() {
		return victim;
	}

	Outcome step(ServerLevel level) {
		age++;
		if (age > KaraKorukConfig.EMBER_MAX_AGE_TICKS) {
			impact = position;
			return Outcome.EXPIRED;
		}

		Vec3 sub = velocity.scale(1.0 / SUBSTEPS);
		for (int i = 0; i < SUBSTEPS; i++) {
			Vec3 next = position.add(sub);
			BlockPos blockPos = BlockPos.containing(next);
			if (!level.hasChunkAt(blockPos)) {
				return Outcome.LOST;
			}

			var state = level.getBlockState(blockPos);
			if (!state.getCollisionShape(level, blockPos).isEmpty()) {
				impact = position; // duvarın hemen önünde patlar (blok içinde değil)
				return Outcome.HIT_BLOCK;
			}

			double r = KaraKorukConfig.EMBER_HIT_RADIUS;
			AABB box = new AABB(next.x - r, next.y - r, next.z - r, next.x + r, next.y + r, next.z + r);
			for (Player player : level.getEntitiesOfClass(Player.class, box, p -> p.isAlive() && !p.isSpectator())) {
				victim = player;
				impact = next;
				return Outcome.HIT_PLAYER;
			}
			position = next;
		}

		// Uçuş izi: ölçülü (tick başına birkaç parçacık)
		level.sendParticles(ParticleTypes.FLAME, position.x, position.y, position.z, 3, 0.08, 0.08, 0.08, 0.01);
		if (age % 2 == 0) {
			level.sendParticles(ParticleTypes.LARGE_SMOKE, position.x, position.y, position.z, 1, 0.05, 0.05, 0.05, 0.0);
			level.sendParticles(ParticleTypes.ELECTRIC_SPARK, position.x, position.y, position.z, 1, 0.1, 0.1, 0.1, 0.02);
		}
		return Outcome.FLYING;
	}
}
