package com.battleaxe.boss;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.loot.KaraKorukLoot;

/**
 * Kara Körük: Nether'ın dışlanmış dahi demircisi.
 *
 * <p>Üç ağır saldırısı vardır; hepsi önceden uyarı verir ve bir durum makinesiyle ({@link KaraKorukLogic.Brain})
 * yönetilir, yani aynı anda yalnızca biri yürür:
 * <ul>
 *   <li><b>Dövme Darbesi</b> (yakın): çekicini kaldırır, zemindeki halka dolar, sonra alan hasarı verir ve iter.</li>
 *   <li><b>Kor Mermisi</b> (orta-uzak): çekiciyle kızgın bir metal parçası savurur; çarpınca küçük (blok hasarsız) patlar.</li>
 *   <li><b>Demirci Hücumu</b> (uzak): navigasyonla hızla mesafe kapatır (duvarlardan geçmez, ışınlanmaz).</li>
 * </ul>
 * Canı %50'nin altına inince ikinci aşama BİR KEZ başlar (daha hızlı tempo, küçük tek seferlik artışlar).
 *
 * <p>Canavar (MONSTER) kategorisindedir; baltayla öldürülünce Ruh Bağı ruhu kazandırır
 * ({@link KaraKorukConfig#SOUL_VALUE}). Savaş Baltası sistemlerinde hiçbir değişiklik gerekmez.
 */
public class KaraKorukEntity extends Monster {
	/** Saldırı durumu (KaraKorukLogic.Attack sırası). İstemci çekiç animasyonu için okur. */
	private static final EntityDataAccessor<Integer> DATA_ATTACK =
			SynchedEntityData.defineId(KaraKorukEntity.class, EntityDataSerializers.INT);
	/** Durumun ilerlemesi, yüzde (0-100). */
	private static final EntityDataAccessor<Integer> DATA_PROGRESS =
			SynchedEntityData.defineId(KaraKorukEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Boolean> DATA_PHASE2 =
			SynchedEntityData.defineId(KaraKorukEntity.class, EntityDataSerializers.BOOLEAN);

	private static final Identifier CHARGE_SPEED_ID = BattleAxeMod.id("kara_koruk_charge");
	private static final Identifier PHASE2_SPEED_ID = BattleAxeMod.id("kara_koruk_phase2_speed");
	private static final Identifier PHASE2_DAMAGE_ID = BattleAxeMod.id("kara_koruk_phase2_damage");

	private final ServerBossEvent bossEvent = new ServerBossEvent(
			getUUID(), getDisplayName(), BossEvent.BossBarColor.GREEN, BossEvent.BossBarOverlay.PROGRESS);
	// Not: GREEN rengi, resource'taki boss_bar/green_* sprite'larını (kor kırmızısı) kullanır; bkz. assets/minecraft/.../boss_bar/

	private final KaraKorukLogic.Brain brain = new KaraKorukLogic.Brain();
	private final List<KorMermisi> embers = new ArrayList<>();

	// Demirci Hücumu çalışma durumu
	private final Set<UUID> chargeHit = new HashSet<>();
	private Vec3 chargeLastPosition = Vec3.ZERO;
	private int chargeStuckTicks;
	private int chargeAge;
	private boolean cachedCanCharge;
	private int lastChargeCheck = -100;

	public KaraKorukEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
		setPersistenceRequired(); // uzaklaşınca kaybolmaz
	}

	/**
	 * Dünya yüklenirken ya da yapı şablonundan gelirken kayıtta "PersistenceRequired" etiketi olmasa bile
	 * boss kalıcı sayılır. Ayrıca ESKİ kayıtlı boss'lar (eski, düşük özniteliklerle kaydedilmiş) yeni değerlere
	 * yükseltilir; can ORANI korunur (yarı canlı boss yarı canlı kalır). İkinci aşama can oranından geri kurulur.
	 */
	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		setPersistenceRequired();

		double oldMax = getMaxHealth();
		if (Math.abs(oldMax - KaraKorukConfig.MAX_HEALTH) > 0.5) {
			float ratio = getHealth() / (float) Math.max(1.0, oldMax);
			applyBaseStats();
			setHealth(Math.max(1.0F, ratio * getMaxHealth()));
		} else {
			applyBaseStats();
		}
		if (getHealth() <= getMaxHealth() * KaraKorukConfig.PHASE2_HEALTH_RATIO) {
			brain.restorePhaseTwo(true);
			this.entityData.set(DATA_PHASE2, true);
			applyPhaseTwoModifiers();
		}
	}

	private void applyBaseStats() {
		setBase(Attributes.MAX_HEALTH, KaraKorukConfig.MAX_HEALTH);
		setBase(Attributes.ATTACK_DAMAGE, KaraKorukConfig.ATTACK_DAMAGE);
		setBase(Attributes.MOVEMENT_SPEED, KaraKorukConfig.MOVEMENT_SPEED);
		setBase(Attributes.FOLLOW_RANGE, KaraKorukConfig.FOLLOW_RANGE);
		setBase(Attributes.KNOCKBACK_RESISTANCE, KaraKorukConfig.KNOCKBACK_RESISTANCE);
		setBase(Attributes.ARMOR, KaraKorukConfig.ARMOR);
	}

	private void setBase(Holder<Attribute> attribute, double value) {
		AttributeInstance instance = getAttribute(attribute);
		if (instance != null && Math.abs(instance.getBaseValue() - value) > 1.0E-6) {
			instance.setBaseValue(value);
		}
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, KaraKorukConfig.MAX_HEALTH)
				.add(Attributes.ATTACK_DAMAGE, KaraKorukConfig.ATTACK_DAMAGE)
				.add(Attributes.MOVEMENT_SPEED, KaraKorukConfig.MOVEMENT_SPEED)
				.add(Attributes.FOLLOW_RANGE, KaraKorukConfig.FOLLOW_RANGE)
				.add(Attributes.KNOCKBACK_RESISTANCE, KaraKorukConfig.KNOCKBACK_RESISTANCE)
				.add(Attributes.ARMOR, KaraKorukConfig.ARMOR);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_ATTACK, 0);
		builder.define(DATA_PROGRESS, 0);
		builder.define(DATA_PHASE2, false);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		// Yakın dövüş yalnızca özel bir saldırı sürmüyorken çalışır: saldırılar birbirine karışmaz.
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, KaraKorukConfig.MELEE_SPEED_MODIFIER, true) {
			@Override
			public boolean canUse() {
				return brain.isIdle() && super.canUse();
			}

			@Override
			public boolean canContinueToUse() {
				return brain.isIdle() && super.canContinueToUse();
			}
		});
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	// ------------------------------------------------------------------
	// İstemci için okuma (animasyon)
	// ------------------------------------------------------------------

	public KaraKorukLogic.Attack getAttackState() {
		return KaraKorukLogic.Attack.byOrdinal(this.entityData.get(DATA_ATTACK));
	}

	/** Mevcut saldırı aşamasının ilerlemesi 0-1. */
	public float getAttackProgress() {
		return this.entityData.get(DATA_PROGRESS) / 100.0F;
	}

	public boolean isPhaseTwo() {
		return this.entityData.get(DATA_PHASE2);
	}

	/** Eski API: Dövme Darbesi hazırlığının ilerlemesi (0-1). */
	public float getWindupProgress() {
		return KaraKorukLogic.slamWindupProgress(getAttackState(), getAttackProgress());
	}

	// ------------------------------------------------------------------
	// Boss çubuğu: yakındaki oyuncular görür
	// ------------------------------------------------------------------

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		bossEvent.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		bossEvent.removePlayer(player);
	}

	// ------------------------------------------------------------------
	// Savaş döngüsü
	// ------------------------------------------------------------------

	@Override
	public void aiStep() {
		super.aiStep();
		if (!(level() instanceof ServerLevel server) || !isAlive()) {
			return;
		}
		bossEvent.setProgress(getHealth() / getMaxHealth());
		tickCombat(server);
		tickEmbers(server);
		syncAnimation();
	}

	private static boolean validTarget(LivingEntity target) {
		return target != null && target.isAlive() && !(target instanceof Player player && (player.isSpectator() || player.isCreative()));
	}

	private void tickCombat(ServerLevel server) {
		LivingEntity target = getTarget();
		boolean hasTarget = validTarget(target);

		double distance = hasTarget ? Math.sqrt(distanceToSqr(target)) : 0.0;
		boolean lineOfSight = hasTarget && getSensing().hasLineOfSight(target);
		boolean canCharge = hasTarget && brain.isIdle() && updateCanCharge(target, distance, lineOfSight);
		boolean chargeShouldEnd = brain.attack() == KaraKorukLogic.Attack.CHARGING && chargeShouldEnd(target, hasTarget, distance);

		KaraKorukLogic.Event event = brain.step(new KaraKorukLogic.Inputs(
				hasTarget, distance, lineOfSight, canCharge, chargeShouldEnd,
				getHealth() / getMaxHealth(), this.random.nextDouble()));

		if (brain.phaseTwo() && !isPhaseTwo()) {
			enterPhaseTwo(server);
		}

		switch (event) {
			case SLAM_WINDUP_START -> server.playSound(null, getX(), getY(), getZ(),
					SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.2F, 0.6F);
			case SLAM_STRIKE -> strike(server);
			case EMBER_WINDUP_START -> server.playSound(null, getX(), getY(), getZ(),
					SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.0F, 0.9F);
			case EMBER_LAUNCH -> {
				if (hasTarget) {
					launchEmber(server, target);
				}
			}
			case CHARGE_WINDUP_START -> server.playSound(null, getX(), getY(), getZ(),
					SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.0F, 0.75F);
			case CHARGE_BEGIN -> beginCharge(server, target, hasTarget);
			case CHARGE_END -> endCharge();
			case NONE -> {
			}
		}

		switch (brain.attack()) {
			case SLAM_WINDUP -> {
				getNavigation().stop(); // hazırlık sırasında olduğu yerde durur
				if (tickCount % 4 == 0) {
					warningRing(server, brain.progress());
				}
			}
			case SLAM_RECOVER -> getNavigation().stop();
			case EMBER_WINDUP -> {
				getNavigation().stop();
				faceTarget(target, hasTarget);
				emberTelegraph(server, target, hasTarget, brain.progress());
			}
			case EMBER_SWING -> {
				getNavigation().stop();
				faceTarget(target, hasTarget);
			}
			case CHARGE_WINDUP -> {
				getNavigation().stop();
				faceTarget(target, hasTarget);
				if (tickCount % 3 == 0) {
					server.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 0.1, getZ(), 3, 0.5, 0.05, 0.5, 0.02);
				}
			}
			case CHARGING -> tickCharge(server, target, hasTarget);
			case CHARGE_RECOVER -> getNavigation().stop();
			case IDLE -> retarget(server);
		}

		if (brain.attack() != KaraKorukLogic.Attack.CHARGING) {
			removeModifier(Attributes.MOVEMENT_SPEED, CHARGE_SPEED_ID); // takılı kalmış hız bonusu olmasın
		}
		if (isPhaseTwo() && tickCount % 6 == 0) {
			server.sendParticles(ParticleTypes.FLAME, getX(), getY(1.2), getZ(), 2, 0.5, 0.8, 0.5, 0.02);
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(1.6), getZ(), 1, 0.6, 0.6, 0.6, 0.05);
		}
	}

	private void faceTarget(LivingEntity target, boolean hasTarget) {
		if (hasTarget) {
			getLookControl().setLookAt(target, 30.0F, 30.0F);
		}
	}

	// ------------------------------------------------------------------
	// Hedef seçimi (birden fazla oyuncu)
	// ------------------------------------------------------------------

	/** Boştayken, daha yakın başka bir oyuncu varsa hedefi güvenle değiştirir. Saldırı sırasında hedef değişmez. */
	private void retarget(ServerLevel server) {
		if (tickCount % KaraKorukConfig.RETARGET_INTERVAL_TICKS != 0) {
			return;
		}
		double range = KaraKorukConfig.FOLLOW_RANGE;
		Player best = null;
		double bestDistance = Double.MAX_VALUE;
		for (Player player : server.getEntitiesOfClass(Player.class, getBoundingBox().inflate(range),
				p -> p.isAlive() && !p.isSpectator() && !p.isCreative())) {
			double d = distanceToSqr(player);
			if (d < bestDistance) {
				bestDistance = d;
				best = player;
			}
		}
		if (best == null) {
			return;
		}
		LivingEntity current = getTarget();
		if (!validTarget(current)) {
			setTarget(best);
		} else if (best != current && Math.sqrt(bestDistance) * 1.5 + 3.0 < Math.sqrt(distanceToSqr(current))) {
			setTarget(best);
		}
	}

	// ------------------------------------------------------------------
	// İkinci aşama
	// ------------------------------------------------------------------

	private void enterPhaseTwo(ServerLevel server) {
		this.entityData.set(DATA_PHASE2, true);
		applyPhaseTwoModifiers();
		server.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 2.0F, 0.5F);
		for (int i = 0; i < 24; i++) {
			double angle = i * (Math.PI * 2.0 / 24.0);
			server.sendParticles(ParticleTypes.FLAME, getX() + Math.cos(angle) * 2.2, getY() + 0.3, getZ() + Math.sin(angle) * 2.2,
					2, 0.1, 0.4, 0.1, 0.05);
		}
		server.sendParticles(ParticleTypes.LAVA, getX(), getY(1.2), getZ(), 16, 0.8, 0.8, 0.8, 0.0);
	}

	/** Tek seferlik, küçük artışlar (sınırsız büyüme yok). Aynı kimlikle yazıldığı için tekrar eklenmez. */
	private void applyPhaseTwoModifiers() {
		addModifier(Attributes.MOVEMENT_SPEED, PHASE2_SPEED_ID, KaraKorukConfig.PHASE2_SPEED_BONUS);
		addModifier(Attributes.ATTACK_DAMAGE, PHASE2_DAMAGE_ID, KaraKorukConfig.PHASE2_DAMAGE_BONUS);
	}

	private void addModifier(Holder<Attribute> attribute, Identifier id, double amount) {
		AttributeInstance instance = getAttribute(attribute);
		if (instance != null && instance.getModifier(id) == null) {
			instance.addTransientModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
		}
	}

	private void removeModifier(Holder<Attribute> attribute, Identifier id) {
		AttributeInstance instance = getAttribute(attribute);
		if (instance != null && instance.getModifier(id) != null) {
			instance.removeModifier(id);
		}
	}

	// ------------------------------------------------------------------
	// Dövme Darbesi
	// ------------------------------------------------------------------

	/**
	 * Etki halkasını alevlerle gösterir: dış halka sabittir, iç halka hazırlık ilerledikçe dışarı doğru dolar.
	 * Oyuncu halkanın dışına çıkarak darbeden kaçabilir.
	 */
	private void warningRing(ServerLevel server, float progress) {
		double radius = KaraKorukConfig.SLAM_RADIUS;
		for (int i = 0; i < 20; i++) {
			double angle = i * (Math.PI * 2.0 / 20.0);
			server.sendParticles(ParticleTypes.FLAME,
					getX() + Math.cos(angle) * radius, getY() + 0.1, getZ() + Math.sin(angle) * radius,
					1, 0.0, 0.0, 0.0, 0.0);
		}
		double inner = radius * Math.max(0.15F, progress);
		for (int i = 0; i < 12; i++) {
			double angle = i * (Math.PI * 2.0 / 12.0) + progress * 2.0;
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
					getX() + Math.cos(angle) * inner, getY() + 0.1, getZ() + Math.sin(angle) * inner,
					1, 0.0, 0.0, 0.0, 0.0);
		}
		server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(1.1), getZ(), 3, 0.4, 0.4, 0.4, 0.05);
	}

	private void strike(ServerLevel server) {
		double radius = KaraKorukConfig.SLAM_RADIUS;
		var box = getBoundingBox().inflate(radius, 2.0, radius);
		DamageSource source = damageSources().mobAttack(this);

		for (Player player : server.getEntitiesOfClass(Player.class, box, p -> p.isAlive() && !p.isSpectator())) {
			if (distanceToSqr(player) > radius * radius) {
				continue;
			}
			if (player.hurtServer(server, source, KaraKorukConfig.SLAM_DAMAGE)) {
				player.knockback(KaraKorukConfig.SLAM_KNOCKBACK, getX() - player.getX(), getZ() - player.getZ(), source, KaraKorukConfig.SLAM_DAMAGE);
			}
		}

		server.playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.6F, 0.5F);
		server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 3, 1.5, 0.1, 1.5, 0.0);
		server.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 0.2, getZ(), 24, 2.5, 0.2, 2.5, 0.03);
		for (int i = 0; i < 24; i++) {
			double angle = i * (Math.PI * 2.0 / 24.0);
			server.sendParticles(ParticleTypes.FLAME,
					getX() + Math.cos(angle) * radius, getY() + 0.2, getZ() + Math.sin(angle) * radius,
					2, 0.1, 0.1, 0.1, 0.05);
		}
	}

	// ------------------------------------------------------------------
	// Kor Mermisi
	// ------------------------------------------------------------------

	private Vec3 forward() {
		double yaw = Math.toRadians(getYRot());
		return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
	}

	/** Çekiç başının yaklaşık dünya konumu (parçacıklar ve mermi çıkışı için). */
	private Vec3 hammerPosition() {
		Vec3 forward = forward();
		Vec3 right = new Vec3(-forward.z, 0.0, forward.x).scale(-1.0);
		return position().add(forward.scale(1.5)).add(right.scale(0.7)).add(0.0, 1.9, 0.0);
	}

	private void emberTelegraph(ServerLevel server, LivingEntity target, boolean hasTarget, float progress) {
		Vec3 hammer = hammerPosition();
		if (tickCount % 2 == 0) {
			server.sendParticles(ParticleTypes.FLAME, hammer.x, hammer.y, hammer.z, 3 + (int) (progress * 4), 0.3, 0.3, 0.3, 0.02);
		}
		if (tickCount % 4 == 0) {
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK, hammer.x, hammer.y, hammer.z, 2, 0.4, 0.4, 0.4, 0.06);
		}
		// Yön ipucu: yerde hedefe doğru kısa bir kor çizgisi (hazırlık sonunda atış o yöne gelir).
		if (hasTarget && tickCount % 5 == 0) {
			Vec3 toTarget = new Vec3(target.getX() - getX(), 0.0, target.getZ() - getZ());
			double length = toTarget.length();
			if (length > 0.5) {
				Vec3 dir = toTarget.scale(1.0 / length);
				double reach = Math.min(length, 12.0);
				for (double d = 2.0; d <= reach; d += 1.5) {
					server.sendParticles(ParticleTypes.FLAME, getX() + dir.x * d, getY() + 0.1, getZ() + dir.z * d, 1, 0.0, 0.0, 0.0, 0.0);
				}
			}
		}
	}

	private void launchEmber(ServerLevel server, LivingEntity target) {
		Vec3 forward = forward();
		Vec3 origin = position().add(forward.scale(1.6)).add(0.0, 2.1, 0.0);
		BlockPos originPos = BlockPos.containing(origin);
		var state = server.getBlockState(originPos);
		if (!state.getCollisionShape(server, originPos).isEmpty()) {
			origin = getEyePosition(); // çıkış noktası duvarın içindeyse gövdenin gözünden çık
		}

		Vec3 targetPos = target.position().add(0.0, target.getBbHeight() * 0.55, 0.0);
		double distance = origin.distanceTo(targetPos);
		int flightTicks = (int) Math.min(KaraKorukConfig.EMBER_MAX_LEAD_TICKS, distance / KaraKorukConfig.EMBER_SPEED);
		Vec3 motion = target.getDeltaMovement();
		Vec3 lead = new Vec3(motion.x, 0.0, motion.z).scale(flightTicks * KaraKorukConfig.EMBER_LEAD_FACTOR);
		Vec3 direction = targetPos.add(lead).subtract(origin);
		if (direction.lengthSqr() < 1.0E-4) {
			return;
		}
		embers.add(new KorMermisi(origin, direction.normalize().scale(KaraKorukConfig.EMBER_SPEED)));

		server.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 0.8F, 1.6F);
		server.sendParticles(ParticleTypes.FLAME, origin.x, origin.y, origin.z, 10, 0.2, 0.2, 0.2, 0.1);
	}

	private void tickEmbers(ServerLevel server) {
		Iterator<KorMermisi> iterator = embers.iterator();
		while (iterator.hasNext()) {
			KorMermisi ember = iterator.next();
			KorMermisi.Outcome outcome = ember.step(server);
			switch (outcome) {
				case FLYING -> {
				}
				case HIT_PLAYER, HIT_BLOCK -> {
					impact(server, ember.impact(), ember.victim());
					iterator.remove();
				}
				case EXPIRED, LOST -> {
					if (ember.impact() != null) {
						server.sendParticles(ParticleTypes.LARGE_SMOKE, ember.impact().x, ember.impact().y, ember.impact().z, 6, 0.2, 0.2, 0.2, 0.02);
					}
					iterator.remove();
				}
			}
		}
	}

	/**
	 * İsabet: doğrudan vurulan oyuncuya tam hasar, yakındaki DİĞER oyunculara küçük alan hasarı (blok hasarı YOK).
	 * Mermi bu çağrıdan sonra listeden çıkarıldığı için aynı mermi aynı oyuncuya ikinci kez hasar veremez.
	 */
	private void impact(ServerLevel server, Vec3 at, Player victim) {
		DamageSource source = damageSources().mobAttack(this);
		if (victim != null && victim.isAlive() && victim.hurtServer(server, source, KaraKorukConfig.EMBER_DAMAGE)) {
			victim.knockback(0.7, at.x - victim.getX(), at.z - victim.getZ(), source, KaraKorukConfig.EMBER_DAMAGE);
		}

		double radius = KaraKorukConfig.EMBER_BLAST_RADIUS;
		var box = new net.minecraft.world.phys.AABB(at.x - radius, at.y - radius, at.z - radius, at.x + radius, at.y + radius, at.z + radius);
		for (Player other : server.getEntitiesOfClass(Player.class, box, p -> p.isAlive() && !p.isSpectator() && p != victim)) {
			if (other.distanceToSqr(at.x, at.y, at.z) <= radius * radius
					&& other.hurtServer(server, source, KaraKorukConfig.EMBER_BLAST_DAMAGE)) {
				other.knockback(0.5, at.x - other.getX(), at.z - other.getZ(), source, KaraKorukConfig.EMBER_BLAST_DAMAGE);
			}
		}

		server.playSound(null, at.x, at.y, at.z, SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.4F, 0.7F);
		server.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.2, 0.2, 0.2, 0.0);
		server.sendParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 24, 0.5, 0.4, 0.5, 0.12);
		server.sendParticles(ParticleTypes.LAVA, at.x, at.y, at.z, 8, 0.4, 0.3, 0.4, 0.0);
		server.sendParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 8, 0.4, 0.3, 0.4, 0.03);
	}

	// ------------------------------------------------------------------
	// Demirci Hücumu
	// ------------------------------------------------------------------

	/** Hücum için gerçek bir yol var mı? Pahalı olduğundan 10 tickte bir ve yalnızca gerektiğinde hesaplanır. */
	private boolean updateCanCharge(LivingEntity target, double distance, boolean lineOfSight) {
		if (brain.chargeCooldown() > 0 || distance < KaraKorukConfig.CHARGE_MIN_RANGE || distance > KaraKorukConfig.CHARGE_MAX_RANGE) {
			cachedCanCharge = false;
			return false;
		}
		if (tickCount - lastChargeCheck >= 10) {
			lastChargeCheck = tickCount;
			boolean ok = lineOfSight && Math.abs(target.getY() - getY()) <= KaraKorukConfig.CHARGE_MAX_VERTICAL && onGround();
			if (ok) {
				Path path = getNavigation().createPath(target, 0);
				ok = path != null && path.canReach();
			}
			cachedCanCharge = ok;
		}
		return cachedCanCharge;
	}

	private boolean chargeShouldEnd(LivingEntity target, boolean hasTarget, double distance) {
		if (!hasTarget || distance <= KaraKorukConfig.CHARGE_END_DISTANCE) {
			return true;
		}
		// Takılma: 6 tick boyunca neredeyse hiç ilerlemediyse hücum biter (duvara/engele çarptı).
		Vec3 now = position();
		if (chargeAge > 4 && now.distanceToSqr(chargeLastPosition) < 0.01) {
			chargeStuckTicks++;
		} else {
			chargeStuckTicks = 0;
		}
		chargeLastPosition = now;
		return chargeStuckTicks >= 6;
	}

	private void beginCharge(ServerLevel server, LivingEntity target, boolean hasTarget) {
		chargeHit.clear();
		chargeStuckTicks = 0;
		chargeAge = 0;
		chargeLastPosition = position();
		addModifier(Attributes.MOVEMENT_SPEED, CHARGE_SPEED_ID, KaraKorukConfig.CHARGE_SPEED_BONUS);
		server.playSound(null, getX(), getY(), getZ(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 1.2F, 0.8F);
		if (hasTarget) {
			getNavigation().moveTo(target, 1.0);
		}
	}

	private void tickCharge(ServerLevel server, LivingEntity target, boolean hasTarget) {
		chargeAge++;
		if (hasTarget) {
			getNavigation().moveTo(target, 1.0); // gerçek navigasyon: duvarlardan geçmez, engelleri dolaşır
		}
		if (tickCount % 2 == 0) {
			server.sendParticles(ParticleTypes.FLAME, getX(), getY() + 0.1, getZ(), 2, 0.4, 0.05, 0.4, 0.02);
			server.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.1, getZ(), 2, 0.4, 0.05, 0.4, 0.05);
		}

		// Çarpma: yolundaki oyuncular bir kez hasar alır ve yatay olarak itilir (dikey itme yok).
		DamageSource source = damageSources().mobAttack(this);
		for (Player player : server.getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.8, 0.2, 0.8),
				p -> p.isAlive() && !p.isSpectator())) {
			if (chargeHit.add(player.getUUID())
					&& player.hurtServer(server, source, KaraKorukConfig.CHARGE_IMPACT_DAMAGE)) {
				player.knockback(KaraKorukConfig.CHARGE_IMPACT_KNOCKBACK, getX() - player.getX(), getZ() - player.getZ(),
						source, KaraKorukConfig.CHARGE_IMPACT_DAMAGE);
				server.playSound(null, getX(), getY(), getZ(), SoundEvents.ANVIL_HIT, SoundSource.HOSTILE, 1.0F, 0.6F);
			}
		}
	}

	private void endCharge() {
		removeModifier(Attributes.MOVEMENT_SPEED, CHARGE_SPEED_ID);
		getNavigation().stop();
		chargeHit.clear();
	}

	// ------------------------------------------------------------------
	// Senkron / temizlik
	// ------------------------------------------------------------------

	private void syncAnimation() {
		int attack = brain.attack().ordinal();
		if (this.entityData.get(DATA_ATTACK) != attack) {
			this.entityData.set(DATA_ATTACK, attack);
		}
		int progress = Math.round(brain.progress() * 100.0F);
		if (this.entityData.get(DATA_PROGRESS) != progress) {
			this.entityData.set(DATA_PROGRESS, progress);
		}
	}

	// ------------------------------------------------------------------
	// Ganimet: ölümde garanti, tek seferlik
	// ------------------------------------------------------------------

	private boolean lootDropped;

	@Override
	public void die(DamageSource source) {
		// Aktif mermiler ve geçici saldırı durumları güvenle temizlenir.
		embers.clear();
		brain.abort();
		endCharge();
		super.die(source);
		if (!lootDropped && level() instanceof ServerLevel server) {
			lootDropped = true;
			KaraKorukLoot.dropAll(server, this);
		}
	}
}
