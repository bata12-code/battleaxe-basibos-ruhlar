package com.battleaxe.boss;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import com.battleaxe.BattleAxeMod;

/** Boss varlık tipleri. Çağırmak için: /summon battleaxe:kara_koruk */
public final class ModBossTypes {
	private ModBossTypes() {
	}

	public static final ResourceKey<EntityType<?>> KARA_KORUK_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, BattleAxeMod.id("kara_koruk"));

	public static final EntityType<KaraKorukEntity> KARA_KORUK = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			KARA_KORUK_KEY,
			EntityType.Builder.<KaraKorukEntity>of(KaraKorukEntity::new, MobCategory.MONSTER)
					.sized(1.1F, 2.9F)
					.eyeHeight(2.5F)
					.clientTrackingRange(10)
					.fireImmune()
					.build(KARA_KORUK_KEY)
	);

	public static void initialize() {
		FabricDefaultAttributeRegistry.register(KARA_KORUK, KaraKorukEntity.createAttributes());
	}
}
