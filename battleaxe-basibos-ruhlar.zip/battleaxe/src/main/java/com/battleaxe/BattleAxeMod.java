package com.battleaxe;

import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.battleaxe.berserker.BerserkerManager;
import com.battleaxe.call.CallManager;
import com.battleaxe.chain.ChainManager;
import com.battleaxe.boss.ModBossTypes;
import com.battleaxe.block.ModBlocks;
import com.battleaxe.component.ModComponents;
import com.battleaxe.execution.ExecutionManager;
import com.battleaxe.item.ModItems;
import com.battleaxe.evolution.EvolutionManager;
import com.battleaxe.nexus.NexusManager;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.thrown.ThrownAxeManager;

public class BattleAxeMod implements ModInitializer {
	public static final String MOD_ID = "battleaxe";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// Eşya bileşenleri (Ruh Bağı sayacı, Berserker görünüm bayrağı) eşyalardan ÖNCE kaydedilir.
		ModComponents.initialize();

		// Kara Körük'ün Örsü (blok + eşya); ModItems'taki yaratıcı sekme girdisinden önce kaydedilir.
		ModBlocks.initialize();

		// Eşyaları kaydeder ve yaratıcı moddaki "Savaş" sekmesine ekler.
		ModItems.initialize();

		// Berserker sistemi: sunucu tarafı durum takibi ve istemci HUD paketi.
		BerserkerManager.initialize();

		// Ruh Bağı: baltayla öldürdükçe rütbe atlar (kozmetik).
		SoulManager.initialize();

		// Ruh Ağı: 100 düğümlük RPG yetenek ağacı (mevcut ruh sistemine bağlanır, onun yerine geçmez).
		NexusManager.initialize();

		// Berserker Evrimi: Savaş Özü, aşamalar, üç dal (mevcut Berserker'ın üzerine kurulur, onun yerine geçmez).
		EvolutionManager.initialize();

		// Baltanın Çağrısı: balta edinilmeden önce seyrek mesaj ve işaretler (hiçbir ilerlemeyi kilitlemez).
		CallManager.initialize();

		// Execution: baltayla nadiren sinematik bitirici (ilk sürüm: Zombi ve İskelet).
		ExecutionManager.initialize();
		com.battleaxe.berserker.HiddetRoar.initialize();

		// Kıyım Zinciri: süre dolmadan art arda öldürmeler kademe atlatır (küçük bonus, aura, tören; ağ paketi yok).
		ChainManager.initialize();

		// Ağır Balta Fırlatma: fırlatılan balta varlığı ve sunucu tarafı doğrulama.
		ThrownAxeManager.initialize();

		// Shunpo: isabetten sonra ikinci tuşla fırlatma konumuna ışınlanma (büyü: data/battleaxe/enchantment/shunpo.json).
		com.battleaxe.shunpo.ShunpoManager.initialize();

		// Kara Körük (boss): varlık tipi ve öznitelikleri.
		ModBossTypes.initialize();

		// Başıboş Ruhlar: üç ruh türünün varlık kayıtları, mühür/koordinasyon/fısıltı sistemleri ve test komutu (/baltaruh).
		com.battleaxe.spirit.ModSpiritTypes.initialize();

		LOGGER.info("Savaş Baltası modu yüklendi!");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
