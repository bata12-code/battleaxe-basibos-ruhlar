package com.battleaxe.berserker;

/**
 * Berserker durum makinesinin saf mantığı. Minecraft'a bağımlı değildir; sadece sayı ve
 * boolean alır, böylece oyun olmadan da test edilebilir.
 */
public final class BerserkerLogic {
	private BerserkerLogic() {
	}

	/**
	 * Bir sonraki Berserker durumunu hesaplar. Durum değişimi (INACTIVE -> ACTIVE ve tersi) sadece
	 * burada, açık koşullarla olur; sistem her tick tekrar tekrar "aktive etmeye" çalışmaz.
	 *
	 * <ul>
	 *   <li>Oyuncu ölüyse: her zaman INACTIVE (ölüm state'i sıfırlar).</li>
	 *   <li>INACTIVE iken: yalnızca Savaş Baltası ana elde VE can &lt;= %50 ise ACTIVE olur.</li>
	 *   <li>ACTIVE iken: can %60'ın ÜZERİNE çıkana kadar ACTIVE kalır. Bu sırada baltanın elde
	 *       olup olmaması state'i etkilemez (sadece bonusların uygulanıp uygulanmayacağını
	 *       etkiler, bkz. {@link #bonusesActive}).</li>
	 * </ul>
	 */
	public static BerserkerState nextState(
			BerserkerState current,
			boolean alive,
			boolean holdingBattleAxe,
			double health,
			double maxHealth
	) {
		if (!alive || maxHealth <= 0.0) {
			return BerserkerState.INACTIVE;
		}

		if (current == BerserkerState.ACTIVE) {
			boolean recovered = health > maxHealth * BerserkerConfig.DEACTIVATION_HEALTH_RATIO + BerserkerConfig.EPSILON;
			return recovered ? BerserkerState.INACTIVE : BerserkerState.ACTIVE;
		}

		boolean lowEnough = health <= maxHealth * BerserkerConfig.ACTIVATION_HEALTH_RATIO + BerserkerConfig.EPSILON;
		return (holdingBattleAxe && lowEnough) ? BerserkerState.ACTIVE : BerserkerState.INACTIVE;
	}

	/**
	 * Saldırı hasarı/hızı bonusları şu an uygulanmalı mı? Yalnızca Berserker AKTİF ve Savaş Baltası
	 * ana elde iken. Böylece oyuncu aktifken başka silaha geçerse o silah bonus almaz.
	 */
	public static boolean bonusesActive(BerserkerState state, boolean holdingBattleAxe) {
		return state == BerserkerState.ACTIVE && holdingBattleAxe;
	}
}
