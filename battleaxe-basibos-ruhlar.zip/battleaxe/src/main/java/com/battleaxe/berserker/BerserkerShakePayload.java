package com.battleaxe.berserker;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan oyuncunun kendi istemcisine: "ekranı şu şiddette, şu kadar tick titret".
 * Titreme tamamen görseldir; oyuncunun gerçek nişanını/rotasyonunu değiştirmez.
 */
public record BerserkerShakePayload(float strength, int ticks) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<BerserkerShakePayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("berserker_shake"));

	public static final StreamCodec<RegistryFriendlyByteBuf, BerserkerShakePayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.FLOAT,
			BerserkerShakePayload::strength,
			ByteBufCodecs.VAR_INT,
			BerserkerShakePayload::ticks,
			BerserkerShakePayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
