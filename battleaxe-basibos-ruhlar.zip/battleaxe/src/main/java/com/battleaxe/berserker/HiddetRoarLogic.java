package com.battleaxe.berserker;

/** Hiddet kükremesinin SAF kararı (Minecraft'tan bağımsız, test edilebilir). */
public final class HiddetRoarLogic {
	private HiddetRoarLogic() {
	}

	/** Aynı oyuncunun iki kükremesi arasındaki en kısa süre (tick). Ses üst üste binmesin; gerçek öldürüşleri yutmasın diye kısa. */
	public static final int MIN_GAP_TICKS = 6;
	/** Aynı ölümün tekrar işlenmesini engellemek için hatırlanan son kurban sayısı. */
	public static final int RECENT_VICTIMS = 8;

	/**
	 * @param hiddetActive    sunucudaki Hiddet durumu açık mı
	 * @param holdingAxe      oyuncu ana elde özel baltayı tutuyor mu
	 * @param critical        öldüren vuruş kritik miydi (vanilla kritik, Cellat darbesi ya da kombo bitirici)
	 * @param victimDead      kurban gerçekten ölü mü
	 * @param alreadyHandled  bu kurban için kükreme zaten işlendi mi
	 * @param ticksSinceLast  bu oyuncunun son kükremesinden beri geçen tick
	 */
	public static boolean shouldRoar(boolean hiddetActive, boolean holdingAxe, boolean critical, boolean victimDead,
			boolean alreadyHandled, long ticksSinceLast) {
		return hiddetActive && holdingAxe && critical && victimDead && !alreadyHandled && ticksSinceLast >= MIN_GAP_TICKS;
	}
}
