package com.battleaxe.berserker;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import com.battleaxe.BattleAxeMod;

/**
 * Sunucudan oyuncunun kendi istemcisine giden paket: "Berserker şu an aktif mi?"
 * Sadece HUD içindir; hasar/hız bonusları sunucuda uygulanır ve vanilla tarafından senkronlanır.
 */
public record BerserkerStatePayload(boolean active) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<BerserkerStatePayload> TYPE =
			new CustomPacketPayload.Type<>(BattleAxeMod.id("berserker_state"));

	public static final StreamCodec<RegistryFriendlyByteBuf, BerserkerStatePayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.BOOL,
			BerserkerStatePayload::active,
			BerserkerStatePayload::new
	);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
