package com.battleaxe.berserker;

import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.item.ModItems;
import com.battleaxe.soul.SoulLogic;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.soul.Whispers;

/**
 * Berserker'ın SUNUCU tarafı (otoriter) yöneticisi.
 *
 * <ul>
 *   <li>Durum sunucuda tutulur; istemci sadece HUD için bilgilendirilir.</li>
 *   <li>Hasar/hız bonusları oyuncunun gerçek özniteliklerine SUNUCUDA eklenir; vanilla bunları
 *       istemciye kendisi senkronlar (saldırı göstergesi de doğru çalışır).</li>
 *   <li>Bonuslar sabit kimlikli (id) geçici modifier'lardır: aynı id ikinci kez eklenmez
 *       (üst üste binme yok) ve kayda yazılmaz (oyun çökse bile kalıcı bonus kalmaz).</li>
 * </ul>
 */
public final class BerserkerManager {
	private BerserkerManager() {
	}

	/** Oyuncunun Berserker durumu. Kalıcı değil; ölünce/yeniden doğunca yeni oyuncu nesnesiyle sıfırlanır. */
	private static final AttachmentType<BerserkerState> STATE =
			AttachmentRegistry.create(BattleAxeMod.id("berserker_state"));

	/** İstemciye en son hangi durumu bildirdiğimiz (gereksiz/eksik paket olmasın diye). */
	private static final AttachmentType<Boolean> CLIENT_SYNCED =
			AttachmentRegistry.create(BattleAxeMod.id("berserker_client_synced"));

	/** Son yıldırımın düştüğü oyun zamanı (bekleme süresi için). Kalıcı değil. */
	private static final AttachmentType<Long> LAST_STRIKE_TIME =
			AttachmentRegistry.create(BattleAxeMod.id("berserker_last_strike"));

	private static final Identifier DAMAGE_MODIFIER_ID = BattleAxeMod.id("berserker_damage");
	private static final Identifier SPEED_MODIFIER_ID = BattleAxeMod.id("berserker_attack_speed");

	public static void initialize() {
		PayloadTypeRegistry.clientboundPlay().register(BerserkerStatePayload.TYPE, BerserkerStatePayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(BerserkerShakePayload.TYPE, BerserkerShakePayload.CODEC);

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tick(player);
			}
		});
	}

	public static boolean isActive(ServerPlayer player) {
		return getState(player) == BerserkerState.ACTIVE;
	}

	private static BerserkerState getState(ServerPlayer player) {
		return player.getAttachedOrElse(STATE, BerserkerState.INACTIVE);
	}

	private static boolean isHoldingBattleAxe(ServerPlayer player) {
		return player.getMainHandItem().is(ModItems.BATTLE_AXE);
	}

	private static void tick(ServerPlayer player) {
		BerserkerState current = getState(player);
		BerserkerState next = BerserkerLogic.nextState(
				current,
				!player.isDeadOrDying(),
				isHoldingBattleAxe(player),
				player.getHealth(),
				player.getMaxHealth()
		);

		// Durum SADECE gerçekten değiştiğinde yazılır (tek seferlik geçiş).
		if (next != current) {
			player.setAttached(STATE, next);

			// Tek seferlik efekt: Berserker'ın başladığı an (her tick tekrarlanmaz).
			if (next == BerserkerState.ACTIVE && player.level() instanceof ServerLevel level) {
				BerserkerEffects.activation(level, player);
				Whispers.onBerserk(level, player, SoulManager.rankOf(player.getMainHandItem()));
				com.battleaxe.nexus.NexusWhispers.onBerserk(level, player);
			}
		}

		syncBonuses(player);
		syncClient(player);

		// Aktifken ve balta elde iken oyuncunun etrafında hafif kor aurası.
		if (next == BerserkerState.ACTIVE && isHoldingBattleAxe(player)
				&& player.tickCount % BerserkerConfig.AURA_INTERVAL_TICKS == 0
				&& player.level() instanceof ServerLevel level) {
			BerserkerEffects.aura(level, player);
		}
	}

	/**
	 * Berserker aktifken, başarılı bir balta vuruşunda belli bir olasılıkla hedefin üzerine
	 * (sadece görsel) yıldırım düşürür. Düşerse true döner.
	 *
	 * <p>Çağıran taraf baltanın ana elde olduğunu garanti eder. Burada ayrıca Berserker'ın aktif
	 * olması, bekleme süresi ve olasılık kontrol edilir.
	 */
	public static boolean tryLightningStrike(ServerLevel level, ServerPlayer player, Entity target) {
		// Eski Berserker'ın yıldırımı, Berserker Evrimi Uyanış (II) ve üstünde de çalışır.
		if ((!isActive(player) && com.battleaxe.evolution.EvolutionManager.stageLevel(player) < 2) || target == player) {
			return false;
		}

		long now = level.getGameTime();
		Long last = player.getAttached(LAST_STRIKE_TIME);
		if (last != null && now - last < BerserkerConfig.BERSERKER_LIGHTNING_COOLDOWN_TICKS) {
			return false;
		}

		double chance = BerserkerConfig.BERSERKER_LIGHTNING_CHANCE
				+ SoulLogic.lightningChanceBonus(SoulManager.rankOf(player.getMainHandItem()))
				+ com.battleaxe.evolution.EvolutionEvents.lightningChanceBonus(player);
		if (ThreadLocalRandom.current().nextDouble() >= chance) {
			return false;
		}

		player.setAttached(LAST_STRIKE_TIME, now);
		BerserkerEffects.visualLightning(level, player, target);
		return true;
	}

	/**
	 * Bonusları, durum + ana eldeki eşyayla uyumlu hale getirir. Idempotent'tir: kaç kez
	 * çağrılırsa çağrılsın sonuç aynıdır, bonus asla birikmez. PlayerMixin bunu ayrıca her
	 * saldırının hemen öncesinde çağırır (aynı tick'te silah değiştirip vurma açığını kapatmak için).
	 */
	public static void syncBonuses(ServerPlayer player) {
		boolean apply = BerserkerLogic.bonusesActive(getState(player), isHoldingBattleAxe(player));
		setBonuses(player, apply);
	}

	private static void setBonuses(ServerPlayer player, boolean apply) {
		AttributeInstance damage = player.getAttribute(Attributes.ATTACK_DAMAGE);
		AttributeInstance speed = player.getAttribute(Attributes.ATTACK_SPEED);

		if (damage != null) {
			boolean present = damage.getModifier(DAMAGE_MODIFIER_ID) != null;
			if (apply && !present) {
				damage.addTransientModifier(new AttributeModifier(
						DAMAGE_MODIFIER_ID,
						BerserkerConfig.BERSERKER_DAMAGE_BONUS,
						AttributeModifier.Operation.ADD_VALUE));
			} else if (!apply && present) {
				damage.removeModifier(DAMAGE_MODIFIER_ID);
			}
		}

		if (speed != null) {
			boolean present = speed.getModifier(SPEED_MODIFIER_ID) != null;
			if (apply && !present) {
				// ADD_MULTIPLIED_TOTAL: diğer her şey hesaplandıktan sonra değeri (1 + miktar) ile çarpar.
				// Çarpan 1.35 ise miktar 0.35 olur: normal hızdan tam %35 daha hızlı.
				speed.addTransientModifier(new AttributeModifier(
						SPEED_MODIFIER_ID,
						BerserkerConfig.BERSERKER_ATTACK_SPEED_MULTIPLIER - 1.0,
						AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
			} else if (!apply && present) {
				speed.removeModifier(SPEED_MODIFIER_ID);
			}
		}
	}

	/**
	 * İstemciye (HUD için) durumu bildirir: yalnızca istemcinin bildiği değer değiştiyse paket gider.
	 * Oyuncu nesnesi yeniden oluştuğunda (giriş, ölüm sonrası doğma) kayıt boş olduğundan ilk tick'te
	 * güncel durum otomatik olarak yeniden gönderilir.
	 */
	private static void syncClient(ServerPlayer player) {
		boolean active = getState(player) == BerserkerState.ACTIVE;
		Boolean last = player.getAttached(CLIENT_SYNCED);

		if (last == null || last != active) {
			if (ServerPlayNetworking.canSend(player, BerserkerStatePayload.TYPE)) {
				ServerPlayNetworking.send(player, new BerserkerStatePayload(active));
			}
			player.setAttached(CLIENT_SYNCED, active);
		}
	}
}
