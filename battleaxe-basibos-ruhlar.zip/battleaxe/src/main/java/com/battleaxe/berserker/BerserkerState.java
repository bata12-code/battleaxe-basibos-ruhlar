package com.battleaxe.berserker;

/** Bir oyuncunun Berserker durumu. */
public enum BerserkerState {
	INACTIVE,
	ACTIVE
}
