package com.battleaxe.berserker;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;

import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.NexusApi;
import com.battleaxe.nexus.Stat;

/**
 * <b>Hiddet kükremesi</b>: Hiddet aktifken, özel baltayla yapılan GEÇERLİ BİR KRİTİK ÖLDÜRÜŞTE baltaya özgü, kısa ve güçlü
 * bir kükreme (sunucudan, tek kez) çalar ve küçük bir ruhsal parçacık patlaması çıkar.
 *
 * <p>Yeni bir kritik sistemi YOKTUR: çağrı noktaları mevcut kritik akışlarındadır —
 * {@code PlayerMixin#attackVisualEffects} (vanilla kritik vuruşun sonucu; Ruh Ağı'nın Cellat darbesi de aynı tick'te
 * tespit edilir) ve kombo bitirici vuruşu. Normal öldürüşlerde ve Hiddet kapalıyken çalmaz.
 *
 * <p>Çoğalma önlemi: ses yalnızca sunucuda çalınır (istemci yalnızca duyar). Aynı kurban için ikinci çağrı yok
 * sayılır ({@link HiddetRoarLogic#RECENT_VICTIMS} kurbanlık kısa hafıza) ve aynı oyuncunun iki kükremesi arasında
 * {@link HiddetRoarLogic#MIN_GAP_TICKS} tick vardır.
 *
 * <p>Ses: yeni bir ses dosyası/kaydı eklenmedi (mod henüz özel SoundEvent kaydetmiyor); mevcut Vanilla sesleri,
 * baltaya yakışan alçak perdede katmanlanır.
 */
public final class HiddetRoar {
	private HiddetRoar() {
	}

	private static final Map<UUID, Long> LAST_TICK = new HashMap<>();
	private static final ArrayDeque<UUID> RECENT = new ArrayDeque<>();

	public static void initialize() {
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> LAST_TICK.remove(handler.getPlayer().getUUID()));
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			LAST_TICK.clear();
			RECENT.clear();
		});
	}

	/**
	 * Kritik bir vuruş {@code victim}'i öldürdüyse çağrılır (kritik olmayan vuruşlarda çağrılmaz).
	 *
	 * @return kükreme çalındıysa true
	 */
	public static boolean onCriticalKill(ServerLevel level, ServerPlayer player, LivingEntity victim) {
		long now = level.getGameTime();
		boolean handled = RECENT.contains(victim.getUUID());
		long since = now - LAST_TICK.getOrDefault(player.getUUID(), Long.MIN_VALUE / 2);
		if (!HiddetRoarLogic.shouldRoar(BerserkerManager.isActive(player), player.getMainHandItem().is(ModItems.BATTLE_AXE),
				true, victim.isDeadOrDying(), handled, since)) {
			return false;
		}
		RECENT.addLast(victim.getUUID());
		while (RECENT.size() > HiddetRoarLogic.RECENT_VICTIMS) {
			RECENT.removeFirst();
		}
		LAST_TICK.put(player.getUUID(), now);

		double x = player.getX();
		double y = player.getY(0.6);
		double z = player.getZ();
		level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.0F, 0.55F);
		level.playSound(null, x, y, z, SoundEvents.ANVIL_HIT, SoundSource.PLAYERS, 0.35F, 0.5F);
		level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 14, 0.5, 0.5, 0.5, 0.06);
		level.sendParticles(ParticleTypes.SOUL, victim.getX(), victim.getY(0.6), victim.getZ(), 6, 0.3, 0.4, 0.3, 0.04);
		BerserkerEffects.sendShake(player, 0.35F, 6);

		// Lanetli Bilinç: kükremenin şifası (düğümlerden; yoksa 0).
		double heal = NexusApi.stats(player).get(Stat.HIDDET_ROAR_HEAL);
		if (heal > 0.0 && player.isAlive()) {
			player.heal((float) heal);
		}
		return true;
	}
}
