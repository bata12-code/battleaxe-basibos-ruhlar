package com.battleaxe.berserker;

import java.util.concurrent.ThreadLocalRandom;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;

/**
 * Berserker'ın görsel/işitsel efektleri. Hasar, yangın veya blok değişimi YAPMAZ.
 */
public final class BerserkerEffects {
	private BerserkerEffects() {
	}

	/** Kor: parlak turuncu-kırmızıdan kömür siyahına. */
	private static final DustColorTransitionOptions EMBER =
			new DustColorTransitionOptions(0xFF3A10, 0x1A0000, 0.9F);
	/** Aura: daha küçük ve soluk kor. */
	private static final DustColorTransitionOptions AURA =
			new DustColorTransitionOptions(0xE02A10, 0x200000, 0.6F);

	/** Berserker'ın başladığı an: kükreme, kor patlaması ve ekran titremesi. */
	public static void activation(ServerLevel level, ServerPlayer player) {
		double x = player.getX();
		double y = player.getY(0.5);
		double z = player.getZ();

		level.playSound(null, x, y, z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.0F, 0.9F);

		level.sendParticles(EMBER, x, y, z, 30, 0.5, 0.7, 0.5, 0.0);
		level.sendParticles(ParticleTypes.FLAME, x, y, z, 14, 0.4, 0.5, 0.4, 0.12);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 6, 0.4, 0.6, 0.4, 0.03);

		sendShake(player, BerserkerConfig.ACTIVATION_SHAKE_STRENGTH, BerserkerConfig.ACTIVATION_SHAKE_TICKS);
	}

	/** Berserker aktifken oyuncunun etrafında hafif kor ve alev; yakındaki herkes görür. */
	public static void aura(ServerLevel level, ServerPlayer player) {
		double x = player.getX();
		double y = player.getY(0.55);
		double z = player.getZ();

		level.sendParticles(AURA, x, y, z, 3, 0.35, 0.6, 0.35, 0.0);
		if (ThreadLocalRandom.current().nextInt(3) == 0) {
			level.sendParticles(ParticleTypes.FLAME, x, player.getY(0.2), z, 1, 0.25, 0.1, 0.25, 0.02);
		}
	}

	/**
	 * Hedefin üzerine SADECE GÖRSEL bir yıldırım düşürür (setVisualOnly): vanilla'nın hasar, yangın,
	 * dönüşüm (köylü/domuz/creeper) ve paratoner etkileri çalışmaz. Gök gürültüsü ve ışık kalır.
	 */
	public static void visualLightning(ServerLevel level, ServerPlayer attacker, Entity target) {
		LightningBolt bolt = EntityTypes.LIGHTNING_BOLT.create(level, EntitySpawnReason.TRIGGERED);
		if (bolt == null) {
			return;
		}
		bolt.snapTo(target.getX(), target.getY(), target.getZ());
		bolt.setVisualOnly(true);
		level.addFreshEntity(bolt);

		sendShake(attacker, BerserkerConfig.STRIKE_SHAKE_STRENGTH, BerserkerConfig.STRIKE_SHAKE_TICKS);
	}

	public static void sendShake(ServerPlayer player, float strength, int ticks) {
		if (ServerPlayNetworking.canSend(player, BerserkerShakePayload.TYPE)) {
			ServerPlayNetworking.send(player, new BerserkerShakePayload(strength, ticks));
		}
	}
}
