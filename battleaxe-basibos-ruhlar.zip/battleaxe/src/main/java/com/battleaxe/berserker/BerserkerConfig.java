package com.battleaxe.berserker;

/**
 * Berserker sisteminin dengeleme ayarları. Dengelemek için sadece bu dosyayı değiştirmen yeterli.
 */
public final class BerserkerConfig {
	private BerserkerConfig() {
	}

	/**
	 * Can, maksimum canın bu oranına VEYA altına düşünce Berserker aktifleşir.
	 * 0.50 = %50 (maks. can 20 ise 10 HP ve altı). Oran, oyuncunun GÜNCEL azami canına göre hesaplanır
	 * (Can Artışı, Ruh Ağı can bonusları, Kan Borcu vb. dahil); emici/sarı kalpler (absorption) sayılmaz.
	 */
	public static final double ACTIVATION_HEALTH_RATIO = 0.50;

	/**
	 * Berserker aktifken can, maksimum canın bu oranının ÜZERİNE çıkınca kapanır.
	 * 0.60 = %60. Aktivasyondan (0.50) bilerek daha yüksektir (histerezis): sınırda dalgalanan
	 * can Berserker'ı sürekli açıp kapatmaz, başlangıç efektleri (kükreme, titreme, fısıltı) tekrarlanmaz.
	 * Bu değer ACTIVATION_HEALTH_RATIO'dan büyük olmalıdır; eşitlenirse histerezis kaybolur.
	 * (Eski değerler: aktivasyon 0.30, kapanma 0.50; aradaki fark 0.20 idi, şimdi 0.10.)
	 */
	public static final double DEACTIVATION_HEALTH_RATIO = 0.60;

	/**
	 * Berserker'da Savaş Baltası'na eklenen düz hasar. Balta 16 vurur, Berserker'da 16 + 4 = 20.
	 */
	public static final double BERSERKER_DAMAGE_BONUS = 4.0;

	/**
	 * Berserker'da saldırı hızı çarpanı. 1.35 = normal hızdan %35 daha hızlı
	 * (balta normalde 0.8 saldırı/sn, Berserker'da 0.8 * 1.35 = 1.08 saldırı/sn).
	 */
	public static final double BERSERKER_ATTACK_SPEED_MULTIPLIER = 1.35;

	// ------------------------------------------------------------------
	// Berserker'a özel efektler
	// ------------------------------------------------------------------

	/**
	 * Berserker aktifken, baltayla başarılı her vuruşta vurulan mobun üzerine görsel yıldırım
	 * düşme olasılığı (0.25 = %25). Yıldırım SADECE görseldir: hasar vermez, yangın çıkarmaz,
	 * blok/entity'ye etki etmez; sadece ışık, gök gürültüsü ve ekran titremesi verir.
	 */
	public static final double BERSERKER_LIGHTNING_CHANCE = 0.25;

	/** İki yıldırım arasındaki en kısa süre (tick; 20 tick = 1 sn). Yıldırım yağmuru olmasın diye. */
	public static final int BERSERKER_LIGHTNING_COOLDOWN_TICKS = 20;

	/**
	 * Berserker aktifken KRİTİK vuruşta, alev yerine parçacık yıldırımı seçilme olasılığı.
	 * Normalde bu oran {@code CritEffects.LIGHTNING_CHANCE} (%25) kadardır.
	 */
	public static final double BERSERKER_CRIT_LIGHTNING_CHANCE = 0.50;

	/** Berserker aktifken oyuncunun etrafında kor/duman aurasının tazelenme aralığı (tick). */
	public static final int AURA_INTERVAL_TICKS = 6;

	/** Berserker'ın başladığı anda ekran titremesinin şiddeti (0-1) ve süresi (tick). */
	public static final float ACTIVATION_SHAKE_STRENGTH = 1.0F;
	public static final int ACTIVATION_SHAKE_TICKS = 14;

	/** Yıldırım düştüğünde ekran titremesinin şiddeti (0-1) ve süresi (tick). */
	public static final float STRIKE_SHAKE_STRENGTH = 0.7F;
	public static final int STRIKE_SHAKE_TICKS = 8;

	/** Kayan nokta yuvarlama hatalarına karşı küçük tolerans (can değerleri float). */
	static final double EPSILON = 1.0E-4;
}
