package com.battleaxe.block;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

import com.battleaxe.BattleAxeMod;

/** Kara Körük'ün Örsü: blok ve blok eşyası. */
public final class ModBlocks {
	private ModBlocks() {
	}

	public static final ResourceKey<Block> KARA_KORUK_ORS_KEY =
			ResourceKey.create(Registries.BLOCK, BattleAxeMod.id("kara_koruk_ors"));
	public static final ResourceKey<Item> KARA_KORUK_ORS_ITEM_KEY =
			ResourceKey.create(Registries.ITEM, BattleAxeMod.id("kara_koruk_ors"));

	public static final Block KARA_KORUK_ORS = Registry.register(
			BuiltInRegistries.BLOCK, KARA_KORUK_ORS_KEY,
			new KaraKorukAnvilBlock(BlockBehaviour.Properties.of()
					.setId(KARA_KORUK_ORS_KEY)
					.mapColor(MapColor.COLOR_BLACK)
					.requiresCorrectToolForDrops()
					.strength(5.0F, 1200.0F)
					.sound(SoundType.ANVIL)));

	public static final Item KARA_KORUK_ORS_ITEM = Registry.register(
			BuiltInRegistries.ITEM, KARA_KORUK_ORS_ITEM_KEY,
			new BlockItem(KARA_KORUK_ORS, new Item.Properties()
					.setId(KARA_KORUK_ORS_ITEM_KEY)
					.useBlockDescriptionPrefix()
					.rarity(Rarity.RARE)));

	/** Sınıfın yüklenip kayıtların yapılmasını sağlar. */
	public static void initialize() {
	}
}
