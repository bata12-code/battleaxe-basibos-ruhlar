package com.battleaxe.block;

import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import com.battleaxe.item.BlackHandle;
import com.battleaxe.item.ModItems;

/**
 * Kara Körük'ün Örsü'nün sunucu taraflı menüsü.
 *
 * <p>İstemci tarafında vanilla huni (HOPPER) arayüzü kullanılır; böylece istemciye ek ekran/menü
 * kodu gerekmez. Yuva düzeni (soldan sağa): 0 = Savaş Baltası, 1 = Kara Çubuk, 2 = Blaze Çubuğu,
 * 3 = kapalı (kullanılmaz), 4 = sonuç. Tüm mantık sunucuda çalışır ve istemci vanilla gibi senkronlanır.
 */
public class KaraKorukAnvilMenu extends AbstractContainerMenu {
	private static final int AXE = 0, ROD = 1, BLAZE = 2, SPARE = 3, OUT = 4;
	private static final int INV_START = 5, INV_END = 32, HOTBAR_END = 41;

	private final Container inputs = new SimpleContainer(3) {
		@Override
		public void setChanged() {
			super.setChanged();
			KaraKorukAnvilMenu.this.slotsChanged(this);
		}
	};
	private final Container output = new SimpleContainer(1);
	private final ContainerLevelAccess access;

	public KaraKorukAnvilMenu(int containerId, Inventory playerInventory, ContainerLevelAccess access) {
		super(MenuType.HOPPER, containerId);
		this.access = access;

		addSlot(new Slot(inputs, AXE, 44, 20) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.is(ModItems.BATTLE_AXE);
			}

			@Override
			public int getMaxStackSize() {
				return 1;
			}
		});
		addSlot(new Slot(inputs, ROD, 62, 20) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.is(ModItems.KARA_CUBUK);
			}
		});
		addSlot(new Slot(inputs, BLAZE, 80, 20) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return stack.is(Items.BLAZE_ROD);
			}
		});
		addSlot(new Slot(new SimpleContainer(1), 0, 98, 20) { // kapalı yuva
			@Override
			public boolean mayPlace(ItemStack stack) {
				return false;
			}
		});
		addSlot(new Slot(output, 0, 116, 20) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return false;
			}

			@Override
			public void onTake(Player player, ItemStack stack) {
				consumeInputs();
			}
		});

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 51 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			addSlot(new Slot(playerInventory, col, 8 + col * 18, 109));
		}
	}

	private boolean recipeMatches() {
		ItemStack axe = inputs.getItem(AXE);
		return axe.is(ModItems.BATTLE_AXE) && !BlackHandle.isUpgraded(axe)
				&& inputs.getItem(ROD).is(ModItems.KARA_CUBUK)
				&& inputs.getItem(BLAZE).is(Items.BLAZE_ROD);
	}

	@Override
	public void slotsChanged(Container container) {
		super.slotsChanged(container);
		if (container == inputs) {
			output.setItem(0, recipeMatches() ? BlackHandle.upgraded(inputs.getItem(AXE)) : ItemStack.EMPTY);
			broadcastChanges();
		}
	}

	/** Sonuç alındığında çağrılır: malzemeleri tam olarak bir kez tüketir. */
	private void consumeInputs() {
		if (!recipeMatches()) {
			return;
		}
		inputs.setItem(AXE, ItemStack.EMPTY);
		inputs.removeItem(ROD, 1);
		inputs.removeItem(BLAZE, 1);
		slotsChanged(inputs);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = slots.get(index);
		if (slot == null || !slot.hasItem()) {
			return ItemStack.EMPTY;
		}
		ItemStack stack = slot.getItem();
		ItemStack original = stack.copy();

		if (index == OUT) {
			if (!moveItemStackTo(stack, INV_START, HOTBAR_END, true)) {
				return ItemStack.EMPTY;
			}
		} else if (index < OUT) {
			if (index == SPARE || !moveItemStackTo(stack, INV_START, HOTBAR_END, true)) {
				return ItemStack.EMPTY;
			}
		} else {
			int target = stack.is(ModItems.BATTLE_AXE) ? AXE
					: stack.is(ModItems.KARA_CUBUK) ? ROD
					: stack.is(Items.BLAZE_ROD) ? BLAZE : -1;
			if (target >= 0 && moveItemStackTo(stack, target, target + 1, false)) {
				// taşındı
			} else if (index < INV_END) {
				if (!moveItemStackTo(stack, INV_END, HOTBAR_END, false)) {
					return ItemStack.EMPTY;
				}
			} else if (!moveItemStackTo(stack, INV_START, INV_END, false)) {
				return ItemStack.EMPTY;
			}
		}

		if (stack.isEmpty()) {
			slot.setByPlayer(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}
		if (stack.getCount() == original.getCount()) {
			return ItemStack.EMPTY;
		}
		slot.onTake(player, stack);
		return original;
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		clearContainer(player, inputs); // yuvalardaki eşyalar oyuncuya geri verilir; hiçbir şey kaybolmaz
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(access, player, ModBlocks.KARA_KORUK_ORS);
	}
}
