package com.battleaxe.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Kara Körük'ün Örsü: sağ tıkla açılır, Savaş Baltası'nı Kara Çubuk sapına dönüştürür. */
public class KaraKorukAnvilBlock extends Block {
	public static final EnumProperty<Direction> FACING = BlockStateProperties.HORIZONTAL_FACING;

	private static final VoxelShape BASE = Shapes.or(
			Block.box(1, 0, 1, 15, 3, 15),
			Block.box(3, 3, 3, 13, 5, 13),
			Block.box(5, 5, 5, 11, 10, 11));
	private static final VoxelShape SHAPE_Z = Shapes.or(BASE, Block.box(3, 10, 0, 13, 16, 16));
	private static final VoxelShape SHAPE_X = Shapes.or(BASE, Block.box(0, 10, 3, 16, 16, 13));

	public KaraKorukAnvilBlock(Properties properties) {
		super(properties);
		registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getClockWise());
	}

	@Override
	protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return state.getValue(FACING).getAxis() == Direction.Axis.X ? SHAPE_X : SHAPE_Z;
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
			BlockHitResult hit) {
		if (!level.isClientSide()) {
			player.openMenu(new SimpleMenuProvider(
					(id, inventory, p) -> new KaraKorukAnvilMenu(id, inventory, ContainerLevelAccess.create(level, pos)),
					Component.translatable("container.battleaxe.kara_koruk_ors")));
		}
		return InteractionResult.SUCCESS;
	}
}
