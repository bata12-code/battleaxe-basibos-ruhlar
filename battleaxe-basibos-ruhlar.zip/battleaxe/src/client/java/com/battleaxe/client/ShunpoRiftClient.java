package com.battleaxe.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.shunpo.vfx.RiftConfig;
import com.battleaxe.shunpo.vfx.RiftGeometry;
import com.battleaxe.shunpo.vfx.RiftKind;
import com.battleaxe.shunpo.vfx.RiftLogic;
import com.battleaxe.shunpo.vfx.RiftPalette;
import com.battleaxe.shunpo.vfx.RiftStyle;
import com.battleaxe.shunpo.vfx.ShunpoVfxPayload;
import com.battleaxe.soul.RankStyle;

/**
 * <b>Gerçeklik yarığı</b> görselleri (yalnızca istemci). Sunucu yalnızca doğrulanmış olayı bildirir
 * ({@link ShunpoVfxPayload}); burada bu olaydan sınırlı ömürlü yarıklar ve izler kurulur ve vanilla parçacıklarla çizilir.
 *
 * <p>Oyun durumu bu sınıfta ASLA değişmez: kamera, hareket, hasar, ışınlanma yoktur. Efektler kısa ömürlüdür
 * (en çok ~18 tick), her tick'te sabit bir parçacık bütçesi vardır ({@link RiftConfig#MAX_PARTICLES_PER_TICK}), aktif
 * yarık sayısı sınırlıdır; dünya değişince, bağlantı kesilince ve yerel oyuncu yokken tüm durum silinir.
 *
 * <pre>
 *  SHUNPO:  başlangıç yarığı (açıl-titre-çök) ──iz──► varış yarığı (3 tick sonra), her ikisi hareket doğrultusuna dik
 *  HIT_CRACK: isabet noktasında küçük, kısa ömürlü çatlak
 *  COMBO_*: 1. vuruş ince kesik, 2. vuruş belirgin çatlak + küçük yarık, bitirici dikey kesik + kapanış patlaması
 * </pre>
 */
public final class ShunpoRiftClient {
	private ShunpoRiftClient() {
	}

	private static final class Rift {
		final int actor;
		final double x;
		final double centerY;
		final double z;
		final double axisX;
		final double axisZ;
		final RiftStyle style;
		final int rank;
		final long seed;
		final double[] left;
		final double[] right;
		int age;
		int delay;

		Rift(int actor, Vec3 center, double axisX, double axisZ, RiftStyle style, int rank, long seed, int delay) {
			this.actor = actor;
			this.x = center.x;
			this.centerY = center.y;
			this.z = center.z;
			this.axisX = axisX;
			this.axisZ = axisZ;
			this.style = style;
			this.rank = rank;
			this.seed = seed;
			this.left = RiftGeometry.edgeProfile(seed, style.halfWidth());
			this.right = RiftGeometry.edgeProfile(seed * 31L + 7L, style.halfWidth());
			this.delay = delay;
		}
	}

	private static final class Trail {
		final int actor;
		final Vec3 from;
		final Vec3 to;
		final int rank;
		final int ticks;
		final int points;
		final boolean slash;
		final double perpX;
		final double perpZ;
		int age;

		Trail(int actor, Vec3 from, Vec3 to, int rank, int ticks, int points, boolean slash) {
			this.actor = actor;
			this.from = from;
			this.to = to;
			this.rank = rank;
			this.ticks = Math.max(1, ticks);
			this.points = points;
			this.slash = slash;
			double dx = to.x - from.x;
			double dz = to.z - from.z;
			double len = Math.sqrt(dx * dx + dz * dz);
			this.perpX = len > 1.0E-4 ? -dz / len : 0.0;
			this.perpZ = len > 1.0E-4 ? dx / len : 1.0;
		}
	}

	private static final List<Rift> RIFTS = new ArrayList<>();
	private static final List<Trail> TRAILS = new ArrayList<>();
	private static ClientLevel lastLevel;
	private static long lastSignature;
	private static long lastSignatureTick = Long.MIN_VALUE / 2;
	private static long seedCounter = 1L;
	private static int budget;

	public static void initialize() {
		ClientTickEvents.END_CLIENT_TICK.register(ShunpoRiftClient::tick);
	}

	/** Dünya/bağlantı değişiminde ya da Shunpo kapanınca: tüm geçici görsel durum silinir. */
	public static void reset() {
		RIFTS.clear();
		TRAILS.clear();
		lastLevel = null;
		lastSignatureTick = Long.MIN_VALUE / 2;
	}

	// ------------------------------------------------------------------
	// Olay alımı
	// ------------------------------------------------------------------

	public static void receive(ShunpoVfxPayload p) {
		Minecraft mc = Minecraft.getInstance();
		ClientLevel level = mc.level;
		LocalPlayer me = mc.player;
		if (!RiftConfig.ENABLED || RiftConfig.DENSITY <= 0.0F || level == null || me == null) {
			return;
		}
		if (!RiftLogic.validPayload(p.kind(), p.rank(), p.ax(), p.ay(), p.az(), p.bx(), p.by(), p.bz())) {
			return;
		}
		RiftKind kind = RiftKind.byCode(p.kind());
		Vec3 a = new Vec3(p.ax(), p.ay(), p.az());
		Vec3 b = new Vec3(p.bx(), p.by(), p.bz());
		double radiusSq = RiftConfig.VIEW_RADIUS * RiftConfig.VIEW_RADIUS;
		if (me.distanceToSqr(a) > radiusSq && me.distanceToSqr(b) > radiusSq) {
			return;
		}
		long now = level.getGameTime();
		long signature = RiftLogic.signature(p.kind(), p.actor(), a.x, a.y, a.z, b.x, b.y, b.z);
		if (RiftLogic.isDuplicate(lastSignature, lastSignatureTick, signature, now)) {
			return; // aynı olay kısa sürede iki kez gelirse tek efekt
		}
		lastSignature = signature;
		lastSignatureTick = now;
		int rank = RiftStyle.clampRank(p.rank());

		switch (kind) {
			case SHUNPO -> {
				closeActor(p.actor()); // üst üste kapanış karmaşasını önler
				double dx = b.x - a.x;
				double dz = b.z - a.z;
				double len = Math.sqrt(dx * dx + dz * dz);
				// Yarık düzlemi hareket doğrultusuna DİK: genişlik ekseni = doğrultunun yatay dik vektörü.
				double axisX = len > 0.05 ? -dz / len : 1.0;
				double axisZ = len > 0.05 ? dx / len : 0.0;
				RiftStyle style = RiftStyle.main(rank);
				addRift(new Rift(p.actor(), new Vec3(a.x, a.y + style.height() * 0.5, a.z), axisX, axisZ, style, rank, nextSeed(), 0));
				addRift(new Rift(p.actor(), new Vec3(b.x, b.y + style.height() * 0.5, b.z), axisX, axisZ, style, rank, nextSeed(),
						RiftConfig.ARRIVAL_DELAY_TICKS));
				double distance = a.distanceTo(b);
				if (distance > 0.5) {
					addTrail(new Trail(p.actor(), a.add(0.0, 1.0, 0.0), b.add(0.0, 1.0, 0.0), rank, RiftConfig.TRAIL_TICKS,
							RiftGeometry.trailPoints(distance), false));
				}
			}
			case HIT_CRACK -> {
				double dx = me.getX() - a.x;
				double dz = me.getZ() - a.z;
				double len = Math.sqrt(dx * dx + dz * dz);
				addRift(new Rift(p.actor(), a, len > 0.05 ? -dz / len : 1.0, len > 0.05 ? dx / len : 0.0,
						RiftStyle.small(rank, 0.5, 3), rank, nextSeed(), 0));
			}
			case COMBO_FIRST -> slash(p.actor(), a, b, rank, 35.0, 1.2, 2);
			case COMBO_SECOND -> {
				slash(p.actor(), a, b, rank, -50.0, 1.6, 3);
				addSmallRiftAt(p.actor(), a, b, rank, 0.45, 2);
			}
			case COMBO_FINISH -> {
				slash(p.actor(), a, b, rank, 90.0, 2.0, 3);
				addSmallRiftAt(p.actor(), a, b, rank, 0.8, 2);
			}
			case FAIL -> {
				// Gerçek ışınlanma izlenimi vermeyen birkaç soluk kıvılcım.
				RandomSource random = level.getRandom();
				for (int i = 0; i < RiftLogic.scaled(4); i++) {
					level.addParticle(ParticleTypes.ELECTRIC_SPARK, a.x + (random.nextDouble() - 0.5) * 0.5, a.y + 0.9 + random.nextDouble() * 0.6,
							a.z + (random.nextDouble() - 0.5) * 0.5, 0.0, 0.01, 0.0);
				}
			}
			case CANCEL -> closeActor(p.actor());
		}
	}

	private static void slash(int actor, Vec3 source, Vec3 target, int rank, double angleDeg, double length, int ticks) {
		double dx = target.x - source.x;
		double dz = target.z - source.z;
		double len = Math.sqrt(dx * dx + dz * dz);
		double rx = len > 1.0E-4 ? -dz / len : 1.0;
		double rz = len > 1.0E-4 ? dx / len : 0.0;
		double angle = Math.toRadians(angleDeg);
		double c = Math.cos(angle) * length * 0.5;
		double s = Math.sin(angle) * length * 0.5;
		Vec3 center = target; // hedefin gövde merkezi (sunucu gönderir)
		Vec3 from = new Vec3(center.x - rx * c, center.y - s, center.z - rz * c);
		Vec3 to = new Vec3(center.x + rx * c, center.y + s, center.z + rz * c);
		addTrail(new Trail(actor, from, to, rank, ticks, 9, true));
	}

	private static void addSmallRiftAt(int actor, Vec3 source, Vec3 target, int rank, double heightScale, int hold) {
		double dx = source.x - target.x;
		double dz = source.z - target.z;
		double len = Math.sqrt(dx * dx + dz * dz);
		addRift(new Rift(actor, target, len > 0.05 ? -dz / len : 1.0, len > 0.05 ? dx / len : 0.0,
				RiftStyle.small(rank, heightScale, hold), rank, nextSeed(), 0));
	}

	private static long nextSeed() {
		return seedCounter++ * 0x2545F4914F6CDD1DL;
	}

	private static void addRift(Rift rift) {
		while (RIFTS.size() >= RiftConfig.MAX_ACTIVE_RIFTS) {
			RIFTS.remove(0); // en eski yarık feda edilir (görsel karmaşa/performans sınırı)
		}
		RIFTS.add(rift);
	}

	private static void addTrail(Trail trail) {
		while (TRAILS.size() >= RiftConfig.MAX_ACTIVE_TRAILS) {
			TRAILS.remove(0);
		}
		TRAILS.add(trail);
	}

	/** Bu oyuncunun açık yarıklarını hızla kapanışa zorlar, bekleyenleri ve izleri siler. */
	private static void closeActor(int actor) {
		Iterator<Rift> it = RIFTS.iterator();
		while (it.hasNext()) {
			Rift rift = it.next();
			if (rift.actor != actor) {
				continue;
			}
			if (rift.delay > 0) {
				it.remove();
			} else {
				rift.age = RiftLogic.forcedCloseAge(rift.age, rift.style);
			}
		}
		TRAILS.removeIf(trail -> trail.actor == actor);
	}

	// ------------------------------------------------------------------
	// Tick: çizim
	// ------------------------------------------------------------------

	private static void tick(Minecraft mc) {
		ClientLevel level = mc.level;
		if (level != lastLevel || mc.player == null) {
			RIFTS.clear();
			TRAILS.clear();
			lastLevel = level;
		}
		if (level == null || (RIFTS.isEmpty() && TRAILS.isEmpty())) {
			return;
		}
		budget = RiftLogic.tickBudget();

		Iterator<Rift> riftIt = RIFTS.iterator();
		while (riftIt.hasNext()) {
			Rift rift = riftIt.next();
			if (rift.delay > 0) {
				rift.delay--;
				continue;
			}
			RiftLogic.Phase phase = RiftLogic.phase(rift.age, rift.style);
			if (phase == RiftLogic.Phase.DONE) {
				riftIt.remove();
				continue;
			}
			emitRift(level, rift, phase);
			rift.age++;
		}

		Iterator<Trail> trailIt = TRAILS.iterator();
		while (trailIt.hasNext()) {
			Trail trail = trailIt.next();
			if (trail.age >= trail.ticks) {
				trailIt.remove();
				continue;
			}
			emitTrail(level, trail);
			trail.age++;
		}
	}

	private static void emit(ClientLevel level, ParticleOptions options, double x, double y, double z, double vx, double vy, double vz) {
		if (budget <= 0) {
			return;
		}
		budget--;
		level.addParticle(options, x, y, z, vx, vy, vz);
	}

	private static void emitRift(ClientLevel level, Rift rift, RiftLogic.Phase phase) {
		RiftStyle style = rift.style;
		RandomSource random = level.getRandom();
		double open = RiftLogic.openProgress(rift.age, style);
		double close = RiftLogic.closeProgress(rift.age, style);

		double grow = phase == RiftLogic.Phase.OPENING ? 1.0 - Math.pow(1.0 - open, 2.0) : 1.0;
		double shrink = phase == RiftLogic.Phase.CLOSING ? Math.pow(1.0 - close, 1.4) : 1.0; // kenarlar merkeze çekilir
		double flicker = phase == RiftLogic.Phase.HOLD ? 1.0 + 0.14 * Math.sin(rift.age * 1.9 + (rift.seed & 7L)) : 1.0;
		double widthScale = grow * shrink * flicker;
		// Görünen dikey aralık: açılışta ortadan büyür, kapanışta ortaya doğru daralır.
		double visible = 0.5 * (phase == RiftLogic.Phase.OPENING ? open : 1.0) * (phase == RiftLogic.Phase.CLOSING ? 1.0 - 0.45 * close : 1.0);
		double bottom = rift.centerY - style.height() * 0.5;

		int perEdge = RiftLogic.scaled(style.edgeParticles());
		for (int side = 0; side < 2; side++) {
			double sign = side == 0 ? -1.0 : 1.0;
			double[] profile = side == 0 ? rift.left : rift.right;
			for (int k = 0; k < perEdge; k++) {
				double t = 0.5 + (random.nextDouble() * 2.0 - 1.0) * visible;
				double w = RiftGeometry.sample(profile, t) * widthScale;
				double x = rift.x + rift.axisX * w * sign;
				double z = rift.z + rift.axisZ * w * sign;
				double y = bottom + t * style.height();
				// Her üçüncü kenar parçacığı rütbenin vurgu rengini taşır (yarık rütbeyle "evrilir").
				ParticleOptions options = (k % 3 == 2) ? RankStyle.dust(rift.rank) : (side == 0 ? RiftPalette.PURPLE : RiftPalette.CRIMSON);
				emit(level, options, x, y, z, rift.axisX * sign * 0.004, 0.0, rift.axisZ * sign * 0.004);
			}
			// İkinci ince enerji çizgisi (orta rütbe ve üstü): kenarın biraz dışında, seyrek.
			if (style.secondLine() && phase != RiftLogic.Phase.OPENING && random.nextInt(2) == 0) {
				double t = 0.5 + (random.nextDouble() * 2.0 - 1.0) * visible;
				double w = RiftGeometry.sample(profile, t) * widthScale + 0.12;
				emit(level, RiftPalette.TRAIL, rift.x + rift.axisX * w * sign, bottom + t * style.height(), rift.z + rift.axisZ * w * sign, 0.0, 0.0, 0.0);
			}
		}

		// İç boşluk: koyu, neredeyse siyah.
		int inner = RiftLogic.scaled(1 + style.edgeParticles() / 2);
		for (int k = 0; k < inner; k++) {
			double t = 0.5 + (random.nextDouble() * 2.0 - 1.0) * visible;
			double w = RiftGeometry.sample(rift.left, t) * widthScale * (random.nextDouble() * 2.0 - 1.0);
			emit(level, RiftPalette.VOID, rift.x + rift.axisX * w, bottom + t * style.height(), rift.z + rift.axisZ * w, 0.0, 0.0, 0.0);
		}

		// Enerji damarı: kenardan içeri kısa bir çizgi (açılış ve titreme sırasında).
		if (phase != RiftLogic.Phase.CLOSING && random.nextInt(2) == 0) {
			double t = 0.5 + (random.nextDouble() * 2.0 - 1.0) * visible;
			double w = RiftGeometry.sample(rift.left, t) * widthScale;
			double y = bottom + t * style.height();
			emit(level, ParticleTypes.ELECTRIC_SPARK, rift.x - rift.axisX * w, y, rift.z - rift.axisZ * w, rift.axisX * 0.03, 0.0, rift.axisZ * 0.03);
			for (int i = 1; i <= 3; i++) {
				double f = (i / 3.0) * 2.0 - 1.0;
				emit(level, RiftPalette.VEIN, rift.x + rift.axisX * w * f, y, rift.z + rift.axisZ * w * f, 0.0, 0.0, 0.0);
			}
		}

		// Rün benzeri çatlaklar (yüksek rütbe): kenardan dışarı kısa, kırık dallar.
		if (style.runes() && phase == RiftLogic.Phase.HOLD && rift.age % 2 == 0) {
			double t = 0.5 + (random.nextDouble() * 2.0 - 1.0) * visible;
			double sign = random.nextBoolean() ? 1.0 : -1.0;
			double w = RiftGeometry.sample(sign < 0 ? rift.left : rift.right, t) * widthScale;
			double slope = (random.nextDouble() - 0.5) * 1.2;
			for (int i = 1; i <= 3; i++) {
				double ext = w + i * 0.14;
				emit(level, RiftPalette.VEIN, rift.x + rift.axisX * ext * sign, bottom + t * style.height() + slope * i * 0.12,
						rift.z + rift.axisZ * ext * sign, 0.0, 0.0, 0.0);
			}
		}

		// En yüksek rütbe: kapanış başlarken kısa, ayırt edilebilir enerji halkası (görüşü kapatmaz: 8 kıvılcım).
		if (style.signature() && rift.age == style.openTicks() + style.holdTicks()) {
			for (int i = 0; i < 8; i++) {
				double ang = i * (Math.PI * 2.0 / 8.0);
				emit(level, ParticleTypes.ELECTRIC_SPARK, rift.x, bottom + 0.15, rift.z, Math.cos(ang) * 0.12, 0.01, Math.sin(ang) * 0.12);
				emit(level, RankStyle.dust(rift.rank), rift.x, bottom + 0.2, rift.z, 0.0, 0.0, 0.0);
			}
		}

		// Son kare: ince bir ışık çizgisi ve kısa parlama, sonra yarık yok olur.
		if (rift.age == style.totalTicks() - 1) {
			for (int i = 0; i <= 6; i++) {
				emit(level, RiftPalette.VEIN, rift.x, bottom + style.height() * (0.05 + 0.9 * i / 6.0), rift.z, 0.0, 0.0, 0.0);
			}
			emit(level, ParticleTypes.END_ROD, rift.x, rift.centerY, rift.z, 0.0, 0.0, 0.0);
			emit(level, ParticleTypes.ELECTRIC_SPARK, rift.x, rift.centerY, rift.z, 0.0, 0.0, 0.0);
		}
	}

	private static void emitTrail(ClientLevel level, Trail trail) {
		RandomSource random = level.getRandom();
		int perTick = (int) Math.ceil(trail.points / (double) trail.ticks);
		int start = trail.age * perTick;
		int end = Math.min(trail.points, start + perTick);
		for (int i = start; i < end; i++) {
			double t = (i + random.nextDouble()) / trail.points;
			double x = trail.from.x + (trail.to.x - trail.from.x) * t;
			double y = trail.from.y + (trail.to.y - trail.from.y) * t;
			double z = trail.from.z + (trail.to.z - trail.from.z) * t;
			// Yarılmış mekân hissi: çizgi yer yer hafifçe kayar.
			double jitter = (random.nextDouble() - 0.5) * 0.08;
			x += trail.perpX * jitter;
			z += trail.perpZ * jitter;
			y += (random.nextDouble() - 0.5) * 0.05;
			ParticleOptions main = trail.slash ? (i % 2 == 0 ? RiftPalette.CRIMSON : RiftPalette.VEIN) : RiftPalette.TRAIL;
			emit(level, main, x, y, z, 0.0, 0.0, 0.0);
			if (i % 4 == 0) {
				emit(level, ParticleTypes.ELECTRIC_SPARK, x, y, z, 0.0, 0.0, 0.0);
			}
			if (!trail.slash && trail.rank >= RiftConfig.SECOND_LINE_RANK && i % 2 == 0) {
				emit(level, RiftPalette.PURPLE, x, y + 0.14, z, 0.0, 0.0, 0.0); // ikinci, paralel ince çizgi
			}
		}
	}
}
