package com.battleaxe.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import net.minecraft.client.Camera;

import com.battleaxe.client.ClientCameraShake;

/**
 * Kameranın bakış açısını belirleyen Camera#setRotation(yaw, pitch) çağrısına, titreme sırasında
 * küçük bir sapma ekler. Titreme yokken sapma 0'dır; yani hiçbir şey değişmez.
 *
 * <p>require = 0: hedef metot bir güncellemede değişirse oyun çökmez, titreme devre dışı kalır.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
	@ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
	private float battleaxe$shakeYaw(float yRot) {
		return yRot + ClientCameraShake.yawOffset();
	}

	@ModifyVariable(method = "setRotation(FF)V", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
	private float battleaxe$shakePitch(float xRot) {
		return xRot + ClientCameraShake.pitchOffset();
	}
}
