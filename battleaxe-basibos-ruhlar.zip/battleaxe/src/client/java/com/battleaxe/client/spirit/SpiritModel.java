package com.battleaxe.client.spirit;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Başıboş Ruh modellerinin ortak tabanı. Model örneği bütün aynı türden varlıklar arasında PAYLAŞILIR; bu yüzden her karede
 * önce bütün kayıtlı parçalar başlangıç duruşuna döndürülür, sonra tür animasyonu ve (ölümde) dağılma uygulanır.
 *
 * <p>Dağılma: ruhsal beden yere düşmez; parçalar dışa savrulup dönerek tek tek küçülüp kaybolur (renderer vanilla düşme dönüşünü kapatır).
 */
public abstract class SpiritModel extends EntityModel<SpiritRenderState> {
	/** Her şeyin altındaki ana parça: süzülme ve ölçü burada. */
	protected final ModelPart rig;
	private final List<ModelPart> parts = new ArrayList<>();
	private final List<float[]> base = new ArrayList<>();
	protected final float rigBaseY;

	protected SpiritModel(ModelPart root) {
		super(root);
		this.rig = root.getChild("rig");
		this.rigBaseY = this.rig.y;
	}

	/** Parçayı kaydeder (başlangıç duruşu hatırlanır; her karede sıfırlanır, dağılmaya katılır). */
	protected ModelPart part(ModelPart part) {
		parts.add(part);
		base.add(new float[] {part.x, part.y, part.z});
		return part;
	}

	/** Kayıtlı bütün parçaları başlangıç duruşuna döndürür. Alt sınıf setupAnim başında çağırmalıdır. */
	protected void resetParts() {
		for (int i = 0; i < parts.size(); i++) {
			ModelPart p = parts.get(i);
			float[] b = base.get(i);
			p.x = b[0];
			p.y = b[1];
			p.z = b[2];
			p.xRot = 0.0F;
			p.yRot = 0.0F;
			p.zRot = 0.0F;
			p.xScale = 1.0F;
			p.yScale = 1.0F;
			p.zScale = 1.0F;
		}
		this.rig.y = this.rigBaseY;
	}

	/** Ölümde parçaları dışa savurur, döndürür ve sırayla gizler (s: 0-1). */
	protected void applyShatter(float s) {
		if (s <= 0.0F) {
			return;
		}
		float spread = s * s * 14.0F;
		for (int i = 0; i < parts.size(); i++) {
			ModelPart p = parts.get(i);
			float[] b = base.get(i);
			float seed = i * 2.399F;
			p.x = b[0] + Mth.sin(seed) * spread;
			p.y = b[1] + (Mth.cos(seed * 1.3F) * 0.7F - 0.35F) * spread * 0.8F - s * 4.0F;
			p.z = b[2] + Mth.cos(seed) * spread;
			p.xRot = Mth.sin(seed * 0.7F) * s * 2.6F;
			p.yRot = Mth.cos(seed * 0.9F) * s * 2.6F;
			p.zRot = Mth.sin(seed * 1.1F) * s * 2.6F;
			// Her parça kendi anında küçülüp kaybolur (sıfır ölçek tekilliğe yol açmasın diye çok küçük bir değer).
			float start = 0.25F + 0.45F * ((i * 0.618F) % 1.0F);
			float shrink = Mth.clamp((s - start) / 0.35F, 0.0F, 1.0F);
			float scale = Math.max(0.001F, 1.0F - shrink);
			p.xScale = scale;
			p.yScale = scale;
			p.zScale = scale;
		}
	}

	protected static float ease(float t) {
		float c = Mth.clamp(t, 0.0F, 1.0F);
		return c * c * (3.0F - 2.0F * c);
	}

	/** Hızlı başlayıp yavaşlayan (vuruş) eğri. */
	protected static float snap(float t) {
		float c = Mth.clamp(t, 0.0F, 1.0F);
		return 1.0F - (1.0F - c) * (1.0F - c);
	}
}
