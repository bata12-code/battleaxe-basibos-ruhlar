package com.battleaxe.client.spirit;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

import com.battleaxe.spirit.SavrulmusRuhEntity;

/** Savrulmuş Ruh çizicisi. */
public class SavrulmusRenderer extends SpiritRenderer<SavrulmusRuhEntity, SavrulmusModel> {
	public SavrulmusRenderer(EntityRendererProvider.Context context) {
		super(context, new SavrulmusModel(context.bakeLayer(SavrulmusModel.LAYER)), 0.45F, "savrulmus_ruh");
	}
}
