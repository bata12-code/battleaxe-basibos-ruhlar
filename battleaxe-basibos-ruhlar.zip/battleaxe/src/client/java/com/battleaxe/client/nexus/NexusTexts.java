package com.battleaxe.client.nexus;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.network.chat.Component;

import com.battleaxe.nexus.Effect;
import com.battleaxe.nexus.NexusEvent;
import com.battleaxe.nexus.NodeDef;
import com.battleaxe.nexus.Stat;

/** Düğüm açıklamaları: etkilerden otomatik kurulur, böylece metin ile gerçek etki asla ayrışmaz. */
final class NexusTexts {
	private NexusTexts() {
	}

	static List<Component> effectLines(NodeDef node) {
		List<Component> lines = new ArrayList<>();
		for (Effect effect : node.effects()) {
			Object param = paramArg(effect);
			lines.add(Component.translatable(effect.stat().langKey(), signed(effect.value()), param, unsigned(effect.value())));
		}
		return lines;
	}

	private static Object paramArg(Effect effect) {
		if (effect.stat() == Stat.WHISPER_UNLOCK) {
			NexusEvent event = NexusEvent.byId(effect.param());
			return event == null ? "?" : Component.translatable("nexus.event." + event.id);
		}
		return Integer.toString(effect.param());
	}

	/** İşaretsiz sayı: 3, 0.3 */
	static String unsigned(double value) {
		return signed(Math.abs(value)).substring(1);
	}

	/** +3, -20, +0.3 gibi işaretli sayı. */
	static String signed(double value) {
		if (Math.abs(value - Math.rint(value)) < 1.0E-6) {
			return String.format(Locale.ROOT, "%+d", (long) Math.rint(value));
		}
		String text = String.format(Locale.ROOT, "%+.2f", value);
		while (text.endsWith("0")) {
			text = text.substring(0, text.length() - 1);
		}
		return text;
	}
}
