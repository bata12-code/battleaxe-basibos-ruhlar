package com.battleaxe.client.spirit;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.spirit.SpiritConfig;
import com.battleaxe.spirit.SpiritEntity;

/** Başıboş Ruh çizicilerinin ortak tabanı: sunucu durumunu okur, vanilla ölüm düşmesini kapatır. */
public abstract class SpiritRenderer<E extends SpiritEntity, M extends SpiritModel> extends MobRenderer<E, SpiritRenderState, M> {
	private final Identifier texture;

	protected SpiritRenderer(EntityRendererProvider.Context context, M model, float shadow, String textureName) {
		super(context, model, shadow);
		this.texture = BattleAxeMod.id("textures/entity/" + textureName + ".png");
	}

	@Override
	public SpiritRenderState createRenderState() {
		return new SpiritRenderState();
	}

	@Override
	public void extractRenderState(E entity, SpiritRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.attack = entity.getSpiritState();
		state.progress = entity.getSpiritProgress();
		state.exposed = entity.isSpiritExposed();
		state.shatter = entity.deathTime > 0
				? Math.min(1.0F, (entity.deathTime + partialTick) / SpiritConfig.DEATH_TICKS)
				: 0.0F;
		// Ruhsal beden ölünce yere devrilmez; model parçalanarak dağılır (bkz. SpiritModel#applyShatter).
		state.deathTime = 0.0F;
	}

	@Override
	public Identifier getTextureLocation(SpiritRenderState state) {
		return texture;
	}
}
