package com.battleaxe.client.evolution;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

import com.battleaxe.evolution.EvolutionConfig;
import com.battleaxe.evolution.EvolutionPath;
import com.battleaxe.evolution.EvolutionStage;
import com.battleaxe.evolution.Recovery;

/**
 * Savaş Özü göstergesi: ekranın sol kenarına yakın, dar ve DİKEY bir çubuk. Özün dolulukla (aşağıdan yukarıya)
 * temsil edildiği, başlıksız ve çerçevesiz sade bir görünüm. Balta elde değilken (ya da gösterecek bir şey
 * yokken) hiçbir şey çizmez; görünürlük koşulları eski panelle birebir aynıdır.
 *
 * <p>Durum üretmez: yalnızca {@link ClientEvolutionState}'i (sunucunun özetini) okuyup çizer. Her kare yalnızca
 * birkaç dikdörtgen çizer; nesne üretmez (sayı metni yalnızca değer değişince yeniden oluşturulur).
 *
 * <p>Neyi nasıl gösterir:
 * <ul>
 *   <li><b>Dolgu</b>: Savaş Özü / 100, aşağıdan yukarıya. Rengi seçili dalın rengidir; aşama ve öz arttıkça
 *       parlaklığı ve çevresindeki hale artar. Eski Berserker aktifken hafif ek vurgu ve nabız vardır.</li>
 *   <li><b>Çentikler</b>: Kıvılcım / Uyanış / Taşkınlık eşikleri çubuğun içinde ince çizgilerdir.</li>
 *   <li><b>İnce yan sütun</b>: Aşırı yüklenme (yalnızca doluyorken ya da toparlanma sürerken görünür).</li>
 *   <li><b>Alttaki sayı</b>: öz değeri; toparlanma ya da Son Eşik sürerken kalan saniye (renkli).</li>
 *   <li><b>Çerçeve</b>: normalde sönük siyah; Son Eşik'e hazırken altın nabız, toparlanırken sıcak uyarı rengi.</li>
 * </ul>
 */
public final class EvolutionHud {
	private EvolutionHud() {
	}

	// ------------------------------------------------------------------
	// Yerleşim ve görünüm ayarları (GUI birimi; GUI ölçeğiyle birlikte ölçeklenir)
	// ------------------------------------------------------------------

	/** Ekranın sol kenarından uzaklık. */
	private static final int MARGIN_LEFT = 3;
	/** Çubuğun dış genişliği (1 piksellik çerçeve dahil). */
	private static final int BAR_WIDTH = 5;
	/** Aşırı yüklenme sütununun genişliği ve çubukla arasındaki boşluk. */
	private static final int OVERLOAD_WIDTH = 2;
	private static final int OVERLOAD_GAP = 1;
	/** Çubuk yüksekliği ekran yüksekliğinin dörtte biri; bu sınırlar içinde kalır (küçük/büyük GUI ölçeklerinde). */
	private static final int MIN_BAR_HEIGHT = 40;
	private static final int MAX_BAR_HEIGHT = 64;
	/** Çubuğun üstündeki küçük balta rünü ve alttaki sayı. */
	private static final int GLYPH_SIZE = 5;
	private static final int GLYPH_GAP = 2;
	private static final int VALUE_GAP = 2;
	private static final int VALUE_HEIGHT = 8;
	/** false yaparsan alttaki sayı hiç çizilmez (yalnızca çubuk kalır). */
	private static final boolean SHOW_VALUE = true;

	private static final int GOLD = 0xFFE08A;
	private static final int WARN = 0xFF8A6B;
	private static final int NEUTRAL = 0x9A8FB5;

	/** Balta rünü: 5x5, '#' dolu. */
	private static final String[] GLYPH = {
			".###.",
			"####.",
			"####.",
			".#...",
			".#..."
	};

	/** Alt sayının önbelleği: her karede String üretmemek için. */
	private static int cachedNumber = Integer.MIN_VALUE;
	private static String cachedText = "";

	public static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.player == null || !ClientEvolutionState.hasData() || !ClientEvolutionState.armed()) {
			return;
		}
		EvolutionPath path = ClientEvolutionState.path();
		int essence = ClientEvolutionState.essence();
		EvolutionStage stage = ClientEvolutionState.stage();
		if (path == null && essence < 1 && stage == EvolutionStage.NONE) {
			return;
		}

		Recovery recovery = ClientEvolutionState.recovery();
		boolean recovering = recovery != Recovery.NONE;
		boolean finalActive = ClientEvolutionState.finalActiveLeft() > 0;
		boolean legacy = ClientEvolutionState.legacyBerserker();
		boolean finalReady = !recovering && !finalActive && path != null
				&& ClientEvolutionState.finalCooldownLeft() <= 0
				&& stage.level >= EvolutionStage.SURGE.level
				&& essence >= EvolutionConfig.FINAL_COST;
		int overload = ClientEvolutionState.overload();
		boolean showOverload = overload > 3 || recovering;

		// ---- Yerleşim ----
		int guiHeight = graphics.guiHeight();
		int barHeight = Mth.clamp(guiHeight / 4, MIN_BAR_HEIGHT, MAX_BAR_HEIGHT);
		int totalHeight = GLYPH_SIZE + GLYPH_GAP + barHeight + (SHOW_VALUE ? VALUE_GAP + VALUE_HEIGHT : 0);
		int x = MARGIN_LEFT;
		int top = guiHeight / 2 - totalHeight / 2;
		int barY = top + GLYPH_SIZE + GLYPH_GAP;

		// ---- Renkler ----
		int accent = path == null ? NEUTRAL : path.rgb;
		float stageHeat = stage == EvolutionStage.FINAL_THRESHOLD ? 1.0F : stage.level / 3.0F;
		float essenceHeat = Mth.clamp(essence / (float) EvolutionConfig.MAX_ESSENCE, 0.0F, 1.0F);
		float heat = Mth.clamp(0.25F + 0.45F * stageHeat + 0.30F * essenceHeat, 0.0F, 1.0F);
		float pulse = 0.5F + 0.5F * Mth.sin((Util.getMillis() % 100_000L) * (stage.level >= 3 || legacy ? 0.012F : 0.005F));

		int baseColor = shade(accent, 0.45F + 0.55F * heat);
		int tipColor = blend(baseColor, 0xFFFFFF, 0.22F * heat + (legacy ? 0.14F * pulse : 0.0F));
		if (recovering) {
			baseColor = blend(shade(WARN, 0.55F), 0x1A1018, 0.35F);
			tipColor = shade(WARN, 0.85F);
		}

		// ---- Hale: aşama yükseldikçe ve Berserker aktifken çubuğun etrafı hafifçe parlar ----
		int glow = stage.level * 16 + (legacy ? 18 : 0) + (finalReady ? 14 : 0);
		if (glow > 0 && !recovering) {
			int alpha = (int) (Math.min(90, glow) * (0.65F + 0.35F * pulse));
			graphics.fill(x - 2, barY - 2, x + BAR_WIDTH + 2, barY + barHeight + 2, argb(alpha / 2, accent));
			graphics.fill(x - 1, barY - 1, x + BAR_WIDTH + 1, barY + barHeight + 1, argb(alpha, accent));
		}

		// ---- Çubuk: zemin, dolgu, çentikler, çerçeve ----
		int innerX = x + 1;
		int innerY = barY + 1;
		int innerW = BAR_WIDTH - 2;
		int innerH = barHeight - 2;
		graphics.fill(x, barY, x + BAR_WIDTH, barY + barHeight, 0xC8050308);

		int filled = Math.round(innerH * essenceHeat);
		int fillTop = innerY + innerH - filled;
		if (filled > 0) {
			graphics.fillGradient(innerX, fillTop, innerX + innerW, innerY + innerH, argb(255, tipColor), argb(255, baseColor));
			if (filled > 1) {
				// Dolgunun üst kenarında ince parlak çizgi: "su seviyesi".
				graphics.fill(innerX, fillTop, innerX + innerW, fillTop + 1, argb(255, blend(tipColor, 0xFFFFFF, 0.45F)));
			}
		}

		int[] marks = {(int) EvolutionConfig.SPARK_ENTER, (int) EvolutionConfig.AWAKENING_ENTER, (int) EvolutionConfig.SURGE_ENTER};
		for (int mark : marks) {
			int markY = innerY + innerH - Math.round(innerH * (mark / (float) EvolutionConfig.MAX_ESSENCE));
			if (markY < innerY || markY >= innerY + innerH) {
				continue;
			}
			graphics.fill(innerX, markY, innerX + innerW, markY + 1, markY >= fillTop ? 0x99000000 : 0x55FFFFFF);
		}

		int outline = finalReady ? argb((int) (150 + 105 * pulse), GOLD)
				: recovering ? argb((int) (140 + 90 * pulse), WARN)
				: 0xD0000000;
		graphics.outline(x, barY, BAR_WIDTH, barHeight, outline);

		// ---- Aşırı yüklenme: ince yan sütun (yalnızca gerektiğinde) ----
		if (showOverload) {
			int ox = x + BAR_WIDTH + OVERLOAD_GAP;
			float ratio = Mth.clamp(overload / (float) EvolutionConfig.MAX_OVERLOAD, 0.0F, 1.0F);
			int oh = Math.round(innerH * ratio);
			graphics.fill(ox, innerY, ox + OVERLOAD_WIDTH, innerY + innerH, 0x90050308);
			if (oh > 0) {
				int color = ratio > 0.8F ? 0xFF3A2A : 0xFFB347;
				graphics.fill(ox, innerY + innerH - oh, ox + OVERLOAD_WIDTH, innerY + innerH, argb(255, color));
			}
		}

		// ---- Üstte küçük balta rünü ----
		int glyphColor = recovering ? shade(WARN, 0.8F) : finalReady ? GOLD : blend(baseColor, tipColor, 0.5F + 0.5F * pulse * (stage.level > 0 ? 1.0F : 0.0F));
		drawGlyph(graphics, x, top, argb(230, glyphColor));

		// ---- Alttaki sayı: öz ya da (toparlanma / Son Eşik sürerken) kalan saniye ----
		if (SHOW_VALUE) {
			int number;
			int color;
			if (recovering) {
				number = seconds(ClientEvolutionState.recoveryLeft());
				color = 0xFF000000 | WARN;
			} else if (finalActive) {
				number = seconds(ClientEvolutionState.finalActiveLeft());
				color = 0xFF000000 | GOLD;
			} else {
				number = essence;
				color = finalReady ? 0xFF000000 | GOLD : 0xC8C9C2D8;
			}
			Font font = minecraft.font;
			graphics.text(font, numberText(number), x, barY + barHeight + VALUE_GAP, color, true);
		}
	}

	private static void drawGlyph(GuiGraphicsExtractor graphics, int x, int y, int color) {
		for (int row = 0; row < GLYPH.length; row++) {
			String line = GLYPH[row];
			for (int col = 0; col < line.length(); col++) {
				if (line.charAt(col) == '#') {
					graphics.fill(x + col, y + row, x + col + 1, y + row + 1, color);
				}
			}
		}
	}

	private static String numberText(int value) {
		if (value != cachedNumber) {
			cachedNumber = value;
			cachedText = Integer.toString(value);
		}
		return cachedText;
	}

	private static int seconds(int ticks) {
		return (ticks + 19) / 20;
	}

	/** RGB'yi parlaklık çarpanıyla koyulaştırır/açar (0-1 koyulaştırır). */
	private static int shade(int rgb, float factor) {
		int r = Mth.clamp((int) (((rgb >> 16) & 0xFF) * factor), 0, 255);
		int g = Mth.clamp((int) (((rgb >> 8) & 0xFF) * factor), 0, 255);
		int b = Mth.clamp((int) ((rgb & 0xFF) * factor), 0, 255);
		return (r << 16) | (g << 8) | b;
	}

	private static int blend(int from, int to, float t) {
		float f = Mth.clamp(t, 0.0F, 1.0F);
		int r = (int) Mth.lerp(f, (from >> 16) & 0xFF, (to >> 16) & 0xFF);
		int g = (int) Mth.lerp(f, (from >> 8) & 0xFF, (to >> 8) & 0xFF);
		int b = (int) Mth.lerp(f, from & 0xFF, to & 0xFF);
		return (r << 16) | (g << 8) | b;
	}

	private static int argb(int alpha, int rgb) {
		return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0xFFFFFF);
	}
}
