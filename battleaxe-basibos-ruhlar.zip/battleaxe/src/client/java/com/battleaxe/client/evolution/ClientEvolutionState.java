package com.battleaxe.client.evolution;

import net.minecraft.util.Util;

import com.battleaxe.evolution.EvolutionPath;
import com.battleaxe.evolution.EvolutionStage;
import com.battleaxe.evolution.EvolutionSyncPayload;
import com.battleaxe.evolution.Recovery;

/**
 * İstemcinin Berserker Evrimi görünümü. Yalnızca sunucunun özetinin kopyasıdır (HUD ve ekran için);
 * hiçbir karar buna dayanmaz. Süreler paket alındığı andan itibaren yerel olarak geri sayılır.
 */
public final class ClientEvolutionState {
	private ClientEvolutionState() {
	}

	private static EvolutionSyncPayload payload;
	private static long receivedMillis;

	public static void apply(EvolutionSyncPayload value) {
		payload = value;
		receivedMillis = Util.getMillis();
	}

	public static void reset() {
		payload = null;
	}

	public static boolean hasData() {
		return payload != null;
	}

	public static EvolutionPath path() {
		return payload == null ? null : EvolutionPath.byIndex(payload.core().path());
	}

	public static EvolutionStage stage() {
		return payload == null ? EvolutionStage.NONE : EvolutionStage.byLevel(payload.core().stage());
	}

	public static int essence() {
		return payload == null ? 0 : payload.core().essence();
	}

	public static int overload() {
		return payload == null ? 0 : payload.core().overload();
	}

	public static int momentum() {
		return payload == null ? 0 : payload.core().momentum();
	}

	public static Recovery recovery() {
		return payload == null ? Recovery.NONE : Recovery.byOrdinal(payload.core().recovery());
	}

	public static boolean armed() {
		return payload != null && payload.armed();
	}

	public static boolean legacyBerserker() {
		return payload != null && payload.legacy();
	}

	public static int masteryPoints(EvolutionPath path) {
		return payload == null || path == null ? 0 : payload.mastery().of(path);
	}

	/** Son Eşik'in kalan aktif süresi (tick). */
	public static int finalActiveLeft() {
		return payload == null ? 0 : left(payload.timers().finalActiveLeft());
	}

	public static int finalCooldownLeft() {
		return payload == null ? 0 : left(payload.timers().finalCooldownLeft());
	}

	public static int pathCooldownLeft() {
		return payload == null ? 0 : left(payload.timers().pathCooldownLeft());
	}

	public static int recoveryLeft() {
		return payload == null ? 0 : left(payload.timers().recoveryLeft());
	}

	private static int left(int ticksAtReceive) {
		if (ticksAtReceive <= 0) {
			return 0;
		}
		long elapsedTicks = (Util.getMillis() - receivedMillis) / 50L;
		return (int) Math.max(0L, ticksAtReceive - elapsedTicks);
	}
}
