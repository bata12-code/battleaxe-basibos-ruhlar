package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

/**
 * ÜRETİLDİ: tools/gen_spirit_assets.py. Elle düzenleme; model parçaları ve doku düzeni o araçta tek kaynaktır.
 * Tüm parçalar "rig" altındadır (süzülme/dağılma animasyonu tek noktadan sürülür). Doku 64x64.
 */
final class RuhYiyenParts {
	private RuhYiyenParts() {
	}

	static final int TEX_W = 64;
	static final int TEX_H = 64;

	static LayerDefinition create() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_rig = root.addOrReplaceChild("rig", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_torso = p_rig.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-3F, -16F, -2F, 6F, 16F, 4F), PartPose.offset(0F, 9F, 0F));
		PartDefinition p_core = p_torso.addOrReplaceChild("core", CubeListBuilder.create().texOffs(42, 20).addBox(-2F, -12F, -2.6F, 4F, 5F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_rib_0 = p_torso.addOrReplaceChild("rib_0", CubeListBuilder.create().texOffs(14, 29).addBox(-3.5F, -6F, -2.4F, 7F, 1F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_rib_1 = p_torso.addOrReplaceChild("rib_1", CubeListBuilder.create().texOffs(14, 29).addBox(-3.5F, -4F, -2.4F, 7F, 1F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_rib_2 = p_torso.addOrReplaceChild("rib_2", CubeListBuilder.create().texOffs(14, 29).addBox(-3.5F, -2F, -2.4F, 7F, 1F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(38, 0).addBox(-2.5F, -7F, -2.5F, 5F, 7F, 5F), PartPose.offset(0F, -16F, 0F));
		PartDefinition p_hood = p_head.addOrReplaceChild("hood", CubeListBuilder.create().texOffs(0, 20).addBox(-3F, -8F, -3F, 6F, 3F, 6F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_hood_point = p_hood.addOrReplaceChild("hood_point", CubeListBuilder.create().texOffs(0, 29).addBox(-1F, -4F, 0F, 2F, 4F, 2F), PartPose.offset(0F, -8F, 1F));
		PartDefinition p_arm_r = p_torso.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(20, 0).addBox(-1F, 0F, -1F, 2F, 18F, 2F), PartPose.offset(-4F, -14F, 0F));
		PartDefinition p_finger_r_0 = p_arm_r.addOrReplaceChild("finger_r_0", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, -1F));
		PartDefinition p_finger_r_1 = p_arm_r.addOrReplaceChild("finger_r_1", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, 0F));
		PartDefinition p_finger_r_2 = p_arm_r.addOrReplaceChild("finger_r_2", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, 1F));
		PartDefinition p_arm_l = p_torso.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(20, 0).addBox(-1F, 0F, -1F, 2F, 18F, 2F), PartPose.offset(4F, -14F, 0F));
		PartDefinition p_finger_l_0 = p_arm_l.addOrReplaceChild("finger_l_0", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, -1F));
		PartDefinition p_finger_l_1 = p_arm_l.addOrReplaceChild("finger_l_1", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, 0F));
		PartDefinition p_finger_l_2 = p_arm_l.addOrReplaceChild("finger_l_2", CubeListBuilder.create().texOffs(38, 20).addBox(-0.5F, 0F, -0.5F, 1F, 6F, 1F), PartPose.offset(0F, 18F, 1F));
		PartDefinition p_rag_r = p_torso.addOrReplaceChild("rag_r", CubeListBuilder.create().texOffs(28, 0).addBox(-1F, 0F, -2F, 1F, 10F, 4F), PartPose.offset(-3F, -14F, 0F));
		PartDefinition p_rag_l = p_torso.addOrReplaceChild("rag_l", CubeListBuilder.create().texOffs(28, 0).addBox(0F, 0F, -2F, 1F, 10F, 4F), PartPose.offset(3F, -14F, 0F));
		PartDefinition p_tail_a = p_rig.addOrReplaceChild("tail_a", CubeListBuilder.create().texOffs(24, 20).addBox(-2F, 0F, -1.5F, 4F, 5F, 3F), PartPose.offset(0F, 9F, 0F));
		PartDefinition p_tail_b = p_tail_a.addOrReplaceChild("tail_b", CubeListBuilder.create().texOffs(52, 20).addBox(-1.5F, 0F, -1F, 3F, 4F, 2F), PartPose.offset(0F, 5F, 0F));
		PartDefinition p_tail_c = p_tail_b.addOrReplaceChild("tail_c", CubeListBuilder.create().texOffs(8, 29).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 4F, 0F));
		return LayerDefinition.create(mesh, TEX_W, TEX_H);
	}
}
