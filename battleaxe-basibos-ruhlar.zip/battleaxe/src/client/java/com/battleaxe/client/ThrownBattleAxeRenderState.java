package com.battleaxe.client;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;

/** Fırlatılmış balta çizimi için gereken veriler. */
public class ThrownBattleAxeRenderState extends EntityRenderState {
	/** Baltanın eşya modeli: rütbe görünümü, Berserker hâli vb. eşyanın kendi bileşenlerinden gelir. */
	public final ItemStackRenderState item = new ItemStackRenderState();

	public boolean stuck;
	public boolean returning;
	public float yaw;
	public int variant;
}
