package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

/**
 * ÜRETİLDİ: tools/gen_spirit_assets.py. Elle düzenleme; model parçaları ve doku düzeni o araçta tek kaynaktır.
 * Tüm parçalar "rig" altındadır (süzülme/dağılma animasyonu tek noktadan sürülür). Doku 64x64.
 */
final class SavrulmusParts {
	private SavrulmusParts() {
	}

	static final int TEX_W = 64;
	static final int TEX_H = 64;

	static LayerDefinition create() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_rig = root.addOrReplaceChild("rig", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_torso = p_rig.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(12, 0).addBox(-3F, -11F, -2F, 6F, 11F, 4F), PartPose.offset(0F, 11F, 0F));
		PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(32, 0).addBox(-3F, -7F, -3F, 6F, 7F, 6F), PartPose.offset(0F, -11F, 0F));
		PartDefinition p_splinter_r = p_head.addOrReplaceChild("splinter_r", CubeListBuilder.create().texOffs(6, 27).addBox(-3F, -10F, -1F, 1F, 4F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_splinter_l = p_head.addOrReplaceChild("splinter_l", CubeListBuilder.create().texOffs(10, 27).addBox(2F, -9F, 0F, 1F, 3F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_spine_0 = p_torso.addOrReplaceChild("spine_0", CubeListBuilder.create().texOffs(0, 27).addBox(-0.5F, -9F, 2F, 1F, 3F, 2F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_spine_1 = p_torso.addOrReplaceChild("spine_1", CubeListBuilder.create().texOffs(0, 27).addBox(-0.5F, -5F, 2F, 1F, 3F, 2F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_arm_r = p_torso.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(0, 0).addBox(-1.5F, 0F, -1.5F, 3F, 16F, 3F), PartPose.offset(-4.5F, -9.5F, 0F));
		PartDefinition p_hand_r = p_arm_r.addOrReplaceChild("hand_r", CubeListBuilder.create().texOffs(18, 19).addBox(-2F, 0F, -2F, 4F, 3F, 4F), PartPose.offset(0F, 16F, 0F));
		PartDefinition p_claw_r_0 = p_hand_r.addOrReplaceChild("claw_r_0", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(-1.5F, 3F, 0F));
		PartDefinition p_claw_r_1 = p_hand_r.addOrReplaceChild("claw_r_1", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_claw_r_2 = p_hand_r.addOrReplaceChild("claw_r_2", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(1.5F, 3F, 0F));
		PartDefinition p_arm_l = p_torso.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(0, 0).addBox(-1.5F, 0F, -1.5F, 3F, 16F, 3F), PartPose.offset(4.5F, -9.5F, 0F));
		PartDefinition p_hand_l = p_arm_l.addOrReplaceChild("hand_l", CubeListBuilder.create().texOffs(18, 19).addBox(-2F, 0F, -2F, 4F, 3F, 4F), PartPose.offset(0F, 16F, 0F));
		PartDefinition p_claw_l_0 = p_hand_l.addOrReplaceChild("claw_l_0", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(-1.5F, 3F, 0F));
		PartDefinition p_claw_l_1 = p_hand_l.addOrReplaceChild("claw_l_1", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_claw_l_2 = p_hand_l.addOrReplaceChild("claw_l_2", CubeListBuilder.create().texOffs(48, 19).addBox(-0.5F, 0F, -0.5F, 1F, 5F, 1F), PartPose.offset(1.5F, 3F, 0F));
		PartDefinition p_wisp_a = p_rig.addOrReplaceChild("wisp_a", CubeListBuilder.create().texOffs(0, 19).addBox(-2.5F, 0F, -2F, 5F, 4F, 4F), PartPose.offset(0F, 11F, 0F));
		PartDefinition p_wisp_b = p_wisp_a.addOrReplaceChild("wisp_b", CubeListBuilder.create().texOffs(34, 19).addBox(-2F, 0F, -1.5F, 4F, 4F, 3F), PartPose.offset(0F, 4F, 0F));
		PartDefinition p_wisp_c = p_wisp_b.addOrReplaceChild("wisp_c", CubeListBuilder.create().texOffs(52, 19).addBox(-1F, 0F, -1F, 2F, 3F, 2F), PartPose.offset(0F, 4F, 0F));
		return LayerDefinition.create(mesh, TEX_W, TEX_H);
	}
}
