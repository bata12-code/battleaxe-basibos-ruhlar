package com.battleaxe.client.nexus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.joml.Matrix3x2fStack;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import com.battleaxe.item.ModItems;
import com.battleaxe.nexus.Branch;
import com.battleaxe.nexus.NexusActionPayload;
import com.battleaxe.nexus.NexusConfig;
import com.battleaxe.nexus.NexusData;
import com.battleaxe.nexus.NexusMath;
import com.battleaxe.nexus.NexusRules;
import com.battleaxe.nexus.NexusStats;
import com.battleaxe.nexus.NexusTree;
import com.battleaxe.nexus.NodeDef;
import com.battleaxe.nexus.NodeType;
import com.battleaxe.nexus.Stat;
import com.battleaxe.soul.SoulManager;
import com.battleaxe.soul.SoulText;

/**
 * Ruh Ağı ekranı: geniş, kaydırılabilir ve yakınlaştırılabilir pasif yetenek ağacı.
 *
 * <p>İstemci YALNIZCA gösterir ve istek gönderir: satın alma, XP/puan düşümü ve tüm doğrulama sunucudadır.
 * Düğümlerin durumu (açık / açılabilir / yetersiz kaynak / kilitli) sunucunun kullandığı aynı saf kurallardan
 * hesaplanır, ama bu yalnızca görsel içindir. Konum ve yakınlaştırma ekran kapanıp açılınca korunur.
 */
public final class NexusScreen extends Screen {
	private static final float UNIT = 58.0F;
	private static final int TOP = 34;
	private static final int BOTTOM = 26;
	private static final int PANEL_W = 214;
	private static final double MAX_VIEW = 11.0;

	private enum Visual { UNLOCKED, AVAILABLE, LACKING, LOCKED }

	// Görünüm kapanıp açılınca korunur.
	private static double viewX;
	private static double viewY;
	private static float zoom = 0.8F;
	private static String selected;

	private double targetX;
	private double targetY;
	private float targetZoom;
	private boolean animating;

	private double mouseX;
	private double mouseY;
	private boolean panning;
	private double dragDistance;
	private boolean confirming;

	private Button buyButton;
	private Button resetButton;
	private Button confirmButton;
	private Button cancelButton;
	private final List<Button> mainButtons = new ArrayList<>();

	// Düğüm durumları önbelleği (veri veya XP değişince yeniden hesaplanır)
	private NexusData cachedData;
	private long cachedXp = -1L;
	private final Map<String, NexusRules.Result> results = new HashMap<>();
	private Set<String> owned = Set.of();
	private NexusStats stats = NexusStats.EMPTY;

	private static ItemStack coreIcon;
	private static final Map<Branch, ItemStack> BRANCH_ICONS = new HashMap<>();

	public NexusScreen() {
		super(Component.translatable("nexus.screen.title"));
	}

	@Override
	public boolean isPauseScreen() {
		return false; // tek oyunculuda sunucu durmasın: satın alma istekleri işlensin
	}

	// ------------------------------------------------------------------
	// Kurulum
	// ------------------------------------------------------------------

	@Override
	protected void init() {
		ClientPlayNetworking.send(new NexusActionPayload(NexusActionPayload.SYNC, "", 0));
		mainButtons.clear();

		int areaW = width - PANEL_W;
		int by = height - BOTTOM + 3;
		String[] names = {"nexus.ui.center", "nexus.branch.soul", "nexus.branch.exec", "nexus.branch.rift",
				"nexus.branch.guard", "nexus.branch.mind", "nexus.ui.zoom_out", "nexus.ui.zoom_in"};
		ChatFormatting[] colors = {ChatFormatting.WHITE, ChatFormatting.AQUA, ChatFormatting.RED,
				ChatFormatting.LIGHT_PURPLE, ChatFormatting.GOLD, ChatFormatting.GREEN, ChatFormatting.WHITE,
				ChatFormatting.WHITE};
		int gap = 3;
		int smallW = 20;
		int bigW = Math.max(36, Math.min(66, (areaW - 8 - gap * 7 - smallW * 2) / 6));
		int x = 4;
		for (int i = 0; i < names.length; i++) {
			final int index = i;
			int w = i >= 6 ? smallW : bigW;
			Button button = Button.builder(Component.translatable(names[i]).withStyle(colors[i]), b -> onNav(index))
					.bounds(x, by, w, 20).build();
			addRenderableWidget(button);
			mainButtons.add(button);
			x += w + gap;
		}

		int px = width - PANEL_W + 8;
		buyButton = addRenderableWidget(Button.builder(Component.translatable("nexus.ui.buy"), b -> buy())
				.bounds(px, height - 76, PANEL_W - 16, 20).build());
		resetButton = addRenderableWidget(Button.builder(Component.translatable("nexus.ui.reset"), b -> confirming = true)
				.bounds(px, height - 50, (PANEL_W - 20) / 2, 20).build());
		Button close = addRenderableWidget(Button.builder(Component.translatable("nexus.ui.close"), b -> onClose())
				.bounds(px + (PANEL_W - 20) / 2 + 4, height - 50, (PANEL_W - 20) / 2, 20).build());
		mainButtons.add(buyButton);
		mainButtons.add(resetButton);
		mainButtons.add(close);

		int dw = 300;
		int dx = (width - dw) / 2;
		int dy = (height - 120) / 2;
		confirmButton = addRenderableWidget(Button.builder(Component.translatable("nexus.ui.confirm"), b -> doReset())
				.bounds(dx + 12, dy + 94, dw / 2 - 18, 20).build());
		cancelButton = addRenderableWidget(Button.builder(Component.translatable("nexus.ui.cancel"), b -> confirming = false)
				.bounds(dx + dw / 2 + 6, dy + 94, dw / 2 - 18, 20).build());
	}

	private void onNav(int index) {
		if (index == 0) {
			jumpTo(0.0, 0.0, 0.8F);
		} else if (index <= 5) {
			Branch branch = Branch.values()[index - 1];
			double sx = 0.0;
			double sy = 0.0;
			List<NodeDef> nodes = NexusTree.branch(branch);
			for (NodeDef node : nodes) {
				sx += node.x();
				sy += node.y();
			}
			jumpTo(sx / nodes.size(), sy / nodes.size(), 1.0F);
		} else if (index == 6) {
			zoomAt(width / 2.0, height / 2.0, 1.0 / 1.25);
		} else {
			zoomAt(width / 2.0, height / 2.0, 1.25);
		}
	}

	private void jumpTo(double x, double y, float z) {
		targetX = x;
		targetY = y;
		targetZoom = z;
		animating = true;
	}

	private boolean holdingAxe() {
		LocalPlayer player = minecraft == null ? null : minecraft.player;
		return player != null
				&& (player.getMainHandItem().is(ModItems.BATTLE_AXE) || player.getOffhandItem().is(ModItems.BATTLE_AXE));
	}

	private void buy() {
		NodeDef node = selected == null ? null : NexusTree.get(selected);
		if (node != null && visualOf(node) == Visual.AVAILABLE) {
			ClientPlayNetworking.send(new NexusActionPayload(NexusActionPayload.PURCHASE, node.id(), 0));
		}
	}

	private void doReset() {
		confirming = false;
		int count = ClientNexusState.data().unlocked().size();
		if (count > 0) {
			ClientPlayNetworking.send(new NexusActionPayload(NexusActionPayload.RESET, "", count));
		}
	}

	// ------------------------------------------------------------------
	// Durum hesapları
	// ------------------------------------------------------------------

	private long xpPoints() {
		LocalPlayer player = minecraft == null ? null : minecraft.player;
		return player == null ? 0L : NexusMath.playerPoints(player.experienceLevel, player.experienceProgress);
	}

	private void refreshCache() {
		NexusData data = ClientNexusState.data();
		long xp = xpPoints();
		if (data == cachedData && xp == cachedXp) {
			return;
		}
		cachedData = data;
		cachedXp = xp;
		owned = data.unlockedSet();
		stats = NexusStats.compute(NexusTree.resolve(data.unlocked()));
		results.clear();
		for (NodeDef node : NexusTree.all()) {
			if (!owned.contains(node.id())) {
				results.put(node.id(), NexusRules.purchase(data, node.id(), xp).result());
			}
		}
	}

	private Visual visualOf(NodeDef node) {
		if (owned.contains(node.id())) {
			return Visual.UNLOCKED;
		}
		NexusRules.Result result = results.get(node.id());
		if (result == NexusRules.Result.OK) {
			return Visual.AVAILABLE;
		}
		if (result == NexusRules.Result.NOT_REACHABLE || result == NexusRules.Result.REQUIREMENTS || result == null) {
			return Visual.LOCKED;
		}
		return Visual.LACKING;
	}

	// ------------------------------------------------------------------
	// Koordinatlar
	// ------------------------------------------------------------------

	private float originX() {
		return (width - PANEL_W) / 2.0F;
	}

	private float originY() {
		return (TOP + height - BOTTOM) / 2.0F;
	}

	private float scale() {
		return UNIT * zoom;
	}

	private static float radius(NodeType type) {
		return switch (type) {
			case SMALL -> 7.0F;
			case MEDIUM -> 10.0F;
			case LARGE -> 14.0F;
			case CAPSTONE -> 19.0F;
		};
	}

	private NodeDef nodeAt(double mx, double my) {
		NodeDef best = null;
		double bestDist = Double.MAX_VALUE;
		for (NodeDef node : NexusTree.all()) {
			double sx = originX() + (node.x() - viewX) * scale();
			double sy = originY() + (node.y() - viewY) * scale();
			double r = radius(node.type()) * zoom + 3.0;
			double d = (mx - sx) * (mx - sx) + (my - sy) * (my - sy);
			if (d <= r * r && d < bestDist) {
				best = node;
				bestDist = d;
			}
		}
		return best;
	}

	private void zoomAt(double mx, double my, double factor) {
		double wx = viewX + (mx - originX()) / scale();
		double wy = viewY + (my - originY()) / scale();
		zoom = Mth.clamp((float) (zoom * factor), 0.4F, 2.4F);
		viewX = wx - (mx - originX()) / scale();
		viewY = wy - (my - originY()) / scale();
		animating = false;
	}

	// ------------------------------------------------------------------
	// Girdi
	// ------------------------------------------------------------------

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (super.mouseClicked(event, doubleClick)) {
			return true;
		}
		if (confirming || mouseX >= width - PANEL_W || mouseY < TOP || mouseY > height - BOTTOM) {
			return true;
		}
		panning = true;
		dragDistance = 0.0;
		animating = false;
		return true;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (panning) {
			viewX = Mth.clamp(viewX - dx / scale(), -MAX_VIEW, MAX_VIEW);
			viewY = Mth.clamp(viewY - dy / scale(), -MAX_VIEW, MAX_VIEW);
			dragDistance += Math.abs(dx) + Math.abs(dy);
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		boolean handled = super.mouseReleased(event);
		if (panning) {
			panning = false;
			if (dragDistance < 4.0) {
				NodeDef hit = nodeAt(mouseX, mouseY);
				if (hit != null) {
					selected = hit.id();
				}
			}
			return true;
		}
		return handled;
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
		if (confirming || mx >= width - PANEL_W || scrollY == 0.0) {
			return super.mouseScrolled(mx, my, scrollX, scrollY);
		}
		zoomAt(mx, my, scrollY > 0.0 ? 1.12 : 1.0 / 1.12);
		return true;
	}

	// ------------------------------------------------------------------
	// Çizim
	// ------------------------------------------------------------------

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
		this.mouseX = mx;
		this.mouseY = my;
		refreshCache();

		if (animating) {
			viewX += (targetX - viewX) * 0.22;
			viewY += (targetY - viewY) * 0.22;
			zoom += (targetZoom - zoom) * 0.22F;
			if (Math.abs(targetX - viewX) < 0.01 && Math.abs(targetY - viewY) < 0.01 && Math.abs(targetZoom - zoom) < 0.01F) {
				animating = false;
			}
		}

		g.fill(0, 0, width, height, 0xFF0A0810);
		drawDust(g);

		NodeDef hovered = confirming || mx >= width - PANEL_W || my < TOP || my > height - BOTTOM ? null : nodeAt(mx, my);
		float pulse = 0.5F + 0.5F * Mth.sin((Util.getMillis() % 100_000L) * 0.005F);

		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		pose.translate(originX() - (float) (viewX * scale()), originY() - (float) (viewY * scale()));
		pose.scale(zoom, zoom);
		drawLinks(g, pose);
		drawBranchLabels(g, pose);
		drawCore(g, pose);
		for (NodeDef node : NexusTree.all()) {
			drawNode(g, pose, node, visualOf(node), node == hovered, node.id().equals(selected), pulse);
		}
		pose.popMatrix();

		NodeDef shown = hovered != null ? hovered : (selected == null ? null : NexusTree.get(selected));
		drawTopBar(g);
		drawPanel(g, shown);
		drawBottomBar(g);
		drawToast(g);

		boolean canAct = holdingAxe();
		NodeDef sel = selected == null ? null : NexusTree.get(selected);
		buyButton.active = canAct && sel != null && visualOf(sel) == Visual.AVAILABLE;
		resetButton.active = canAct && !ClientNexusState.data().unlocked().isEmpty();
		for (Button button : mainButtons) {
			button.visible = !confirming;
		}
		confirmButton.visible = confirming;
		cancelButton.visible = confirming;
		if (confirming) {
			drawConfirm(g);
		}
		super.extractRenderState(g, mx, my, partialTick);
	}

	private void drawDust(GuiGraphicsExtractor g) {
		int shiftX = (int) (viewX * scale() * 0.12);
		int shiftY = (int) (viewY * scale() * 0.12);
		for (int i = 0; i < 110; i++) {
			long h = (i + 1) * 2654435761L;
			int px = (int) (((h >>> 7) % width - shiftX) % width);
			int py = (int) (((h >>> 19) % height - shiftY) % height);
			if (px < 0) {
				px += width;
			}
			if (py < 0) {
				py += height;
			}
			int alpha = 28 + (int) ((h >>> 31) % 50);
			g.fill(px, py, px + 1, py + 1, argb(alpha, 0xB69CFF));
		}
	}

	private void line(GuiGraphicsExtractor g, Matrix3x2fStack pose, float x1, float y1, float x2, float y2, int half, int color) {
		float dx = x2 - x1;
		float dy = y2 - y1;
		int length = Math.round((float) Math.sqrt(dx * dx + dy * dy));
		pose.pushMatrix();
		pose.translate(x1, y1);
		pose.rotate((float) Math.atan2(dy, dx));
		g.fill(0, -half, length, half, color);
		pose.popMatrix();
	}

	private void drawLinks(GuiGraphicsExtractor g, Matrix3x2fStack pose) {
		int dark = 0xFF2A2336;
		for (NodeDef node : NexusTree.all()) {
			float x1 = node.x() * UNIT;
			float y1 = node.y() * UNIT;
			Visual a = visualOf(node);
			if (node.isGate()) {
				int color = a == Visual.UNLOCKED ? argb(255, node.branch().rgb) : dark;
				line(g, pose, 0.0F, 0.0F, x1, y1, a == Visual.UNLOCKED ? 2 : 1, color);
			}
			for (String id : node.links()) {
				if (id.compareTo(node.id()) < 0) {
					continue; // her bağlantı bir kez çizilir
				}
				NodeDef other = NexusTree.get(id);
				Visual b = visualOf(other);
				int color = dark;
				int half = 1;
				if (a == Visual.UNLOCKED && b == Visual.UNLOCKED) {
					color = argb(255, node.branch() == other.branch() ? node.branch().rgb : 0xE8D9A0);
					half = 2;
				} else if (a == Visual.UNLOCKED || b == Visual.UNLOCKED) {
					NodeDef lit = a == Visual.UNLOCKED ? node : other;
					color = argb(120, lit.branch().rgb);
				}
				line(g, pose, x1, y1, other.x() * UNIT, other.y() * UNIT, half, color);
			}
		}
	}

	private void drawBranchLabels(GuiGraphicsExtractor g, Matrix3x2fStack pose) {
		Branch[] branches = Branch.values();
		for (int i = 0; i < branches.length; i++) {
			double angle = Math.toRadians(-90 + 72 * i);
			float px = (float) (Math.cos(angle) * 9.9 * UNIT);
			float py = (float) (Math.sin(angle) * 9.9 * UNIT);
			String name = Component.translatable(branches[i].langKey()).getString();
			pose.pushMatrix();
			pose.translate(px, py);
			pose.scale(1.5F, 1.5F);
			g.text(font, name, -font.width(name) / 2, -4, argb(230, branches[i].rgb), true);
			pose.popMatrix();
			ItemStack icon = icon(branches[i]);
			pose.pushMatrix();
			pose.translate(px - 16, py - 36);
			pose.scale(2.0F, 2.0F);
			g.item(icon, 0, 0);
			pose.popMatrix();
		}
	}

	private void drawCore(GuiGraphicsExtractor g, Matrix3x2fStack pose) {
		int r = 24;
		g.fill(-r - 3, -r - 3, r + 3, r + 3, 0xFF3A2C5E);
		g.fill(-r, -r, r, r, 0xFF120D1E);
		pose.pushMatrix();
		pose.rotate((float) (Math.PI / 4.0));
		g.fill(-r, -r, r, r, argb(110, 0x8A63FF));
		pose.popMatrix();
		if (coreIcon == null) {
			coreIcon = new ItemStack(ModItems.BATTLE_AXE);
		}
		pose.pushMatrix();
		pose.translate(-16.0F, -16.0F);
		pose.scale(2.0F, 2.0F);
		g.item(coreIcon, 0, 0);
		pose.popMatrix();
	}

	private void drawNode(GuiGraphicsExtractor g, Matrix3x2fStack pose, NodeDef node, Visual visual, boolean hovered,
			boolean isSelected, float pulse) {
		float cx = node.x() * UNIT;
		float cy = node.y() * UNIT;
		float r = radius(node.type());
		int rgb = node.branch().rgb;

		int border;
		int fill;
		switch (visual) {
			case UNLOCKED -> {
				border = argb(255, brighten(rgb, 0.55F));
				fill = argb(255, rgb);
			}
			case AVAILABLE -> {
				border = argb(255, mix(0xFFFFFF, 0xFFD36B, pulse));
				fill = argb(255, darken(rgb, 0.55F));
			}
			case LACKING -> {
				border = argb(255, 0xC0553A);
				fill = argb(255, darken(rgb, 0.28F));
			}
			default -> {
				border = argb(255, 0x3A3347);
				fill = argb(255, 0x191521);
			}
		}

		// Büyük ve dal sonu düğümleri: parlama halkası
		if ((node.type() == NodeType.LARGE || node.type() == NodeType.CAPSTONE) && visual != Visual.LOCKED) {
			int glowAlpha = visual == Visual.UNLOCKED ? 70 : 38;
			rotSquare(g, pose, cx, cy, r * 1.25F, (float) (Math.PI / 8.0), argb(glowAlpha, rgb));
		}

		switch (node.type()) {
			case SMALL -> {
				rotSquare(g, pose, cx, cy, r * 0.9F, 0.0F, border);
				rotSquare(g, pose, cx, cy, r * 0.9F - 2.0F, 0.0F, fill);
			}
			case MEDIUM -> {
				rotSquare(g, pose, cx, cy, r * 0.78F, (float) (Math.PI / 4.0), border);
				rotSquare(g, pose, cx, cy, r * 0.78F - 2.0F, (float) (Math.PI / 4.0), fill);
			}
			default -> {
				float half = r * 0.76F;
				rotSquare(g, pose, cx, cy, half, 0.0F, border);
				rotSquare(g, pose, cx, cy, half, (float) (Math.PI / 4.0), border);
				rotSquare(g, pose, cx, cy, half - 2.5F, 0.0F, fill);
				rotSquare(g, pose, cx, cy, half - 2.5F, (float) (Math.PI / 4.0), fill);
				ItemStack icon = icon(node.branch());
				pose.pushMatrix();
				pose.translate(cx - 8.0F, cy - 8.0F);
				g.item(icon, 0, 0);
				pose.popMatrix();
			}
		}

		if (visual == Visual.UNLOCKED && (node.type() == NodeType.SMALL || node.type() == NodeType.MEDIUM)) {
			g.fill(Math.round(cx) - 1, Math.round(cy) - 1, Math.round(cx) + 1, Math.round(cy) + 1, 0xFFFFFFFF);
		}

		if (isSelected) {
			float ring = r * 1.05F + 4.0F + pulse * 2.0F;
			rotSquare(g, pose, cx, cy, ring, (float) (Math.PI / 4.0), argb(70, 0xFFFFFF));
		}
		if (hovered) {
			rotSquare(g, pose, cx, cy, r + 5.0F, (float) (Math.PI / 4.0), argb(60, 0xFFFFFF));
		}
	}

	private void rotSquare(GuiGraphicsExtractor g, Matrix3x2fStack pose, float cx, float cy, float half, float angle, int color) {
		int h = Math.max(1, Math.round(half));
		pose.pushMatrix();
		pose.translate(cx, cy);
		if (angle != 0.0F) {
			pose.rotate(angle);
		}
		g.fill(-h, -h, h, h, color);
		pose.popMatrix();
	}

	private ItemStack icon(Branch branch) {
		return BRANCH_ICONS.computeIfAbsent(branch, key -> new ItemStack(switch (key) {
			case SOUL -> Items.SOUL_LANTERN;
			case EXECUTIONER -> Items.NETHERITE_AXE;
			case RIFT -> Items.ENDER_PEARL;
			case GUARD -> Items.SHIELD;
			case MIND -> Items.WITHER_SKELETON_SKULL;
		}));
	}

	// ------------------------------------------------------------------
	// Paneller
	// ------------------------------------------------------------------

	private void drawTopBar(GuiGraphicsExtractor g) {
		g.fillGradient(0, 0, width, TOP, 0xF0160F26, 0xF00B0714);
		g.fill(0, TOP - 1, width, TOP, 0xFF3A2C5E);

		NexusData data = ClientNexusState.data();
		LocalPlayer player = minecraft.player;
		int rank = 0;
		if (player != null) {
			ItemStack held = player.getMainHandItem().is(ModItems.BATTLE_AXE) ? player.getMainHandItem() : player.getOffhandItem();
			rank = held.is(ModItems.BATTLE_AXE) ? SoulManager.rankOf(held) : 0;
		}
		int next = NexusMath.pointsForLifetime(data.lifetimeSouls()) >= NexusConfig.MAX_POINTS ? -1
				: (int) (NexusMath.thresholdForPoint(data.earnedPoints() + 1) - data.lifetimeSouls());

		String balance = Component.translatable("nexus.ui.balance", fmt(data.soulBalance())).getString();
		String points = Component.translatable("nexus.ui.points", NexusRules.availablePoints(data), data.earnedPoints()).getString();
		int level = player == null ? 0 : player.experienceLevel;
		String xp = Component.translatable("nexus.ui.xp", level, fmt(xpPoints())).getString();
		g.text(font, balance, 8, 5, 0xFF7FE6FF, true);
		int x = 8 + font.width(balance) + 14;
		g.text(font, points, x, 5, 0xFFFFE08A, true);
		x += font.width(points) + 14;
		g.text(font, xp, x, 5, 0xFF9CFF8A, true);

		String rankText = Component.translatable("nexus.ui.rank",
				rank > 0 || holdingAxe() ? SoulText.rankName(rank) : Component.literal("-")).getString();
		String nextText = next < 0 ? Component.translatable("nexus.ui.next_max").getString()
				: Component.translatable("nexus.ui.next_point", fmt(Math.max(0, next))).getString();
		g.text(font, rankText, 8, 19, 0xFFC9C0E0, true);
		g.text(font, nextText, 8 + font.width(rankText) + 14, 19, 0xFF8F86A8, true);
	}

	private void drawBottomBar(GuiGraphicsExtractor g) {
		int y = height - BOTTOM;
		g.fill(0, y, width - PANEL_W, height, 0xE00B0714);
		g.fill(0, y, width - PANEL_W, y + 1, 0xFF3A2C5E);
	}

	private void drawPanel(GuiGraphicsExtractor g, NodeDef node) {
		int x = width - PANEL_W;
		g.fillGradient(x, TOP, width, height, 0xF0140E22, 0xF00A0612);
		g.fill(x, TOP, x + 1, height, 0xFF3A2C5E);

		int tx = x + 9;
		int maxW = PANEL_W - 18;
		int y = TOP + 9;
		if (node == null) {
			for (String line : wrap(Component.translatable("nexus.ui.hint").getString(), maxW)) {
				g.text(font, line, tx, y, 0xFF8F86A8, false);
				y += 11;
			}
			return;
		}

		Visual visual = visualOf(node);
		g.text(font, Component.translatable(node.nameKey()).getString(), tx, y, argb(255, brighten(node.branch().rgb, 0.3F)), true);
		y += 12;
		String typeLine = Component.translatable(node.role().langKey()).getString() + "  -  "
				+ Component.translatable(node.type().langKey()).getString() + "  -  "
				+ Component.translatable(node.branch().langKey()).getString();
		g.text(font, typeLine, tx, y, 0xFF8F86A8, false);
		y += 14;
		g.fill(tx, y - 3, tx + maxW, y - 2, 0xFF2A2336);

		g.text(font, Component.translatable("nexus.ui.effects").getString(), tx, y, 0xFFB69CFF, false);
		y += 11;
		for (Component effect : NexusTexts.effectLines(node)) {
			for (String line : wrap(effect.getString(), maxW - 6)) {
				g.text(font, line, tx + 6, y, 0xFFE8E2F5, false);
				y += 10;
			}
			y += 2;
		}
		y += 4;

		// Durum
		String stateKey = switch (visual) {
			case UNLOCKED -> "nexus.ui.state.unlocked";
			case AVAILABLE -> "nexus.ui.state.available";
			case LACKING -> "nexus.ui.state.lacking";
			case LOCKED -> "nexus.ui.state.locked";
		};
		int stateColor = switch (visual) {
			case UNLOCKED -> 0xFF8CFF9C;
			case AVAILABLE -> 0xFFFFE08A;
			case LACKING -> 0xFFFF8A6B;
			case LOCKED -> 0xFF8F86A8;
		};
		g.text(font, Component.translatable(stateKey).getString(), tx, y, stateColor, true);
		y += 14;

		if (visual == Visual.UNLOCKED) {
			return;
		}

		NexusData data = ClientNexusState.data();
		int availablePoints = NexusRules.availablePoints(data);
		boolean linked = NexusTree.isReachable(owned, node);
		y = req(g, tx, y, maxW, linked, Component.translatable("nexus.ui.req.link").getString());
		// Sinerji önkoşulları: başka daldaki düğüm(ler); açık/kapalı durumu renkle gösterilir.
		for (String required : node.requires()) {
			NodeDef reqNode = NexusTree.get(required);
			if (reqNode != null) {
				y = req(g, tx, y, maxW, owned.contains(required), Component.translatable("nexus.ui.req.node",
						Component.translatable(reqNode.nameKey()).getString(),
						Component.translatable(reqNode.branch().langKey()).getString()).getString());
			}
		}
		y = req(g, tx, y, maxW, availablePoints >= node.type().points,
				Component.translatable("nexus.ui.req.points", node.type().points, availablePoints).getString());
		if (node.type().xpLevels > 0) {
			y = req(g, tx, y, maxW, xpPoints() >= node.type().xpPoints(),
					Component.translatable("nexus.ui.req.xp", node.type().xpLevels, node.type().xpPoints()).getString());
		}
		if (node.type() == NodeType.CAPSTONE) {
			int inBranch = 0;
			int large = 0;
			for (String id : owned) {
				NodeDef other = NexusTree.get(id);
				if (other != null && other.branch() == node.branch()) {
					inBranch++;
					if (other.type() == NodeType.LARGE) {
						large++;
					}
				}
			}
			y = req(g, tx, y, maxW, NexusRules.capstoneReady(owned, node), Component.translatable("nexus.ui.req.capstone",
					NexusConfig.CAPSTONE_MIN_BRANCH_NODES, NexusConfig.CAPSTONE_MIN_LARGE_NODES, inBranch, large).getString());
		}
		if (!holdingAxe()) {
			for (String line : wrap(Component.translatable("nexus.ui.need_axe").getString(), maxW)) {
				g.text(font, line, tx, y, 0xFFFF8A6B, false);
				y += 10;
			}
		}
	}

	private int req(GuiGraphicsExtractor g, int x, int y, int maxW, boolean ok, String text) {
		int color = ok ? 0xFF8CFF9C : 0xFFFF8A6B;
		String mark = ok ? "[+] " : "[x] ";
		List<String> lines = wrap(mark + text, maxW);
		for (String line : lines) {
			g.text(font, line, x, y, color, false);
			y += 10;
		}
		return y + 2;
	}

	private void drawToast(GuiGraphicsExtractor g) {
		String key = ClientNexusState.message();
		if (key.isEmpty()) {
			return;
		}
		String text = Component.translatable(key).getString();
		int w = font.width(text) + 16;
		int x = (width - PANEL_W - w) / 2;
		int y = height - BOTTOM - 24;
		g.fill(x, y, x + w, y + 16, 0xE0120C1E);
		g.outline(x, y, w, 16, ClientNexusState.messageOk() ? 0xFF5DDB7A : 0xFFDB5D4A);
		g.text(font, text, x + 8, y + 4, ClientNexusState.messageOk() ? 0xFFB6FFC4 : 0xFFFFC2B8, false);
	}

	private void drawConfirm(GuiGraphicsExtractor g) {
		g.fill(0, 0, width, height, 0xB0000000);
		int dw = 300;
		int dx = (width - dw) / 2;
		int dy = (height - 120) / 2;
		g.fill(dx, dy, dx + dw, dy + 120, 0xFF140E22);
		g.outline(dx, dy, dw, 120, 0xFFB69CFF);

		NexusData data = ClientNexusState.data();
		NexusRules.ResetPlan plan = NexusRules.resetPlan(data, stats.get(Stat.RESET_DISCOUNT_PCT));
		boolean enough = data.soulBalance() >= plan.souls() && xpPoints() >= plan.xpPoints();

		g.text(font, Component.translatable("nexus.ui.reset.title").getString(), dx + 12, dy + 10, 0xFFFFE08A, true);
		int y = dy + 26;
		for (String line : wrap(Component.translatable("nexus.ui.reset.body", plan.nodes()).getString(), dw - 24)) {
			g.text(font, line, dx + 12, y, 0xFFE8E2F5, false);
			y += 10;
		}
		String cost = Component.translatable("nexus.ui.reset.cost", fmt(plan.souls()), plan.xpPoints(), plan.xpLevels()).getString();
		for (String line : wrap(cost, dw - 24)) {
			g.text(font, line, dx + 12, y, enough ? 0xFF9CFF8A : 0xFFFF8A6B, false);
			y += 10;
		}
		for (String line : wrap(Component.translatable(enough ? "nexus.ui.reset.keeps" : "nexus.ui.reset.insufficient").getString(), dw - 24)) {
			g.text(font, line, dx + 12, y, enough ? 0xFF8F86A8 : 0xFFFF8A6B, false);
			y += 10;
		}
		confirmButton.active = enough && holdingAxe();
	}

	// ------------------------------------------------------------------
	// Yardımcılar
	// ------------------------------------------------------------------

	private List<String> wrap(String text, int maxWidth) {
		List<String> lines = new ArrayList<>();
		StringBuilder current = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = current.length() == 0 ? word : current + " " + word;
			if (font.width(candidate) > maxWidth && current.length() > 0) {
				lines.add(current.toString());
				current = new StringBuilder(word);
			} else {
				current = new StringBuilder(candidate);
			}
		}
		if (current.length() > 0) {
			lines.add(current.toString());
		}
		return lines;
	}

	private static String fmt(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	private static int argb(int alpha, int rgb) {
		return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0xFFFFFF);
	}

	private static int darken(int rgb, float factor) {
		int r = (int) (((rgb >> 16) & 0xFF) * factor);
		int gr = (int) (((rgb >> 8) & 0xFF) * factor);
		int b = (int) ((rgb & 0xFF) * factor);
		return (r << 16) | (gr << 8) | b;
	}

	private static int brighten(int rgb, float amount) {
		int r = (rgb >> 16) & 0xFF;
		int gr = (rgb >> 8) & 0xFF;
		int b = rgb & 0xFF;
		r += (int) ((255 - r) * amount);
		gr += (int) ((255 - gr) * amount);
		b += (int) ((255 - b) * amount);
		return (r << 16) | (gr << 8) | b;
	}

	private static int mix(int a, int b, float t) {
		int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
		int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
		int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
		return (r << 16) | (g << 8) | bl;
	}
}
