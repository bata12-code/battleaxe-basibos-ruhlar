package com.battleaxe.client.spirit;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

import com.battleaxe.spirit.ZincirliRuhEntity;

/** Zincirli Ruh çizicisi. */
public class ZincirliRenderer extends SpiritRenderer<ZincirliRuhEntity, ZincirliModel> {
	public ZincirliRenderer(EntityRendererProvider.Context context) {
		super(context, new ZincirliModel(context.bakeLayer(ZincirliModel.LAYER)), 0.9F, "zincirli_ruh");
	}
}
