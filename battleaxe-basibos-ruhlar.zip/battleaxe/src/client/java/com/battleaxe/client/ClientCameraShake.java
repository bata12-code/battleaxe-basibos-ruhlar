package com.battleaxe.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

/**
 * Ekran titremesi (yalnızca görsel). Kameranın bakış açısına kısa süreli, sönümlenen bir sapma
 * ekler; oyuncunun gerçek nişanını/rotasyonunu DEĞİŞTİRMEZ.
 */
public final class ClientCameraShake {
	private ClientCameraShake() {
	}

	/** Erişilebilirlik: false yaparsan ekran titremesi tamamen kapanır. */
	public static final boolean ENABLED = true;

	/** En güçlü titremede kameranın sapabileceği en büyük açı (derece). */
	private static final float MAX_YAW_DEGREES = 2.2F;
	private static final float MAX_PITCH_DEGREES = 1.6F;

	/**
	 * Hiddet aktifken süren, çok düşük yoğunluklu sürekli sarsıntı (0-1). 0 yaparsan yalnızca sunucunun istediği
	 * kısa sarsıntılar kalır. Aşağıdaki darbe, ~2.6 sn'de bir kalp atışı gibi kısa süreli hafif bir yoğunlaşmadır.
	 */
	public static final float HIDDET_AMBIENT = 0.07F;
	public static final float HIDDET_BEAT = 0.14F;

	private static long startMillis;
	private static long durationMillis;
	private static float strength;

	/** Titremeyi başlatır. Devam eden daha güçlü bir titremeyi zayıf olan kesmez. */
	public static void start(float newStrength, int ticks) {
		if (!ENABLED || ticks <= 0) {
			return;
		}
		if (newStrength < currentIntensity()) {
			return;
		}
		startMillis = Util.getMillis();
		durationMillis = ticks * 50L;
		strength = Mth.clamp(newStrength, 0.0F, 1.0F);
	}

	/** Şu anki genlik (0-1): başta güçlü, kare alan sönümle sıfıra iner. */
	private static float currentIntensity() {
		if (durationMillis <= 0) {
			return 0.0F;
		}
		long elapsed = Util.getMillis() - startMillis;
		if (elapsed >= durationMillis) {
			return 0.0F;
		}
		float remaining = 1.0F - elapsed / (float) durationMillis;
		return strength * remaining * remaining;
	}

	/**
	 * Hiddet'e bağlı sürekli sarsıntı. Durum her çağrıda istemcideki gerçek duruma bakılarak hesaplanır:
	 * Hiddet kapanınca, oyuncu ölünce ya da dünyadan ayrılınca anında 0 olur (takılı kalan efekt yoktur).
	 */
	private static float ambientIntensity() {
		if (!ENABLED || !ClientBerserkerState.isActive()) {
			return 0.0F;
		}
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null || !player.isAlive()) {
			return 0.0F;
		}
		float ease = Mth.clamp(ClientBerserkerState.millisSinceActivated() / 600.0F, 0.0F, 1.0F);
		float phase = (Util.getMillis() % 2600L) / 2600.0F;
		float beat = phase < 0.07F ? 1.0F - phase / 0.07F : 0.0F;
		return ease * (HIDDET_AMBIENT + HIDDET_BEAT * beat);
	}

	private static float intensity() {
		return Math.max(currentIntensity(), ambientIntensity());
	}

	public static float yawOffset() {
		float intensity = intensity();
		if (intensity <= 0.0F) {
			return 0.0F;
		}
		float t = (Util.getMillis() % 100_000L);
		return intensity * MAX_YAW_DEGREES * (Mth.sin(t * 0.071F) + 0.5F * Mth.sin(t * 0.113F + 1.3F)) / 1.5F;
	}

	public static float pitchOffset() {
		float intensity = intensity();
		if (intensity <= 0.0F) {
			return 0.0F;
		}
		float t = (Util.getMillis() % 100_000L);
		return intensity * MAX_PITCH_DEGREES * (Mth.sin(t * 0.089F + 0.7F) + 0.5F * Mth.sin(t * 0.137F + 2.1F)) / 1.5F;
	}
}
