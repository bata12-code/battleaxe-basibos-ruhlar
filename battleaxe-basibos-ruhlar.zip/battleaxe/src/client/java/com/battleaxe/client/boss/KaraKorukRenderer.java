package com.battleaxe.client.boss;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.boss.KaraKorukEntity;

/** Kara Körük çizicisi. */
public class KaraKorukRenderer extends MobRenderer<KaraKorukEntity, KaraKorukRenderState, KaraKorukModel> {
	private static final Identifier TEXTURE = BattleAxeMod.id("textures/entity/kara_koruk.png");

	public KaraKorukRenderer(EntityRendererProvider.Context context) {
		super(context, new KaraKorukModel(context.bakeLayer(KaraKorukModel.LAYER)), 0.9F);
	}

	@Override
	public KaraKorukRenderState createRenderState() {
		return new KaraKorukRenderState();
	}

	@Override
	public void extractRenderState(KaraKorukEntity entity, KaraKorukRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.slamProgress = entity.getWindupProgress();
		state.attack = entity.getAttackState();
		state.attackProgress = entity.getAttackProgress();
		state.phaseTwo = entity.isPhaseTwo();
	}

	@Override
	public Identifier getTextureLocation(KaraKorukRenderState state) {
		return TEXTURE;
	}
}
