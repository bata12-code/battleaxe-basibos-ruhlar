package com.battleaxe.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.EntityRenderers;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.thrown.ModEntityTypes;
import com.battleaxe.thrown.ThrowAxePayload;
import com.battleaxe.berserker.BerserkerShakePayload;
import com.battleaxe.shunpo.vfx.ShunpoVfxPayload;
import com.battleaxe.call.CallSignPayload;
import com.battleaxe.call.OmenPayload;
import com.battleaxe.client.call.MoonAxeEffect;
import com.battleaxe.client.call.OmenEffect;
import com.battleaxe.boss.ModBossTypes;
import com.battleaxe.spirit.ModSpiritTypes;
import com.battleaxe.client.boss.KaraKorukModel;
import com.battleaxe.client.boss.KaraKorukRenderer;
import com.battleaxe.client.spirit.RuhYiyenModel;
import com.battleaxe.client.spirit.RuhYiyenRenderer;
import com.battleaxe.client.spirit.SavrulmusModel;
import com.battleaxe.client.spirit.SavrulmusRenderer;
import com.battleaxe.client.spirit.ZincirliModel;
import com.battleaxe.client.spirit.ZincirliRenderer;
import com.battleaxe.berserker.BerserkerStatePayload;
import com.battleaxe.chain.ChainSyncPayload;
import com.battleaxe.client.evolution.ClientEvolutionState;
import com.battleaxe.client.evolution.EvolutionHud;
import com.battleaxe.client.evolution.EvolutionScreen;
import com.battleaxe.client.nexus.ClientNexusState;
import com.battleaxe.client.nexus.NexusScreen;
import com.battleaxe.evolution.EvolutionActionPayload;
import com.battleaxe.evolution.EvolutionSyncPayload;
import com.battleaxe.nexus.NexusResultPayload;
import com.battleaxe.nexus.NexusSyncPayload;

public class BattleAxeClient implements ClientModInitializer {
	/** Tuş grubu (Kontroller menüsünde "Savaş Baltası" başlığı altında görünür). */
	private static final KeyMapping.Category KEY_CATEGORY = KeyMapping.Category.register(BattleAxeMod.id("main"));

	/** Baltayı fırlat. Varsayılan R; Seçenekler > Kontroller'den değiştirilebilir. Q (eşya bırakma) etkilenmez. */
	private static final KeyMapping THROW_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.battleaxe.throw_axe", InputConstants.Type.KEYSYM, InputConstants.KEY_R, KEY_CATEGORY));

	/** Ruh Ağı ekranını açar. Varsayılan N (vanilla'da kullanılmaz); Kontroller'den değiştirilebilir. */
	private static final KeyMapping NEXUS_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.battleaxe.nexus", InputConstants.Type.KEYSYM, InputConstants.KEY_N, KEY_CATEGORY));

	/** Berserker Evrimi ekranı. Varsayılan B (vanilla'da boş); Kontroller'den değiştirilebilir. */
	private static final KeyMapping EVOLUTION_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.battleaxe.evolution", InputConstants.Type.KEYSYM, InputConstants.KEY_B, KEY_CATEGORY));

	/** Son Eşik'i başlatır (yalnızca koşullar sağlanıyorsa; sunucu doğrular). Varsayılan V. */
	private static final KeyMapping FINAL_THRESHOLD_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.battleaxe.final_threshold", InputConstants.Type.KEYSYM, InputConstants.KEY_V, KEY_CATEGORY));

	@Override
	public void onInitializeClient() {
		// Sunucu Berserker durumu değiştirdiğinde (veya giriş/doğma sonrası) bilgilendirir.
		ClientPlayNetworking.registerGlobalReceiver(BerserkerStatePayload.TYPE,
				(payload, context) -> ClientBerserkerState.setActive(payload.active()));

		// Sunucu ekran titretmek istediğinde (Berserker başlangıcı, yıldırım düşüşü).
		ClientPlayNetworking.registerGlobalReceiver(BerserkerShakePayload.TYPE,
				(payload, context) -> ClientCameraShake.start(payload.strength(), payload.ticks()));

		// Shunpo gerçeklik yarığı görselleri: sunucunun doğruladığı olayları kısa ömürlü parçacıklara çevirir.
		ShunpoRiftClient.initialize();
		ClientPlayNetworking.registerGlobalReceiver(ShunpoVfxPayload.TYPE,
				(payload, context) -> ShunpoRiftClient.receive(payload));

		// Sunucudan ayrılınca eski durum kalmasın (ör. mod olmayan başka bir sunucuya girince).
		ClientPlayConnectionEvents.DISCONNECT.register((listener, client) -> {
			ClientBerserkerState.reset();
			ClientChainState.reset();
			ShunpoRiftClient.reset();
			ClientNexusState.reset();
			ClientEvolutionState.reset();
			MoonAxeEffect.reset();
			OmenEffect.reset();
		});

		// Baltanın Çağrısı: ayın önünden geçen balta silueti (yalnızca bu oyuncuya gönderilir, yalnızca görsel).
		ClientPlayNetworking.registerGlobalReceiver(CallSignPayload.TYPE,
				(payload, context) -> MoonAxeEffect.start(payload));
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.CROSSHAIR, BattleAxeMod.id("call_moon_axe"), MoonAxeEffect::extract);

		// Baltanın Çağrısı - Öncü Belirtiler: gökteki balta, göz, ufuktaki dev, imkânsız yapı (yalnızca görsel).
		ClientPlayNetworking.registerGlobalReceiver(OmenPayload.TYPE,
				(payload, context) -> OmenEffect.receive(payload));
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.CROSSHAIR, BattleAxeMod.id("call_omen"), OmenEffect::extract);

		// Kıyım Zinciri: sunucunun bildirdiği sayı ve kalan süre (yalnızca HUD için); HUD nişangâhın sağına çizilir.
		ClientPlayNetworking.registerGlobalReceiver(ChainSyncPayload.TYPE,
				(payload, context) -> ClientChainState.apply(payload.count(), payload.remainingTicks()));
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.CROSSHAIR, BattleAxeMod.id("chain"), ChainHud::extract);

		// Ruh Ağı: sunucudan gelen özet ve işlem sonucu (yalnızca gösterim için).
		ClientPlayNetworking.registerGlobalReceiver(NexusSyncPayload.TYPE,
				(payload, context) -> ClientNexusState.apply(payload));
		ClientPlayNetworking.registerGlobalReceiver(NexusResultPayload.TYPE,
				(payload, context) -> ClientNexusState.result(payload));

		// Berserker Evrimi: sunucu özeti (HUD/ekran) ve HUD kaydı.
		ClientPlayNetworking.registerGlobalReceiver(EvolutionSyncPayload.TYPE,
				(payload, context) -> ClientEvolutionState.apply(payload));
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.CROSSHAIR, BattleAxeMod.id("evolution"), EvolutionHud::extract);

		// Kara Körük (boss): model katmanı ve çizici.
		ModelLayerRegistry.registerModelLayer(KaraKorukModel.LAYER, KaraKorukModel::createBodyLayer);
		EntityRenderers.register(ModBossTypes.KARA_KORUK, KaraKorukRenderer::new);

		// Başıboş Ruhlar (Savrulmuş Ruh, Ruh Yiyen, Zincirli Ruh): model katmanları ve çiziciler.
		ModelLayerRegistry.registerModelLayer(SavrulmusModel.LAYER, SavrulmusModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(RuhYiyenModel.LAYER, RuhYiyenModel::createBodyLayer);
		ModelLayerRegistry.registerModelLayer(ZincirliModel.LAYER, ZincirliModel::createBodyLayer);
		EntityRenderers.register(ModSpiritTypes.SAVRULMUS, SavrulmusRenderer::new);
		EntityRenderers.register(ModSpiritTypes.RUH_YIYEN, RuhYiyenRenderer::new);
		EntityRenderers.register(ModSpiritTypes.ZINCIRLI, ZincirliRenderer::new);

		// Fırlatılmış balta çizici ve fırlatma tuşu.
		EntityRenderers.register(ModEntityTypes.THROWN_BATTLE_AXE, ThrownBattleAxeRenderer::new);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (EVOLUTION_KEY.consumeClick()) {
				if (client.player != null && client.gui.screen() == null) {
					client.gui.setScreen(new EvolutionScreen());
				}
			}
			while (FINAL_THRESHOLD_KEY.consumeClick()) {
				if (client.player != null && client.gui.screen() == null) {
					ClientPlayNetworking.send(new EvolutionActionPayload(EvolutionActionPayload.FINAL_THRESHOLD, 0));
				}
			}
			while (NEXUS_KEY.consumeClick()) {
				// Ekran görüntüleme içindir; satın alma/sıfırlama için baltanın elde olmasını SUNUCU şart koşar.
				if (client.player != null && client.gui.screen() == null) {
					client.gui.setScreen(new NexusScreen());
				}
			}
			while (THROW_KEY.consumeClick()) {
				// Sadece istek gönderir; geçerliliği (elde balta, bekleme, tek balta, Shunpo isabeti...) SUNUCU denetler.
				// Shunpo'nun ikinci basışında balta havada olduğu için el boştur; bu yüzden el koşulu kaldırıldı.
				if (client.player != null) {
					ClientPlayNetworking.send(new ThrowAxePayload());
				}
			}
		});

		// Yar Geç şarj çubuğu: nişangahın altında.
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.CROSSHAIR, BattleAxeMod.id("yar_gec_charge"), YarGecChargeHud::extract);

		// Hiddet göstergesi + ekran görünümü: vanilla efekt ikonlarının hemen üstüne çizilir (eski Berserker göstergesinin yerine).
		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MOB_EFFECTS, BattleAxeMod.id("hiddet"), HiddetHud::extract);
	}
}
