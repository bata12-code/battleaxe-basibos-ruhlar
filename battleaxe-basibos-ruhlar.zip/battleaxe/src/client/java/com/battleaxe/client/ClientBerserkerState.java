package com.battleaxe.client;

import net.minecraft.util.Util;

/**
 * İstemcide, sunucunun bildirdiği Berserker durumu (yalnızca HUD için).
 * Gerçek hasar/hız bonusları burada DEĞİL sunucuda uygulanır.
 */
public final class ClientBerserkerState {
	private ClientBerserkerState() {
	}

	private static boolean active;
	private static long activatedAtMillis;

	/** Sunucudan paket geldiğinde çağrılır. Animasyon zamanı sadece false -> true geçişinde bir kez ayarlanır. */
	public static void setActive(boolean value) {
		if (value && !active) {
			activatedAtMillis = Util.getMillis();
		}
		active = value;
	}

	public static boolean isActive() {
		return active;
	}

	public static long millisSinceActivated() {
		return Util.getMillis() - activatedAtMillis;
	}

	/** Sunucudan ayrılınca çağrılır. */
	public static void reset() {
		active = false;
	}
}
