package com.battleaxe.client.call;

import org.joml.Matrix3x2fStack;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.level.Level;

import com.battleaxe.call.CallMoon;
import com.battleaxe.call.OmenConfig;
import com.battleaxe.call.OmenGeometry;
import com.battleaxe.call.OmenKind;
import com.battleaxe.call.OmenLogic;
import com.battleaxe.call.OmenPayload;
import com.battleaxe.call.OmenShapes;
import com.battleaxe.client.ClientCameraShake;

/**
 * Baltanın Çağrısı - Öncü Belirtiler: istemci tarafı. Dört tezahür (devasa balta, göz, ufuktaki dev, imkânsız yapı)
 * burada çizilir.
 *
 * <p><b>Ne değildir:</b> varlık, blok, yapı, model ya da dünya render'ı değildir; oynanışı, FPS'i ve fiziği
 * etkilemez. İstemci kendiliğinden hiçbir tezahür üretmez; yalnızca sunucunun {@link OmenPayload}'ı gelince çizer.
 *
 * <p><b>Nasıl çizilir:</b> her tezahür dünyada SABİT bir yöne bağlıdır (gökteki bir cisim gibi: paralaks yok, ölçek
 * hissi buradan gelir). {@link OmenShapes} çokgenleri köşe köşe kamera yönü ve FOV ile izdüşürülür (kamera
 * döndükçe doğru perspektifle kayar, ekran ortasına yapıştırılmış düz bir resim gibi durmaz) ve {@code fill} şeritleriyle
 * HUD katmanında çizilir. Arazi, ağaç ve yapılar tezahürü örter ({@link OmenOcclusion}); ayrıca bulut/karanlık örtüsü
 * ({@code cover}) bazı tezahürleri kısmen gizler.
 *
 * <p><b>Yaşam döngüsü:</b> aynı anda tek tezahür. Dünya, oyuncu nesnesi (yeniden doğma/boyut), ölüm, açık gökyüzünün
 * kaybı, sunucudan ayrılma ve sunucunun {@link OmenPayload#end()} paketi etkin olayı anında/yumuşakça bitirir ve
 * tüm geçici durum bırakılır. Ekran (envanter vb.) açıkken çizilmez.
 */
public final class OmenEffect {
	private OmenEffect() {
	}

	/** Erişilebilirlik: false yaparsan öncü belirtiler bu istemcide tamamen kapanır (MoonAxeEffect.ENABLED gibi). */
	public static final boolean ENABLED = true;

	private static final float[] CLEAR = new float[0];

	// ---- Etkin olay durumu ----
	private static boolean active;
	private static OmenKind kind;
	private static int variant;
	private static int tone;
	private static int flags;
	private static long seed;
	private static double az;
	private static double el;
	private static long startMs;
	private static long durationMs;
	private static long fadeInMs;
	private static long fadeOutMs;
	private static long vanishAtMs;
	private static long lastFrameMs;

	private static Level levelRef;
	private static LocalPlayer playerRef;
	private static double startX;
	private static double startZ;

	private static boolean noticed;
	private static long dwellMs;
	private static long awayMs;
	private static boolean seenOnce;
	private static boolean tremorDone;
	private static long tremorMs;
	private static long lastSkyCheckMs;
	private static long noSkySinceMs;

	private static double irisX;
	private static double irisY;
	private static double sinkDeg;
	private static double warp;
	/** İmkânsız Halkalar'ın çok yavaş dönüşü (derece) ve Monolith'e yaklaştıkça artan perspektif bozulması (0..1). */
	private static double ringRot;
	private static double approachWarp;
	private static double timeSeconds;

	// ---- Çizim önbelleği ----
	private static OmenShapes.Scene scene;
	private static float[][] sx = new float[0][];
	private static float[][] sy = new float[0][];
	private static float[] gx = CLEAR;
	private static float[] gy = CLEAR;
	private static final OmenOcclusion OCCLUSION = new OmenOcclusion();
	private static int[] clipTop = new int[0];
	private static int[] clipBottom = new int[0];
	private static final double[] POINT = new double[2];

	// ---- "YILDIZI BUL!" mesajı (olaydan bağımsız kısa ömürlü) ----
	private static long messageStartMs;
	private static final long MESSAGE_TOTAL_MS = 4600L;

	// ==================================================================
	// Paket
	// ==================================================================

	public static void receive(OmenPayload payload) {
		if (!ENABLED) {
			return;
		}
		if (payload.kind() == OmenPayload.KIND_END) {
			dismiss();
			return;
		}
		// Parçalanmış Güneş, gün boyu süren dünya çapında bir durumdur: diğer tezahürlerle AYNI ANDA sürer, kendi durumunu taşır.
		if (payload.kind() == OmenKind.FRACTURED_SUN.id()) {
			SunAnomalyEffect.receive(payload);
			return;
		}
		OmenKind newKind = OmenKind.byId(payload.kind());
		Minecraft minecraft = Minecraft.getInstance();
		if (newKind == null || payload.ticks() <= 0 || active || minecraft.level == null || minecraft.player == null) {
			return; // Aynı anda tek tezahür: sunucu zaten çakışmayı önler, bu yalnızca ikinci güvencedir.
		}
		kind = newKind;
		seed = payload.seed();
		variant = OmenLogic.unpackVariant(payload.packed());
		tone = OmenLogic.unpackTone(payload.packed());
		flags = OmenLogic.unpackFlags(payload.packed());
		az = payload.azimuth();
		el = payload.elevation();
		long now = Util.getMillis();
		startMs = now;
		lastFrameMs = now;
		durationMs = payload.ticks() * 50L;
		switch (newKind) {
			case SKY_AXE -> {
				fadeInMs = 1600L;
				fadeOutMs = 2200L;
			}
			case WATCHER_EYE -> {
				fadeInMs = 2400L;
				fadeOutMs = 2800L;
			}
			case HORIZON_COLOSSUS -> {
				fadeInMs = 5000L;
				fadeOutMs = 4500L;
			}
			case SECOND_MOON -> {
				// Gökyüzünde "yavaşça belirir, yavaşça çekilir": jumpscare yok.
				fadeInMs = 9000L;
				fadeOutMs = 9000L;
			}
			case IMPOSSIBLE_RINGS -> {
				fadeInMs = 7000L;
				fadeOutMs = 8000L;
			}
			case MONOLITH -> {
				fadeInMs = 6500L;
				fadeOutMs = 6500L;
			}
			default -> {
				fadeInMs = 6000L;
				fadeOutMs = 5000L;
			}
		}
		vanishAtMs = 0L;
		noticed = false;
		dwellMs = 0L;
		awayMs = 0L;
		seenOnce = false;
		tremorDone = false;
		tremorMs = 0L;
		lastSkyCheckMs = 0L;
		noSkySinceMs = 0L;
		irisX = 0.0;
		irisY = 0.0;
		sinkDeg = 0.0;
		warp = 0.0;
		ringRot = 0.0;
		approachWarp = 0.0;
		levelRef = minecraft.level;
		playerRef = minecraft.player;
		startX = minecraft.player.getX();
		startZ = minecraft.player.getZ();

		scene = OmenShapes.build(newKind, variant, seed);
		int count = scene.polys().length;
		sx = new float[count][];
		sy = new float[count][];
		for (int i = 0; i < count; i++) {
			sx[i] = new float[scene.polys()[i].x().length];
			sy[i] = new float[scene.polys()[i].y().length];
		}
		gx = new float[scene.glints().length / 3];
		gy = new float[scene.glints().length / 3];

		boolean sky = isSkyKind(newKind);
		double halfH = scene.halfHeight();
		double halfSpan = Math.min(60.0, (scene.halfWidth() * 1.15 + 6.0) / Math.max(0.35, Math.cos(Math.toRadians(Math.max(0.0, Math.min(70.0, el))))));
		double top = Math.min(88.0, el + halfH * (sky ? 1.1 : 1.15));
		double bottom = sky ? Math.max(-3.0, el - halfH * 1.1) : -3.0;
		OCCLUSION.configure(az, halfSpan, top, bottom);
		active = true;
	}

	/** Gökyüzünde (ufuktan bağımsız, merkezi {@code el}'de) duran türler: sahne merkezden çizilir. Ufuk türlerinin tabanı {@code el}'dedir. */
	private static boolean isSkyKind(OmenKind k) {
		return k == OmenKind.SKY_AXE || k == OmenKind.WATCHER_EYE || k == OmenKind.SECOND_MOON || k == OmenKind.IMPOSSIBLE_RINGS;
	}

	/** Sunucudan ayrılınca / dünya kapanınca çağrılır. */
	public static void reset() {
		SunAnomalyEffect.reset();
		clear();
		messageStartMs = 0L;
	}

	private static void clear() {
		active = false;
		scene = null;
		levelRef = null;
		playerRef = null;
		sx = new float[0][];
		sy = new float[0][];
		gx = CLEAR;
		gy = CLEAR;
	}

	/** Sunucu "bitir" dedi (balta edinildi, boyut değişti...): yumuşakça sön. */
	private static void dismiss() {
		if (active) {
			long now = Util.getMillis();
			fadeOutMs = 1200L;
			vanishAtMs = now;
		}
	}

	/** Davranış: erken kaybolma talebi. Yalnızca daha erken bir zaman eskisinin yerine geçer. */
	private static void vanishNow(long now, long fadeMs) {
		if (vanishAtMs == 0L || now < vanishAtMs) {
			vanishAtMs = now;
			fadeOutMs = fadeMs;
		}
	}

	// ==================================================================
	// Kare
	// ==================================================================

	public static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		long now = Util.getMillis();
		SunAnomalyEffect.extract(graphics, deltaTracker, minecraft, now);
		if (active) {
			renderOmen(graphics, deltaTracker, minecraft, now);
		}
		drawMessage(graphics, minecraft, now);
	}

	private static void renderOmen(GuiGraphicsExtractor g, DeltaTracker deltaTracker, Minecraft minecraft, long now) {
		LocalPlayer player = minecraft.player;
		if (player == null || minecraft.level != levelRef || player != playerRef || !player.isAlive()) {
			clear(); // Boyut/dünya değişti, yeniden doğdu ya da öldü: yanlış yerde görüntü kalmaz.
			return;
		}
		long dtMs = Math.max(0L, Math.min(100L, now - lastFrameMs));
		lastFrameMs = now;
		long elapsed = now - startMs;
		timeSeconds = elapsed / 1000.0;

		long naturalVanish = startMs + durationMs - fadeOutMs;
		long vanishAbs = vanishAtMs > 0L ? Math.min(vanishAtMs, naturalVanish) : naturalVanish;
		double v = Math.max(0.0, Math.min(1.0, (now - vanishAbs) / (double) fadeOutMs));
		if (v >= 1.0) {
			clear();
			return;
		}
		double in = OmenLogic.smooth(elapsed / (double) fadeInMs);

		float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
		double yaw = player.getViewYRot(partial);
		double pitch = player.getViewXRot(partial);

		// Açık gökyüzü: kaybolursa (tavan, mağara) tezahür yumuşakça sönmeye başlar.
		if (now - lastSkyCheckMs >= 250L) {
			lastSkyCheckMs = now;
			if (minecraft.level.canSeeSky(player.blockPosition())) {
				noSkySinceMs = 0L;
			} else if (noSkySinceMs == 0L) {
				noSkySinceMs = now;
			} else if (now - noSkySinceMs > 1500L) {
				vanishNow(now, 1500L);
			}
		}

		OCCLUSION.update(minecraft.level, player.getEyePosition(), now);

		boolean sky = isSkyKind(kind);
		double centerEl = sky ? el : el + scene.halfHeight() * 0.5;
		double[] look = CallMoon.lookVector(yaw, pitch);
		double angle = OmenGeometry.angleDegrees(look, OmenGeometry.direction(az, centerEl));
		float open = OCCLUSION.openFraction(centerEl);

		// Ekran (envanter, menü) açıkken oyuncu görmüyor: fark etme sayılmaz, çizilmez. Zaman akmaya devam eder.
		if (minecraft.gui.screen() != null) {
			return;
		}
		behave(now, dtMs, v, in, angle, open, player);

		double alpha = in * styleAlpha(v) * toneFactor();
		if (alpha <= 0.012) {
			return;
		}
		double extent = Math.max(scene.halfWidth(), scene.halfHeight()) * 1.3 + 8.0;
		if (angle - extent > 78.0) {
			return; // Görüş alanının çok uzağında: çizime değmez.
		}

		double fov = minecraft.options.fov().get();
		int width = g.guiWidth();
		int height = g.guiHeight();
		prepareDynamics(v, dtMs, yaw, pitch, fov, width, height);
		mapScene(yaw, pitch, fov, width, height);
		buildClips(yaw, pitch, fov, width, height);

		int step = Math.max(2, Math.round(height / 240.0F));
		// Gökyüzünün Hafızası: Monolith belirdiğinde gökyüzü normalden çok az karanlık görünür (yalnızca bir varyantta).
		if (kind == OmenKind.MONOLITH && (OmenLogic.lowBits(variant) & 16) != 0) {
			int shade = (int) (alpha * 0.12 * 255.0);
			if (shade >= 2) {
				g.fillGradient(0, 0, width, (int) (height * 0.62), (shade << 24) | 0x02000A, 0x0002000A);
			}
		}
		OmenShapes.Poly[] polys = scene.polys();
		int edge = OmenCanvas.argb((float) (0.55 * alpha), 0x7A1633);
		for (int i = 0; i < polys.length; i++) {
			OmenShapes.Poly poly = polys[i];
			float a = (float) (OmenCanvas.baseAlpha(poly.style()) * poly.alpha() * alpha);
			if (a < 0.012F || offscreen(sx[i], sy[i], width, height)) {
				continue;
			}
			OmenCanvas.fillPoly(g, sx[i], sy[i], OmenCanvas.argb(a, OmenCanvas.rgb(poly.style(), tone)), step, width, height, clipTop, clipBottom);
			if (poly.outline()) {
				OmenCanvas.outline(g, sx[i], sy[i], edge, width, height, clipTop, clipBottom);
			}
		}
		float[] glints = scene.glints();
		for (int i = 0; i < gx.length; i++) {
			double pulse = 0.5 + 0.5 * Math.sin(timeSeconds * 1.1 + glints[i * 3 + 2]);
			float a = (float) (0.42 * alpha * pulse);
			if (a > 0.05F) {
				OmenCanvas.glint(g, Math.round(gx[i]), Math.round(gy[i]), 3, OmenCanvas.argb(a, 0xD6CCEE), width, height, clipTop, clipBottom);
			}
		}
	}

	private static boolean offscreen(float[] xs, float[] ys, int width, int height) {
		float minX = Float.MAX_VALUE;
		float maxX = -Float.MAX_VALUE;
		float minY = Float.MAX_VALUE;
		float maxY = -Float.MAX_VALUE;
		for (int i = 0; i < xs.length; i++) {
			minX = Math.min(minX, xs[i]);
			maxX = Math.max(maxX, xs[i]);
			minY = Math.min(minY, ys[i]);
			maxY = Math.max(maxY, ys[i]);
		}
		return maxX < 0 || minX > width || maxY < 0 || minY > height;
	}

	// ==================================================================
	// Davranış: fark etme, kaybolma biçimleri, hafif sarsıntı, mesaj
	// ==================================================================

	private static void behave(long now, long dtMs, double v, double in, double angle, float open, LocalPlayer player) {
		int low = OmenLogic.lowBits(variant);
		boolean visibleNow = in > 0.45 && v <= 0.01 && open > 0.3;
		switch (kind) {
			case SKY_AXE, WATCHER_EYE -> {
				double threshold = kind == OmenKind.SKY_AXE ? 38.0 : 24.0;
				if (!noticed) {
					dwellMs = visibleNow && angle < threshold ? dwellMs + dtMs : Math.max(0L, dwellMs - dtMs);
					if (dwellMs >= 450L) {
						noticed = true;
						if (kind == OmenKind.SKY_AXE) {
							// Fark etti: çok hafif ama hissedilir tek bir sarsıntı; ardından kısa bir bekleme ve kayboluş.
							ClientCameraShake.start(0.22F, 14);
							if ((flags & OmenLogic.FLAG_MESSAGE) != 0) {
								messageStartMs = now;
							}
							vanishNow(now + 2200L + (seed & 0x3FF), fadeOutMs);
						} else {
							vanishNow(now + 4200L + (seed & 0x7FF) * 2L, fadeOutMs);
						}
					}
				} else if (kind == OmenKind.WATCHER_EYE && (low & 2) != 0) {
					// "Tekrar baktığında kaybolmuş olabilir": bakışı kaçırıp geri dönmeden yok olur.
					awayMs = angle > 55.0 ? awayMs + dtMs : 0L;
					if (awayMs >= 1400L) {
						vanishNow(now, 900L);
					}
				}
			}
			case SECOND_MOON, IMPOSSIBLE_RINGS -> {
				// Gökte sakin durur: fark edilmesine bağlı bir tepkisi yoktur; süresi dolunca (ya da gökyüzü kapanınca) çekilir.
			}
			case MONOLITH -> behaveMonolith(now, player, low);
			default -> behaveHorizon(now, dtMs, v, angle, open, player, low);
		}
	}

	/**
	 * Monolith hiçbir gerçek konumda değildir: oyuncu ona yürüyünce MESAFESİNİ KORUR (sabit yönlü, paralaksız çizim bunu doğal olarak sağlar).
	 * Yaklaştıkça perspektif belli belirsiz bozulmaya başlar (sezdirir); yeterince yaklaşınca ya da uzağa yürüyünce söner. Oyuncuyu
	 * sonsuza dek yürümeye zorlamaz: sınırlar {@link com.battleaxe.call.OmenConfig} içindedir.
	 */
	private static void behaveMonolith(long now, LocalPlayer player, int low) {
		double dx = player.getX() - startX;
		double dz = player.getZ() - startZ;
		double[] dir = OmenGeometry.direction(az, 0.0);
		double approach = dx * dir[0] + dz * dir[2];
		double travelled = Math.sqrt(dx * dx + dz * dz);
		double warpStart = OmenConfig.MONOLITH_WARP_APPROACH_BLOCKS;
		double vanish = OmenConfig.MONOLITH_VANISH_APPROACH_BLOCKS;
		approachWarp = Math.max(0.0, Math.min(1.0, OmenLogic.smooth((approach - warpStart) / Math.max(1.0, vanish - warpStart))));
		if (vanishAtMs == 0L && (approach >= vanish || travelled >= OmenConfig.MONOLITH_VANISH_TRAVEL_BLOCKS)) {
			int style = (low >> 2) & 3;
			vanishNow(now, style == 2 ? 6500L : style == 1 ? 4200L : 5000L);
		}
	}

	private static void behaveHorizon(long now, long dtMs, double v, double angle, float open, LocalPlayer player, int low) {
		boolean colossus = kind == OmenKind.HORIZON_COLOSSUS;
		int mode = (low >> 2) & 3;
		double dx = player.getX() - startX;
		double dz = player.getZ() - startZ;
		double[] dir = OmenGeometry.direction(az, 0.0);
		double approach = dx * dir[0] + dz * dir[2];
		double travelled = Math.sqrt(dx * dx + dz * dz);

		// Yaklaşınca gerçek bir konumda olmadığı anlaşılır: söner, batar ya da perspektifi bozulur.
		if (vanishAtMs == 0L && (approach >= (colossus ? 45.0 : 40.0) || travelled >= 130.0)) {
			vanishNow(now, colossus ? 3500L : 4200L);
		}
		// Bakış kaçınca kaybolma (Dev, mod 2): bir kez görüldükten sonra 2.5 sn başka yöne bakılırsa.
		if (colossus && mode == 2) {
			if (angle < 30.0 && open > 0.3) {
				dwellMs += dtMs;
				if (dwellMs >= 1000L) {
					seenOnce = true;
				}
			}
			awayMs = seenOnce && angle > 70.0 ? awayMs + dtMs : 0L;
			if (awayMs >= 2500L) {
				vanishNow(now, 1800L);
			}
		}
		// Çok hafif, tek seferlik alçak titreme (yalnızca sunucunun işaretlediği bazı Dev'lerde).
		if (colossus && (flags & OmenLogic.FLAG_TREMOR) != 0 && !tremorDone && angle < 26.0 && open > 0.3) {
			tremorMs += dtMs;
			if (tremorMs >= 800L) {
				tremorDone = true;
				ClientCameraShake.start(0.07F, 36);
			}
		}
	}

	/** Kaybolma biçiminin saydamlık çarpanı (0..1). */
	private static double styleAlpha(double v) {
		int low = OmenLogic.lowBits(variant);
		double fade = 1.0 - OmenLogic.smooth(v);
		switch (kind) {
			case SKY_AXE -> {
				if ((low & 3) == 1 && v > 0.1) {
					return fade * (0.62 + 0.38 * Math.sin(v * 34.0 + seed)); // kararsız sönme
				}
				return fade;
			}
			case HORIZON_COLOSSUS -> {
				if (((low >> 2) & 3) == 1) {
					return 1.0 - OmenLogic.smooth((v - 0.55) / 0.45); // arazi arkasına batarken geç söner
				}
				return fade;
			}
			case SECOND_MOON, IMPOSSIBLE_RINGS -> {
				int vanishStyle = (low >> 5) & 3;
				if (vanishStyle == 1) {
					return 1.0 - OmenLogic.smooth((v - 0.35) / 0.65); // karanlığa gömülme
				}
				if (vanishStyle == 2) {
					return 1.0 - OmenLogic.smooth((v - 0.55) / 0.45); // ufka batarken geç söner
				}
				return fade;
			}
			case MONOLITH -> {
				int vanishStyle = (low >> 2) & 3;
				if (vanishStyle == 2) {
					return 1.0 - OmenLogic.smooth((v - 0.25) / 0.75); // sisin içinde silinir
				}
				if (vanishStyle == 1) {
					return 1.0 - OmenLogic.smooth((v - 0.6) / 0.4); // perspektifi bozulurken geç söner
				}
				return fade;
			}
			default -> {
				if (((low >> 2) & 3) == 2) {
					return 1.0 - OmenLogic.smooth((v - 0.35) / 0.65); // karanlığa batma
				}
				return fade;
			}
		}
	}

	private static double toneFactor() {
		if (kind == OmenKind.MONOLITH) {
			// Gündüz, parlak gökyüzünün karşısında simsiyah bir levha, geceden DAHA rahatsız edicidir: gündüz neredeyse tam görünür.
			return switch (tone) {
				case OmenLogic.TONE_NIGHT -> 1.0;
				case OmenLogic.TONE_TWILIGHT -> 0.94;
				default -> 0.97;
			};
		}
		return switch (tone) {
			case OmenLogic.TONE_NIGHT -> 1.0;
			case OmenLogic.TONE_TWILIGHT -> 0.82;
			default -> 0.62;
		};
	}

	/** Kaybolma ilerledikçe değişen geometri parametreleri: batma, perspektif bozulması, bakış takibi. */
	private static void prepareDynamics(double v, long dtMs, double yaw, double pitch, double fov, int width, int height) {
		int low = OmenLogic.lowBits(variant);
		sinkDeg = 0.0;
		warp = 0.0;
		switch (kind) {
			case SKY_AXE -> {
				if ((low & 3) == 2) {
					sinkDeg = -v * 6.0;
				}
			}
			case HORIZON_COLOSSUS -> {
				// Bit 5: yalnızca başları ufkun üstünde görünür (gövde arazinin/ufkun arkasında kalır).
				double headsOnly = (low & 32) != 0 ? -0.40 * scene.halfHeight() : 0.0;
				sinkDeg = headsOnly;
				if (((low >> 2) & 3) == 1) {
					sinkDeg -= v * (scene.halfHeight() + 4.0);
				}
			}
			case SECOND_MOON -> {
				if (((low >> 5) & 3) == 2) {
					sinkDeg = -v * (el + scene.halfHeight() + 6.0); // ufka batar; arazi örtüsü alt kısmı gizler
				}
			}
			case IMPOSSIBLE_RINGS -> {
				// Çok yavaş, yönü belli olmayan dönüş (bazı karşılaşmalarda hiç dönmez). Başta yumuşak başlar.
				int motion = low & 3;
				double rate = motion == 1 ? 0.55 : motion == 2 ? -0.45 : 0.0;
				ringRot = rate * timeSeconds * OmenLogic.smooth(timeSeconds / 20.0);
				if (((low >> 5) & 3) == 2) {
					sinkDeg = -v * (el + scene.halfHeight() + 6.0);
				}
				if ((low & 4) != 0) {
					trackIris(dtMs, yaw, pitch, fov, width, height); // Hafıza: merkezdeki gözün bebeği oyuncuyu çok yavaş izler
				}
			}
			case MONOLITH -> {
				int vanishStyle = (low >> 2) & 3;
				warp = Math.max(approachWarp * 0.7, vanishStyle == 1 ? OmenLogic.smooth(v) : 0.0);
				if (vanishStyle == 2) {
					sinkDeg = -v * 6.0; // sisin içinde taban hafifçe çöker
				}
			}
			case IMPOSSIBLE_STRUCTURE -> {
				int vanishMode = (low >> 2) & 3;
				if (vanishMode == 1) {
					warp = OmenLogic.smooth(v);
				} else if (vanishMode == 2) {
					sinkDeg = -v * 10.0;
				}
			}
			case WATCHER_EYE -> trackIris(dtMs, yaw, pitch, fov, width, height);
			default -> {
			}
		}
	}

	/** Göz bebeği, oyuncunun bakışını çok yavaş ve belli belirsiz izler. */
	private static void trackIris(long dtMs, double yaw, double pitch, double fov, int width, int height) {
		double[] c = OmenGeometry.projectClamped(OmenGeometry.direction(az, el), yaw, pitch, fov, width, height);
		double tx = Math.max(-1.4, Math.min(1.4, (width / 2.0 - c[0]) / width * 2.8));
		double ty = Math.max(-0.9, Math.min(0.9, -(height / 2.0 - c[1]) / height * 1.6));
		double k = Math.min(1.0, dtMs / 2500.0);
		irisX += (tx - irisX) * k;
		irisY += (ty - irisY) * k;
	}

	// ==================================================================
	// İzdüşüm ve örtü
	// ==================================================================

	private static void mapScene(double yaw, double pitch, double fov, int width, int height) {
		OmenShapes.Poly[] polys = scene.polys();
		for (int i = 0; i < polys.length; i++) {
			OmenShapes.Poly poly = polys[i];
			float[] px = poly.x();
			float[] py = poly.y();
			for (int k = 0; k < px.length; k++) {
				map(px[k], py[k], poly.group() == 1, yaw, pitch, fov, width, height);
				sx[i][k] = (float) POINT[0];
				sy[i][k] = (float) POINT[1];
			}
		}
		float[] glints = scene.glints();
		for (int i = 0; i < gx.length; i++) {
			map(glints[i * 3], glints[i * 3 + 1], false, yaw, pitch, fov, width, height);
			gx[i] = (float) POINT[0];
			gy[i] = (float) POINT[1];
		}
	}

	private static void map(double dx, double dy, boolean iris, double yaw, double pitch, double fov, int width, int height) {
		if (iris) {
			dx += irisX;
			dy += irisY;
		} else if (ringRot != 0.0 && kind == OmenKind.IMPOSSIBLE_RINGS) {
			double rad = Math.toRadians(ringRot);
			double c = Math.cos(rad);
			double sn = Math.sin(rad);
			double rx = dx * c - dy * sn;
			dy = dx * sn + dy * c;
			dx = rx;
		}
		if (warp > 0.0) {
			double oy = dy;
			dx += warp * (0.22 * oy + 2.0 * Math.sin(oy * 0.3 + timeSeconds * 0.7));
			dy = oy * (1.0 + 0.35 * warp);
		}
		dy += sinkDeg;
		double[] p = OmenGeometry.projectClamped(OmenGeometry.vertexDirection(az, el, dx, dy), yaw, pitch, fov, width, height);
		POINT[0] = p[0];
		POINT[1] = p[1];
	}

	/** Arazi (dünya-sabit ışın ölçümü) ve bulut/karanlık örtüsünden ekran sütunu başına görünürlük sınırları. */
	private static void buildClips(double yaw, double pitch, double fov, int width, int height) {
		int chunks = width / OmenCanvas.CHUNK + 2;
		if (clipTop.length != chunks) {
			clipTop = new int[chunks];
			clipBottom = new int[chunks];
		}
		java.util.Arrays.fill(clipTop, -1_000_000);
		java.util.Arrays.fill(clipBottom, 1_000_000);

		// Arazi: her yön sütunu için engel yüksekliğini ekrana izdüşür; arası doğrusal.
		double prevX = 0.0;
		double prevY = 0.0;
		boolean prevOk = false;
		for (int i = 0; i <= OmenOcclusion.COLUMNS; i++) {
			float t = OCCLUSION.terrainAt(i);
			double e = t <= OmenOcclusion.NONE ? -25.0 : Math.max(-88.0, t);
			double[] p = OmenGeometry.projectClamped(OmenGeometry.direction(OCCLUSION.azimuthAt(i), e), yaw, pitch, fov, width, height);
			boolean ok = p[3] > 0.5;
			if (ok && prevOk) {
				applyBottomSegment(prevX, prevY, p[0], p[1], chunks);
			}
			prevX = p[0];
			prevY = p[1];
			prevOk = ok;
		}

		// Bulut/karanlık örtüsü: yalnızca Balta ve Göz'de, kenarı pürüzlü bir çizgiyle ikiye bölünmüş görünüm.
		int level = OmenLogic.coverLevel(variant);
		if (level > 0 && (kind == OmenKind.SKY_AXE || kind == OmenKind.WATCHER_EYE)) {
			float top = Float.MAX_VALUE;
			float bottom = -Float.MAX_VALUE;
			OmenShapes.Poly[] polys = scene.polys();
			for (int i = 0; i < polys.length; i++) {
				if (polys[i].style() == OmenShapes.S_AURA) {
					continue;
				}
				for (float y : sy[i]) {
					top = Math.min(top, y);
					bottom = Math.max(bottom, y);
				}
			}
			float span = Math.max(8.0F, bottom - top);
			float fraction = 0.15F * level;
			boolean fromTop = OmenLogic.coverFromTop(variant);
			for (int c = 0; c < chunks; c++) {
				double noise = 0.25 * Math.sin(c * 0.45 + seed) + 0.15 * Math.sin(c * 0.17 + seed * 1.7);
				float line = (float) ((fromTop ? top + span * fraction * (1.0 + noise) : bottom - span * fraction * (1.0 + noise)));
				if (fromTop) {
					clipTop[c] = Math.max(clipTop[c], (int) line);
				} else {
					clipBottom[c] = Math.min(clipBottom[c], (int) line);
				}
			}
		}
	}

	private static void applyBottomSegment(double x0, double y0, double x1, double y1, int chunks) {
		double lo = Math.min(x0, x1);
		double hi = Math.max(x0, x1);
		int c0 = Math.max(0, (int) Math.floor(lo / OmenCanvas.CHUNK));
		int c1 = Math.min(chunks - 1, (int) Math.ceil(hi / OmenCanvas.CHUNK));
		for (int c = c0; c <= c1; c++) {
			double xc = c * OmenCanvas.CHUNK + OmenCanvas.CHUNK / 2.0;
			double t = x1 == x0 ? 0.0 : Math.max(0.0, Math.min(1.0, (xc - x0) / (x1 - x0)));
			double y = Math.max(-1_000_000.0, Math.min(1_000_000.0, y0 + t * (y1 - y0)));
			clipBottom[c] = Math.min(clipBottom[c], (int) y);
		}
	}

	// ==================================================================
	// "YILDIZI BUL!"
	// ==================================================================

	/**
	 * Tek, sessiz bir mesaj: sesli vurgu, başlık süresi ya da boss bar yok; etkisi görüntüden ve bağlamdan gelir.
	 * Yalnızca balta tezahürü fark edilince (ve sunucu mesajı onayladıysa) bir kez gösterilir.
	 */
	private static void drawMessage(GuiGraphicsExtractor g, Minecraft minecraft, long now) {
		if (messageStartMs == 0L) {
			return;
		}
		long t = now - messageStartMs;
		if (t >= MESSAGE_TOTAL_MS) {
			messageStartMs = 0L;
			return;
		}
		if (minecraft.player == null || !minecraft.player.isAlive() || minecraft.gui.screen() != null) {
			return;
		}
		double a = OmenLogic.smooth(t / 900.0) * OmenLogic.smooth((MESSAGE_TOTAL_MS - t) / 1500.0);
		int alpha = (int) (a * 232.0);
		if (alpha < 8) {
			return;
		}
		Font font = minecraft.font;
		String text = Component.translatable("call.omen.find_star").getString();
		int textWidth = font.width(text);
		float scale = 2.6F;
		int width = g.guiWidth();
		int height = g.guiHeight();
		float cx = width / 2.0F;
		float cy = height * 0.27F;

		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		pose.translate(cx, cy);
		pose.scale(scale, scale);
		g.text(font, text, -textWidth / 2, 0, (alpha << 24) | 0xD9C8E4, true);
		pose.popMatrix();

		// İnce kızıl çizgi: yazının altında yavaşça açılır.
		int half = (int) (textWidth * scale / 2.0F * OmenLogic.smooth(t / 1600.0));
		int lineY = (int) (cy + (font.lineHeight + 3) * scale);
		g.fill((int) cx - half, lineY, (int) cx + half, lineY + 1, ((int) (a * 150.0) << 24) | 0x7A1633);
	}
}
