package com.battleaxe.client;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.item.ModItems;
import com.battleaxe.yargec.YarGec;
import com.battleaxe.yargec.YarGecConfig;
import com.battleaxe.yargec.YarGecLogic;

/**
 * "Yar Geç" şarjı sürerken nişangahın altında beliren küçük şarj çubuğu.
 * Durum üretmez: oyuncunun vanilla "eşya kullanma" süresini okuyup çizer.
 */
public final class YarGecChargeHud {
	private YarGecChargeHud() {
	}

	private static final int WIDTH = 62;
	private static final int HEIGHT = 6;
	private static final int OFFSET_BELOW_CROSSHAIR = 16;

	private static final int LOW_COLOR = 0xFFB347;
	private static final int MID_COLOR = 0xFF3A2A;
	private static final int MAX_COLOR = 0xC080FF;

	public static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || !player.isUsingItem()) {
			return;
		}

		ItemStack stack = player.getUseItem();
		if (!stack.is(ModItems.BATTLE_AXE) || !YarGec.has(stack, player.level())) {
			return;
		}

		float usedTicks = player.getTicksUsingItem() + deltaTracker.getGameTimeDeltaPartialTick(false);
		float ratio = YarGecLogic.chargeRatio(usedTicks);
		int tier = YarGecLogic.tier(ratio);

		int color = tier >= 3 ? MAX_COLOR : tier == 2 ? MID_COLOR : LOW_COLOR;
		if (tier >= 3) {
			// Tam şarjda hafifçe parlayıp söner: "hazır" göstergesi.
			float pulse = 0.5F + 0.5F * Mth.sin((Util.getMillis() % 100_000L) * 0.02F);
			color = blend(MAX_COLOR, 0xFFFFFF, pulse * 0.6F);
		}

		int x = graphics.guiWidth() / 2 - WIDTH / 2;
		int y = graphics.guiHeight() / 2 + OFFSET_BELOW_CROSSHAIR;

		graphics.fill(x, y, x + WIDTH, y + HEIGHT, 0xC0101010);
		int innerWidth = WIDTH - 2;
		int filled = (int) (innerWidth * ratio);
		if (filled > 0) {
			graphics.fill(x + 1, y + 1, x + 1 + filled, y + HEIGHT - 1, 0xFF000000 | color);
		}
		// Orta seviyenin başladığı yeri gösteren ince çentik.
		int notch = x + 1 + (int) (innerWidth * YarGecConfig.TIER_2_RATIO);
		graphics.fill(notch, y, notch + 1, y + HEIGHT, 0x90FFFFFF);
		graphics.outline(x, y, WIDTH, HEIGHT, tier >= 3 ? 0xFFFFFFFF : 0xFF606060);
	}

	private static int blend(int from, int to, float t) {
		int r = (int) Mth.lerp(t, (from >> 16) & 0xFF, (to >> 16) & 0xFF);
		int g = (int) Mth.lerp(t, (from >> 8) & 0xFF, (to >> 8) & 0xFF);
		int b = (int) Mth.lerp(t, from & 0xFF, to & 0xFF);
		return (r << 16) | (g << 8) | b;
	}
}
