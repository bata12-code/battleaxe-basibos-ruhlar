package com.battleaxe.client;

import net.minecraft.util.Util;

import com.battleaxe.chain.ChainConfig;
import com.battleaxe.chain.ChainLogic;

/**
 * İstemcide, sunucunun bildirdiği Kıyım Zinciri durumu (yalnızca HUD için; gerçek bonuslar sunucudadır).
 * Yalnızca ZAMAN DAMGALARINI tutar: kalan süre ve tüm animasyonlar çizim sırasında {@code now - damga}'dan hesaplanır
 * ({@link com.battleaxe.chain.ChainHudMath}); bu yüzden ayrı bir animasyon durum makinesi yoktur.
 */
public final class ClientChainState {
	private ClientChainState() {
	}

	/** "Hiç olmadı" damgası: şimdiden çok uzak geçmiş (taşmadan), hiçbir animasyon süresine girmez. */
	private static final long NEVER = Long.MIN_VALUE / 4;
	/** Sunucudan makul olmayan kalan süre gelirse (veri bozulması) kırpılır: en uzun pencerenin iki katı. */
	private static final int MAX_REMAINING_TICKS = ChainLogic.windowFor(ChainLogic.MAX_TIER) * 2;

	private static int count;
	private static int tier;
	private static int windowTicks;
	private static long expiresAtMillis = NEVER;
	private static long killAtMillis = NEVER;
	private static long tierUpAtMillis = NEVER;

	private static int brokenCount;
	private static int brokenTier;
	private static long brokenAtMillis = NEVER;

	/** Sunucudan paket geldiğinde çağrılır. {@code newCount == 0} zincirin koptuğunu bildirir. */
	public static void apply(int newCount, int remainingTicks) {
		long now = Util.getMillis();
		if (newCount <= 0) {
			if (count > 0) {
				brokenCount = count;
				brokenTier = tier;
				brokenAtMillis = now;
			}
			count = 0;
			tier = 0;
			return;
		}
		int clamped = Math.min(newCount, ChainConfig.MAX_COUNT);
		int newTier = ChainLogic.tierOf(clamped);
		if (clamped > count) {
			killAtMillis = now;
		}
		if (newTier > tier) {
			tierUpAtMillis = now;
		}
		count = clamped;
		tier = newTier;
		windowTicks = ChainLogic.windowFor(newTier);
		expiresAtMillis = now + Math.max(0, Math.min(MAX_REMAINING_TICKS, remainingTicks)) * 50L;
	}

	/**
	 * Süre dolduktan sonra sunucudan kopma paketi gelmezse (ör. oyuncu öldü, bağlantı değişti) zinciri sessizce siler.
	 * Normalde sunucu kopma paketini en geç bir iki tick içinde yollar; {@code graceMs} bunu fazlasıyla karşılar.
	 */
	public static void expireIfStale(long now, long graceMs) {
		if (count > 0 && now > expiresAtMillis + graceMs) {
			count = 0;
			tier = 0;
		}
	}

	public static int count() {
		return count;
	}

	public static int tier() {
		return tier;
	}

	public static int windowTicks() {
		return windowTicks;
	}

	public static int brokenCount() {
		return brokenCount;
	}

	public static int brokenTier() {
		return brokenTier;
	}

	public static long remainingMillis(long now) {
		return Math.max(0L, expiresAtMillis - now);
	}

	public static long sinceKill(long now) {
		return now - killAtMillis;
	}

	public static long sinceTierUp(long now) {
		return now - tierUpAtMillis;
	}

	public static long sinceBroken(long now) {
		return now - brokenAtMillis;
	}

	/** Oyuncu öldüğünde / sunucudan ayrılınca çağrılır. */
	public static void reset() {
		count = 0;
		tier = 0;
		windowTicks = 0;
		expiresAtMillis = NEVER;
		killAtMillis = NEVER;
		tierUpAtMillis = NEVER;
		brokenCount = 0;
		brokenTier = 0;
		brokenAtMillis = NEVER;
	}
}
