package com.battleaxe.client.call;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.call.OmenGeometry;

/**
 * Bir tezahürün bulunduğu yön aralığında ARAZİ/ağaç/yapı örtüsünü ölçer: her yön sütunu için, yukarıdan aşağıya inen
 * ışının ilk engele çarptığı yükseklik açısı (o açının altı örtülüdür). Dünya-sabitlidir (kameradan bağımsız), bu yüzden
 * önbelleğe alınır ve kare başına YALNIZCA BİR sütun yenilenir (ilk geçişte birkaç sütun): kare başı yük çok küçüktür.
 * Oyuncu birkaç blok hareket edince ya da birkaç saniyede bir geçiş yeniden başlar.
 *
 * <p>Yüklü olmayan parçalar hava sayılır (siluet o bölgede örtülmez). Hiçbir blok/varlık değiştirilmez; yalnızca okunur.
 */
final class OmenOcclusion {
	static final int COLUMNS = 24;
	/** "Bu sütunda engel yok". */
	static final float NONE = -90.0F;

	private static final double RAY_START = 2.0;
	private static final double RAY_GROWTH = 1.12;
	private static final double RAY_RANGE = 160.0;
	private static final double SCAN_STEP_DEGREES = 2.5;
	/** Sınırı hassaslaştıran ikiye bölme adımı sayısı (2,5 / 2^6 ≈ 0,04 derece). */
	private static final int REFINE_STEPS = 6;
	private static final double RESAMPLE_MOVE_SQ = 25.0;
	private static final long RESAMPLE_MILLIS = 6000L;

	private final float[] terrain = new float[COLUMNS + 1];
	private double az0;
	private double az1;
	private double elTop;
	private double elBottom;
	private double sampleX;
	private double sampleY;
	private double sampleZ;
	private boolean sampled;
	private long lastPassMillis;
	private int cursor = COLUMNS + 1;
	private boolean firstPass;

	void configure(double azimuthCenter, double azimuthHalfSpan, double elevationTop, double elevationBottom) {
		this.az0 = azimuthCenter - azimuthHalfSpan;
		this.az1 = azimuthCenter + azimuthHalfSpan;
		this.elTop = elevationTop;
		this.elBottom = elevationBottom;
		java.util.Arrays.fill(terrain, NONE);
		this.sampled = false;
		this.cursor = COLUMNS + 1;
		this.firstPass = true;
	}

	double azimuthAt(int column) {
		return az0 + (az1 - az0) * column / COLUMNS;
	}

	float terrainAt(int column) {
		return terrain[column];
	}

	/** Her karede çağrılır. */
	void update(Level level, Vec3 eye, long nowMillis) {
		boolean moved = sampled && distSq(eye) > RESAMPLE_MOVE_SQ;
		if (!sampled || moved || nowMillis - lastPassMillis > RESAMPLE_MILLIS) {
			sampled = true;
			sampleX = eye.x;
			sampleY = eye.y;
			sampleZ = eye.z;
			lastPassMillis = nowMillis;
			cursor = 0;
		}
		int budget = firstPass ? 6 : 1;
		while (budget-- > 0 && cursor <= COLUMNS) {
			terrain[cursor] = scanColumn(level, eye, azimuthAt(cursor));
			cursor++;
		}
		if (cursor > COLUMNS) {
			firstPass = false;
		}
	}

	private double distSq(Vec3 eye) {
		double dx = eye.x - sampleX;
		double dy = eye.y - sampleY;
		double dz = eye.z - sampleZ;
		return dx * dx + dy * dy + dz * dz;
	}

	/**
	 * Yukarıdan aşağıya: ilk engelli ışının hemen üstündeki açı; engel yoksa {@link #NONE}. Kaba adımla ({@link #SCAN_STEP_DEGREES}) engelli
	 * bir ışın bulunca, ikiye bölme (bisection) ile gerçek sınır ~0,04 dereceye kadar hassaslaştırılır. Bu, DÜZ ARAZİDE ufuk çizgisinin
	 * (göz hizasından yalnızca yaklaşık yarım derece aşağıdaki) doğru bulunmasını sağlar: eskiden ±1,25 derece hata vardı ve ufuktaki
	 * devasa figürlerin tabanı yakın zemin üzerine biniyordu.
	 */
	private float scanColumn(Level level, Vec3 eye, double azimuth) {
		for (double el = elTop; el >= elBottom; el -= SCAN_STEP_DEGREES) {
			if (blocked(level, eye, azimuth, el)) {
				double lo = el; // engelli
				double hi = Math.min(elTop, el + SCAN_STEP_DEGREES); // bir önceki (engelsiz) örnek ya da tavan
				if (hi <= lo) {
					return (float) lo;
				}
				for (int i = 0; i < REFINE_STEPS; i++) {
					double mid = (lo + hi) * 0.5;
					if (blocked(level, eye, azimuth, mid)) {
						lo = mid;
					} else {
						hi = mid;
					}
				}
				return (float) hi;
			}
		}
		return NONE;
	}

	private static boolean blocked(Level level, Vec3 eye, double azimuth, double elevation) {
		double[] d = OmenGeometry.direction(azimuth, elevation);
		for (double dist = RAY_START; dist <= RAY_RANGE; dist *= RAY_GROWTH) {
			BlockPos pos = BlockPos.containing(eye.x + d[0] * dist, eye.y + d[1] * dist, eye.z + d[2] * dist);
			if (!level.getBlockState(pos).isAir()) {
				return true;
			}
		}
		return false;
	}

	/** Merkez yükseklikte engelsiz sütunların oranı (0..1): "tezahür gerçekten görünüyor mu?". */
	float openFraction(double centerElevation) {
		int open = 0;
		for (int i = 0; i <= COLUMNS; i++) {
			if (terrain[i] < centerElevation - 2.0) {
				open++;
			}
		}
		return open / (float) (COLUMNS + 1);
	}
}
