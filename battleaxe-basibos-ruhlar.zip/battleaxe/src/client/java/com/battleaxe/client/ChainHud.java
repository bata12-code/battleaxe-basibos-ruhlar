package com.battleaxe.client;

import org.joml.Matrix3x2fStack;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

import com.battleaxe.chain.ChainHudMath;
import com.battleaxe.chain.ChainLogic;

/**
 * <b>Kıyım Zinciri</b> HUD'ı (istemci, yalnızca çizim). Sürekli görünen kısım bilerek MİNİMALDİR (göz yormasın):
 * nişangâhın sağında ince bir geri sayan süre çubuğu, yanında küçük bir kombo sayacı ve çubuğun üstünde 4 minik kademe noktası.
 * Koyu kutu, kademe adı yazısı ve büyük sayı yoktur.
 *
 * <p>Yazı yalnızca ANLARDA görünür: kademe atlayınca kısa, küçük bir başlık belirir ve söner. Kalıcı gösterge, son öldürmeden
 * {@link ChainHudMath#IDLE_HOLD_MS} sonra yarı saydamlığa iner; yeni öldürmede, süre azalırken ve kademe atlarken yeniden
 * parlar. Zincir kopunca ince çubuk küçük kırıklara ayrılıp düşer.
 *
 * <p>Durum üretmez; yalnızca {@link ClientChainState}'in zaman damgalarını okur, tüm animasyonlar {@link ChainHudMath}'tandır
 * (saf, test edilir). Mod kurulu olmayan istemcilerde sunucu yazıyı aksiyon çubuğundan gösterir.
 */
public final class ChainHud {
	private ChainHud() {
	}

	/** Kademe atlarken ekran kenarlarındaki çok hafif renkli ışımayı kapatmak için false yap; gösterge kalır. */
	public static final boolean SCREEN_FX_ENABLED = true;

	/** Kademe 0..4 renkleri (soluk gümüş, turuncu, kırmızı, mor, altın). */
	private static final int[] TIER_RGB = {0xB8B8C0, 0xFF9A2E, 0xFF3B3B, 0xC060FF, 0xFFE070};

	/** Çubuğun nişangâha göre yeri (ekran ortasından sağa/yukarı). Yar Geç çubuğu aşağıda olduğundan çakışmaz. */
	private static final int OFFSET_X = 18;
	private static final int OFFSET_Y = -2;
	private static final int BAR_W = 38;
	private static final int BAR_H = 3;
	/** Çubuğun üstündeki (noktalar) ve altındaki (ilerleme çizgisi) boşluk; kutunun toplam yüksekliğini belirler. */
	private static final int TOP_PAD = 6;
	private static final int BOTTOM_PAD = 5;
	private static final int COUNT_GAP = 5;
	private static final int PIP = 2;
	private static final int PIP_STEP = 4;
	private static final long STALE_GRACE_MS = 1500L;

	public static void extract(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || !player.isAlive()) {
			ClientChainState.reset();
			return;
		}
		long now = Util.getMillis();
		ClientChainState.expireIfStale(now, STALE_GRACE_MS);
		Font font = minecraft.font;

		int count = ClientChainState.count();
		int tier = ClientChainState.tier();
		long sinceTierUp = ClientChainState.sinceTierUp(now);

		if (SCREEN_FX_ENABLED) {
			edgeGlow(g, tier, sinceTierUp);
		}
		if (count > 0) {
			gauge(g, font, now, count, tier, sinceTierUp);
		}
		long sinceBroken = ClientChainState.sinceBroken(now);
		if (sinceBroken >= 0L && sinceBroken < ChainHudMath.SHATTER_MS) {
			shatter(g, font, sinceBroken);
		}
		if (count > 0 && sinceTierUp >= 0L && sinceTierUp < ChainHudMath.BANNER_MS) {
			banner(g, font, count, tier, sinceTierUp);
		}
	}

	/** Göstergenin yeri ve boyutu: {sol, üst, genişlik, yükseklik}. Çubuk {@code üst + TOP_PAD} satırındadır. */
	private static int[] layout(GuiGraphicsExtractor g, Font font, int count) {
		String countText = Component.translatable("hud.battleaxe.chain.count", count).getString();
		int countWidth = (int) (font.width(countText) * ChainHudMath.PULSE_PEAK);
		int width = BAR_W + COUNT_GAP + countWidth;
		int height = TOP_PAD + BAR_H + BOTTOM_PAD;
		int left = Math.min(g.guiWidth() / 2 + OFFSET_X, g.guiWidth() - width - 4);
		int top = g.guiHeight() / 2 + OFFSET_Y - TOP_PAD;
		return new int[] {left, top, width, height};
	}

	private static void gauge(GuiGraphicsExtractor g, Font font, long now, int count, int tier, long sinceTierUp) {
		int rgb = TIER_RGB[Mth.clamp(tier, 0, ChainLogic.MAX_TIER)];
		String countText = Component.translatable("hud.battleaxe.chain.count", count).getString();

		float pulse = ChainHudMath.killPulse(ClientChainState.sinceKill(now));
		float ratio = ChainHudMath.barRatio(ClientChainState.remainingMillis(now), ClientChainState.windowTicks());
		float flash = ChainHudMath.lowTimeFlash(now, ratio);
		// Genel saydamlık: boştayken geri çekilir, olay anlarında parlar (göz yormaz).
		float a = ChainHudMath.hudAlpha(ClientChainState.sinceKill(now), ratio, sinceTierUp);

		int[] box = layout(g, font, count);
		int x = box[0];
		int barY = box[1] + TOP_PAD;

		// Kademe atlama çerçevesi: göstergeden dışa doğru kısa süre yayılıp söner.
		float glow = ChainHudMath.tierUpGlow(sinceTierUp);
		if (glow > 0.0F) {
			int e = (int) (8.0F * (1.0F - glow)) + 1;
			g.outline(x - e, box[1] - e, box[2] + e * 2, box[3] + e * 2, argb((int) (170.0F * glow), rgb));
		}

		// İnce süre çubuğu: koyu 1 piksellik zemin, dolu kısım kademe renginde; süre azalınca beyaza doğru nabız atar.
		g.fill(x - 1, barY - 1, x + BAR_W + 1, barY + BAR_H + 1, argb(scale(0xB0, a), 0x050508));
		int fill = (int) (BAR_W * ratio);
		if (fill > 0) {
			g.fill(x, barY, x + fill, barY + BAR_H, argb(scale(255, a), blend(rgb, 0xFFFFFF, flash * 0.7F)));
		}

		// Sonraki kademeye ilerleme: çubuğun altında 1 piksellik ince çizgi.
		int py = barY + BAR_H + 2;
		g.fill(x, py, x + BAR_W, py + 1, argb(scale(0x60, a), 0x303038));
		int progress = (int) (BAR_W * ChainLogic.tierProgress(count));
		if (progress > 0) {
			g.fill(x, py, x + progress, py + 1, argb(scale(0xD0, a), rgb));
		}

		// Minik kademe noktaları (çubuğun üstünde, sola dayalı): ulaşılan kademeler dolu.
		for (int i = 0; i < ChainLogic.MAX_TIER; i++) {
			boolean reached = tier >= i + 1;
			int x0 = x + i * PIP_STEP;
			int y0 = barY - 4;
			g.fill(x0, y0, x0 + PIP, y0 + PIP, argb(scale(reached ? 255 : 90, a), reached ? rgb : 0x505058));
		}

		// Kombo sayacı: çubuğun sağında normal boyutta küçük sayı; öldürmede kısa "vurur".
		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		pose.translate(x + BAR_W + COUNT_GAP, barY + 1);
		pose.scale(pulse, pulse);
		g.text(font, countText, 0, -(font.lineHeight / 2), argb(scale(255, a), rgb), true);
		pose.popMatrix();
	}

	/** Zincir koptu: ince çubuk küçük kırıklara ayrılıp düşer ve söner. */
	private static void shatter(GuiGraphicsExtractor g, Font font, long sinceBroken) {
		int brokenCount = ClientChainState.brokenCount();
		int brokenTier = ClientChainState.brokenTier();
		if (brokenCount <= 0) {
			return;
		}
		int rgb = TIER_RGB[Mth.clamp(brokenTier, 0, ChainLogic.MAX_TIER)];
		float t = ChainHudMath.shatterProgress(sinceBroken);
		int alpha = (int) (255.0F * ChainHudMath.shardAlpha(t));
		if (alpha < 8) {
			return;
		}
		int[] box = layout(g, font, brokenCount);
		int barY = box[1] + TOP_PAD;
		// Sönen hayalet çerçeve (yalnızca çubuk)
		g.outline(box[0] - 1, barY - 1, BAR_W + 2, BAR_H + 2, argb((int) (alpha * 0.5F), rgb));
		for (int i = 0; i < ChainHudMath.SHARDS; i++) {
			int ox = box[0] + (BAR_W * (2 * i + 1)) / (2 * ChainHudMath.SHARDS);
			int oy = barY + ((i % 3) - 1) * 2;
			// Küçük gösterge için dağılım %60'a ölçeklenir; kırıklar da bir piksel küçüktür.
			int sx = ox + Math.round(ChainHudMath.shardDx(i, t) * 0.6F);
			int sy = oy + Math.round(ChainHudMath.shardDy(i, t) * 0.6F);
			int size = Math.max(1, ChainHudMath.shardSize(i) - 1);
			g.fill(sx, sy, sx + size, sy + size, argb(alpha, rgb));
		}
	}

	/** Kademe atlama başlığı: küçük, kısa ömürlü; nişangâhın üstünde belirip söner (sürekli yazı yok). */
	private static void banner(GuiGraphicsExtractor g, Font font, int count, int tier, long sinceTierUp) {
		int textAlpha = (int) (255.0F * ChainHudMath.bannerAlpha(sinceTierUp));
		if (textAlpha < 8) { // çok düşük saydamlıkta yazı tam opak çizilebilir
			return;
		}
		int rgb = TIER_RGB[Mth.clamp(tier, 0, ChainLogic.MAX_TIER)];
		String text = Component.translatable("message.battleaxe.chain.tier." + tier, count).getString();
		float scale = ChainHudMath.bannerScale(sinceTierUp);
		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		pose.translate(g.guiWidth() / 2.0F, g.guiHeight() / 2.0F - 40.0F);
		pose.scale(scale, scale);
		g.text(font, text, -(font.width(text) / 2), -(font.lineHeight / 2), argb(textAlpha, rgb), true);
		pose.popMatrix();
	}

	/** Kademe atlarken ekranın üst ve alt kenarında çok hafif, kısa renkli ışıma. */
	private static void edgeGlow(GuiGraphicsExtractor g, int tier, long sinceTierUp) {
		float glow = ChainHudMath.tierUpGlow(sinceTierUp);
		if (glow <= 0.0F) {
			return;
		}
		int rgb = TIER_RGB[Mth.clamp(tier, 0, ChainLogic.MAX_TIER)];
		int edge = (int) (0x26 * glow);
		if (edge < 2) {
			return;
		}
		int w = g.guiWidth();
		int h = g.guiHeight();
		g.fillGradient(0, 0, w, 16, argb(edge, rgb), argb(0, rgb));
		g.fillGradient(0, h - 16, w, h, argb(0, rgb), argb(edge, rgb));
	}

	private static int scale(int value, float alpha) {
		return (int) (value * Mth.clamp(alpha, 0.0F, 1.0F));
	}

	private static int blend(int from, int to, float t) {
		int r = (int) Mth.lerp(t, (from >> 16) & 0xFF, (to >> 16) & 0xFF);
		int gr = (int) Mth.lerp(t, (from >> 8) & 0xFF, (to >> 8) & 0xFF);
		int b = (int) Mth.lerp(t, from & 0xFF, to & 0xFF);
		return (r << 16) | (gr << 8) | b;
	}

	private static int argb(int alpha, int rgb) {
		return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0xFFFFFF);
	}
}
