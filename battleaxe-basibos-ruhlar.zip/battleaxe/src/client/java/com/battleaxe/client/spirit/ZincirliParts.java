package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

/**
 * ÜRETİLDİ: tools/gen_spirit_assets.py. Elle düzenleme; model parçaları ve doku düzeni o araçta tek kaynaktır.
 * Tüm parçalar "rig" altındadır (süzülme/dağılma animasyonu tek noktadan sürülür). Doku 128x128.
 */
final class ZincirliParts {
	private ZincirliParts() {
	}

	static final int TEX_W = 128;
	static final int TEX_H = 128;

	static LayerDefinition create() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		PartDefinition p_rig = root.addOrReplaceChild("rig", CubeListBuilder.create(), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_leg_r = p_rig.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(68, 0).addBox(-3F, 0F, -3F, 6F, 12F, 6F), PartPose.offset(-4F, 12F, 0F));
		PartDefinition p_leg_l = p_rig.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(68, 0).addBox(-3F, 0F, -3F, 6F, 12F, 6F), PartPose.offset(4F, 12F, 0F));
		PartDefinition p_torso = p_rig.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-7F, -18F, -4F, 14F, 18F, 8F), PartPose.offset(0F, 12F, 0F));
		PartDefinition p_chest_plate = p_torso.addOrReplaceChild("chest_plate", CubeListBuilder.create().texOffs(68, 26).addBox(-6F, -16F, -4.8F, 12F, 9F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_core = p_torso.addOrReplaceChild("core", CubeListBuilder.create().texOffs(110, 26).addBox(-2F, -11F, -5.6F, 4F, 4F, 1F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_pauldron_r = p_torso.addOrReplaceChild("pauldron_r", CubeListBuilder.create().texOffs(0, 26).addBox(-7F, -4F, -5F, 8F, 6F, 10F), PartPose.offset(-7F, -16F, 0F));
		PartDefinition p_pauldron_l = p_torso.addOrReplaceChild("pauldron_l", CubeListBuilder.create().texOffs(0, 26).addBox(-1F, -4F, -5F, 8F, 6F, 10F), PartPose.offset(7F, -16F, 0F));
		PartDefinition p_head = p_torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(92, 0).addBox(-4F, -9F, -4F, 8F, 9F, 8F), PartPose.offset(0F, -16F, -1F));
		PartDefinition p_horn_r = p_head.addOrReplaceChild("horn_r", CubeListBuilder.create().texOffs(94, 26).addBox(-6F, -12F, -1F, 2F, 7F, 2F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_horn_l = p_head.addOrReplaceChild("horn_l", CubeListBuilder.create().texOffs(102, 26).addBox(4F, -10F, 1F, 2F, 5F, 2F), PartPose.offset(0F, 0F, 0F));
		PartDefinition p_spike_0 = p_torso.addOrReplaceChild("spike_0", CubeListBuilder.create().texOffs(102, 26).addBox(-1F, -5F, 0F, 2F, 5F, 2F), PartPose.offset(0F, -14F, 4F));
		PartDefinition p_spike_1 = p_torso.addOrReplaceChild("spike_1", CubeListBuilder.create().texOffs(102, 26).addBox(-1F, -5F, 0F, 2F, 5F, 2F), PartPose.offset(0F, -9F, 4F));
		PartDefinition p_spike_2 = p_torso.addOrReplaceChild("spike_2", CubeListBuilder.create().texOffs(102, 26).addBox(-1F, -5F, 0F, 2F, 5F, 2F), PartPose.offset(0F, -4F, 4F));
		PartDefinition p_arm_r = p_torso.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(44, 0).addBox(-3F, 0F, -3F, 6F, 18F, 6F), PartPose.offset(-10F, -14F, 0F));
		PartDefinition p_fist_r = p_arm_r.addOrReplaceChild("fist_r", CubeListBuilder.create().texOffs(36, 26).addBox(-4F, 0F, -4F, 8F, 7F, 8F), PartPose.offset(0F, 18F, 0F));
		PartDefinition p_arm_l = p_torso.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(44, 0).addBox(-3F, 0F, -3F, 6F, 18F, 6F), PartPose.offset(10F, -14F, 0F));
		PartDefinition p_fist_l = p_arm_l.addOrReplaceChild("fist_l", CubeListBuilder.create().texOffs(36, 26).addBox(-4F, 0F, -4F, 8F, 7F, 8F), PartPose.offset(0F, 18F, 0F));
		PartDefinition p_chain_r_0 = p_pauldron_r.addOrReplaceChild("chain_r_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(-3F, 5F, -3F));
		PartDefinition p_chain_r_1 = p_chain_r_0.addOrReplaceChild("chain_r_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_r_2 = p_chain_r_1.addOrReplaceChild("chain_r_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_r_3 = p_chain_r_2.addOrReplaceChild("chain_r_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_r_4 = p_chain_r_3.addOrReplaceChild("chain_r_4", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_l_0 = p_pauldron_l.addOrReplaceChild("chain_l_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(3F, 5F, -3F));
		PartDefinition p_chain_l_1 = p_chain_l_0.addOrReplaceChild("chain_l_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_l_2 = p_chain_l_1.addOrReplaceChild("chain_l_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_l_3 = p_chain_l_2.addOrReplaceChild("chain_l_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_l_4 = p_chain_l_3.addOrReplaceChild("chain_l_4", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wr_0 = p_torso.addOrReplaceChild("chain_wr_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(-6F, -1F, -4F));
		PartDefinition p_chain_wr_1 = p_chain_wr_0.addOrReplaceChild("chain_wr_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wr_2 = p_chain_wr_1.addOrReplaceChild("chain_wr_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wr_3 = p_chain_wr_2.addOrReplaceChild("chain_wr_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wl_0 = p_torso.addOrReplaceChild("chain_wl_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(6F, -1F, -4F));
		PartDefinition p_chain_wl_1 = p_chain_wl_0.addOrReplaceChild("chain_wl_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wl_2 = p_chain_wl_1.addOrReplaceChild("chain_wl_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_wl_3 = p_chain_wl_2.addOrReplaceChild("chain_wl_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fr_0 = p_fist_r.addOrReplaceChild("chain_fr_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 6F, 0F));
		PartDefinition p_chain_fr_1 = p_chain_fr_0.addOrReplaceChild("chain_fr_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fr_2 = p_chain_fr_1.addOrReplaceChild("chain_fr_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fr_3 = p_chain_fr_2.addOrReplaceChild("chain_fr_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fr_4 = p_chain_fr_3.addOrReplaceChild("chain_fr_4", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fr_5 = p_chain_fr_4.addOrReplaceChild("chain_fr_5", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fl_0 = p_fist_l.addOrReplaceChild("chain_fl_0", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 6F, 0F));
		PartDefinition p_chain_fl_1 = p_chain_fl_0.addOrReplaceChild("chain_fl_1", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fl_2 = p_chain_fl_1.addOrReplaceChild("chain_fl_2", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fl_3 = p_chain_fl_2.addOrReplaceChild("chain_fl_3", CubeListBuilder.create().texOffs(120, 26).addBox(-0.5F, 0F, -1F, 1F, 3F, 2F), PartPose.offset(0F, 3F, 0F));
		PartDefinition p_chain_fl_4 = p_chain_fl_3.addOrReplaceChild("chain_fl_4", CubeListBuilder.create().texOffs(0, 42).addBox(-1F, 0F, -0.5F, 2F, 3F, 1F), PartPose.offset(0F, 3F, 0F));
		return LayerDefinition.create(mesh, TEX_W, TEX_H);
	}
}
