package com.battleaxe.client.spirit;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Başıboş Ruh çizimi için gereken veriler (üç tür de aynı durumu kullanır). */
public class SpiritRenderState extends LivingEntityRenderState {
	/** Sunucudaki saldırı durumunun sıra numarası (türün Attack enum'u: bkz. Savrulmus/RuhYiyen/ZincirliLogic.Attack.byOrdinal). */
	public int attack;
	/** O durumun ilerlemesi (0-1). */
	public float progress;
	/** Savunmasız mı (gövde titrer). */
	public boolean exposed;
	/** Ölüm dağılma ilerlemesi (0-1): ruhsal beden düşmez, parçalanıp dağılır. */
	public float shatter;
}
