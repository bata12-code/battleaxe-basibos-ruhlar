package com.battleaxe.client;

import org.joml.Matrix3x2fStack;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.item.ItemStack;

import com.battleaxe.berserker.BerserkerConfig;
import com.battleaxe.item.ModItems;

/**
 * <b>Hiddet</b> göstergesi ve ekran görünümü (istemci, yalnızca çizim).
 *
 * <p>Bu sınıf durum üretmez; yalnızca {@link ClientBerserkerState}'i (sunucunun bildirdiği Hiddet durumu) okur.
 * İki katmandan oluşur:
 * <ol>
 *   <li><b>Ekran görünümü:</b> dört kenarda kan kırmızısı nabız atan vinyet, köşelerden uzanan çatlaklar, çok hafif koyu
 *       kırmızı renk tonu. Ekranın ortası (nişangâh, düşmanlar) temiz bırakılır.</li>
 *   <li><b>Gösterge:</b> sağ üstte, düzensiz kenarlı koyu panel: balta ikonu, "HİDDET" yazısı, kısa bonus özeti,
 *       kan damlaları ve yükselen ruh kıvılcımları.</li>
 * </ol>
 * Eski Berserker göstergesinin YERİNE geçer (üst üste çizilmez). Durum Hiddet kapanınca ya da oyuncu ölünce
 * hemen çizilmez olur; sınıf hiçbir kalıcı durum tutmaz.
 */
public final class HiddetHud {
	private HiddetHud() {
	}

	/** Ekran görünümü (vinyet, çatlak, ton) tamamen kapatmak için false yap; gösterge kalır. */
	public static final boolean SCREEN_FX_ENABLED = true;

	private static final int PADDING = 5;
	private static final int ICON_SIZE = 16;
	private static final int MARGIN_RIGHT = 6;
	private static final int MARGIN_TOP = 6;
	/** Oyuncuda efekt (iksir vb.) varsa vanilla efekt ikonlarının altına kayar. */
	private static final int EFFECTS_OFFSET = 54;

	private static final float ANIMATION_MILLIS = 400.0F;
	private static final float START_SCALE = 0.7F;

	private static final int BODY_TOP = 0x3A0808;
	private static final int BODY_BOTTOM = 0x0E0202;
	private static final int BLOOD = 0xB01418;
	private static final int BLOOD_BRIGHT = 0xFF2A2A;
	private static final int SPIRIT = 0x7A5CFF;
	private static final int TEXT = 0xFF3A3A;
	private static final int SUBTEXT = 0xD08C8C;

	private static final int VIGNETTE_RGB = 0x7A0000;
	private static final int VIGNETTE_BAND = 34;
	private static final int VIGNETTE_MIN_ALPHA = 0x1C;
	private static final int VIGNETTE_PULSE_ALPHA = 0x24;
	private static final int TINT_RGB = 0x300000;
	private static final int TINT_ALPHA = 0x0C;

	/** Panelin üst kenarındaki düzensiz "diş" yükseklikleri (piksel), sabit desen. */
	private static final int[] TEETH = {2, 0, 3, 1, 0, 2, 3, 0, 1, 2, 0, 3, 1, 2, 0};
	/** Panelin altından sarkan kan damlalarının (x payı 0-1, uzunluk). */
	private static final float[] DRIP_X = {0.12F, 0.46F, 0.81F};
	private static final int[] DRIP_LEN = {5, 3, 6};

	/** Köşelerden içeri uzanan çatlak kırık çizgileri; her satır (dx, dy) adımları, sabit ve deterministik. */
	private static final int[][] CRACK = {{9, 4}, {7, 9}, {5, 5}, {8, 3}, {4, 8}, {6, 6}};

	private static ItemStack iconStack;

	public static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		if (!ClientBerserkerState.isActive()) {
			return;
		}
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || !player.isAlive()) {
			return;
		}

		float progress = Mth.clamp(ClientBerserkerState.millisSinceActivated() / ANIMATION_MILLIS, 0.0F, 1.0F);
		float eased = 1.0F - (1.0F - progress) * (1.0F - progress) * (1.0F - progress);
		int alpha = (int) (255.0F * progress);
		if (alpha < 8) {
			return;
		}
		long millis = Util.getMillis() % 100_000L;
		// Yavaş nabız (~1.5 sn) ve arada bir kısa kalp atışı vurgusu.
		float pulse = 0.5F + 0.5F * Mth.sin(millis * 0.004F);
		float beat = heartbeat(millis);

		if (SCREEN_FX_ENABLED) {
			screenFx(graphics, progress, pulse, beat, millis);
		}
		panel(graphics, minecraft, player, progress, eased, alpha, pulse, millis);
	}

	// ------------------------------------------------------------------
	// Ekran görünümü
	// ------------------------------------------------------------------

	private static void screenFx(GuiGraphicsExtractor g, float progress, float pulse, float beat, long millis) {
		int w = g.guiWidth();
		int h = g.guiHeight();

		// Çok hafif renk tonu: dünyanın renklerini koyu kırmızıya doğru kaydırır, okunabilirliği bozmaz.
		g.fill(0, 0, w, h, argb((int) (TINT_ALPHA * progress), TINT_RGB));

		int edge = (int) ((VIGNETTE_MIN_ALPHA + VIGNETTE_PULSE_ALPHA * pulse + 0x20 * beat) * progress);
		// Üst / alt: dikey degrade
		g.fillGradient(0, 0, w, VIGNETTE_BAND, argb(edge, VIGNETTE_RGB), argb(0, VIGNETTE_RGB));
		g.fillGradient(0, h - VIGNETTE_BAND, w, h, argb(0, VIGNETTE_RGB), argb(edge, VIGNETTE_RGB));
		// Sol / sağ: yatay degrade, 1 piksellik sütunlarla
		int side = VIGNETTE_BAND - 8;
		for (int i = 0; i < side; i++) {
			int a = (int) (edge * (1.0F - i / (float) side) * 0.85F);
			if (a <= 0) {
				break;
			}
			g.fill(i, 0, i + 1, h, argb(a, VIGNETTE_RGB));
			g.fill(w - i - 1, 0, w - i, h, argb(a, VIGNETTE_RGB));
		}

		// Çatlaklar: köşelerden uzanır; ruhani mor bir iz kan kırmızısının yanında soluk parlar.
		int crackAlpha = (int) ((0x50 + 0x40 * pulse + 0x40 * beat) * progress);
		crack(g, 0, 0, 1, 1, crackAlpha);
		crack(g, w - 1, 0, -1, 1, crackAlpha);
		crack(g, 0, h - 1, 1, -1, crackAlpha);
		crack(g, w - 1, h - 1, -1, -1, crackAlpha);

		// Köşelerde yavaşça süzülen birkaç ruh kıvılcımı (kenarlarda kalır, merkeze girmez).
		for (int i = 0; i < 6; i++) {
			float t = ((millis * 0.0006F) + i * 0.173F) % 1.0F;
			int x = (i % 2 == 0) ? 6 + (int) (Mth.sin(i * 12.9F + t * 6.0F) * 5.0F + 5.0F)
					: w - 12 - (int) (Mth.sin(i * 7.7F + t * 6.0F) * 5.0F + 5.0F);
			int y = h - 8 - (int) (t * (h * 0.35F)) - (i / 2) * 30;
			int a = (int) (Mth.sin(t * 3.1416F) * 110 * progress);
			g.fill(x, y, x + 2, y + 2, argb(a, SPIRIT));
		}
	}

	/** Bir köşeden (sx, sy) içeri, (dirX, dirY) yönünde kırık bir çatlak çizer. */
	private static void crack(GuiGraphicsExtractor g, int sx, int sy, int dirX, int dirY, int alpha) {
		int x = sx;
		int y = sy;
		for (int i = 0; i < CRACK.length; i++) {
			int nx = x + dirX * CRACK[i][0];
			int ny = y + dirY * CRACK[i][1];
			float fade = 1.0F - i / (float) CRACK.length;
			line(g, x, y, nx, ny, argb((int) (alpha * fade), BLOOD));
			if (i % 2 == 1) {
				// Küçük yan dal
				line(g, x, y, x + dirX * 5, y - dirY * 3, argb((int) (alpha * fade * 0.6F), SPIRIT));
			}
			x = nx;
			y = ny;
		}
	}

	private static void line(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int color) {
		int dx = x1 - x0;
		int dy = y1 - y0;
		int steps = Math.max(Math.abs(dx), Math.abs(dy));
		if (steps == 0) {
			g.fill(x0, y0, x0 + 1, y0 + 1, color);
			return;
		}
		for (int i = 0; i <= steps; i++) {
			int x = x0 + Math.round(dx * (i / (float) steps));
			int y = y0 + Math.round(dy * (i / (float) steps));
			g.fill(x, y, x + 1, y + 1, color);
		}
	}

	/** ~2.6 sn'de bir kısa, çift vuruşlu kalp atışı (0-1). */
	private static float heartbeat(long millis) {
		float phase = (millis % 2600L) / 2600.0F;
		float first = phase < 0.07F ? 1.0F - phase / 0.07F : 0.0F;
		float second = (phase >= 0.12F && phase < 0.19F) ? 0.7F * (1.0F - (phase - 0.12F) / 0.07F) : 0.0F;
		return Math.max(first, second);
	}

	// ------------------------------------------------------------------
	// Gösterge paneli
	// ------------------------------------------------------------------

	private static void panel(GuiGraphicsExtractor g, Minecraft minecraft, LocalPlayer player, float progress, float eased,
			int alpha, float pulse, long millis) {
		Font font = minecraft.font;
		String title = Component.translatable("hiddet.hud.title").getString();
		String detail = Component.translatable("hiddet.hud.detail",
				trim(BerserkerConfig.BERSERKER_DAMAGE_BONUS),
				Math.round((BerserkerConfig.BERSERKER_ATTACK_SPEED_MULTIPLIER - 1.0) * 100.0)).getString();

		int textW = Math.max(font.width(title), (int) (font.width(detail) * 0.75F));
		int width = PADDING + ICON_SIZE + PADDING + textW + PADDING + 4;
		int height = PADDING + ICON_SIZE + PADDING + 2;
		int x = g.guiWidth() - width - MARGIN_RIGHT;
		int y = MARGIN_TOP + (player.getActiveEffects().isEmpty() ? 0 : EFFECTS_OFFSET);

		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		float cx = x + width / 2.0F;
		float cy = y + height / 2.0F;
		float scale = START_SCALE + (1.0F - START_SCALE) * eased;
		pose.translate(cx, cy);
		pose.scale(scale, scale);
		pose.translate(-cx, -cy);

		int bg = (int) (0xE6 * progress);
		g.fillGradient(x, y, x + width, y + height, argb(bg, BODY_TOP), argb(bg, BODY_BOTTOM));

		// Düzensiz üst kenar: kan kırmızısı dişler (panelin içine doğru)
		int teethCount = Math.min(TEETH.length, width / 4);
		for (int i = 0; i < teethCount; i++) {
			int tx = x + i * (width / teethCount);
			int tw = Math.max(2, width / teethCount - 1);
			g.fill(tx, y, tx + tw, y + 1 + TEETH[i], argb((int) (alpha * (0.75F + 0.25F * pulse)), BLOOD));
		}
		// Alt kenar ince çizgi ve sarkan damlalar
		g.fill(x, y + height - 1, x + width, y + height, argb((int) (alpha * 0.6F), BLOOD));
		for (int i = 0; i < DRIP_X.length; i++) {
			int dxp = x + (int) (DRIP_X[i] * width);
			int len = DRIP_LEN[i] + (int) (2.0F * Mth.sin(millis * 0.003F + i * 2.0F) + 1.0F);
			g.fill(dxp, y + height, dxp + 1, y + height + len, argb((int) (alpha * 0.7F), BLOOD));
			g.fill(dxp - 1, y + height + len, dxp + 2, y + height + len + 1, argb((int) (alpha * 0.5F), BLOOD_BRIGHT));
		}
		// Sol ve sağ kenar: kalın kırmızı şerit + ince mor ruh izi
		g.fill(x, y, x + 3, y + height, argb(alpha, BLOOD_BRIGHT));
		g.fill(x + 3, y + 2, x + 4, y + height - 2, argb((int) (alpha * 0.45F), SPIRIT));
		g.fill(x + width - 1, y + 3, x + width, y + height - 3, argb((int) (alpha * 0.5F), BLOOD));
		g.outline(x, y, width, height, argb((int) (alpha * (0.45F + 0.25F * pulse)), BLOOD));

		// Yükselen küçük ruh kıvılcımları
		for (int i = 0; i < 3; i++) {
			float t = ((millis * 0.0009F) + i * 0.33F) % 1.0F;
			int sx = x + 8 + i * (width / 4);
			int sy = y + height - 3 - (int) (t * (height - 4));
			g.fill(sx, sy, sx + 1, sy + 1, argb((int) (Mth.sin(t * 3.1416F) * 200 * progress), SPIRIT));
		}

		// Item ikonu yarı saydam çizilemez; animasyonun ortasından itibaren belirir.
		if (progress >= 0.4F) {
			g.item(icon(), x + PADDING + 3, y + PADDING + 1);
		}

		int textX = x + PADDING + 3 + ICON_SIZE + PADDING;
		g.text(font, title, textX, y + PADDING, argb(alpha, TEXT), true);
		pose.pushMatrix();
		pose.translate(textX, y + PADDING + font.lineHeight + 1);
		pose.scale(0.75F, 0.75F);
		g.text(font, detail, 0, 0, argb(alpha, SUBTEXT), false);
		pose.popMatrix();

		pose.popMatrix();
	}

	private static String trim(double value) {
		return Math.abs(value - Math.rint(value)) < 1.0E-6 ? Long.toString((long) Math.rint(value)) : Double.toString(value);
	}

	private static ItemStack icon() {
		if (iconStack == null) {
			iconStack = new ItemStack(ModItems.BATTLE_AXE);
		}
		return iconStack;
	}

	private static int argb(int alpha, int rgb) {
		return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0xFFFFFF);
	}
}
