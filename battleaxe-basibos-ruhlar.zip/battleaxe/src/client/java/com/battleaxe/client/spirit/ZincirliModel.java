package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.spirit.ZincirliLogic;

/**
 * Zincirli Ruh: üç ruhun en büyük ve ağır silüeti. Geniş omuzlu, çökük başlı, kırık boynuzlu; iri kollar ve plaka yumruklar.
 * Gövdesinde sallanan altı zincir bulunur (omuz, bel ve iki yumruk); zincirler yalnızca süs değildir, savaş animasyonlarında
 * gerçekten hareket eder (savurmada dışa savrulur, darbede yukarı kalkıp iner, mühürde sağ yumruktaki zincir öne uzanır).
 * Parça yapısı ve doku: tools/gen_spirit_assets.py (ZincirliParts). Toplam boy ~41 piksel (~2.6 blok).
 */
public class ZincirliModel extends SpiritModel {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(BattleAxeMod.id("zincirli_ruh"), "main");

	private final ModelPart legR;
	private final ModelPart legL;
	private final ModelPart torso;
	private final ModelPart core;
	private final ModelPart head;
	private final ModelPart armR;
	private final ModelPart armL;
	private final ModelPart[] chainShoulderR;
	private final ModelPart[] chainShoulderL;
	private final ModelPart[] chainWaistR;
	private final ModelPart[] chainWaistL;
	private final ModelPart[] chainFistR;
	private final ModelPart[] chainFistL;

	public ZincirliModel(ModelPart root) {
		super(root);
		this.legR = part(rig.getChild("leg_r"));
		this.legL = part(rig.getChild("leg_l"));
		this.torso = part(rig.getChild("torso"));
		part(torso.getChild("chest_plate"));
		this.core = part(torso.getChild("core"));
		ModelPart pauldronR = part(torso.getChild("pauldron_r"));
		ModelPart pauldronL = part(torso.getChild("pauldron_l"));
		this.head = part(torso.getChild("head"));
		part(head.getChild("horn_r"));
		part(head.getChild("horn_l"));
		for (int i = 0; i < 3; i++) {
			part(torso.getChild("spike_" + i));
		}
		this.armR = part(torso.getChild("arm_r"));
		ModelPart fistR = part(armR.getChild("fist_r"));
		this.armL = part(torso.getChild("arm_l"));
		ModelPart fistL = part(armL.getChild("fist_l"));
		this.chainShoulderR = chain(pauldronR, "chain_r", 5);
		this.chainShoulderL = chain(pauldronL, "chain_l", 5);
		this.chainWaistR = chain(torso, "chain_wr", 4);
		this.chainWaistL = chain(torso, "chain_wl", 4);
		this.chainFistR = chain(fistR, "chain_fr", 6);
		this.chainFistL = chain(fistL, "chain_fl", 5);
	}

	/** İç içe zincir halkalarını sırayla bulur ve kaydeder (her halka bir öncekinin çocuğudur). */
	private ModelPart[] chain(ModelPart parent, String prefix, int links) {
		ModelPart[] out = new ModelPart[links];
		ModelPart current = parent;
		for (int i = 0; i < links; i++) {
			current = part(current.getChild(prefix + "_" + i));
			out[i] = current;
		}
		return out;
	}

	public static LayerDefinition createBodyLayer() {
		return ZincirliParts.create();
	}

	/** Zincir sarkacı: her halka bir öncekinin gecikmesiyle sallanır; bias halkaların genel eğimidir. */
	private static void swing(ModelPart[] links, float t, float phase, float amp, float xBias, float zBias) {
		for (int i = 0; i < links.length; i++) {
			float lag = t * 0.1F - i * 0.5F + phase;
			links[i].xRot = xBias / links.length * 2.0F + Mth.sin(lag) * amp;
			links[i].zRot = zBias / links.length * 2.0F + Mth.sin(lag * 0.8F + 1.3F) * amp * 0.6F;
		}
	}

	@Override
	public void setupAnim(SpiritRenderState state) {
		super.setupAnim(state);
		resetParts();

		float t = state.ageInTicks;
		float walk = Mth.clamp(state.walkAnimationSpeed, 0.0F, 1.0F);
		float pos = state.walkAnimationPos * 0.6662F;
		float p = Mth.clamp(state.progress, 0.0F, 1.0F);
		ZincirliLogic.Attack attack = ZincirliLogic.Attack.byOrdinal(state.attack);

		float torsoX = 0.05F;
		float torsoY = 0.0F;
		float torsoZ = Mth.sin(pos) * 0.05F * walk;
		float armRX = 0.05F + Mth.cos(pos + Mth.PI) * 0.5F * walk;
		float armLX = 0.05F + Mth.cos(pos) * 0.5F * walk;
		float armRY = 0.0F;
		float armRZ = -0.08F;
		float armLZ = 0.08F;
		float lift = 0.0F;
		float chainAmp = 0.08F + walk * 0.12F;
		float chainXR = 0.0F;
		float chainXL = 0.0F;
		float chainZR = 0.0F;
		float chainZL = 0.0F;
		boolean fistChainStraight = false;
		float fistChainCoil = 0.0F;
		float corePush = (0.5F + 0.5F * Mth.sin(t * 0.15F)) * 0.3F;

		switch (attack) {
			case SWEEP_WINDUP -> {
				float e = ease(p);
				torsoY = -1.0F * e;
				armRX = Mth.lerp(e, armRX, -1.0F);
				armRZ = -1.1F * e - 0.08F;
				armLX = -0.6F * e + armLX;
				armLZ = 0.5F * e + 0.08F;
				chainXR = 0.6F * e;
				chainXL = 0.6F * e;
				chainAmp = 0.15F;
			}
			case SWEEP_STRIKE -> {
				float s = snap(p);
				torsoY = Mth.lerp(s, -1.0F, 1.2F);
				armRX = -1.3F;
				armRZ = Mth.lerp(s, -1.1F, -0.3F);
				armLX = -1.0F;
				chainZR = -0.9F;
				chainZL = 0.9F;
				chainAmp = 0.2F;
			}
			case SWEEP_RECOVER -> {
				float e = ease(p);
				torsoY = Mth.lerp(e, 1.2F, 0.0F);
				armRX = Mth.lerp(e, -1.3F, armRX);
				armLX = Mth.lerp(e, -1.0F, armLX);
				armRZ = Mth.lerp(e, -0.3F, armRZ);
			}
			case SLAM_WINDUP -> {
				float e = ease(p);
				armRX = Mth.lerp(e, armRX, -3.0F);
				armLX = Mth.lerp(e, armLX, -3.0F);
				armRZ = -0.2F * e - 0.08F;
				armLZ = 0.2F * e + 0.08F;
				torsoX = 0.05F - 0.3F * e;
				lift = -1.5F * e;
				chainXR = -0.6F * e;
				chainXL = -0.6F * e;
				chainAmp = 0.12F;
				corePush = 0.3F + 0.7F * e;
			}
			case SLAM_STRIKE -> {
				float s = snap(Math.min(1.0F, p * 3.0F));
				armRX = Mth.lerp(s, -3.0F, -0.2F);
				armLX = Mth.lerp(s, -3.0F, -0.2F);
				torsoX = Mth.lerp(s, -0.25F, 0.4F);
				lift = 1.5F * s * (1.0F - p);
				chainXR = Mth.lerp(s, -0.6F, 0.9F);
				chainXL = Mth.lerp(s, -0.6F, 0.9F);
				chainAmp = 0.1F;
			}
			case SLAM_RECOVER -> {
				float e = ease(p);
				armRX = Mth.lerp(e, -0.2F, armRX);
				armLX = Mth.lerp(e, -0.2F, armLX);
				torsoX = Mth.lerp(e, 0.4F, 0.05F);
				lift = 1.0F * (1.0F - p);
			}
			case CHAIN_WINDUP -> {
				float e = ease(p);
				armRX = Mth.lerp(e, armRX, -1.0F);
				armRY = 0.8F * e;
				torsoY = 0.5F * e;
				fistChainCoil = 0.7F * e;
				corePush = 0.3F + 0.5F * e;
			}
			case CHAIN_THROW -> {
				armRX = -1.6F;
				armRY = -0.1F;
				torsoY = -0.25F;
				fistChainStraight = true;
			}
			case CHAIN_RECOVER -> {
				float e = ease(p);
				armRX = Mth.lerp(e, -1.6F, armRX);
				armRY = Mth.lerp(e, -0.1F, 0.0F);
				torsoY = Mth.lerp(e, -0.25F, 0.0F);
			}
			default -> {
			}
		}
		if (state.exposed) {
			torsoZ += Mth.sin(t * 1.5F) * 0.05F;
		}

		rig.y = rigBaseY + Math.abs(Mth.cos(pos)) * walk * 0.8F + lift;
		legR.xRot = Mth.cos(pos) * 0.9F * walk;
		legL.xRot = Mth.cos(pos + Mth.PI) * 0.9F * walk;
		torso.xRot = torsoX;
		torso.yRot = torsoY;
		torso.zRot = torsoZ;
		head.xRot = state.xRot * Mth.DEG_TO_RAD;
		head.yRot = state.yRot * Mth.DEG_TO_RAD - torsoY * 0.7F;
		armR.xRot = armRX;
		armR.yRot = armRY;
		armR.zRot = armRZ;
		armL.xRot = armLX;
		armL.zRot = armLZ;
		core.z = core.z - corePush;

		swing(chainShoulderR, t, 0.0F, chainAmp, chainXR, chainZR);
		swing(chainShoulderL, t, 1.7F, chainAmp, chainXL, chainZL);
		swing(chainWaistR, t, 0.8F, chainAmp, chainXR, chainZR);
		swing(chainWaistL, t, 2.5F, chainAmp, chainXL, chainZL);
		swing(chainFistL, t, 3.1F, chainAmp, chainXL, chainZL);
		if (fistChainStraight) {
			for (int i = 0; i < chainFistR.length; i++) {
				chainFistR[i].xRot = i == 0 ? -1.45F : 0.0F;
				chainFistR[i].zRot = 0.0F;
			}
		} else if (fistChainCoil > 0.0F) {
			for (int i = 0; i < chainFistR.length; i++) {
				chainFistR[i].xRot = fistChainCoil;
				chainFistR[i].zRot = 0.0F;
			}
		} else {
			swing(chainFistR, t, 4.2F, chainAmp, chainXR, chainZR);
		}

		applyShatter(state.shatter);
	}
}
