package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.spirit.RuhYiyenLogic;

/**
 * Ruh Yiyen: diğer iki ruhtan uzun ve ince; kukuletalı sivri başlı, uzun kollu, gövdesinin merkezinde enerji toplayan karanlık
 * ve parlayan bir ruh çekirdeği taşır. Ayakları yok: gövde uzun ince bir kuyrukla süzülür. Hareketleri yavaş ve ürkütücüdür.
 * Parça yapısı ve doku: tools/gen_spirit_assets.py (RuhYiyenParts). Toplam boy ~43 piksel (~2.7 blok).
 */
public class RuhYiyenModel extends SpiritModel {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(BattleAxeMod.id("ruh_yiyen"), "main");

	private final ModelPart torso;
	private final ModelPart core;
	private final ModelPart head;
	private final ModelPart hoodPoint;
	private final ModelPart armR;
	private final ModelPart armL;
	private final ModelPart[] fingersR = new ModelPart[3];
	private final ModelPart[] fingersL = new ModelPart[3];
	private final ModelPart ragR;
	private final ModelPart ragL;
	private final ModelPart tailA;
	private final ModelPart tailB;
	private final ModelPart tailC;

	public RuhYiyenModel(ModelPart root) {
		super(root);
		this.torso = part(rig.getChild("torso"));
		this.core = part(torso.getChild("core"));
		for (int i = 0; i < 3; i++) {
			part(torso.getChild("rib_" + i));
		}
		this.head = part(torso.getChild("head"));
		ModelPart hood = part(head.getChild("hood"));
		this.hoodPoint = part(hood.getChild("hood_point"));
		this.armR = part(torso.getChild("arm_r"));
		this.armL = part(torso.getChild("arm_l"));
		for (int i = 0; i < 3; i++) {
			fingersR[i] = part(armR.getChild("finger_r_" + i));
			fingersL[i] = part(armL.getChild("finger_l_" + i));
		}
		this.ragR = part(torso.getChild("rag_r"));
		this.ragL = part(torso.getChild("rag_l"));
		this.tailA = part(rig.getChild("tail_a"));
		this.tailB = part(tailA.getChild("tail_b"));
		this.tailC = part(tailB.getChild("tail_c"));
	}

	public static LayerDefinition createBodyLayer() {
		return RuhYiyenParts.create();
	}

	@Override
	public void setupAnim(SpiritRenderState state) {
		super.setupAnim(state);
		resetParts();

		float t = state.ageInTicks;
		float walk = Mth.clamp(state.walkAnimationSpeed, 0.0F, 1.0F);
		float p = Mth.clamp(state.progress, 0.0F, 1.0F);
		RuhYiyenLogic.Attack attack = RuhYiyenLogic.Attack.byOrdinal(state.attack);

		float torsoX = 0.08F + Mth.sin(t * 0.07F) * 0.03F;
		float torsoZ = 0.0F;
		float headX = -0.1F;
		float headZ = Mth.sin(t * 0.05F) * 0.12F; // rahatsız edici yan yatık baş
		float armRX = 0.1F + Mth.sin(t * 0.09F) * 0.06F;
		float armLX = 0.1F + Mth.sin(t * 0.09F + 1.5F) * 0.06F;
		float armRZ = -0.1F;
		float armLZ = 0.1F;
		float curl = -0.3F + Mth.sin(t * 0.11F) * 0.08F;
		float tailLean = -0.1F - walk * 0.4F;
		float lift = 0.0F;
		float pulse = 0.5F + 0.5F * Mth.sin(t * 0.2F);
		float corePush = pulse * 0.25F;

		switch (attack) {
			case BOLT_WINDUP -> {
				float e = ease(p);
				armRX = Mth.lerp(e, armRX, -2.3F);
				armRZ = -0.3F * e - 0.1F;
				armLX = -0.4F * e + 0.1F;
				headX = -0.1F - 0.3F * e;
				torsoX = -0.18F * e;
				corePush = 0.25F + 0.6F * e;
				curl = -0.8F * e;
			}
			case BOLT_RELEASE -> {
				float s = snap(p);
				armRX = Mth.lerp(s, -2.3F, -1.3F);
				torsoX = Mth.lerp(s, -0.18F, 0.25F);
				corePush = 0.0F;
				curl = 0.2F;
			}
			case DRAIN_WINDUP -> {
				float e = ease(p);
				armRX = Mth.lerp(e, armRX, -2.7F);
				armLX = Mth.lerp(e, armLX, -2.7F);
				armRZ = -0.1F - 0.7F * e;
				armLZ = 0.1F + 0.7F * e;
				torsoX = -0.3F * e;
				headX = -0.1F - 0.35F * e;
				lift = -2.0F * e;
				corePush = 0.25F + 0.7F * e;
				tailLean = -0.1F - 0.4F * e;
			}
			case DRAIN_CHANNEL -> {
				float tremble = Mth.sin(t * 1.7F) * 0.05F;
				armRX = -1.6F + tremble;
				armLX = -1.6F - tremble;
				armRZ = -0.45F;
				armLZ = 0.45F;
				torsoX = -0.1F;
				headX = -0.3F;
				lift = -2.5F;
				corePush = 0.9F * (0.6F + 0.4F * pulse);
				tailLean = -0.55F;
				curl = -0.9F;
			}
			case DRAIN_RECOVER -> {
				torsoX = Mth.lerp(p, 0.6F, 0.3F);
				headX = 0.45F;
				armRX = 0.4F;
				armLX = 0.4F;
				lift = 1.0F;
				torsoZ = Mth.sin(t * 1.4F) * 0.06F;
				corePush = 0.0F;
			}
			default -> {
			}
		}
		if (state.exposed) {
			torsoZ += Mth.sin(t * 1.5F) * 0.05F;
		}

		rig.y = rigBaseY + Mth.sin(t * 0.1F) * 1.6F + lift;
		torso.xRot = torsoX;
		torso.zRot = torsoZ;
		head.xRot = headX + state.xRot * Mth.DEG_TO_RAD;
		head.yRot = state.yRot * Mth.DEG_TO_RAD;
		head.zRot = headZ;
		hoodPoint.xRot = 0.5F + Mth.sin(t * 0.08F) * 0.05F;
		armR.xRot = armRX;
		armR.zRot = armRZ;
		armL.xRot = armLX;
		armL.zRot = armLZ;
		for (int i = 0; i < 3; i++) {
			float side = (i - 1) * 0.3F;
			fingersR[i].xRot = curl;
			fingersR[i].zRot = side;
			fingersL[i].xRot = curl;
			fingersL[i].zRot = side;
		}
		ragR.zRot = -0.15F + Mth.sin(t * 0.1F) * 0.1F;
		ragL.zRot = 0.15F - Mth.sin(t * 0.1F + 1.0F) * 0.1F;
		tailA.xRot = tailLean + Mth.sin(t * 0.12F) * 0.12F;
		tailB.xRot = Mth.sin(t * 0.12F - 0.8F) * 0.2F;
		tailC.xRot = Mth.sin(t * 0.12F - 1.6F) * 0.3F;
		core.z = core.z - corePush;

		applyShatter(state.shatter);
	}
}
