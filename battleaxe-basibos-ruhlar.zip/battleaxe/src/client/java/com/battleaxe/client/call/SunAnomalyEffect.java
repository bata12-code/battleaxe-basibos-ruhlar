package com.battleaxe.client.call;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.Level;

import com.battleaxe.call.CallMoon;
import com.battleaxe.call.OmenGeometry;
import com.battleaxe.call.OmenLogic;
import com.battleaxe.call.OmenPayload;
import com.battleaxe.call.SunAnomalyLogic;
import com.battleaxe.call.SunAnomalyShapes;

/**
 * <b>Parçalanmış Güneş</b> (istemci, yalnızca görüntü): güneşin üstüne, kopmuş/çatlamış/sönmüş görünmesini sağlayan karanlık parçalar çizer.
 * Gerçek güneşi, ışığı, gündüz-gece döngüsünü ve blokları DEĞİŞTİRMEZ; yalnızca bu oyuncunun ekranına çizilen bir görüntüdür.
 *
 * <p>Durum sunucudan gelir ({@link OmenPayload}, tür {@code FRACTURED_SUN}): hangi gün/varyasyon ve gün içi zaman. Hangi günün anomali
 * günü olduğu dünya tohumundan deterministik türetildiği için aynı dünyadaki bütün oyuncular aynı güneşi görür. İstemci güneşin
 * gökteki yerini ay efektiyle AYNI yöntemle kendisi ilerletir (sunucu zamanından {@link CallMoon#celestialAngle}), arada sunucu seyrek
 * olarak zamanı tazeler.
 *
 * <p>Diğer tezahürlerle aynı anda sürebilir (kendi durumu vardır). Güneşin karesi gökyüzünün dönüşüyle ekrana göre döner; bu yüzden
 * şekiller güneşin yerel eksenlerine (vanilla'nın kendi dönüş zinciriyle, bkz. {@link SunAnomalyShapes#frame}) eşlenir ve
 * perspektife doğru izdüşürülür. Ufuğa yakınken arazi örtüsü uygulanır; kapalı alanda, yağmurda ve ufuk altında söner.
 */
final class SunAnomalyEffect {
	private SunAnomalyEffect() {
	}

	private static int variant;
	private static int seed;
	private static float baseTimeOfDay;
	private static long receivedMs;
	private static long expiresMs;
	private static long shownSinceMs;
	private static SunAnomalyShapes.Piece[] pieces = new SunAnomalyShapes.Piece[0];
	private static float[][] sx = new float[0][];
	private static float[][] sy = new float[0][];

	private static final OmenOcclusion OCCLUSION = new OmenOcclusion();
	private static double occAz = 1.0E9;
	private static double occEl = 1.0E9;
	private static int[] clipTop = new int[0];
	private static int[] clipBottom = new int[0];

	private static boolean skyOpen = true;
	private static long lastSkyCheckMs;
	private static long lastFrameMs;
	private static double skyVisibility = 1.0;

	/** Sunucudan paket: varyasyon 0 = anomali yok/bitti; aksi halde durum (gün içi zaman yükseklik alanında). */
	static void receive(OmenPayload payload) {
		int newVariant = OmenLogic.unpackVariant(payload.packed());
		if (newVariant < SunAnomalyLogic.PARTIAL || newVariant > SunAnomalyLogic.SCAR) {
			clear();
			return;
		}
		long now = net.minecraft.util.Util.getMillis();
		if (newVariant != variant || payload.seed() != seed || pieces.length == 0) {
			variant = newVariant;
			seed = payload.seed();
			pieces = SunAnomalyShapes.build(variant, seed);
			sx = new float[pieces.length][];
			sy = new float[pieces.length][];
			for (int i = 0; i < pieces.length; i++) {
				sx[i] = new float[pieces[i].xy().length / 2];
				sy[i] = new float[pieces[i].xy().length / 2];
			}
			shownSinceMs = now;
		}
		baseTimeOfDay = payload.elevation();
		receivedMs = now;
		expiresMs = now + Math.max(1, payload.ticks()) * 50L;
	}

	static void reset() {
		clear();
		skyVisibility = 1.0;
	}

	private static void clear() {
		variant = 0;
		pieces = new SunAnomalyShapes.Piece[0];
		sx = new float[0][];
		sy = new float[0][];
		occAz = 1.0E9;
		occEl = 1.0E9;
	}

	static void extract(GuiGraphicsExtractor g, DeltaTracker deltaTracker, Minecraft minecraft, long now) {
		if (variant == 0 || pieces.length == 0) {
			return;
		}
		LocalPlayer player = minecraft.player;
		if (player == null || minecraft.level == null || !player.isAlive() || minecraft.gui.screen() != null) {
			return;
		}
		if (now > expiresMs || minecraft.level.dimension() != Level.OVERWORLD) {
			return;
		}

		// Güneşin gökteki yeri: sunucunun bildirdiği gün içi zamanı kendi saatimizle ilerlet (ay efektiyle aynı yöntem).
		double ticks = baseTimeOfDay + (now - receivedMs) / 50.0;
		double celestial = CallMoon.celestialAngle((long) ticks);
		double elevation = SunAnomalyLogic.sunElevationDegrees(celestial);
		if (elevation < -4.0) {
			return; // ufkun altında: görünürde güneş yok
		}

		// Açık gökyüzü ve hava: kapalı alanda ve yağmurda vanilla güneşi de görünmez/soluktur; üstüne kırık çizmek tutarsız olurdu.
		long dtMs = Math.max(0L, Math.min(100L, now - lastFrameMs));
		lastFrameMs = now;
		if (now - lastSkyCheckMs >= 250L) {
			lastSkyCheckMs = now;
			skyOpen = minecraft.level.canSeeSky(player.blockPosition());
		}
		double target = skyOpen && !minecraft.level.isRaining() ? 1.0 : 0.0;
		skyVisibility += (target - skyVisibility) * Math.min(1.0, dtMs / 900.0);
		double alpha = skyVisibility * OmenLogic.smooth((elevation + 3.0) / 9.0) * OmenLogic.smooth((now - shownSinceMs) / 6000.0);
		if (alpha <= 0.02) {
			return;
		}

		float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
		double yaw = player.getViewYRot(partial);
		double pitch = player.getViewXRot(partial);
		double[] frame = SunAnomalyShapes.frame(celestial);
		double[] look = CallMoon.lookVector(yaw, pitch);
		if (OmenGeometry.angleDegrees(look, new double[] {frame[0], frame[1], frame[2]}) > 85.0) {
			return; // güneş görüş alanının çok dışında
		}

		double fov = minecraft.options.fov().get();
		int width = g.guiWidth();
		int height = g.guiHeight();
		buildClips(minecraft, player, frame, elevation, yaw, pitch, fov, width, height, now);

		// Güneş karesinin köşeleri -> ekran (güneşin yerel eksenleri ve perspektifle)
		double half = SunAnomalyShapes.SUN_HALF_TAN;
		for (int i = 0; i < pieces.length; i++) {
			float[] xy = pieces[i].xy();
			for (int k = 0; k < xy.length / 2; k++) {
				double x = xy[k * 2];
				double y = xy[k * 2 + 1];
				double dx = frame[0] + half * (x * frame[3] + y * frame[6]);
				double dy = frame[1] + half * (x * frame[4] + y * frame[7]);
				double dz = frame[2] + half * (x * frame[5] + y * frame[8]);
				double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
				double[] p = OmenGeometry.projectClamped(new double[] {dx / len, dy / len, dz / len}, yaw, pitch, fov, width, height);
				sx[i][k] = (float) p[0];
				sy[i][k] = (float) p[1];
			}
		}

		int step = Math.max(2, Math.round(height / 240.0F));
		for (int i = 0; i < pieces.length; i++) {
			SunAnomalyShapes.Piece piece = pieces[i];
			float a = (float) (piece.alpha() * alpha);
			if (a < 0.012F) {
				continue;
			}
			// Kopmuş kısım simsiyah-mor; sönmüş bölge koyu kahve (güneşin ışığını yutar ama simsiyah değildir).
			int rgb = piece.dim() ? 0x1A0E08 : 0x05030A;
			OmenCanvas.fillPoly(g, sx[i], sy[i], OmenCanvas.argb(a, rgb), step, width, height, clipTop, clipBottom);
		}
	}

	/** Ufuğa yakın güneşte arazi/ağaç örtüsü: yalnızca alçak güneşte (yüksekte arazi gökyüzünü örtmez, tarama yapılmaz). */
	private static void buildClips(Minecraft minecraft, LocalPlayer player, double[] frame, double elevation, double yaw, double pitch,
			double fov, int width, int height, long now) {
		int chunks = width / OmenCanvas.CHUNK + 2;
		if (clipTop.length != chunks) {
			clipTop = new int[chunks];
			clipBottom = new int[chunks];
		}
		java.util.Arrays.fill(clipTop, -1_000_000);
		java.util.Arrays.fill(clipBottom, 1_000_000);
		if (elevation >= 28.0) {
			return;
		}
		double azimuth = Math.toDegrees(Math.atan2(-frame[0], frame[2]));
		// Geniş bir alanı bir kez yapılandır; güneş bu alanın ortasından belirgin uzaklaşınca yeniden (sık yeniden yapılandırma titretir).
		if (Math.abs(OmenGeometry.wrap180(azimuth - occAz)) > 9.0 || Math.abs(elevation - occEl) > 9.0) {
			occAz = azimuth;
			occEl = elevation;
			OCCLUSION.configure(azimuth, 22.0, Math.min(88.0, elevation + 14.0), Math.max(-3.0, elevation - 14.0));
		}
		OCCLUSION.update(minecraft.level, player.getEyePosition(), now);

		double prevX = 0.0;
		double prevY = 0.0;
		boolean prevOk = false;
		for (int i = 0; i <= OmenOcclusion.COLUMNS; i++) {
			float t = OCCLUSION.terrainAt(i);
			double e = t <= OmenOcclusion.NONE ? -25.0 : Math.max(-88.0, t);
			double[] p = OmenGeometry.projectClamped(OmenGeometry.direction(OCCLUSION.azimuthAt(i), e), yaw, pitch, fov, width, height);
			boolean ok = p[3] > 0.5;
			if (ok && prevOk) {
				applyBottomSegment(prevX, prevY, p[0], p[1], chunks);
			}
			prevX = p[0];
			prevY = p[1];
			prevOk = ok;
		}
	}

	private static void applyBottomSegment(double x0, double y0, double x1, double y1, int chunks) {
		double lo = Math.min(x0, x1);
		double hi = Math.max(x0, x1);
		int c0 = Math.max(0, (int) Math.floor(lo / OmenCanvas.CHUNK));
		int c1 = Math.min(chunks - 1, (int) Math.ceil(hi / OmenCanvas.CHUNK));
		for (int c = c0; c <= c1; c++) {
			double xc = c * OmenCanvas.CHUNK + OmenCanvas.CHUNK / 2.0;
			double t = x1 == x0 ? 0.0 : Math.max(0.0, Math.min(1.0, (xc - x0) / (x1 - x0)));
			double y = Math.max(-1_000_000.0, Math.min(1_000_000.0, y0 + t * (y1 - y0)));
			clipBottom[c] = Math.min(clipBottom[c], (int) y);
		}
	}
}
