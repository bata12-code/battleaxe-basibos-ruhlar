package com.battleaxe.client.call;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import com.battleaxe.call.CallMoon;
import com.battleaxe.call.CallSignPayload;

/**
 * Baltanın Çağrısı - ay işareti: ayın önünden çok kısa süre geçen karanlık bir balta silueti.
 *
 * <p>Gökyüzünü, ay dokusunu ya da dünya render sistemini DEĞİŞTİRMEZ. Silüet, ayın ekrandaki konumuna
 * (sunucunun gönderdiği gök açısı + oyuncunun kamera yönü + FOV'dan hesaplanır) HUD katmanında çizilir ve
 * yalnızca AY DİSKİNİN İÇİNDE görünür (karanlık gökyüzünde zaten görünmez olurdu): yani gerçekten "ayın önünden
 * geçiyor" gibi durur. Ay bir blokla örtülüyse (dağ, ağaç, çatı) hiç çizilmez; ekran açıkken ya da oyuncu
 * ölüyken de çizilmez. Yalnızca bu istemciye gelen pakete tepki verir: başka oyuncular etkilenmez.
 *
 * <p>Her karede birkaç düzine dikdörtgen çizer; ışın denetimi saniyede ~4 kez yapılır, nesne üretmez.
 */
public final class MoonAxeEffect {
	private MoonAxeEffect() {
	}

	/** Erişilebilirlik: false yaparsan ay silueti bu istemcide tamamen kapanır (ClientCameraShake.ENABLED gibi). */
	public static final boolean ENABLED = true;

	/** Silüetin en koyu anındaki en büyük opaklık (yoğunluğa göre ölçeklenir). */
	private static final float MAX_ALPHA = 0.88F;
	/** Ayın görünürlüğünü denetleyen ışının uzunluğu (blok) ve adımı. */
	private static final double OCCLUSION_RANGE = 72.0;
	private static final double OCCLUSION_STEP = 2.0;
	private static final long OCCLUSION_INTERVAL_MILLIS = 250L;
	/** Silüet ay yarıçapının bu katı kadar büyüklükte çizilir. */
	private static final double AXE_SIZE_IN_MOON_RADII = 1.25;

	/**
	 * Silüet: 20x20, '#' dolu. Sapı sol alttan sağ üste uzanan, sağ üstte geniş ağızlı bir savaş baltası.
	 */
	private static final String[] AXE = {
			"....................",
			"..........#######...",
			"..........#########.",
			"..........#########.",
			".........##########.",
			".........##########.",
			"..........#########.",
			"...........########.",
			"..........#########.",
			".........###..####..",
			"........###...##....",
			".......###.....#....",
			"......###...........",
			".....###............",
			"....###.............",
			"...###..............",
			"..###...............",
			".###................",
			"###.................",
			".#.................."
	};

	private static boolean active;
	private static long startMillis;
	private static long durationMillis;
	private static float celestialAtStart;
	private static int intensity;

	private static long lastOcclusionMillis;
	private static boolean occluded;

	public static void start(CallSignPayload payload) {
		if (!ENABLED || payload.kind() != CallSignPayload.KIND_MOON_AXE || payload.ticks() <= 0) {
			return;
		}
		active = true;
		startMillis = Util.getMillis();
		durationMillis = payload.ticks() * 50L;
		celestialAtStart = payload.celestial();
		intensity = Mth.clamp(payload.intensity(), 0, 2);
		lastOcclusionMillis = 0L;
		occluded = false;
	}

	/** Sunucudan ayrılınca çağrılır. */
	public static void reset() {
		active = false;
	}

	public static void extract(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		if (!active) {
			return;
		}
		long now = Util.getMillis();
		long elapsed = now - startMillis;
		if (elapsed >= durationMillis) {
			active = false;
			return;
		}
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || minecraft.level == null || !player.isAlive() || minecraft.gui.screen() != null) {
			return;
		}

		float t = elapsed / (float) durationMillis;

		// Ay yönü: başlangıç gök açısı + süre boyunca (çok küçük) kayma. Bir tick = 1/24000 gün = 0.015 derece.
		double celestial = celestialAtStart + (elapsed / 50.0) / 24000.0;
		double[] moon = CallMoon.moonDirection(celestial);

		float partial = deltaTracker.getGameTimeDeltaPartialTick(false);
		double yaw = player.getViewYRot(partial);
		double pitch = player.getViewXRot(partial);
		double fov = minecraft.options.fov().get();
		int width = graphics.guiWidth();
		int height = graphics.guiHeight();

		double[] screen = CallMoon.project(moon, yaw, pitch, fov, width, height);
		if (screen == null) {
			return;
		}
		double radius = CallMoon.MOON_RADIUS_TAN * screen[2];
		if (screen[0] < -radius || screen[0] > width + radius || screen[1] < -radius || screen[1] > height + radius) {
			return;
		}

		// Ay bir blokla örtülü mü? (Saniyede birkaç kez denetlenir, sonuç önbellekte tutulur.)
		if (now - lastOcclusionMillis >= OCCLUSION_INTERVAL_MILLIS) {
			lastOcclusionMillis = now;
			occluded = moonBlocked(minecraft, player, moon);
		}
		if (occluded) {
			return;
		}

		// Zarf: yumuşak belirme ve kaybolma.
		float envelope = smooth(t / 0.18F) * smooth((1.0F - t) / 0.22F);
		float alpha = MAX_ALPHA * envelope * (0.72F + 0.14F * intensity);
		if (alpha <= 0.01F) {
			return;
		}

		// Silüet, ay diskinin solundan sağına doğru (hafif yukarıdan aşağıya) süzülür.
		double travel = Mth.lerp(t, -1.35, 1.35) * radius;
		double sway = Mth.lerp(t, -0.22, 0.22) * radius;
		double centerX = screen[0] + travel;
		double centerY = screen[1] + sway;

		int pixel = Math.max(1, (int) Math.round(radius * AXE_SIZE_IN_MOON_RADII / AXE[0].length()));
		int size = AXE.length * pixel;
		int originX = (int) Math.round(centerX - size / 2.0);
		int originY = (int) Math.round(centerY - size / 2.0);
		int color = ((int) (alpha * 255.0F) << 24) | 0x040208;
		double clipSq = radius * radius;

		for (int row = 0; row < AXE.length; row++) {
			String line = AXE[row];
			for (int col = 0; col < line.length(); col++) {
				if (line.charAt(col) != '#') {
					continue;
				}
				int px = originX + col * pixel;
				int py = originY + row * pixel;
				// Yalnızca ay diskinin içindeki parçalar çizilir.
				double dx = px + pixel / 2.0 - screen[0];
				double dy = py + pixel / 2.0 - screen[1];
				if (dx * dx + dy * dy <= clipSq) {
					graphics.fill(px, py, px + pixel, py + pixel, color);
				}
			}
		}
	}

	/** Gözden ay yönüne giden ışın üzerinde hava olmayan bir blok var mı? (Yüklü olmayan parçalar hava sayılır.) */
	private static boolean moonBlocked(Minecraft minecraft, LocalPlayer player, double[] moon) {
		Level level = minecraft.level;
		Vec3 eye = player.getEyePosition();
		for (double d = OCCLUSION_STEP; d <= OCCLUSION_RANGE; d += OCCLUSION_STEP) {
			BlockPos pos = BlockPos.containing(eye.x + moon[0] * d, eye.y + moon[1] * d, eye.z + moon[2] * d);
			if (!level.getBlockState(pos).isAir()) {
				return true;
			}
		}
		return false;
	}

	private static float smooth(float v) {
		float c = Mth.clamp(v, 0.0F, 1.0F);
		return c * c * (3.0F - 2.0F * c);
	}
}
