package com.battleaxe.client.spirit;

import net.minecraft.client.renderer.entity.EntityRendererProvider;

import com.battleaxe.spirit.RuhYiyenEntity;

/** Ruh Yiyen çizicisi. */
public class RuhYiyenRenderer extends SpiritRenderer<RuhYiyenEntity, RuhYiyenModel> {
	public RuhYiyenRenderer(EntityRendererProvider.Context context) {
		super(context, new RuhYiyenModel(context.bakeLayer(RuhYiyenModel.LAYER)), 0.4F, "ruh_yiyen");
	}
}
