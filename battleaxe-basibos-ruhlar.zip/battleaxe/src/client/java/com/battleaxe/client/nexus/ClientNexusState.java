package com.battleaxe.client.nexus;

import net.minecraft.util.Util;

import com.battleaxe.nexus.NexusData;
import com.battleaxe.nexus.NexusResultPayload;
import com.battleaxe.nexus.NexusSyncPayload;

/** İstemcinin Ruh Ağı görünümü. Sunucudan gelen özetin kopyasıdır; hiçbir karar buna dayanmaz. */
public final class ClientNexusState {
	private ClientNexusState() {
	}

	private static NexusData data = NexusData.EMPTY;
	private static boolean synced;

	private static String message = "";
	private static boolean messageOk;
	private static long messageMillis;

	public static NexusData data() {
		return data;
	}

	public static boolean isSynced() {
		return synced;
	}

	public static void apply(NexusSyncPayload payload) {
		data = new NexusData(payload.unlocked(), payload.lifetimeSouls(), payload.earnedPoints(), payload.soulsSpent(), 0.0);
		synced = true;
	}

	public static void result(NexusResultPayload payload) {
		// Yalnızca bilinen ileti anahtarları kabul edilir.
		if (payload.messageKey().startsWith("nexus.msg.")) {
			message = payload.messageKey();
			messageOk = payload.ok();
			messageMillis = Util.getMillis();
		}
	}

	public static String message() {
		return Util.getMillis() - messageMillis < 3500L ? message : "";
	}

	public static boolean messageOk() {
		return messageOk;
	}

	public static void reset() {
		data = NexusData.EMPTY;
		synced = false;
		message = "";
	}
}
