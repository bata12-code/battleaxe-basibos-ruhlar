package com.battleaxe.client.evolution;

import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;

import com.battleaxe.evolution.EvolutionActionPayload;
import com.battleaxe.evolution.EvolutionConfig;
import com.battleaxe.evolution.EvolutionLogic;
import com.battleaxe.evolution.EvolutionPath;
import com.battleaxe.evolution.EvolutionStage;

/**
 * Berserker Evrimi ekranı: üç dalı gösterir, dal seçtirir, ustalığı ve kuralları anlatır.
 * İstemci yalnızca gösterir ve istek yollar; tüm kurallar (aşama, savaş, bekleme) sunucuda doğrulanır.
 * Ruh Ağı ekranından AYRIDIR ve onunla çakışmaz. Arka plan yarı saydamdır: sunucunun eylem çubuğu iletileri
 * (örn. "dal değiştirilemez: savaştasın") alt ortada okunabilir kalır.
 */
public final class EvolutionScreen extends Screen {
	private final List<Button> selectButtons = new ArrayList<>();

	public EvolutionScreen() {
		super(Component.translatable("evolution.screen.title"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	protected void init() {
		ClientPlayNetworking.send(new EvolutionActionPayload(EvolutionActionPayload.SYNC, 0));
		selectButtons.clear();

		int cardW = cardWidth();
		int gap = 10;
		int totalW = cardW * 3 + gap * 2;
		int startX = (width - totalW) / 2;
		int buttonY = cardTop() + cardHeight() - 26;
		for (EvolutionPath path : EvolutionPath.values()) {
			final int index = path.ordinal();
			int x = startX + index * (cardW + gap);
			Button button = Button.builder(Component.translatable("evolution.ui.select"), b ->
					ClientPlayNetworking.send(new EvolutionActionPayload(EvolutionActionPayload.SELECT_PATH, index)))
					.bounds(x + 8, buttonY, cardW - 16, 20).build();
			addRenderableWidget(button);
			selectButtons.add(button);
		}
		addRenderableWidget(Button.builder(Component.translatable("nexus.ui.close"), b -> onClose())
				.bounds(width - 66, 6, 60, 20).build());
	}

	private int cardWidth() {
		return Mth.clamp((width - 60) / 3, 120, 210);
	}

	private int cardHeight() {
		return 186;
	}

	private int cardTop() {
		return 62;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		g.fill(0, 0, width, height, 0xC8070510);
		g.fillGradient(0, 0, width, 44, 0xF0160F26, 0xF00B0714);
		g.fill(0, 43, width, 44, 0xFF3A2C5E);

		g.text(font, Component.translatable("evolution.screen.title").getString(), 10, 8, 0xFFFFE08A, true);
		g.text(font, statusSummary(), 10, 22, 0xFFC9C0E0, false);
		g.text(font, Component.translatable("evolution.ui.keys").getString(), 10, 33, 0xFF8F86A8, false);

		EvolutionPath current = ClientEvolutionState.path();
		int cardW = cardWidth();
		int gap = 10;
		int startX = (width - (cardW * 3 + gap * 2)) / 2;
		long millis = Util.getMillis();

		for (EvolutionPath path : EvolutionPath.values()) {
			int x = startX + path.ordinal() * (cardW + gap);
			drawCard(g, path, x, cardTop(), cardW, cardHeight(), path == current, millis);
		}

		// Seçim butonlarının durumu (sunucu yine de doğrular)
		for (EvolutionPath path : EvolutionPath.values()) {
			Button button = selectButtons.get(path.ordinal());
			boolean selected = path == current;
			boolean allowed = canSelectLocally(path);
			button.active = !selected && allowed;
			button.setMessage(Component.translatable(selected ? "evolution.ui.selected" : "evolution.ui.select"));
		}

		// Kurallar
		int ruleY = cardTop() + cardHeight() + 8;
		for (String line : wrap(rulesText(), width - 40)) {
			g.text(font, line, 20, ruleY, 0xFF8F86A8, false);
			ruleY += 10;
		}

		super.extractRenderState(g, mouseX, mouseY, partialTick);
	}

	private void drawCard(GuiGraphicsExtractor g, EvolutionPath path, int x, int y, int w, int h, boolean selected, long millis) {
		int rgb = path.rgb;
		g.fillGradient(x, y, x + w, y + h, 0xE0160F26, 0xE00B0714);
		float pulse = 0.5F + 0.5F * Mth.sin((millis % 100_000L) * 0.005F);
		int borderAlpha = selected ? (int) (170 + 85 * pulse) : 110;
		g.outline(x, y, w, h, argb(borderAlpha, rgb));
		g.fill(x, y, x + w, y + 3, argb(255, rgb));

		int tx = x + 8;
		int maxW = w - 16;
		int cursor = y + 9;
		g.text(font, Component.translatable(path.nameKey()).getString(), tx, cursor, argb(255, brighten(rgb)), true);
		cursor += 13;
		for (String line : wrap(Component.translatable(path.descriptionKey()).getString(), maxW)) {
			g.text(font, line, tx, cursor, 0xFFE8E2F5, false);
			cursor += 10;
		}
		cursor += 3;
		for (String line : wrap(Component.translatable("evolution.ui.limit").getString() + " "
				+ Component.translatable(path.limitKey()).getString(), maxW)) {
			g.text(font, line, tx, cursor, 0xFFFF8A6B, false);
			cursor += 10;
		}

		// Ustalık
		int points = ClientEvolutionState.masteryPoints(path);
		int level = EvolutionLogic.masteryLevel(points);
		int next = EvolutionLogic.nextMasteryThreshold(points);
		int mY = y + h - 54;
		String mastery = Component.translatable("evolution.ui.mastery", level, next < 0
				? Integer.toString(points) : points + "/" + next).getString();
		g.text(font, mastery, tx, mY, 0xFFC9C0E0, false);
		g.fill(tx, mY + 11, tx + maxW, mY + 15, 0xFF08050E);
		g.fill(tx + 1, mY + 12, tx + 1 + (int) ((maxW - 2) * EvolutionLogic.masteryProgress(points)), mY + 14, argb(255, rgb));
	}

	private String statusSummary() {
		EvolutionPath path = ClientEvolutionState.path();
		String stage = Component.translatable(ClientEvolutionState.stage() == EvolutionStage.NONE
				? "evolution.stage.0" : "evolution.stage." + ClientEvolutionState.stage().level).getString();
		String pathName = path == null ? Component.translatable("evolution.hud.no_path").getString()
				: Component.translatable(path.nameKey()).getString();
		return Component.translatable("evolution.ui.summary", pathName, stage, ClientEvolutionState.essence(),
				(int) EvolutionConfig.MAX_ESSENCE).getString();
	}

	/** Yerel tahmin (yalnızca düğmeyi pasifleştirmek için): kesin karar sunucudadır. */
	private boolean canSelectLocally(EvolutionPath target) {
		if (!ClientEvolutionState.hasData()) {
			return true;
		}
		EvolutionPath current = ClientEvolutionState.path();
		if (current == null) {
			return true;
		}
		return ClientEvolutionState.stage() == EvolutionStage.NONE && ClientEvolutionState.pathCooldownLeft() <= 0
				&& target != current;
	}

	private String rulesText() {
		int cooldown = ClientEvolutionState.pathCooldownLeft();
		String base = Component.translatable("evolution.ui.rules", EvolutionConfig.PATH_CHANGE_COOLDOWN_TICKS / 1200).getString();
		if (cooldown > 0) {
			base += " " + Component.translatable("evolution.ui.rules_wait", (cooldown + 19) / 20).getString();
		}
		return base;
	}

	private List<String> wrap(String text, int maxWidth) {
		List<String> lines = new ArrayList<>();
		StringBuilder current = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = current.length() == 0 ? word : current + " " + word;
			if (font.width(candidate) > maxWidth && current.length() > 0) {
				lines.add(current.toString());
				current = new StringBuilder(word);
			} else {
				current = new StringBuilder(candidate);
			}
		}
		if (current.length() > 0) {
			lines.add(current.toString());
		}
		return lines;
	}

	private static int argb(int alpha, int rgb) {
		return (Mth.clamp(alpha, 0, 255) << 24) | (rgb & 0xFFFFFF);
	}

	private static int brighten(int rgb) {
		int r = ((rgb >> 16) & 0xFF) + (255 - ((rgb >> 16) & 0xFF)) / 4;
		int g = ((rgb >> 8) & 0xFF) + (255 - ((rgb >> 8) & 0xFF)) / 4;
		int b = (rgb & 0xFF) + (255 - (rgb & 0xFF)) / 4;
		return (r << 16) | (g << 8) | b;
	}
}
