package com.battleaxe.client.spirit;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.spirit.SavrulmusLogic;

/**
 * Savrulmuş Ruh: eğri, öne çökmüş gövde; normalden uzun kollar ve pençe benzeri parmaklar; yüzü boş ve karanlık; bacak yok,
 * gövde ayaksız süzülen uzayıp incelen sisle biter. Silüet: öne eğik, yere sarkan kollu, yatay yayılan.
 * Parça yapısı ve doku: tools/gen_spirit_assets.py (SavrulmusParts). Toplam boy ~31 piksel (~1.9 blok).
 */
public class SavrulmusModel extends SpiritModel {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(BattleAxeMod.id("savrulmus_ruh"), "main");

	private final ModelPart torso;
	private final ModelPart head;
	private final ModelPart armR;
	private final ModelPart armL;
	private final ModelPart[] clawsR = new ModelPart[3];
	private final ModelPart[] clawsL = new ModelPart[3];
	private final ModelPart wispA;
	private final ModelPart wispB;
	private final ModelPart wispC;

	public SavrulmusModel(ModelPart root) {
		super(root);
		this.torso = part(rig.getChild("torso"));
		this.head = part(torso.getChild("head"));
		part(head.getChild("splinter_r"));
		part(head.getChild("splinter_l"));
		part(torso.getChild("spine_0"));
		part(torso.getChild("spine_1"));
		this.armR = part(torso.getChild("arm_r"));
		ModelPart handR = part(armR.getChild("hand_r"));
		this.armL = part(torso.getChild("arm_l"));
		ModelPart handL = part(armL.getChild("hand_l"));
		for (int i = 0; i < 3; i++) {
			clawsR[i] = part(handR.getChild("claw_r_" + i));
			clawsL[i] = part(handL.getChild("claw_l_" + i));
		}
		this.wispA = part(rig.getChild("wisp_a"));
		this.wispB = part(wispA.getChild("wisp_b"));
		this.wispC = part(wispB.getChild("wisp_c"));
	}

	public static LayerDefinition createBodyLayer() {
		return SavrulmusParts.create();
	}

	@Override
	public void setupAnim(SpiritRenderState state) {
		super.setupAnim(state);
		resetParts();

		float t = state.ageInTicks;
		float walk = Mth.clamp(state.walkAnimationSpeed, 0.0F, 1.0F);
		float pos = state.walkAnimationPos * 0.6662F;
		float p = Mth.clamp(state.progress, 0.0F, 1.0F);
		SavrulmusLogic.Attack attack = SavrulmusLogic.Attack.byOrdinal(state.attack);

		float lean = 0.45F + walk * 0.3F;
		float torsoX = lean;
		float torsoY = 0.0F;
		float torsoZ = 0.0F;
		float headX = -0.4F;
		float armRX = 0.15F + Mth.cos(pos) * walk * 0.9F;
		float armLX = 0.15F + Mth.cos(pos + Mth.PI) * walk * 0.9F;
		float armRZ = -0.12F;
		float armLZ = 0.12F;
		float splay = 0.3F + Mth.sin(t * 0.3F) * 0.05F;
		float wispLean = -0.1F - walk * 0.5F;
		float drop = 0.0F;

		switch (attack) {
			case CLAW_WINDUP -> {
				float e = ease(p);
				torsoY = 0.6F * e;
				torsoX = Mth.lerp(e, lean, 0.9F);
				armRX = Mth.lerp(e, armRX, 1.1F);
				armLX = Mth.lerp(e, armLX, -0.3F);
				armRZ = -0.5F * e;
				splay = 0.8F;
			}
			case CLAW_SWING -> {
				float s = snap(p);
				torsoY = Mth.lerp(s, 0.6F, -0.5F);
				torsoX = Mth.lerp(s, 0.9F, 0.55F);
				armRX = Mth.lerp(s, 1.1F, -1.9F);
				armLX = Mth.lerp(s, -0.3F, -1.9F);
				armRZ = -0.15F;
				splay = 0.9F;
			}
			case RETREAT -> {
				torsoX = -0.05F;
				headX = -0.1F;
				armRX = -0.9F;
				armLX = -0.9F;
				wispLean = -0.5F;
			}
			case LEAP_WINDUP -> {
				float e = ease(p);
				torsoX = Mth.lerp(e, lean, 1.1F);
				armRX = Mth.lerp(e, armRX, 1.3F);
				armLX = Mth.lerp(e, armLX, 1.3F);
				drop = 2.5F * e;
				wispLean = -0.1F + 0.6F * e;
				splay = 0.9F;
			}
			case LEAP_AIR -> {
				torsoX = 0.1F;
				headX = -0.2F;
				armRX = -2.5F;
				armLX = -2.5F;
				wispLean = -0.8F;
				splay = 1.0F;
			}
			case LEAP_RECOVER -> {
				torsoX = Mth.lerp(p, 1.0F, 0.7F);
				headX = 0.5F;
				armRX = 0.5F;
				armLX = 0.5F;
				drop = 1.5F;
				torsoZ = Mth.sin(t * 1.4F) * 0.07F;
			}
			default -> {
			}
		}
		if (state.exposed) {
			torsoZ += Mth.sin(t * 1.5F) * 0.05F;
		}

		rig.y = rigBaseY + Mth.sin(t * 0.12F) * 1.0F + drop;
		torso.xRot = torsoX;
		torso.yRot = torsoY;
		torso.zRot = torsoZ;
		head.xRot = headX + state.xRot * Mth.DEG_TO_RAD;
		head.yRot = state.yRot * Mth.DEG_TO_RAD - torsoY * 0.6F;
		armR.xRot = armRX;
		armR.zRot = armRZ;
		armL.xRot = armLX;
		armL.zRot = armLZ;
		for (int i = 0; i < 3; i++) {
			float side = (i - 1) * 0.25F;
			clawsR[i].xRot = -splay;
			clawsR[i].zRot = side * (0.6F + splay);
			clawsL[i].xRot = -splay;
			clawsL[i].zRot = side * (0.6F + splay);
		}
		wispA.xRot = wispLean + Mth.sin(t * 0.15F) * 0.1F;
		wispB.xRot = Mth.sin(t * 0.2F) * 0.15F - walk * 0.3F;
		wispC.xRot = Mth.sin(t * 0.25F + 1.0F) * 0.25F;
		wispA.zRot = Mth.sin(t * 0.13F) * 0.08F;

		applyShatter(state.shatter);
	}
}
