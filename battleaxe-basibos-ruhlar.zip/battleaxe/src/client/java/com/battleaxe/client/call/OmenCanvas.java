package com.battleaxe.client.call;

import net.minecraft.client.gui.GuiGraphicsExtractor;

import com.battleaxe.call.OmenLogic;
import com.battleaxe.call.OmenShapes;

/**
 * Öncü belirtilerin çizim araçları: çokgenleri yatay şeritlerle doldurur (yalnızca {@code fill}; yeni render API'si yok),
 * kenarları ince çizgiyle vurgular ve arazi/bulut örtüsünü ({@code clipTop}/{@code clipBottom}) uygular.
 *
 * <p>Örtü dizileri ekranı {@link #CHUNK} piksellik sütunlara böler: bir sütunun {@code clipTop}'un altında ve
 * {@code clipBottom}'ın üstündeki pikselleri görünürdür. Bu sayede devasa siluet dağın, ağacın ya da bulutun
 * ARKASINDA kalır (ekrana yapıştırılmış düz bir resim gibi durmaz). Statik ve nesne üretmez.
 */
final class OmenCanvas {
	private OmenCanvas() {
	}

	static final int CHUNK = 4;

	/** Satır başına en fazla kesişim (çift-tek dolgu). Halka çokgenleri için fazlasıyla yeterli. */
	private static final float[] CUTS = new float[256];

	/** Stil rengi (RGB). */
	static int rgb(int style) {
		return switch (style) {
			case OmenShapes.S_AURA -> 0x1C0A33;
			case OmenShapes.S_BODY -> 0x050209;
			case OmenShapes.S_MID -> 0x2B0F4C;
			case OmenShapes.S_DEEP -> 0x000000;
			case OmenShapes.S_VOID -> 0x000004;
			case OmenShapes.S_EMBER -> 0x4A0A14;
			case OmenShapes.S_HAZE -> 0x9AA6BC;
			default -> 0xD6CCEE;
		};
	}

	/**
	 * Stil rengi, gün zamanına göre: yalnızca ufuk sisi ({@link OmenShapes#S_HAZE}) renk değiştirir (gündüz soluk gri-mavi, alacakaranlıkta
	 * morumsu, gece koyu lacivert); diğer stiller sabittir. Bu, atmosferik perspektifin gökyüzüyle uyumlu görünmesini sağlar.
	 */
	static int rgb(int style, int tone) {
		if (style == OmenShapes.S_HAZE) {
			return switch (tone) {
				case OmenLogic.TONE_NIGHT -> 0x141A2E;
				case OmenLogic.TONE_TWILIGHT -> 0x4A3A5C;
				default -> 0x9AA6BC;
			};
		}
		return rgb(style);
	}

	/** Stilin temel saydamlığı (0..1). Aura çok soluk, gövde neredeyse opak. */
	static float baseAlpha(int style) {
		return switch (style) {
			case OmenShapes.S_AURA -> 0.20F;
			case OmenShapes.S_BODY -> 0.93F;
			case OmenShapes.S_MID -> 0.86F;
			case OmenShapes.S_DEEP -> 1.0F;
			case OmenShapes.S_VOID -> 1.0F;
			case OmenShapes.S_HAZE -> 1.0F;
			case OmenShapes.S_EMBER -> 0.95F;
			default -> 0.55F;
		};
	}

	static int argb(float alpha, int rgb) {
		int a = Math.max(0, Math.min(255, (int) (alpha * 255.0F)));
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	/** Çokgeni doldurur. {@code clipTop}/{@code clipBottom} {@code null} olabilir (örtü yok). */
	static void fillPoly(GuiGraphicsExtractor g, float[] xs, float[] ys, int argb, int step, int width, int height,
			int[] clipTop, int[] clipBottom) {
		int n = xs.length;
		float minY = Float.MAX_VALUE;
		float maxY = -Float.MAX_VALUE;
		for (int i = 0; i < n; i++) {
			minY = Math.min(minY, ys[i]);
			maxY = Math.max(maxY, ys[i]);
		}
		int y0 = Math.max(0, (int) Math.floor(minY));
		int y1 = Math.min(height, (int) Math.ceil(maxY));
		for (int y = y0; y < y1; y += step) {
			float yc = y + step * 0.5F;
			int count = 0;
			for (int i = 0; i < n; i++) {
				int j = i + 1 == n ? 0 : i + 1;
				float ya = ys[i];
				float yb = ys[j];
				if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
					float x = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
					if (count < CUTS.length) {
						CUTS[count++] = x;
					}
				}
			}
			if (count < 2) {
				continue;
			}
			// Ekleme sıralaması: kesişim sayısı küçüktür.
			for (int a = 1; a < count; a++) {
				float v = CUTS[a];
				int b = a - 1;
				while (b >= 0 && CUTS[b] > v) {
					CUTS[b + 1] = CUTS[b];
					b--;
				}
				CUTS[b + 1] = v;
			}
			int yEnd = Math.min(height, y + step);
			for (int k = 0; k + 1 < count; k += 2) {
				span(g, CUTS[k], CUTS[k + 1], y, yEnd, yc, argb, width, clipTop, clipBottom);
			}
		}
	}

	private static void span(GuiGraphicsExtractor g, float a, float b, int y, int yEnd, float yc, int argb, int width,
			int[] clipTop, int[] clipBottom) {
		int x0 = Math.max(0, (int) Math.ceil(a));
		int x1 = Math.min(width, (int) Math.floor(b));
		if (x1 <= x0) {
			return;
		}
		if (clipTop == null && clipBottom == null) {
			g.fill(x0, y, x1, yEnd, argb);
			return;
		}
		int runStart = -1;
		int firstChunk = x0 / CHUNK;
		int lastChunk = (x1 - 1) / CHUNK;
		for (int c = firstChunk; c <= lastChunk; c++) {
			boolean visible = (clipTop == null || c >= clipTop.length || yc >= clipTop[c])
					&& (clipBottom == null || c >= clipBottom.length || yc < clipBottom[c]);
			int cx0 = Math.max(x0, c * CHUNK);
			int cx1 = Math.min(x1, (c + 1) * CHUNK);
			if (visible) {
				if (runStart < 0) {
					runStart = cx0;
				}
				if (c == lastChunk) {
					g.fill(runStart, y, cx1, yEnd, argb);
					runStart = -1;
				}
			} else if (runStart >= 0) {
				g.fill(runStart, y, cx0, yEnd, argb);
				runStart = -1;
			}
		}
	}

	/** Kenar vurgusu: köşeler arası ince noktalı çizgi (2x2 piksel). */
	static void outline(GuiGraphicsExtractor g, float[] xs, float[] ys, int argb, int width, int height, int[] clipTop, int[] clipBottom) {
		int n = xs.length;
		for (int i = 0; i < n; i++) {
			int j = i + 1 == n ? 0 : i + 1;
			float x0 = xs[i];
			float y0 = ys[i];
			float x1 = xs[j];
			float y1 = ys[j];
			if ((x0 < 0 && x1 < 0) || (x0 > width && x1 > width) || (y0 < 0 && y1 < 0) || (y0 > height && y1 > height)) {
				continue;
			}
			float len = (float) Math.hypot(x1 - x0, y1 - y0);
			if (len > 6000.0F) {
				continue;
			}
			int steps = Math.max(1, (int) (len / 3.0F));
			for (int s = 0; s <= steps; s++) {
				float t = s / (float) steps;
				int x = (int) (x0 + (x1 - x0) * t);
				int y = (int) (y0 + (y1 - y0) * t);
				if (x < 0 || y < 0 || x >= width || y >= height || !visible(x, y, clipTop, clipBottom)) {
					continue;
				}
				g.fill(x, y, x + 2, y + 2, argb);
			}
		}
	}

	/** Seyrek, küçük beyaz-leylak kıvılcım (artı biçimli). */
	static void glint(GuiGraphicsExtractor g, int x, int y, int arm, int argb, int width, int height, int[] clipTop, int[] clipBottom) {
		if (x < 0 || y < 0 || x >= width || y >= height || !visible(x, y, clipTop, clipBottom)) {
			return;
		}
		g.fill(x - 1, y - 1, x + 2, y + 2, argb);
		g.fill(x - arm, y, x + arm + 1, y + 1, argb);
		g.fill(x, y - arm, x + 1, y + arm + 1, argb);
	}

	private static boolean visible(int x, int y, int[] clipTop, int[] clipBottom) {
		int c = x / CHUNK;
		return (clipTop == null || c >= clipTop.length || y >= clipTop[c])
				&& (clipBottom == null || c >= clipBottom.length || y < clipBottom[c]);
	}
}
