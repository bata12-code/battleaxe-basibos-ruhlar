package com.battleaxe.client.boss;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

import com.battleaxe.boss.KaraKorukLogic;

/** Kara Körük çizimi için gereken veriler. */
public class KaraKorukRenderState extends LivingEntityRenderState {
	/** Dövme Darbesi hazırlığının ilerlemesi (0-1): eski alan, uyumluluk için korunur. */
	public float slamProgress;
	/** Sunucudaki saldırı durumu ve o durumun ilerlemesi (0-1): çekiç animasyonunu sürer. */
	public KaraKorukLogic.Attack attack = KaraKorukLogic.Attack.IDLE;
	public float attackProgress;
	/** İkinci savaş aşaması: çekiç daha kızgın görünür. */
	public boolean phaseTwo;
}
