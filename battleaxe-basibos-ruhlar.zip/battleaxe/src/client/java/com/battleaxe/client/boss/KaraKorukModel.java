package com.battleaxe.client.boss;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartNames;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import com.battleaxe.BattleAxeMod;
import com.battleaxe.boss.KaraKorukLogic;

/**
 * Kara Körük'ün modeli: iri yapılı, uzun kollu, Enderman ve Piglin karışımı bir demirci.
 * Toplam boy 44 piksel (~2.75 blok). Doku 128x128, kutuların standart açılım düzenindedir.
 */
public class KaraKorukModel extends EntityModel<KaraKorukRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(BattleAxeMod.id("kara_koruk"), "main");

	private final ModelPart head;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;
	private final ModelPart hammer;

	public KaraKorukModel(ModelPart root) {
		super(root);
		this.head = root.getChild(PartNames.HEAD);
		this.rightArm = root.getChild(PartNames.RIGHT_ARM);
		this.leftArm = root.getChild(PartNames.LEFT_ARM);
		this.rightLeg = root.getChild(PartNames.RIGHT_LEG);
		this.leftLeg = root.getChild(PartNames.LEFT_LEG);
		this.hammer = this.rightArm.getChild("hammer");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		PartDefinition head = root.addOrReplaceChild(PartNames.HEAD,
				CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -10.0F, -5.0F, 10.0F, 10.0F, 10.0F),
				PartPose.offset(0.0F, -10.0F, 0.0F));
		// Piglin kökeni: yassı kulaklar, ağır kaş çıkıntısı ve küçük bir burun. Ağız yok (kapalı, gölgede).
		head.addOrReplaceChild("right_ear",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1.0F, 0.0F, -1.5F, 1.0F, 5.0F, 3.0F),
				PartPose.offset(-5.0F, -8.0F, 0.0F));
		head.addOrReplaceChild("left_ear",
				CubeListBuilder.create().texOffs(96, 10).addBox(0.0F, 0.0F, -1.5F, 1.0F, 5.0F, 3.0F),
				PartPose.offset(5.0F, -8.0F, 0.0F));
		head.addOrReplaceChild("brow",
				CubeListBuilder.create().texOffs(96, 20).addBox(-5.0F, -8.0F, -6.0F, 10.0F, 2.0F, 1.0F),
				PartPose.ZERO);
		head.addOrReplaceChild("snout",
				CubeListBuilder.create().texOffs(96, 26).addBox(-2.0F, -4.0F, -6.0F, 4.0F, 3.0F, 1.0F),
				PartPose.ZERO);

		PartDefinition body = root.addOrReplaceChild(PartNames.BODY,
				CubeListBuilder.create().texOffs(0, 22).addBox(-6.0F, 0.0F, -3.0F, 12.0F, 18.0F, 6.0F),
				PartPose.offset(0.0F, -10.0F, 0.0F));
		// Demirci önlüğü
		body.addOrReplaceChild("apron",
				CubeListBuilder.create().texOffs(96, 32).addBox(-4.0F, 6.0F, -4.0F, 8.0F, 12.0F, 1.0F),
				PartPose.ZERO);

		PartDefinition rightArm = root.addOrReplaceChild(PartNames.RIGHT_ARM,
				CubeListBuilder.create().texOffs(40, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 20.0F, 6.0F),
				PartPose.offset(-9.0F, -8.0F, 0.0F));
		// Demirci çekici: sağ kola bağlıdır (kolla birlikte döner). Uzun ekseni kolun ekseniyle aynıdır: kol yukarı
		// kalkınca baş yukarıda, kol öne inince baş önde olur. Vuruş yüzleri ileri-geri (z) bakar, yani savurma
		// düzleminde. Doku düzeni tools/gen_hammer_texture.py ile birebir aynıdır (kutular 128x128 dokuda y >= 66).
		rightArm.addOrReplaceChild("hammer",
				CubeListBuilder.create()
						.texOffs(0, 66).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 29.0F, 2.0F)
						.texOffs(50, 66).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 2.0F, 3.0F)
						.texOffs(50, 74).addBox(-1.5F, 3.0F, -1.5F, 3.0F, 2.0F, 3.0F)
						.texOffs(0, 100).addBox(-4.0F, 22.0F, -7.0F, 8.0F, 9.0F, 14.0F),
				PartPose.offset(0.0F, 17.0F, -4.0F));

		root.addOrReplaceChild(PartNames.LEFT_ARM,
				CubeListBuilder.create().texOffs(64, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 20.0F, 6.0F),
				PartPose.offset(9.0F, -8.0F, 0.0F));

		root.addOrReplaceChild(PartNames.RIGHT_LEG,
				CubeListBuilder.create().texOffs(40, 28).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 16.0F, 6.0F),
				PartPose.offset(-3.5F, 8.0F, 0.0F));

		root.addOrReplaceChild(PartNames.LEFT_LEG,
				CubeListBuilder.create().texOffs(64, 28).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 16.0F, 6.0F),
				PartPose.offset(3.5F, 8.0F, 0.0F));

		return LayerDefinition.create(mesh, 128, 128);
	}

	@Override
	public void setupAnim(KaraKorukRenderState state) {
		super.setupAnim(state);

		this.head.xRot = state.xRot * Mth.DEG_TO_RAD;
		this.head.yRot = state.yRot * Mth.DEG_TO_RAD;

		// Yürüyüş: bacaklar ve kollar ters yönde sallanır.
		float swing = state.walkAnimationSpeed;
		float pos = state.walkAnimationPos * 0.6662F;
		this.rightLeg.xRot = Mth.cos(pos) * 1.2F * swing;
		this.leftLeg.xRot = Mth.cos(pos + Mth.PI) * 1.2F * swing;
		this.rightArm.xRot = Mth.cos(pos + Mth.PI) * 0.9F * swing;
		this.leftArm.xRot = Mth.cos(pos) * 0.9F * swing;

		// ---- Çekiç duruşu ve saldırı animasyonları (sunucudan gelen durum + ilerleme ile) ----
		float rest = REST_ARM;
		float walkRight = this.rightArm.xRot;
		float walkLeft = this.leftArm.xRot;
		float rightX = rest + walkRight * 0.25F; // çekiç elindeyken kol az sallanır
		float leftX = walkLeft;
		float rightY = -0.12F;
		float p = Mth.clamp(state.attackProgress, 0.0F, 1.0F);

		switch (state.attack) {
			case SLAM_WINDUP -> {
				// Çekiç başın üstüne kalkar (zemindeki halkayla birlikte uyarı).
				float raise = Mth.lerp(ease(p), rest, RAISED);
				rightX = raise;
				leftX = Mth.lerp(ease(p), walkLeft, RAISED + 0.1F);
			}
			case SLAM_RECOVER -> {
				// Hızlı iniş, yerde kısa bekleyiş, sonra duruşa dönüş.
				float down;
				if (p < 0.3F) {
					float t = p / 0.3F;
					down = Mth.lerp(t * t, RAISED, SLAM_END);
				} else if (p < 0.75F) {
					down = SLAM_END;
				} else {
					down = Mth.lerp((p - 0.75F) / 0.25F, SLAM_END, rest);
				}
				rightX = down;
				leftX = Mth.lerp(Mth.clamp(p / 0.4F, 0.0F, 1.0F), RAISED + 0.1F, SLAM_END + 0.15F);
			}
			case EMBER_WINDUP -> {
				// Çekiç omuz üstüne geri çekilir; sol kol dengeler.
				rightX = Mth.lerp(ease(p), rest, COCKED);
				rightY = Mth.lerp(ease(p), -0.12F, -0.45F);
				leftX = Mth.lerp(ease(p), walkLeft, -0.8F);
			}
			case EMBER_SWING -> {
				// Hızlı ileri savurma: mermi çekicin ileri geldiği anda çıkar.
				float strike = 1.0F - (1.0F - p) * (1.0F - p);
				rightX = Mth.lerp(strike, COCKED, SWING_END);
				rightY = Mth.lerp(strike, -0.45F, -0.12F);
				leftX = -0.8F;
			}
			case CHARGE_WINDUP -> {
				// Çekiç yana/geriye alınır, vücut hücuma hazırlanır.
				rightX = Mth.lerp(ease(p), rest, CHARGE_ARM);
				leftX = Mth.lerp(ease(p), walkLeft, -0.5F);
			}
			case CHARGING -> {
				rightX = CHARGE_ARM + Mth.cos(state.ageInTicks * 0.9F) * 0.06F;
				leftX = -0.6F + Mth.cos(state.ageInTicks * 0.9F + 1.0F) * 0.1F;
			}
			case CHARGE_RECOVER -> {
				rightX = Mth.lerp(ease(p), CHARGE_ARM, rest);
				leftX = Mth.lerp(ease(p), -0.5F, walkLeft);
			}
			case IDLE -> {
			}
		}

		this.rightArm.xRot = rightX;
		this.rightArm.yRot = rightY;
		this.leftArm.xRot = leftX;

		// Çekiç, kolun ekseninde sabit kalır; ikinci aşamada hafif titrer (kızgın hâl).
		this.hammer.xRot = 0.0F;
		if (state.phaseTwo) {
			this.hammer.zRot = Mth.sin(state.ageInTicks * 0.8F) * 0.03F;
		}
	}

	/** Yumuşak başlangıç/bitiş. */
	private static float ease(float t) {
		return t * t * (3.0F - 2.0F * t);
	}

	// Kol açıları (radyan; negatif = öne/yukarı). Kol aşağı sarkarken 0, öne düz uzanırken -PI/2.
	private static final float REST_ARM = -1.15F;
	private static final float RAISED = -2.75F;
	private static final float SLAM_END = -0.75F;
	private static final float COCKED = -2.3F;
	private static final float SWING_END = -0.7F;
	private static final float CHARGE_ARM = 0.55F;
}
