package com.battleaxe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;

import com.battleaxe.thrown.ThrownBattleAxe;

/**
 * Fırlatılmış baltayı çizer: havadayken kendi etrafında döner, saplandığında sabit bir açıyla durur.
 * Balta, elindeki eşyanın mevcut modelini ve dokusunu kullanır (rütbe görünümü dahil).
 */
public class ThrownBattleAxeRenderer extends EntityRenderer<ThrownBattleAxe, ThrownBattleAxeRenderState> {
	/** Havada dönüş hızı (derece/tick). */
	private static final float SPIN_DEGREES_PER_TICK = 38.0F;
	/** Sadakat ile dönerken daha hızlı döner. */
	private static final float RETURN_SPIN_FACTOR = 1.8F;
	/** Saplanmış balta açısı (başı aşağı-ileri bakar) ve baltaya göre küçük sapma. */
	private static final float STUCK_ANGLE = -52.0F;
	/** Ağır bir balta olduğu için normal eşyadan büyük çizilir. */
	private static final float SCALE = 2.4F;

	private final ItemModelResolver itemModelResolver;

	public ThrownBattleAxeRenderer(EntityRendererProvider.Context context) {
		super(context);
		this.itemModelResolver = context.getItemModelResolver();
	}

	@Override
	public ThrownBattleAxeRenderState createRenderState() {
		return new ThrownBattleAxeRenderState();
	}

	@Override
	public void extractRenderState(ThrownBattleAxe entity, ThrownBattleAxeRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.stuck = entity.isStuck();
		state.returning = entity.isReturning();
		state.yaw = entity.getYRot();
		state.variant = entity.getId();
		this.itemModelResolver.updateForNonLiving(state.item, entity.getItem(), ItemDisplayContext.GROUND, entity);
	}

	@Override
	public void submit(ThrownBattleAxeRenderState state, PoseStack poseStack,
			SubmitNodeCollector submitNodeCollector, CameraRenderState cameraRenderState) {
		poseStack.pushPose();

		// Balta düzlemi uçuş yönünü içerir; sonra kendi düzleminde döner (ya da saplı açıda durur).
		poseStack.mulPose(Axis.YP.rotationDegrees(-90.0F - state.yaw));
		float angle = state.stuck
				? STUCK_ANGLE + (state.variant % 7) * 3.0F - 9.0F
				: -(state.ageInTicks * SPIN_DEGREES_PER_TICK * (state.returning ? RETURN_SPIN_FACTOR : 1.0F));
		poseStack.mulPose(Axis.ZP.rotationDegrees(angle));
		poseStack.scale(SCALE, SCALE, SCALE);

		state.item.submit(poseStack, submitNodeCollector, state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);

		poseStack.popPose();
		super.submit(state, poseStack, submitNodeCollector, cameraRenderState);
	}
}
