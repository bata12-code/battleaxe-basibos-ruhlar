# Savaş Baltası (Battle Axe) – Fabric, Minecraft 26.2

Oyuna **Savaş Baltası** ekler. Kılıç gibi çalışır (süpürme vuruşu, ağ kesme, kılıç büyüleri), **16 hasar** vurur ama **yavaştır**.

| Özellik | Değer |
|---|---|
| Toplam hasar | 16 (yumruk hasarı dahil) |
| Saldırı hızı | 0.8 (netherit kılıç 1.6, netherit balta 1.0) |
| Dayanıklılık | 2500 |
| Büyü değeri | 15 |
| Onarım | Örste obsidyen ile |

## Tarif

```
 O  N  O        O = Obsidyen (5)
 O  B  O        N = Nether Yıldızı (1)
    B           B = Blaze Çubuğu (2)
```

Yaratıcı modda "Savaş" sekmesinin sonunda bulunur.

## Kritik vuruş efektleri

Savaş Baltası ile **vanilla kritik vuruş** yaptığında (tam şarjlı, düşerek vuruş) vuruş noktasında
iki efektten biri rastgele oynar. Efektler yalnızca parçacıktır; hasarı, hızı veya başka bir mekaniği
değiştirmez, gerçek yıldırım/ateş oluşturmaz, bloklara ve mobllara hiçbir etki yapmaz.

| Efekt | Olasılık | Görünüm |
|---|---|---|
| Alevli kritik | %75 | Küçük, yoğun turuncu → kırmızı kıvılcımlar ve birkaç alev |
| Yıldırım kritik | %25 | Yukarıdan vuruş noktasına inen zikzaklı beyaz-mavi-mor çizgi ve elektrik kıvılcımları |

Kritik vuruşu mod tahmin etmez; vanilla'nın `Player#attackVisualEffects` metoduna verdiği kritik sonucuna bağlanır.
Olasılık, renkler, yükseklik ve parçacık sayıları `effect/CritEffects.java` başındaki sabitlerde.

Efekt görünmezse (ör. Minecraft güncellemesi vanilla metodu değiştirdiyse) oyun çökmez, efekt sadece devre dışı kalır;
`logs/latest.log` içinde `battleaxe` veya `attackVisualEffects` araması nedeni gösterir.

## Hiddet sistemi

Canın düşükken Savaş Baltası güçlenir.

| | Değer |
|---|---|
| Aktifleşme | Savaş Baltası ana elde **ve** can, maksimum canın **%50'si veya altı** (maks. 20 ise 10 HP). Oran güncel azami cana göre hesaplanır; sarı kalpler (absorption) sayılmaz |
| Kapanma | Can, maksimum canın **%60'ının üzerine** çıkınca (histerezis: sınırda dalgalanınca açılıp kapanmaz, başlangıç efektleri tekrarlanmaz). Eski değerler: %30 / %50 |
| Saldırı hasarı | 16 → **20** |
| Saldırı hızı | normalin **%35 üstü** (0.8 → 1.08 saldırı/sn) |
| Ölüm | State kesin olarak sıfırlanır |

- **Durum sunucuda tutulur (otoriter).** Hasar/hız bonusları oyuncunun gerçek özniteliklerine sunucuda eklenir,
  vanilla bunları istemciye kendisi senkronlar. İstemci yalnızca HUD için "aktif mi?" bilgisini alır.
- **Üst üste binme yok.** Bonuslar sabit kimlikli geçici modifier'dır; zaten varsa tekrar eklenmez. Durum geçişi
  (INACTIVE → ACTIVE) tek seferliktir, her tick tekrarlanmaz.
- **Silah bağlantısı.** Bonuslar yalnızca Savaş Baltası ana eldeyken uygulanır. Aktifken başka silaha geçersen
  state kalır ama bonuslar kalkar; baltayı geri alınca (hâlâ aktifse) geri gelir. Bonuslar ayrıca her saldırıdan
  hemen önce kontrol edilir, böylece aynı tick'te silah değiştirip vurarak başka silaha bonus aktarılamaz.
- **HUD.** Aktifken sağ üstte koyu kırmızı panelde balta ikonu ve kırmızı "BERSERKER" yazısı görünür
  (efekt ikonlarının varlığında onların altına kayar). Aktifleşirken yaklaşık 0.35 sn belirip büyür; bu animasyon
  yalnızca durum değiştiği anda bir kez başlar. Kapanınca tamamen kaybolur.

Tüm değerler `berserker/BerserkerConfig.java` dosyasında: `ACTIVATION_HEALTH_RATIO`, `DEACTIVATION_HEALTH_RATIO`,
`BERSERKER_DAMAGE_BONUS`, `BERSERKER_ATTACK_SPEED_MULTIPLIER`. HUD renkleri ve konumu `client/BerserkerHud.java` başında.

### Hiddet efektleri

| Efekt | Ne yapar |
|---|---|
| **Yıldırım** | Hiddet aktifken, baltayla başarılı vuruşlarda **%25** olasılıkla vurulan mobun üzerine yıldırım düşer (en az 1 sn arayla). Yıldırım **sadece görseldir**: hasar vermez, yangın çıkarmaz, blok/mob dönüştürmez; ışık, gök gürültüsü ve ekran titremesi verir. |
| **Başlangıç** | Hiddet'ın başladığı an: kükreme sesi, kor/alev/duman patlaması ve ekran titremesi (tek seferlik). |
| **Aura** | Aktifken ve balta elde iken oyuncunun etrafında hafif kor ve alev; yakındakiler de görür. |
| **Krit efekti** | Hiddet'da kritik efektleri koyu/sert varyanta geçer (kömür-kırmızı kor, duman; yıldırım kan kırmızısı, daha uzun) ve parçacık yıldırımı %25 yerine %50 seçilir. Aynı vuruşta gerçek yıldırım düştüyse parçacık yıldırımı oynamaz. |
| **Ekran titremesi** | Başlangıçta ve yıldırım düştüğünde kısa, sönümlenen kamera titremesi. Yalnızca görseldir, nişanı değiştirmez. |
| **HUD** | Panelin çerçevesi nabız gibi atar; ekranın üst ve alt kenarında hafif, nabız gibi atan kırmızı vinyet belirir. |

Ayarlar: `BerserkerConfig.java` (`BERSERKER_LIGHTNING_CHANCE`, `BERSERKER_LIGHTNING_COOLDOWN_TICKS`,
`BERSERKER_CRIT_LIGHTNING_CHANCE`, `AURA_INTERVAL_TICKS`, `*_SHAKE_*`).
İstemci: `ClientCameraShake.ENABLED = false` titremeyi, `BerserkerHud.VIGNETTE_ENABLED = false` vinyeti kapatır.

## Yar Geç büyüsü ve sağ tık saldırısı

**Yar Geç**, yalnızca Savaş Baltası'na basılabilen özel bir büyüdür (normal kılıç/balta/diğer eşyalara basılamaz;
büyülü kitap da yalnızca Savaş Baltası'na uygulanabilir). Vanilla büyü sistemiyle uyumludur: büyü masası, örs,
kitap, `/enchant` ve diğer büyülerle birlikte çalışır.

**Nasıl edinilir:** Büyü masasında Savaş Baltası'na çıkabilir, kütüphaneci köylüler büyülü kitap olarak satabilir,
loot'ta çıkabilir ve yaratıcı modda kitap otomatik listelenir. Hızlı deneme: baltayı elinde tut ve `/enchant @s battleaxe:yar_gec`.

**Saldırı:** Yar Geç'li baltayla **sağ tık basılı tut → şarj ol → bırak**. Bıraktığın anda baktığın yönde, önündeki
bir yelpazede birden fazla düşmana TEK SEFER hasar verilir.

| Şarj | Seviye | Hasar | Menzil | Açı (toplam) | En çok hedef |
|---|---|---|---|---|---|
| Kısa | 1 (hafif) | 6'dan başlar | 3 blok | 80° | 3 |
| Orta (%40+) | 2 (güçlü) | ~15 | ~4.5 blok | ~120° | ~7 |
| Tam (2 sn) | 3 (maksimum) | 24 | 6 blok | 160° | 12 |

- Değerler şarjla **doğrusal** artar. **MAX_CHARGE_TIME** (40 tick = 2 sn) sonrası beklemek hiçbir şeyi artırmaz.
- 4 tick'ten (0.2 sn) kısa basışlar kazara tıklama sayılır, saldırıyı tetiklemez.
- Saldırıdan sonra 1.5 sn bekleme ve 2 dayanıklılık kaybı vardır. Diğer oyuncular da vurulabilir (PvP kurallarına uyar).
- **Görsel geri bildirim:** Şarj sırasında baltanın önünde parçacıklar yoğunlaşır ve sertleşir (turuncu kıvılcım → kırmızı kor + alev →
  tam şarjda beyaz-mor elektrik), seviye atlarken ses çalar, nişangahın altında şarj çubuğu dolar. Bırakınca yelpaze boyunca
  süpürme parçacıkları ve her vurulan düşmanda isabet efekti çıkar; seviye yükseldikçe daha vahşi olur.

Tüm değerler `yargec/YarGecConfig.java` dosyasında: `MAX_CHARGE_TIME`, `MIN_CHARGE_TIME`, `TIER_2_RATIO`, `MIN_/MAX_DAMAGE`,
`MIN_/MAX_REACH`, `MIN_/MAX_HALF_ANGLE_DEGREES`, `MIN_/MAX_TARGETS`, `MIN_/MAX_KNOCKBACK`, `COOLDOWN_TICKS`, `DURABILITY_COST`.
Büyünün maliyeti ve nadirliği: `data/battleaxe/enchantment/yar_gec.json`.

## Ruh Bağı: baltan seni tanır

Savaş Baltası ana elde iken düşman öldürdükçe baltanın **ruh** sayısı artar. Ruhlar rütbeyi belirler; her rütbede
balta **görünüm değiştirir, biraz güçlenir, efektleri zenginleşir ve seninle farklı konuşur**.

**Ruh nasıl kazanılır?** Yalnızca düşmanlar (canavarlar) ve oyuncular ruh verir; inek, köylü gibi uysal canlılar vermez.
Güçlü düşman daha çok ruh verir: zombi 1, Enderman 2, Ender Ejderhası 10, Wither 15, Warden 25 (üst sınır). Oyuncu = 5.

| # | Rütbe | Toplam ruh | Balta adı | Rütbe gücü (hasar / hız / Yar Geç) |
|---|---|---|---|---|
| 0 | Uykuda | 0 | Savaş Baltası | – |
| 1 | Uyanan | 50 | Uyanan Savaş Baltası | +0.5 / %2 / %3 |
| 2 | Susamış | 200 | Susamış Savaş Baltası | +1.0 / %4 / %6 |
| 3 | Kanlı | 600 | Kanlı Savaş Baltası | +1.5 / %6 / %9 |
| 4 | Gazaplı | 1.500 | Gazap | +2.0 / %8 / %12 |
| 5 | Yıkıcı | 3.000 | Yıkıcı | +2.5 / %10 / %15 |
| 6 | Kıyamet Habercisi | 6.000 | Kıyamet Habercisi | +3.0 / %12 / %18 |
| 7 | Ölümsüz | 10.000 | Ölümsüz Gölge | +3.5 / %14 / %21 |
| 8 | Efsanevi | 16.000 | Efsanevi Ruh Biçen | +4.0 / %16 / %24 |
| 9 | Ezeli | 25.000 | Ezeli | +4.5 / %18 / %27 |

Rütbe gücü yalnızca balta ana eldeyken uygulanır (Hiddet ile aynı güvenli, birikmeyen yöntem) ve küçüktür:
rütbe 9'da bile hasar 16 → 20.5. Hiddet bonusları bunun üstüne biner.

**Her rütbede görünüm değişir.** 9 rütbenin her biri için ayrı doku seti vardır: mor obsidyen → ayaz yeşili →
kehribar → kızıl → erimiş turuncu → macenta → beyaz-kırmızı → buz mavisi hayalet → altın → prizmatik (Ezeli).
Rütbe yükseldikçe süsler artar (kabza sarımı, bıçakta rünler, sivri uçlar, kor, hale) ve animasyon başlar.
Hiddet ve Yar Geç şarj hâlleri her rütbede ayrıca vardır (rütbe süslerini korur). Balta elde de her rütbede biraz daha heybetlidir.
Balta adı da rütbeyle değişir (anvilde verdiğin ad bunun önüne geçer).

**Her rütbede efektler zenginleşir.** Kritik vuruşlar, sıradan vuruşlar ve Yar Geç rütbeyle yoğunlaşır ve katmanlanır
(rütbe renginde kor, duman, süpürme çizgileri, elektrik sütunu, patlama, rütbe 9'da kıvılcım halkası).
Hiddet'daki görsel yıldırım olasılığı da rütbe başına %1 artar.

**Balta seni tanır.** Tooltip'te baltanın sana karşı tavrı rütbeyle değişir ("Sessiz. Seni henüz tanımıyor." →
"Siz artık ikiniz değilsiniz."), ilk ruhu aldığı oyuncunun adı **Ruhdaş** olarak yazılır, rütbe gücün görünür.
Ayrıca vuruşlarda ve Hiddet başlarken, arada bir ekranın altına kısa bir söz gelir: baltanın kendi fısıltıları
(rütbe yükseldikçe derinleşir, yüksek rütbelerde adını söyler) ya da şiir ve mitlerden alıntılar (Shakespeare, Homeros,
Vergilius, Dante, Nietzsche, Beowulf, Hávamál, Herakleitos, Milton, Ergenekon ve Bozkurt efsaneleri...). Alıntılar
serbest Türkçe uyarlamadır, birebir çeviri değildir. Mesajlar arası en az 40 sn vardır.

Tüm ayarlar `soul/SoulConfig.java` içinde (eşikler, ruh değeri, rütbe başına güç, mesaj sıklığı); mesaj metinleri
`lang/tr_tr.json` ve `en_us.json` içinde (ikisi de Türkçe). Yeni mesaj eklersen `soul/WhisperData.java` tablosunu da güncelle.
Eski sürümden gelen balta ruh sayısını korur; yeni eşiklere göre rütbesi otomatik hesaplanır.

## Ruh Ağı (Soul Nexus): 100 düğümlü yetenek ağacı

Path of Exile tarzı geniş, birbirine bağlı bir pasif ağaç. **`N`** tuşuyla açılır (Seçenekler > Kontroller > Savaş Baltası
bölümünden değiştirilebilir; vanilla'da `N` boştur). Ekranı görüntülemek için baltanın elde olması gerekmez, ancak
**satın alma ve sıfırlama için baltayı ana veya yan elinde tutman gerekir** ve her ikisi de sunucuda doğrulanır.

Ekran: sürükleyerek gezin, tekerlekle yakınlaştır, alttaki düğmelerle (Merkez / 5 dal / + -) dallar arasında kaybolmadan
atla; konum ve yakınlaştırma ekranı kapatıp açınca korunur. Düğüm renkleri: **açık** (dolu renk), **açılabilir** (nabız
atan altın çerçeve), **kaynak yetersiz** (turuncu-kırmızı çerçeve), **kilitli** (koyu).

### Para birimleri (üç ayrı kavram)

| Kavram | Nereden gelir | Ne için |
|---|---|---|
| **Ruh bakiyesi** | Mevcut ruh sistemindeki **aynı öldürme olayı**; defter, oyuncunun toplam ruhundan sıfırlamalara harcananı düşer | Yetenek puanı kazanımının ölçüsü ve **sıfırlama bedeli** |
| **Yetenek puanı** | Toplam ruh ilerlemesi eşikleri (aşağıda) | Düğüm açar: küçük 1, orta 2, büyük 3, dal sonu 4 |
| **Minecraft XP** | Normal oyun | Büyük düğüm **5 seviye değerinde (55 puan)**, dal sonu **15 seviye değerinde (315 puan)** |

* **Baltanın rütbesi hâlâ baltadaki ruh sayacından hesaplanır ve asla harcanmaz.** Ağ, yeni bir ruh olayı yaratmaz:
  `SoulManager` aynı öldürmeyi bir kez işler, ağ bonusu bu değere eklenir ve **aynı miktar** hem baltaya (rütbe) hem
  oyuncunun defterine yazılır. Sıfırlama yalnızca defterdeki harcanabilir bakiyeyi düşürür; rütbeyi, toplam ruhu ve
  kazanılmış puanları etkilemez.
* **Puan eşiği (yapılandırılabilir, `NexusConfig`)**: n. puan için toplam ruh `ceil(20 * n^1.5)`. 1. puan 20, 10. puan 633,
  40. puan 5.060, 100. puan 20.000, 160. puan (tavan, ağın tamamı) 40.478 ruh. Eşikler kalıcı ve **tek yönlüdür**: kazanılmış
  puan bir daha silinmez, aynı eşikten tekrar puan kazanılmaz.
* **XP maliyeti gerçek puan olarak hesaplanır** (vanilla formülleri: 0->5. seviye = 55, 0->15. seviye = 315 puan). Oyuncunun
  seviye + seviye içi ilerlemesinden toplam puanı hesaplanır; yetmiyorsa işlem reddedilir; yeterliyse vanilla'nın kendi
  `giveExperiencePoints(-n)` yoluyla düşülür (seviye ve çubuk doğru iner).

### İlerleme verisi OYUNCUYA bağlıdır (balta kimliğine değil)

Ağ düğümleri, puanlar, defter oyuncunun kalıcı verisinde saklanır (Fabric Data Attachment: dünya kaydıyla yazılır,
ölünce kopyalanır, çıkış-giriş ve yeniden yükleme sonrası korunur; her oyuncunun ağacı ayrıdır). Baltalar ilerleme taşımaz;
bu yüzden balta kopyalansa, sandığa konsa, atılsa, devredilse ya da öbür oyuncuya verilse hiçbir şey çoğalmaz. Etkiler yalnızca
**ana elde balta tutulurken** geçerlidir (Hiddet ve rütbe bonuslarıyla aynı kural).

* **Eski baltalar / eski dünyalar**: güncellemeden önce biriken ruhlar, **balta başına bir kez** (`nexus_claimed` bileşeni)
  ilk tutan oyuncunun defterine işlenir; el değiştirse bile ikinci kez sayılmaz. Mevcut bileşenler, rütbe ve Kara Çubuk
  hiç değişmez.
* Öldürme olayı aynı varlık için ikinci kez deftere yazılmaz (son 16 kurban izlenir).

### Ağ yapısı ve kurallar

* Ortada tek çekirdek; 5 dal çekirdekten ayrılır ve her dal **kendi içinde tam bağlıdır** (başka dalı tamamlamak gerekmez).
* Bir düğüm yalnızca açık bir komşusu varsa (veya dalın ilk düğümüyse) alınabilir. İkinci kez alınamaz.
* Dallar arasında **yalnızca 5 köprü** vardır (her dalın sağ orta düğümü -> sonraki dalın sol orta düğümü): hibrit kurulum mümkün.
* **Dal sonu** için: dalda en az 12 düğüm + en az 1 büyük düğüm (`NexusConfig`).
* **Atomik satın alma**: sunucu bağlantıyı, puanı, XP'yi ve dal şartını önce doğrular; sonra XP düşer, sonra veri yazılır.
  Başarısızlıkta hiçbir şey eksilmez (hata olursa XP iade edilir).
* **Sıfırlama**: onay ekranı düğüm sayısını ve bedeli (ruh + XP puanı) gösterir. Bedel düğüm sayısıyla artar
  (`ruh = 15n + n(n-1)/2`, `XP seviyesi = min(40, 2 + n/4)`); "Hazine" düğümleri ruh bedelini azaltır. Onay sırasında düğüm sayısı
  değişmişse sunucu reddeder. Rütbe, toplam ruh, fısıltılar, Kara Çubuk ve diğer ilerlemeler korunur.

### Dallar (her biri 12 küçük + 5 orta + 2 büyük + 1 dal sonu = 20)

| Dal | Odak | Dal sonu |
|---|---|---|
| **Ruh Hâkimiyeti** (turkuaz) | Ruh kazanımı %, güçlü/elit düşmandan ek ruh, rütbe/ruh eşiğine bağlı avantajlar, öldürmede XP/şifa, sıfırlama indirimi | Ruh Hâkimi |
| **Cellat Yolu** (kırmızı) | Hasar, ağır vuruş, Cellat darbesi (kritik şansı) ve kritik hasar, öldürme serisi, can yüzdesi koşulları; yüksek riskli **Kan Borcu** (+%25 hasar, -%20 azami can) | Cellat'ın Hükmü (infaz) |
| **Yarık Gezgini** (mor) | Mevcut Yar Geç: bekleme (asla sıfırlanmaz, en az 12 tick), hasar, menzil, açı, hedef sayısı, itme, isabet sonrası hız/hasar | Yarığın Efendisi (ritim) |
| **Ruh Muhafızı** (altın) | Zırh, can, koşullu hasar azaltma (mermi/ateş/patlama/düşme/yakın dövüş), can çalma, saldırıdan ödün veren büyük pasifler | Ölümsüz Muhafız (Son Direniş) |
| **Lanetli Bilinç** (yeşil) | Yeni fısıltılar (öldürme, boss, büyük düşman, Hiddet, Yar Geç, fırlatma, düşük can, düğüm, eşik), rütbe tepkileri, Kara Körük sezgisi/etkileşimi, görsel geri bildirimler | Lanetli Bilinç (baltanın uyanışı) |

Düğüm açıklamaları oyunda **etkilerden otomatik üretilir**, böylece açıklama ile gerçek etki ayrışamaz. Toplam etkiler
sınırlıdır: hasar bonusu toplamı [-%40, +%75], gelen hasar azaltma en çok %40 (Son Direniş'in kısa koruması hariç ve yine
%100 değil), kritik şansı %25, bekleme azaltma %40 (+ritim, toplam %60). Hasar HAM miktar üzerinde (zırh hesabından önce)
ölçeklenir; vanilla zırh, büyü ve dokunulmazlık hesapları aynen çalışır.

### Düğüm eklemek / dengelemek

Tüm düğümler `tools/gen_nexus.py` içindeki tabloda tanımlıdır (kimlik, ad, tür, bağlantı, etkiler). Betiği çalıştırınca:

```
python3 tools/gen_nexus.py      # ağı doğrular, NexusNodes.java'yı ve lang girdilerini yeniden üretir, tools/nexus_preview.png çizer
tools/test/run_tests.sh         # Minecraft gerektirmeyen çekirdek testleri (JDK yeterli)
```

Doğrulama: tam 100 düğüm, dal başına 12/5/2/1, çift yönlü bağlantılar, tüm düğümler ulaşılabilir, her dal kendi içinde tam
bağlı, yalnızca 5 köprü, her düğümün etkisi var, her etkinin dil şablonu var. Yeni bir **etki türü** için `Stat` enum'una
bir satır ekle, `NexusDamage` / `NexusCleave` / `NexusSoul` gibi ilgili yerde uygula ve `nexus.stat.<ADI>` şablonunu betiğe ekle.
Sayısal ayarlar (maliyetler, eşikler, sınırlar, süreler) `NexusConfig.java` ve `Stat.java` içindedir.

### Entegrasyon noktaları (mevcut kodda yapılan küçük, geri alınabilir kancalar)

| Dosya | Eklenen |
|---|---|
| `SoulManager` | Öldürmede bonus + defter (`NexusSoul.onKill/afterKill`), rütbe atlayınca fısıltı |
| `YarGecAttack` | Hasar/menzil/açı/hedef/itme çarpanları, sınırlı bekleme, dayanıklılık tasarrufu, isabet sonrası bonuslar |
| `PlayerMixin` | Saldırı bağlamı (ağır vuruş), başarılı vuruş sonrası savunma |
| `LivingEntityMixin` (yeni) | `hurtServer` başında giden/gelen hasar ölçekleme (yeniden giriş korumalı, `require = 0`) |
| `BattleAxeItem` | Eski ruhların balta başına tek seferlik işlenmesi, tooltip satırı |
| `BerserkerManager`, `ThrownAxeManager` | Fısıltı olayları (Hiddet başlangıcı, fırlatma) |
| `ModComponents` | `nexus_claimed` bileşeni |
| Ağ | `nexus_action` (C2S), `nexus_sync` ve `nexus_result` (S2C); paketler doğrulanır, istek sıklığı sınırlıdır |

## Hiddet Evrimi: Savaş Özü, aşamalar ve üç dal

Mevcut Hiddet (can <= %50'de açılan, +4 hasar / +%35 saldırı hızı / yıldırım veren sistem) **aynen çalışmaya devam eder**.
Evrim onun üzerine kurulur: eski Hiddet'ın durumunu bir girdi olarak okur, hiçbir değerini değiştirmez.

**Tuşlar** (Kontroller > Savaş Baltası; ikisi de değiştirilebilir, vanilla'da boştur): **B** evrim ekranı, **V** Son Eşik.
R (fırlatma) ve N (Ruh Ağı) aynen duruyor.

### Savaş Özü (0-100)

Ruh puanlarından ve XP'den **tamamen ayrı**, oyuncuya bağlı kalıcı bir kaynak. Kazanım (hepsi `EvolutionConfig`):

| Kaynak | Kural |
|---|---|
| Yakın dövüş vuruşu | Saldırı gücü <= %40 ise **hiç öz vermez** (kol sallama spam'i). Hedefin canına göre ağırlık, aynı hedefe art arda vuruşta azalan verim (tabanı %25), canın <%50 iken x1.4 |
| Öldürme | Her varlık bir kez; güçlü düşman (100+ can) ek öz |
| Yar Geç / fırlatma isabeti | Yalnızca **canavarlara**; pasif hayvanlar öz vermez |
| Hasar alma | Yalnızca zaten savaştayken (yakın zamanda sen vurduysan), 10 tickte bir, sınırlı; **savaş süresini uzatmaz** |

Hepsi birden **saniyede en çok 14 öz** ile sınırlıdır (pencere sınırlayıcı). Savaş bittikten ~10 sn sonra öz yavaşça azalır;
aşamalar kendi öz tüketimini yapar. Öz hiçbir zaman negatif olamaz, 100'ü aşamaz. Ölünce **öz sıfırlanır**; dal, ustalık ve
bekleme süreleri korunur. Veri sunucuyu kapatıp açınca, çıkış-girişte ve dünya yenilemede devam eder.

### Aşamalar

| Aşama | Koşul | Etki |
|---|---|---|
| **I Kıvılcım** | Eski Hiddet aktif **veya** (dal seçili + savaşta + öz >= 20) | Hafif aura, küçük genel bonus |
| **II Uyanış** | Dal seçili, I'de, savaşta, öz >= 35 | Daha belirgin aura, dalın etkileri hissedilir, yıldırım şansı artar |
| **III Taşkınlık** | II'de, öz >= 65 | Güçlü bonus, yoğun efekt, ekran titremesi; saniyede 2 öz tüketir, **aşırı yüklenir** |
| **IV Son Eşik** | **V tuşu**: III'te, öz >= 50 (harcar), aşırı yük <= 80, 3 dk bekleme geçmiş, toparlanmıyor | 8 sn zirve; sonra 10 sn **Tükenme** |

Girişler yüksek, çıkışlar daha düşük eşiktedir (titreme olmasın). Aşama yalnızca cana bağlı değildir: eski Hiddet, öz,
savaş durumu, seçili dal, toparlanma ve balta tutma birlikte değerlendirilir. Baltayı havadayken (fırlatılmış) de "silahlı" sayılırsın.

### Aşırı yüklenme ve toparlanma

Taşkınlıkta saniyede +5 artar (yaklaşık 20 sn), bu aşamada **Yar Geç +12, fırlatma +8** ekler; altında soğur. %100'de
**Aşırı Yük** toparlanması (6 sn): aşama en çok I'e düşer, hasar -%10, alınan hasar +%10, saldırı hızı -%8, hareket -%10.
Son Eşik sonrası **Tükenme** (10 sn): evrim aşaması yok, saldırı hızı -%12, alınan hasar +%10. Hiçbir toparlanma baltanın
yeteneklerini (Yar Geç, fırlatma, rütbe, Ruh Ağı) kapatmaz ya da kontrolü almaz.

### Üç dal (aynı anda yalnızca biri; ustalık her dalda ayrı ve kalıcı)

| Dal | Avantaj | Sınırlama |
|---|---|---|
| **Kan Kasırgası** (kırmızı) | **İvme** (10 kademe): isabetli tam vuruşlar hasarı (<=+%30), saldırı hızını (<=+%25) ve öz kazanımını artırır. Boşta/zayıf vuruşta çözülür. Son Eşik: ivme tabanı 6, +%10 hasar | Alınan hasar +%6..12; zayıf vuruş ivmeyi düşürür |
| **Son Nefes** (mor) | Can azaldıkça hasar (<=+%25) ve hasar azaltma (<=%35). Düşük canda öz x1.5. **Ölümden dönüş**: ölümcül vuruşta canın %25'iyle kalır (15 öz, **5 dk bekleme**, 3 sn koruma). Son Eşik: +%35 azaltma, saniyede +1 can | Sağlıklıyken neredeyse etkisiz; toplam azaltma **%60'ı aşmaz** |
| **Ruh Yırtıcısı** (turkuaz) | Yar Geç (<=+%25) ve fırlatma (<=+%25) hasarı; Yar Geç/fırlatma isabeti ek öz; Uyanış/Taşkınlıkta güçlü düşmanın **aynı ruh ödülüne +1/+2**; Son Eşik: Yar Geç beklemesi -%40 (asla 12 tick altı) | Sıradan vuruşlar x0.75 öz verir |

Ustalık (5 seviye: 0/150/500/1200/2500 puan) yalnızca dalın **kendi oynanışıyla** ve aşama >= I iken, pencere başına en çok
3 puan kazanılır; etkileri x0.8 -> x1.2 ölçekler. Dal değişimi: ilk seçim serbest; sonrası yalnızca **aşama dışında, savaş dışında,
5 dakikada bir** (sunucu doğrular). Ruh/XP kaybı yoktur. Tüm dalların bonusu aynı anda kullanılamaz (tek dal aktif).

### Diğer sistemlerle denge

* Evrim hasarı, Ruh Ağı'ndan **sonra** aynı ham miktar üzerinde uygulanır; birleşik giden hasar orijinalin **en çok 2.6 katı**
  (Ruh Ağı infazı hariç), birleşik gelen hasar **en çok %70 azalır**. Evrim, Ruh Ağı'nın verdiğini asla düşürmez.
* Ruh Yırtıcısı ruh bonusu **ikinci bir ödül değildir**: aynı öldürme olayının değerine eklenir ve hem baltaya hem Ruh Ağı
  defterine aynı miktar yazılır. Savaş Özü ruh/XP'ye dönüşmez.
* "Son Nefes" ölümden dönüşü ile Ruh Ağı "Son Direniş" birlikte tetiklenmez (ilk dönen ölümü iptal eder).
* Hasar kancası Ruh Ağı'yla aynıdır (`LivingEntityMixin`, `require = 0`); yeni mixin eklenmedi.

### Bilinen sınırlar

* Kan Kasırgası'nda "boşa vuruş" (havaya sallama) doğrudan **algılanmaz**: ivme zayıf vuruşta ve süre dolunca çözülür.
* Sesler yeni dosya içermez; mevcut Minecraft sesleri (örs, hortlak kükremesi...) kullanılır.
* Sayılar oyun içi denenmedi; ayarlar `EvolutionConfig` içinde tek yerde.

## Shunpo büyüsü (isabet sonrası ışınlanma)

**Shunpo**, yalnızca Savaş Baltası'na basılabilen özel bir büyüdür (Yar Geç ile aynı kalıp: `data/battleaxe/enchantment/shunpo.json`,
tag `battleaxe:enchantable/shunpo`, `non_treasure` etiketinde). Büyü masası, örs, büyülü kitap, köylü ticareti, loot,
yaratıcı mod kitap listesi ve `/enchant @s battleaxe:shunpo` ile edinilir/uygulanır.

**Kullanım:** Shunpo'lu baltayı fırlatma tuşuyla (varsayılan **R**) fırlat. Balta bir **canavara** isabet ederse
yaklaşık 4 sn (`ShunpoConfig.WINDOW_TICKS`) içinde **R'ye tekrar bas**: fırlattığın **ilk konuma** ışınlanırsın,
balta anında eline döner ve hedefe normal saldırılarınla devam edersin. Shunpo ekstra hasar vermez.

- Balta bloğa çarparsa ya da hiçbir şeye çarpmazsa Shunpo oluşmaz; ikinci R normal davranışını korur.
- Isabet kendiliğinden ışınlamaz; ışınlanma yalnızca ikinci tuş basışıyla olur ve isabet başına bir kez.
- Fırlatma konumu güvenli değilse (blok içi, lav/ateş, altında zemin yok) çevresindeki (≤2 blok) en yakın geçerli konum
  seçilir; bulunamazsa ışınlanma iptal edilir ve konumun değişmez (hak, süre dolana dek korunur).
- Envanterde balta için yer yoksa ışınlanma yapılmaz.
- Bağlantı; yeni fırlatma, süre sonu, ölüm, çıkış, boyut değişimi, baltanın teslim edilmeden kaybolması ve kullanımda silinir.
  Hedefin (balta öldürse bile) ölmesi ya da baltanın Sadakat ile sana geri dönmesi hakkı SİLMEZ: ikinci R yine fırlatma
  konumuna ışınlar. Kombo sürerken R basışı yutulur. Teşhis: `ShunpoConfig.DEBUG` sunucu günlüğüne "[Shunpo]" satırları yazar.
- Sunucu otoritedir: fırlatma konumu fırlatma anında sunucuda kaydedilir, istemci yalnızca mevcut `ThrowAxePayload` ile
  "tuşa basıldı" der (bu yüzden istemci artık el boşken de bu paketi gönderir; sunucu doğrular).
- Not: Sadakat büyüsü baltayı kendiliğinden geri getirirse (balta yakalanınca) bağlantı da biter; pencere bu durumda kısalır.

Ayarlar: `shunpo/ShunpoConfig.java`. Saf mantık testi: `tools/test/ShunpoLogicTest.java`.

## Shunpo: Gerçeklik Yarıkları (görsel sistem)

Shunpo artık düz bir ışınlanma gibi görünmez: baltanın açtığı kısa ömürlü, dikey ve kırık kenarlı yarıklar ve aralarındaki keskin iz.
- **Mimari:** sunucu parçacık üretmez; doğrulanmış olayı (`shunpo/vfx/ShunpoVfx` -> `ShunpoVfxPayload`: tür, oyuncu, rütbe, iki gerçek konum)
  yakındaki (48 blok) oyunculara gönderir. Çizim `client/ShunpoRiftClient` içinde vanilla parçacıklarla yapılır (özel renderer/shader yok).
- **Olaylar:** `SHUNPO` (başlangıç yarığı açılır-titrer-çöker -> iz -> 3 tick sonra varış yarığı; ikisi hareket doğrultusuna dik; varış yarığı
  güvenli konum aramasından SONRAKİ gerçek konumda), `HIT_CRACK` (isabet), `COMBO_FIRST/SECOND/FINISH` (ince kesik / belirgin çatlak +
  küçük yarık / dikey kesik + kapanış), `FAIL` (başarısız girişimde yalnızca küçük kıvılcım; yarık/iz yok), `CANCEL` (kombo iptalinde açık yarıklar kapanır).
- **Rütbe (0-9):** yalnızca görsel parametre (`RiftStyle`): yükseklik 1,9-2,6, kenar yoğunluğu, süre (en çok 18 tick); rütbe 3+ ikinci ince çizgi,
  6+ rün benzeri çatlaklar, 9 kısa enerji halkası. Hasarı, menzili, Shunpo süresini ya da kombo gücünü etkilemez.
- **Performans:** tek merkezi ayar `shunpo/vfx/RiftConfig` (`ENABLED`, `DENSITY`, `MAX_PARTICLES_PER_TICK`=150, `MAX_ACTIVE_RIFTS`=8); aynı olayın
  3 tick içinde tekrarı yok sayılır; yeni Shunpo aynı oyuncunun eski yarıklarını 3 tick'te kapatır; dünya/bağlantı değişiminde tüm durum silinir.
- **Yar Geç:** kesik efektine aynı koyu kızıl/mor palet (`RiftPalette`) eklendi (hasar/menzil değişmedi).

## Hiddet, Shunpo kombosu ve yenilenen Ruh Ağı (güncelleme)

**Hiddet** (eski adıyla Berserker): mekanik aynıdır (can ≤ %50'de açılır, > %60'ta kapanır; eşikler ve bonuslar değişmedi).
Kod sınıfları `berserker/` altında kaldı; oyuncunun gördüğü her metin "Hiddet" oldu.
- Yeni gösterge `HiddetHud` (eski `BerserkerHud`'un yerine): düzensiz kenarlı koyu panel, kan damlaları, ruh kıvılcımları.
- Ekran görünümü (yalnızca istemci çizimi): dört kenarda nabız atan kırmızı vinyet, köşe çatlakları, çok hafif renk tonu;
  merkez temiz. `HiddetHud.SCREEN_FX_ENABLED` ile kapatılır. Sürekli düşük yoğunluklu kamera sallantısı + kalp atışı:
  `ClientCameraShake.HIDDET_AMBIENT / HIDDET_BEAT` (0 yaparsan kapanır). Durum sunucudan gelir; ölüm/çıkışta anında temizlenir.
- **Kükreme:** Hiddet aktifken kritik bir vuruş (vanilla kritik, Cellat darbesi ya da kombo bitirici) hedefi öldürürse
  (`HiddetRoar`) sunucudan tek sefer ses + ruhsal parçacık. Aynı kurban için tekrar işlenmez; aynı oyuncuda en az 6 tick ara.
  Özel ses dosyası EKLENMEDİ (mod henüz özel SoundEvent kaydetmiyor); Vanilla sesler katmanlanır.

**Shunpo kombosu** (`shunpo/ShunpoCombo`): başarılı Shunpo'dan sonra (blok/boşlukta yok) üç vuruşluk dallanan kombo.
`[yaklaşma] -> 1. vuruş -> 2. vuruş -> bitirici`. Shunpo oyuncuyu hâlâ FIRLATMA konumuna götürür; hedef 4,5 bloktan
uzaktaysa kombo hedefin yanına güvenli kısa bir adım atar (`ComboConfig.APPROACH_ENABLED`; güvenli yer/16 blok yoksa kombo
iptal, oyuncu fırlatma konumunda kalır). Dallar: ana hedef 2. vuruştan önce ölürse ve "Yırtılan Perde" açıksa 4+ blok
içindeki başka bir düşmana (bir kez) geçer, yoksa sonlanır; bitiricide hedef Execution'a uygunsa (Zombi/İskelet, can eşiği)
Execution animasyonu, değilse ağır sabit-kritik vuruş (+ "Yarık Uzmanı"/büyük düğümlerle süpürme). Yalnızca düşman
moblara (Enemy ya da seni hedefleyen mob) kombo yapılır. Her vuruş TEK hasar işlemidir (PLAYER_ATTACK, oyuncu adına):
ham hasar = saldırı hasarı özniteliği (balta + rütbe + Hiddet) x {0,40 / 0,50 / 1,25} x (1 + kombo yüzdeleri, en çok %75),
sonra normal hasar hattı (Ruh Ağı/Evrim, zırh, dokunulmazlık). Büyü bonusları (Keskinlik vb.) kombo vuruşlarına girmez.
Aynı oyuncuda tek kombo; yeni Shunpo eskisini keser. Zaman aşımı 90 tick.

**Ruh Ağı yeniden tasarımı:** 5 dal x 20 düğüm (kimlikler korundu) + `NodeRole` (temel/mekanik/uzmanlık/sinerji/büyük) +
sinerji düğümlerinde başka daldan ÖNKOŞUL (`requires`, arayüzde gösterilir). 16 yeni etki (Shunpo penceresi/hızı/zırhı/şifası,
kombo hasarı/bitirici/hedef değiştirme/süpürme, Execution olasılığı/eşiği/şifası, bitirici ruhu, Hiddet kombo bonusu + CAN BEDELİ,
kükreme şifası). Tüm sistemler `NexusApi` üzerinden okur; yeni düğüm eklemek Hiddet/Shunpo kodunu değiştirmez.
Üretim: `python3 tools/gen_nexus.py` (düğümler + dil + doğrulama).
Ekonomi: puan başına ruh eşiği 20 -> 15 (yaklaşık %25 daha hızlı puan); bedeller: küçük 1, orta 2, büyük 4 (+5 seviye),
dal sonu 5 (+15 seviye); toplam 175 puan. Büyük düğümlerin ruh karşılığı korunur, dal sonu ~%6 ucuzlar.
Veri: kayıt biçimi değişmedi. Yüklemede önkoşulu bozulan/bilinmeyen düğümler atılır, puanları otomatik iade olur (harcanan
puan yalnızca açık düğümlerden hesaplanır) ve oyuncu bilgilendirilir; kazanılmış puan ve ruh geçmişi asla azalmaz.

## Hiddet ve Yar Geç görünümleri

| Durum | Görünüm |
|---|---|
| Normal | Rütbenin kendi görünümü |
| Hiddet aktif (balta ana elde) | Alev kırmızısı, titreşen kor animasyonu, elde ~%18 büyür |
| Yar Geç şarjı: ilk | Turuncu parıltı |
| Yar Geç şarjı: orta (16 tick+) | Kızıl-turuncu, animasyonlu |
| Yar Geç şarjı: tam (40 tick) | Beyaz-mor elektrik, animasyonlu, hafif büyür |

Hiddet görünümü, Hiddet aktifken eşyaya sunucunun eklediği `battleaxe:berserk` bileşeniyle çalışır; rütbe görünümü
eşyanın `item_model` bileşeniyle seçilir (`items/battle_axe_rN.json`). Şarj aşamaları vanilla yay gibi `use_duration` ile
seçilir: `scale 0.05` olduğu için eşikler `0.8` (= 16 tick) ve `2.0` (= 40 tick) değerleridir. `YarGecConfig.MAX_CHARGE_TIME`
veya `TIER_2_RATIO` değişirse bu eşikleri `items/battle_axe*.json` dosyalarında güncelle (eşik = tick x 0.05).

## Ağır Balta Fırlatma

Savaş Baltası ana elde iken **R** tuşuna (Seçenekler > Kontroller > "Savaş Baltası" bölümünden değiştirilebilir) basınca
balta fırlatılır. **Q** (eşya bırakma) hiç etkilenmez.

- **Uçuş:** Balta havada kendi etrafında döner. Hız 1.7, vanilla yerçekimine ek düşüşle "ağır" hissettirir.
- **Çarpma (canlı):** Tek seferlik hasar verir (14 + rütbe bonusu), geri iter, metalik ses ve kıvılcım çıkar; sonra sekip yere düşer ve saplanır.
  Fırlatılan baltayla öldürmek de Ruh Bağı ruhu kazandırır.
- **Çarpma (blok):** Saplanır, dünyada kalır. Saplanmış balta bir daha hasar vermez. Saplandığı blok kırılırsa balta düşer.
- **Geri alma:** Balta kendiliğinden geri dönmez (Sadakat büyüsü sonraki aşamada). Yanına gidip dokununca envanterine,
  mümkünse fırlattığın yuvaya döner. Eşyanın tüm verisi (ruhlar, büyüler, ad) korunur.
- **Tek balta:** Aynı anda oyuncu başına yalnızca bir fırlatılmış balta vardır; alınana kadar yenisi fırlatılamaz.

### Sadakat (Loyalty)

Vanilla **Sadakat** büyüsü artık Savaş Baltası'na da basılabilir (büyü masası, örs, kitap, köylü ticareti; mızraklara
basılabilirliği aynen korunur). Büyülü balta fırlatıldığında bir süre sonra **sahibine geri döner**.

- **Zamanlama:** Canlıya çarptıktan ya da saplandıktan sonra bekler, sonra baltayı yerinden söker ve sahibine uçar.
  Sadakat I: 1.5 sn, II: 1 sn, III: 0.5 sn bekler; seviye arttıkça geri dönüş de hızlanır. Hiçbir şeye çarpmadan 3 sn uçarsa
  ya da boşluğa düşerse de geri dönmeye başlar (boşlukta kaybolmaz).
- **Yakalama:** Sahibe ulaşınca envantere girer, mümkünse fırlatıldığı yuvaya (yani çoğu zaman direkt eline). Hafif bir ekran
  sarsıntısı ve ses vardır. Envanter doluysa balta sahibinin yanında bekler ve yer açılınca yakalanır.
- **Görsel:** Geri dönerken daha hızlı döner, arkasında rütbe renginde iz ve kıvılcım bırakır (yüksek rütbede alev),
  ve sahibine uzanan noktalı bir **ruh bağı ipliği** çizer.
- **Güvenlik:** Sahibi çevrimdışıysa, ölürse, izleyici olursa, başka boyuta geçerse ya da 64 bloktan uzaklaşırsa balta geri
  dönmez; olduğu yerde düşüp saplanır ve sonra tekrar dener. Geri dönen balta hiç hasar vermez. Tüm kaybolma/çoğalma
  korumaları aynen geçerlidir.
- **Teknik not:** Bunun için `data/minecraft/enchantment/loyalty.json` dosyasında yalnızca `supported_items` değiştirildi
  (mızraklar + balta). Başka bir mod/veri paketi aynı dosyayı değiştirirse çakışabilir. Riptide, Channeling ve Impaling
  baltaya BASILAMAZ.
- Ayarlar: `thrown/ThrownAxeConfig.java` (gecikmeler, ivme, hız sınırı, mesafe).

**Kaybolma ve çoğalma korumaları**

| Durum | Ne olur |
|---|---|
| Fırlatma anında | Eşya elden alınıp varlığın içine taşınır (kopyalanmaz); varlık eklenemezse eşya ele geri konur |
| Envanter dolu | Balta yerde saplı kalır, "Envanterin dolu" uyarısı çıkar; yer açılınca alınır |
| Elde başka eşya var | Balta, fırlatıldığı yuva doluysa ilk boş yuvaya konur |
| Oyuncu ölür / bağlantısı kesilir | Balta dünyada saplı kalır; kimse alabilir, kayıt dünyada saklanır |
| Chunk boşalır / sunucu kapanır | Balta kaydedilir, geri yüklenince devam eder |
| /kill, başka mod, boşluğa düşme | Eşya sahibine (çevrimiçiyse), olmazsa güvenli bir noktaya süresiz yere bırakılır (ItemEntity) |
| Alma sırasında | "Teslim edildi" işareti eşya verilmeden önce konur; ikinci kez verilmez |
| Yaratıcı mod | Vanilla `Inventory.add` hasarlı eşyayı eklemeden "başarılı" sayabildiği için kullanılmaz; yuva elle seçilir |
| Lav / ateş | Balta artık ateşe dayanıklı (netherit gibi); varlık da yanmaz |

Not: Sunucu yeniden başlarken bellekteki "tek balta" kaydı sıfırlanır (balta yine dünyada durur). Ayarlar:
`thrown/ThrownAxeConfig.java` (hız, hasar, yerçekimi, bekleme). Karar mantığı `thrown/ThrownAxeLogic.java` içindedir.

## Kara Körük (boss) - Savaş yenilemesi

Nether'ın dışlanmış dahi demircisi. Artık elinde kendi **demirci çekici** var ve üç ağır saldırısı; hepsi önceden uyarı verir.

**Çağırmak:** `/summon battleaxe:kara_koruk` (komut yetkisi gerekir). Normal zorlukta dene; Barışçıl modda canavarlar kaybolabilir.

| Özellik | Değer |
|---|---|
| Can / zırh | **1200 / 16** (Wither 300) |
| Yakın dövüş hasarı / hız | **24** / **0.36** (takip menzili 64, geri savrulma direnci 1.0) |
| Boss çubuğu | Kömür siyahı zemin, kor kırmızısı dolgu, ince metal çerçeve (vanilla `green` boss bar sprite'ları geçersiz kılındı). Yakındaki oyuncular görür |
| Kalıcılık | Uzaklaşınca kaybolmaz; ateşe/lava dayanıklı |
| Ruh Bağı | Canavar sayıldığı için baltayla öldürünce **20 ruh** verir (değer `KaraKorukConfig.SOUL_VALUE` ile sabit; 1200 can formülle 25'e çıkarırdı) |

### Saldırılar (aynı anda yalnızca biri; araları en az 1.5 sn)

| Saldırı | Ne zaman | Nasıl |
|---|---|---|
| **Dövme Darbesi** (yakın) | Hedef 4.5 blok içinde | Çekici başının üstüne kaldırır, **1.3 sn** boyunca etrafında 5 blokluk halka alevlerle belirir ve içi dolar; sonra çekici indirir: halkadaki herkese **30 hasar** + geri itme. Hazırlıkta boss yerinde durur; halkadan çıkan kurtulur. Darbe sonrası 0.6 sn savunmasız kalır. Bekleme 6 sn |
| **Kor Mermisi** (orta-uzak, 8-24 blok) | Hedefi görüyorsa | **1.1 sn** hazırlık (çekicin başında kor birikir, yerde hedefe doğru kor çizgisi); sonra çekici savurup kızgın bir parça fırlatır (**23 blok/sn**, hedefin hareketine yarı yarıya önden nişan: yan hareketle kaçılabilir). İsabette **18 hasar**; 2.5 blok içindeki diğer oyunculara 8 hasar. **Blok hasarı yok, yangın çıkarmaz.** Bekleme 8 sn |
| **Demirci Hücumu** (uzak, 11-28 blok) | Hedefe gerçek bir yol varsa | 0.9 sn hazırlık, sonra ~1.6 sn iki kat hızla koşar. **Gerçek navigasyon** kullanır: duvarlardan geçmez, ışınlanmaz; takılırsa veya hedefe 3 blok kalırsa biter ve yakın dövüş sürer. Yolundaki oyuncular bir kez 10 hasar alır ve yatay itilir (havaya savrulmaz). Bekleme 12 sn |

**İkinci aşama (can <= %50)**, tek seferlik ve geri dönüşsüz (can iyileşse bile geri dönmez): bekleme süreleri %30 kısalır, hazırlıklar %15 kısalır
(ama kaçılabilirlik için alt sınırları var: darbe 1 sn, mermi 0.8 sn, hücum 0.7 sn), hücum daha sık seçilir; tek seferlik +%10 hız ve +%10 hasar; daha yoğun alev
parçacıkları, çekicin titremesi ve kükreme. Birden fazla oyuncu varsa boş anlarda daha yakın olana güvenle geçer (saldırı sırasında hedef değişmez).

**Eski kayıtlı boss'lar** yüklenirken yeni değerlere yükseltilir; can ORANI korunur (yarı canlı boss yarı canlı kalır).

Ayarlar (tek merkez): `boss/KaraKorukConfig.java`. Savaş durum makinesi (saf, testli): `boss/KaraKorukLogic.java`. Varlık: `boss/KaraKorukEntity.java`.
Mermi: `boss/KorMermisi.java` (ayrı varlık değildir: boss içinde sunucuda simüle edilir; kayıt/renderer/paket gerektirmez, boss ölünce temizlenir).
İstemci: `client/boss/` (model, çizici, çekiç animasyonları). Çekiç dokusu `kara_koruk.png`'nin boş alanına `tools/gen_hammer_texture.py` ile boyanır.

### Kara Demirhane (Nether yapısı)

Kara Körük'ün kendi demirhanesi: lav denizinin üstünde bir ada, ortasında ocak ve **Kara Körük'ün Örsü** (`battleaxe:kara_koruk_ors`), çevresinde lav kanalları,
8 ruh fenerli sütun, zincirle sarkan fenerler ve dört köprü. İçinde **tam bir tane** Kara Körük bulunur.

| | |
|---|---|
| Boyut | Yalnızca Nether (biyom: **Bazalt Deltaları**) |
| Yerleşim | `random_spread`: 20 chunk aralık, en az 6 chunk ayrım, %60 şans; Nether kalesi/Bastion başlangıcına 4 chunk yakın olamaz |
| Yükseklik | Zemin Y=34 (lav denizi seviyesinin 2 blok üstü) |
| Boss | Şablonun içinde tek bir Kara Körük; yapı bir kez üretilir, boss yalnızca o anda doğar |
| Yeniden doğma | Yok: spawner, olay veya zamanlayıcı yoktur. Öldürülünce, yapıya dönünce, dünya yeniden yüklenince ya da oyun yeniden başlayınca geri gelmez |

Bulmak: Nether'da `/locate structure battleaxe:kara_demirhane`. Hızlı deneme: `/place structure battleaxe:kara_demirhane` ya da
`/place template battleaxe:kara_demirhane/forge ~ ~ ~` (her çalıştırma yeni bir boss doğurur; bunlar yönetici komutlarıdır).
Yapı yalnızca **yeni üretilen** chunk'larda oluşur. Yapıyı değiştirmek için `tools/generate_kara_demirhane.py` dosyasını düzenleyip
çalıştır (`pip install nbtlib`); betik, lavın taşmayacağını ve tam bir boss ile bir Kara Körük Örsü olduğunu kendi doğrular.

## Gereksinimler

- Minecraft Java Edition **26.2**
- **Java 25** (Minecraft 26.x ile gelen Java yeterli; derleme için JDK 25 gerekir)
- Fabric Loader **0.19.5+**
- Fabric API (26.2 sürümü)

## Derleme

Proje klasöründe:

```bash
./gradlew build          # Windows: gradlew.bat build
```

Hazır mod dosyası: `build/libs/battleaxe-1.0.0.jar`
(`-sources` ile biten dosya kaynak koddur, onu `mods` klasörüne koyma.)

Oyunu denemek için derlemeden başlatmak istersen: `./gradlew runClient`

## Kurulum

1. Fabric Loader'ı 26.2 için kur ve Fabric API'yi indir (Modrinth / CurseForge).
2. `battleaxe-1.0.0.jar` ile Fabric API `.jar` dosyalarını `.minecraft/mods` klasörüne at.

Sunucuda da aynı iki dosya gerekir; mod hem istemci hem sunucu tarafında yüklü olmalıdır.

## Dengeyi değiştirme

`src/main/java/com/battleaxe/item/ModItems.java` dosyasının başındaki üç sabit:

```java
ATTACK_DAMAGE = 16.0F;   // toplam hasar
ATTACK_SPEED  = 0.8F;    // düşük = yavaş
DURABILITY    = 2500;    // dayanıklılık
```

Tarif: `src/main/resources/data/battleaxe/recipe/battle_axe.json`

## Baltanın Çağrısı: balta edinilmeden önce hissedilen varlık

Oyuncu Savaş Baltası'nı edinmeden **önce** onu seyrek ve belirsiz biçimde hisseder. Sistem **hiçbir şeyi kilitlemez**:
tarifleri, edinme yöntemini, boss'ları ve ilerlemeyi değiştirmez; yalnızca mesaj ve görsel/işitsel ipucudur.
Balta edinilince (envanterde görülünce ya da Ruh Ağı/Evrim kayıtlarından daha önce kullanıldığı anlaşılınca) o oyuncu için
**sonsuza dek susar**. Ayarlar `call/CallConfig.java` başındadır (tamamı kapatmak için `ENABLED = false`; mesaj/ay/demir
sesi ayrı ayrı da kapatılabilir; istemcide ay silüeti için `MoonAxeEffect.ENABLED`).

| Aşama | Ne olur |
|---|---|
| **1 Fısıltı** | Sohbette, italik gri, tek satırlık sözler ("Yıldız...", "Demir soğuyor." ...). 16 söz; bağlama duyarlı (gece, yeraltı, Nether). Aynı söz art arda gelmez, her söz bir kez gösterilir. |
| **2 İşaretler** | **Ay silüeti:** gece, açık gökyüzünün altında, aya (22 derece içinde) bakarken çok seyrek, ayın diskinin önünden ~4 sn geçen karanlık bir balta. Yeni ay/hilal evresinde, yağmurda, ay bir blokla örtülüyken ya da ekran açıkken çıkmaz. **Demir sesi:** Nether'da (Bazalt Deltaları'nda 3 kat olasılıkla) uzaktan 2-3 kısık örs vuruşu. |
| **3 Tanınma** | Nether'a girmek, Wither'ı görmek/yenmek, Nether Yıldızı edinmek mesajları anlamlandırır; her dönüm noktası **bir kez** özel bir söz getirir ("O yıldız senin değil." gibi), sonraki fısıltılar ilerlemeye göre değişir. |

**Seyreklik:** oyuna girişten sonra 5 dk sessizlik; iki mesaj arası en az 15 dk; oturum başına en çok 3 mesaj, 1 ay silüeti,
2 demir sesi; iki ayrı olay arası en az 1 dk; hasar alırken/uyurken olay yok; çoğu denetimde hiçbir şey olmaz.

**Çok oyunculu / kayıt:** ilerleme OYUNCUYA bağlı kalıcı veridir (`call` eki; ölünce kopyalanır, çıkış-girişte korunur).
Mesajlar, sesler ve ay paketi yalnızca ilgili oyuncuya gider. Wither doğuşunda/ölümünde öldüren ve 48 blok içindeki aynı
boyuttaki oyuncular tanık sayılır.

**Sürüm notu:** gün zamanı ve yağmur okuması yalnızca `call/SkyProbe.java` içinde, çalışma anında yöntem adı adaylarıyla
yapılır (26.x dünya saatleri nedeniyle). Okunamazsa yalnızca ay silüeti ve "gece" bağlamı devre dışı kalır, günlüğe uyarı yazılır.

## Baltanın Çağrısı - Öncü Belirtiler: gökte ve ufukta dört tezahür

Balta henüz edinilmemişken dünya, onun varlığına dair açıklanamayan, **yalnızca görsel** belirtiler gösterir. Hiçbiri
varlık, boss, blok, yapı ya da kalıcı dünya değişikliği değildir; saldırmaz, hasar vermez, ganimet bırakmaz. Mevcut
Çağrı sistemine (`call/`) bağlıdır; paralel bir mimari yoktur.

| Olay | Ne görülür | Koşul |
| --- | --- | --- |
| **Gökteki Devasa Balta** | Gece gökyüzünde siyah-mor, kızıl kenarlı devasa balta siluet (boynuzlu ağız, sırt mızrağı, bükülmüş sap). Fark edilirse çok hafif tek sarsıntı + **YILDIZI BUL!** (Nether Yıldızı'na çağrı), sonra kaybolur. | gece, açık gökyüzü, yağmursuz |
| **Sana Bakan Şey** | Gökyüzünün bir köşesinde yabancı, insansı olmayan devasa göz (badem ya da mercek biçimli). Bebeği oyuncuyu çok yavaş izler; kısmen bulut/karanlık arkasında kalabilir; bazen bakış kaçınca kaybolur. Mesaj, ses, boss bar yok. | gece, açık gökyüzü, yağmursuz |
| **Ufuktaki Dev** | Dağların ardında, ölçeği anlaşılamayan siluet (üç başlı Wither benzeri / dikili devasa balta / yüzsüz sütun). Yaklaşınca arazinin ardında söner ya da batar. | yeterince yol yürümüş, açık gökyüzü |
| **Olmaması Gereken Yapı** | Ufukta imkânsız mimari: bağlanmayan kemerler, perspektife uymayan sütunlar, iç içe halkalar, balta anıtı. Yaklaşınca perspektifi bozulup karanlığa karışır. | daha çok yol yürümüş, açık gökyüzü |

**Nasıl çalışır.** Sunucu (`OmenManager`) 5 sn'de bir seyrek bir zar atar; geçerse uygun bir tür *kurulur* ve oyuncu uygun
yöne bakınca (gökyüzü olayları için yukarı, ufuk olayları için ufka) başlatılır. İstemci (`OmenEffect`) yalnızca
sunucunun `OmenPayload` paketi gelince çizer: şekiller dünyada SABİT bir yöne bağlıdır (gök cismi gibi), köşe köşe
kamera yönüne göre izdüşürülür; arazi, ağaç ve yapılar tezahürü örter (`OmenOcclusion`, ışın örnekleme). Gerçek model/renderer
yoktur; `GuiGraphicsExtractor.fill` şeritleriyle HUD katmanında çizilir (mevcut ay silueti ile aynı teknik).

**Kalıcı sona erme.** Oyuncu baltayı ilk kez edindiğinde `F_AXE` bayrağı oyuncunun KALICI verisine yazılır ve sistem o
oyuncu için sonsuza dek susar (ölüm, yeniden doğma, yeniden giriş, boyut değişimi, baltayı kaybetme/atma/sandığa koyma
geri açmaz; başka oyuncular etkilenmez). Edinme `AxeAcquisition` ile her 0.2 sn'de, üç bağımsız kaynaktan izlenir:
envanter + imleçteki eşya, vanilla "üretildi/yerden alındı" istatistikleri (kalıcı), Ender sandığı. Bir olay
gösterilmeden hemen önce son bir kez daha denetlenir.

**Ritim.** Bir oturumda en çok 2 olay, en az 12 dk arayla; hasar, uyku, Hiddet, başka çağrı olayı ve etkin bir olay
varken kurulmaz; aynı tür art arda gelmez; gece olasılık artar; ilk oyun günü sakindir. Simülasyon: ilk olaya ortalama
~30 dk. Ayarlar: `call/OmenConfig.java`. **Oyun içinde denemek için** `OmenConfig.TEST_MODE = true` yap (bekleme
süreleri kısalır, olasılık 1 olur; susturma yine geçerlidir), denedikten sonra `false` yap.

**İstemci kapatma.** `OmenEffect.ENABLED = false`. **Sunucu kapatma.** `OmenConfig.ENABLED = false` (ya da türleri tek tek).

## Execution: baltayla nadir bitirici animasyonlar (Zombi, İskelet ve 16 ek mob)

Özel Savaş Baltası ile yapılan, hedefi **öldürecek**, **tam şarjlı** (>= %90) bir **yakın dövüş** vuruşunda, hedef vuruştan
önce azami canının **%30'unda veya altındaysa**, **%25** olasılıkla sinematik bir bitirici oynar. Sıradan silahlar, baltanın
fırlatılması/geri çağrılması ve Yar Geç bitirici başlatmaz (gerçek vuruş, `PlayerMixin#attack` kancasıyla işaretlenir).
Ayarlar `execution/ExecutionConfig.java` başındadır (`ENABLED`, `ZOMBIE_ENABLED`, `SKELETON_ENABLED`, `EXTRA_MOBS_ENABLED`, `DISABLED_EXTRA_IDS`, eşik, olasılık, süreler).

| Mob | Animasyon |
|---|---|
| **Zombi** | Tek, AĞIR, tepeden inen darbe (~0,8 sn). Hazırlıkta koyu kırmızı gerilim ve duman; baltayı başın üstünden savurma; alçak gümleme, küçük kan sıçraması, güçlü geriye savrulma. |
| **İskelet** | İki HIZLI çapraz savurma ve ikincide kemiği çatlatan sert ses (~0,75 sn). Hazırlıkta titreyen kemik kıvılcımları; darbede kemik tozu, kıvılcım, hafif geriye savrulma. |
| **Örümcek** | Üç HIZLI pençe kesiği (~0,8 sn); soluk gri ağ tozu, hafif geriye savrulma. |
| **Mağara Örümceği** | İki çevik kesik (~0,6 sn); turkuaz zehir tozu. |
| **Çöl Zombisi** | Zombi gibi tek ağır tepeden darbe; kuru kum tozu. |
| **Bozkır İskeleti** | İskelet gibi iki hızlı kesik; buz tozu ve `END_ROD` kıvılcımları. |
| **Wither İskeleti** | Yavaş, İKİ ağır darbe (~1,05 sn); karanlık toz, yükselen ruhlar ve mavi ruh alevi. |
| **Zombileşmiş Piglin** | Tek ağır darbe; kor-kırmızı toz, alev ve duman. |
| **Piglin Barbarı** | İki ağır savurma (~0,95 sn); altın toz ve elektrik kıvılcımı, güçlü geriye savrulma. |
| **Korucu (Vindicator)** | Balta düellosu: iki metal çarpışması (kıvılcım + çınlama), ardından tepeden son darbe (~1,05 sn). |
| **Bataklık İskeleti** | İki hızlı kesik, zehir yeşili toz. |
| **Zombi Köylü** | Tek ağır darbe, soluk yeşil toz. |
| **Yağmacı** | İki sert vuruş, metal kıvılcımı. |
| **Çağırıcı (Evoker)** | İki kısa kesik, sönen ruh dumanı. |
| **Yıkıcı (Ravager)** | Dev: yavaş ve çok ağır tek darbe (~1,2 sn), güçlü sarsıntı, sınırlı geri savrulma. |
| **Hoglin** | Ağır boynuz darbesi, kor tozu ve alev. |
| **Zoglin** | Ağır darbe, sönük mavi ruh alevi. |
| **Piglin** | Tek hızlı altın kesik. |

Ek mobların hepsi `execution/ExecutionCatalog.java` tablosundaki **veri satırlarıdır** (zaman çizelgesi, geri savrulma, sarsıntı, renkler,
efekt tadı: ruh/alev/buz/kıvılcım, ağır/hızlı). Efektleri tek bir genel sınıf (`StyledExecution`) üretir. Mobler oyun sınıfıyla değil
**kayıt defteri kimliğiyle** (`minecraft:spider`) eşleşir; yalnızca TAM tür eşleşir. Hepsini `EXTRA_MOBS_ENABLED = false` ile, tek bir
mobu `DISABLED_EXTRA_IDS = Set.of("minecraft:vindicator")` ile kapatabilirsin.

**Bilerek eklenmeyenler:** Creeper (fitili yapay zekâdan bağımsız tick'te ilerler; dondurulmuş creeper bitirici sırasında patlayabilir),
Enderman (ışınlanır), Blaze/Ghast/Phantom (uçar), Slime/Magma Küpü (bölünür), Witch (iksirle kendini iyileştirir), Wither/Ender Ejderhası/Warden (boss).

**Ölüm tek ve tutarlıdır:** ölümcül vuruşta ölüm iptal edilir (Defiance ile aynı kalıp: can 1'e çekilir), hedef kısa süre
dondurulur ve başka hasar almaz; darbe anında yapay zekâ geri verilir ve OYUNCU ADINA öldürücü hasar uygulanır. Böylece ölüm,
loot, deneyim ve ruh kazancı vanilla/mod akışıyla **bir kez** işlenir. Oyuncu kilitlenmez; yalnızca kol savurma, ses,
parçacık ve saldıran oyuncuya kısa kamera sarsıntısı (mevcut `BerserkerShakePayload`) vardır; yeni ağ paketi yoktur,
efektler sunucudan yakındaki istemcilere gider.

**Güvenlik:** oyuncu başına tek etkin bitirici ve 3 sn bekleme; oyuncu ölür/çıkar/uzaklaşır ya da hedef kaybolursa hedef
serbest bırakılır (canlı ve normal davranışıyla). Dondurulan mob `battleaxe_execution` etiketini taşır; sunucu kapanırken
serbest bırakılır, çökme sonrası yüklenirken etiket onarılır. Yalnızca etkin bitiricilerde iş yapılır (dünya taraması yok).

**Yeni mob eklemek:** çoğu mob için `ExecutionCatalog`'taki `static { ... }` bloğuna tek bir `add(...)` satırı yazmak yeter
(`tools/test/run_tests.sh` süre/şiddet sınırlarını otomatik doğrular). Tamamen özel bir animasyon için `ExecutionAnimation` uygulayan bir sınıf
yaz ve `ExecutionRegistry.find` içine bir satır ekle.

## Kıyım Zinciri: art arda öldürmenin ritmi

Savaş Baltasıyla (ana elde veya fırlatılan balta) **süre dolmadan** art arda düşman öldürdükçe bir **zincir** büyür. Her öldürme süreyi
yeniler; süre dolarsa zincir kopar. Eşikler aşıldıkça kademe yükselir ve savaş hem güçlenir hem de görsel olarak coşar.

| Kademe | Zincir | Ad | Hasar | Saldırı hızı | Öldürmeler arası süre |
|---|---|---|---|---|---|
| 0 | 1-2 | (yok) | – | – | 5,0 sn |
| 1 | 3+ | Kıyım Zinciri | +0.5 | %4 | 6,0 sn |
| 2 | 6+ | Katliam Zinciri | +1.0 | %8 | 7,0 sn |
| 3 | 10+ | Kıyamet Zinciri | +1.5 | %12 | 8,0 sn |
| 4 | 15+ | Ragnarök | +2.0 | %16 | 9,0 sn |

- **Kim sayılır:** yalnızca düşmanlar (canavar kategorisi) ve oyuncular; inek, köylü gibi uysal canlılar zinciri beslemez. Güçlü düşman
  daha çok sayılır: azami can 40+ → 2, 150+ → 3 (Wither, Kara Körük gibi bosslar zinciri hızla büyütür). Üst sınır 99.
- **Zincir HUD'ı (istemci) - bilerek minimal:** nişangâhın sağında yalnızca ince bir **geri sayan süre çubuğu**, yanında küçük bir **kombo sayacı**
  (`×7`), çubuğun üstünde 4 minik kademe noktası ve altında 1 piksellik sonraki-kademe ilerleme çizgisi. Koyu kutu, kademe adı yazısı ve büyük sayı
  yoktur; sürekli ekranda duran şey göz yormaz.
  - **Kendiliğinden geri çekilme:** son öldürmeden ~1,5 sn sonra gösterge yarı saydamlığa iner; yeni öldürmede, süre %25'in altına inince (çubuk
    nabız gibi beyaza parlar) ve kademe atlarken yeniden tam parlar. Hiç kaybolmaz, yalnızca geri çekilir.
  - **Yazı yalnızca anlarda:** kademe atlayınca nişangâhın üstünde küçük, kısa ömürlü (~1,1 sn) bir kademe başlığı belirip söner; ayrıca göstergeden
    dışa yayılan ince çerçeve ve ekran kenarında çok hafif renkli ışıma (`ChainHud.SCREEN_FX_ENABLED` ile kapatılır).
  - **Zincir kopunca:** ince çubuk küçük kırıklara ayrılıp düşer ve söner.
  - Tüm animasyonlar çizim anında zaman damgalarından hesaplanır (`ChainHudMath`, saf ve test edilir); ayrı bir animasyon durum makinesi yoktur.
  - Sunucu istemciye yalnızca **öldürmede ve kopmada** küçük bir paket yollar (`ChainSyncPayload`: sayı + kalan süre); istemci süreyi kendi saatiyle
    geri sayar, her tick'te paket gitmez. Paketi alamayan (modsuz) istemcilerde yazılar aksiyon çubuğuna düşer.
- **Dünya efektleri (sunucudan, yakındaki oyunculara):**
  - Zincirdeki her öldürmede kurbanın üzerinde kademe renginde kesik/kıvılcım patlaması.
  - Kademe 1+ iken balta eldeyse oyuncunun etrafında **dönen halka**: kademeyle daha çok nokta (2→5), daha geniş ve daha hızlı;
    kademe 2'de alev, 3'te ruh alevi, 4'te `END_ROD` parlaması eşlik eder.
  - **Kademe atlama töreni:** yükselen perdeli seviye sesi ve alçak çınlama, yere yayılan 24 noktalı halka; kademe 3+ ışık sütunu ve kükreme,
    kademe 4 patlama ve duman. Zincir kopunca alçak çınlama ve duman.
- **Baltanın sesi:** kademe atlayınca balta rütbesine göre konuşur (aksiyon çubuğunda italik fısıltı, rütbe renginde). Üç ton vardır:
  rütbe 0-2 mesafeli/yabancı, 3-6 susamış ve kanlı, 7-9 sadık ve kadim. Her kademe x ton için 2 söz (toplam 24, tr/en), art arda aynı söz
  seçilmez; olasılık kademeyle artar (%50 / %65 / %85 / %100) ve fısıltılar arası en az 20 sn vardır. Yalnızca HUD'u olan istemcilerde
  konuşur (HUD'suzlarda aksiyon çubuğu zaten kademe adını gösteriyor). Mantık `ChainWhisperLogic`, çeviri bütünlüğü
  `ChainWhisperTest` ile doğrulanır (her anahtar iki dil dosyasında da bulunmalı).
- **Gözün Yankısı (kozmik korku):** Öncü Belirtiler baltayı edinince kalıcı olarak susar. Ama zincir **Ragnarök**'e (kademe 4) ulaştığında, **gece, açık gökyüzünün altında,
  yağış yokken** susan şey bir an geri döner: Öncü Belirtiler'in "Sana Bakan Şey" gözü (mevcut tezahür, mevcut çizim) gökte belirir ve birkaç saniye sonra balta
  rütbesine göre aksiyon çubuğunda tek bir söz söyler (örn. yüksek rütbede: *"Seni ben çağırmadım. Hiçbir zaman ben çağırmadım."*). Göz sessizdir: açıklama, ses,
  boss bar yoktur. Hiçbir şey açıklanmaz; soru yalnızca derinleşir.
  - **Nadirdir:** ilk uygun Ragnarök'te kesin gerçekleşir (oyuncuya bağlı KALICI sayaç, ölünce korunur); sonrakilerde olasılık azalır (%30, %15, %10 ... en az %6)
    ve yankılar arası en az 20 dakika vardır.
  - **Güvenli:** yalnızca mevcut `OmenPayload` görüntüsünü gönderir; varlık, blok, hasar, ödül yoktur. Koşullar uygun değilse (gündüz, kapalı gökyüzü, yağmur, `OmenConfig`
    göz tezahürünü kapatmışsa) HİÇBİR ŞEY tüketilmez ve sayaç artmaz; yankı sonraki uygun Ragnarök'e kalır.
  - **Deneme:** `ChainConfig.TEST_MODE = true` iken olasılık ve bekleme atlanır (gece ve açık gökyüzü hâlâ gerekir). Kapatmak için `ChainConfig.EYE_ECHO_ENABLED = false`.
  - Mantık `ChainEchoLogic` (saf, test edilir), gönderim `call/OmenEcho`, planlama `ChainEcho`.
- **Execution bağlantısı:** zincir kademesi bitirici animasyon şansını artırır: kademe başına +%4
  (`ExecutionConfig.CHAIN_CHANCE_PER_TIER`; kademe 4'te %25 -> %41; Ruh Ağı bonusuna eklenir).
- **Beceri: zincir hasar almamayı da ister, Shunpo zinciri taşır:**
  - **Hasar zinciri sarsar:** bir DÜŞMANDAN hasar alırsan zincirin kalan süresi kısalır (hasar x 8 tick, en çok 80 tick; yani 3 canlık vuruş 1,2 sn götürür,
    creeper patlaması 4 sn). Sayaç ve kademe doğrudan düşmez; süre biterse zincir olağan yoldan kopar. **Kalkanla engellenen hasar** ve **çevre hasarı** (lav, ateş,
    düşme) zinciri SARSMAZ: kalkan kullanmak ve yol almak ödüllendirilir, ama ateşte yanmak seni cezalandırmaz. HUD çubuğu anında kısalır.
  - **Shunpo zinciri taşır:** başarılı her Shunpo ışınlanması zincirin kalan süresini 2 sn uzatır (pencereyi aşmaz; dolu zincirde bir şey değişmez) ve varış noktasında
    ince bir kıvılcım çıkar. Düşmanlar arası boşluğu ışınlanarak aşan oyuncu zincirini sürdürür. Yar Geç ve Execution öldürmeleri zaten sayılır.
  - Hepsi `ChainConfig`'te: `DAMAGE_PENALTY_ENABLED`, `DAMAGE_PENALTY_TICKS_PER_HP`, `DAMAGE_PENALTY_MAX_TICKS`, `SHUNPO_EXTENDS`, `SHUNPO_EXTEND_TICKS`.
- **Güvenli bonuslar:** hasar ve saldırı hızı bonusu sabit kimlikli GEÇİCİ modifier'dır (idempotent, birikmez, kayda yazılmaz) ve yalnızca
  balta ana eldeyken uygulanır. Her saldırıdan hemen önce de eşitlenir (aynı tick'te silah değiştirip vurma açığı yoktur). Bonuslar küçüktür;
  rütbe 9 (+4.5) ve Hiddet (+4) yanında denge bozmaz.
- **Diğer sistemlerle:** ruh, Ruh Ağı ve Execution'a dokunmaz; kendi dinleyicisi vardır. Execution bitiricisi de bir öldürme olduğundan
  zincire sayılır. **Evrim bağlantısı:** her kademe atlayışı Berserker Evrimi'ne küçük bir **Savaş Özü** verir (kademe başına
  `EvolutionConfig.CHAIN_TIER_ESSENCE = 2`: kademe 1 = +2, kademe 4 = +8; normal kazanım sınırlayıcısından geçer, yani art arda kademe atlamalar pencere
  sınırını aşamaz; savaşta sayılır). Durum kalıcı değildir (çıkış/ölümle sıfırlanır). Diğer sistemler `ChainManager.tier(player)` ile kademeyi okuyabilir.

**Deneme modu:** oyunda HUD'u, törenleri ve fısıltıları hızla görmek için `ChainConfig.TEST_MODE = true` yap (her öldürme 3 sayılır; 5 öldürmede 4 kademenin hepsi görülür). Yayın sürümünde `false` olmalı; test bunu denetler.

Ayarlar `chain/ChainConfig.java` başındadır (HUD'ın ekran kenarı ışıması `ChainHud.SCREEN_FX_ENABLED` ile kapatılır): `ENABLED`, `BASE_WINDOW_TICKS`, `WINDOW_BONUS_PER_TIER`, `TIER_THRESHOLDS`, `DAMAGE_BONUS`,
`SPEED_BONUS`, ağırlık eşikleri, aura/çubuk sıklıkları. Tüm karar mantığı saf `ChainLogic.java`'da, HUD animasyonları `ChainHudMath.java`'dadır (test: `tools/test/ChainLogicTest.java`, Evrim bağlantısı: `ChainEvolutionLinkTest.java`).

## Kozmik Anomaliler: gerçekliğin çatladığı yer

Öncü Belirtiler'in (Baltanın Çağrısı) genişlemesi. Hedef: oyuncu bazen dünyada kendisinden çok daha büyük bir şeyin bulunduğunu hissetsin; bazen
bütün dünya ona baksın; bazen gökyüzünün kendisi yanlış görünsün. **Ucuz jumpscare, rastgele canavar, sürekli ekran sallantısı, yüksek ses YOKTUR.**
Hiçbir anomali gerçek bir boss, düşman, blok ya da yapı DEĞİLDİR; dünyayı kalıcı olarak değiştirmez; hasar vermez; ödül bırakmaz.

**Mimari:** ikinci bir yönetici kurulmadı. Aynı `OmenManager`, aynı ritim kuralları (ilk gün sessiz, oturum başına en çok 2 büyük olay, büyük olaylar arası
en az 12 dk, hasar/uyku/Hiddet uygunluğu), aynı `OmenPayload`, aynı istemci çizimi (`OmenEffect`). Teknik kategoriler `OmenCategory`'de: gökyüzü, ufuk,
gerçeklik, gözlemci, dünya (oyuncuya gösterilen isimler değildir). Her türün kendi bekleme süresi, olasılık ağırlığı, süresi ve uygunluk koşulu vardır.

**Baltadan bağımsız:** eski dört belirti baltayı edinince kalıcı susar (lore). Yeni anomaliler **balta sonrası da sürer** (`OmenConfig.ANOMALIES_AFTER_AXE`),
biraz daha seyrek (`POST_AXE_CHANCE_MULTIPLIER = 0.75`): dünya susmaz. Balta sonrası oyuncuda, anomali başladıktan bir süre sonra balta rütbesine göre (mesafeli /
susamış / sadık) **tek bir söz** söyleyebilir (örn. Monolith için yüksek rütbede: *"Seni oraya götürmem. Orada kimse beklemiyor."*).

| Anomali | Kategori | Ne zaman | Görünüm |
|---|---|---|---|
| **İkinci Ay** | Gökyüzü | Gece, açık gökyüzü | Gerçek aydan 2-4 kat büyük karanlık küre. 4 görünüm: simsiyah, çatlaklı/düzensiz, yalnızca bir bölümü görünen (hilal), kızıl kenarlı. Çoğunda çevresinde "yıldızsız boşluk". %40 gerçek ayın yakınında doğar. Üç kayboluş: solma, karanlığa gömülme, ufka batma. |
| **İmkânsız Halkalar** | Gerçeklik | Gece/alacakaranlık | 3-4 devasa halka. Üst-alt ilişkisi **döngüseldir** (0, 1'in üstünde; 1, 2'nin; ...; sonuncu, 0'ın üstünde): gerçek 3B'de mümkün değil. Çok yavaş, yönü belirsiz dönüş (bazen hiç dönmez). Bölgeleri karanlıkta kaybolur. %22'sinde merkezde küçük bir göz belirir. |
| **İmkânsız Monolith** | Ufuk | **Gece de gündüz de** (gündüz neredeyse tam görünür) | 74-88° yüksekliğinde, özelliksiz siyah levha; kenarları yukarı doğru perspektifle yakınsar; tabanı ufuk sisinde silinir. **Ulaşılamaz:** yaklaşınca mesafesini korur (gerçek konumu yok); ~28 blok yaklaşınca perspektifi belli belirsiz bozulmaya başlar, ~70 blok yaklaşınca ya da ~150 blok yürüyünce söner. Sonsuz yürümek gerekmez. |
| **Bütün Canlılar Sana Bakıyor** | Gözlemci | Her yerde (mağarada da) | Çevredeki (22 blok) uygun canlılar kendi küçük gecikmeleriyle (0-1,4 sn) davranışını bırakır, oyuncuya doğru yavaşça döner ve 5-8 sn bakar; alt yazıda *"Ensende bir soğukluk hissediyorsun."* Sonra hepsi normale döner. Savaş başlatmaz. |
| **Parçalanmış Güneş** | Dünya | Bir gün boyunca, çok nadir | Güneş kareyken (vanilla güneşi bir kare) 3 varyasyon: A kısmi (köşesi eksik, kenarları kopuk), B büyük çatlaklar ve sönmüş bölgeler, C ağır parçalanma. Ertesi gün bazen çok hafif tek bir "iz". |

**Ölçek ve perspektif (en önemli teknik hedef):**
- Eskiden yalnızca düz arazide ufuktaki figürlerin tabanı yakın zemin üzerine biniyordu: Dev'in tabanı -2° idi ve arazi taraması 2,5°'lik kaba adımlarla ±1,25° hata
  yapıyordu. Şimdi taban **gerçek ufuk çizgisinde** (-0,6°) ve arazi taraması **ikiye bölmeyle ~0,04°'ye** hassaslaştırıldı: figür dağsız düz ovada da ufukta durur.
- **Atmosferik perspektif:** tabana doğru kalınlaşan ufuk sisi (`S_HAZE`, gün zamanına göre gündüz gri-mavi / gece lacivert renklenir). Monolith ve Dev'de.
- **Ölçek:** Dev artık %30 olasılıkla ~1,9 kata kadar büyür (başları görüş alanının dışında kalır) ve %22 olasılıkla yalnızca **başları** ufkun üstünde görünür (gövde ufkun
  arkasında). Monolith kenarları gerçek perspektif gibi yakınsar. Dikey tezahürler görüş alanının dışına taşabilir.
- **Sabit yön, paralaksız:** tüm anomaliler gökte sabit yönlüdür; bu yüzden oyuncu yürüdükçe uzaklıkları değişmez (gerçek konumları yoktur).
- Arazi/ağaç/bulut örtüsü, kısmi görünürlük ve uzaklıkta ayrıntı kaybı mevcut `OmenOcclusion` ile sağlanır; yeni stiller `S_VOID` (saf karanlık), `S_HAZE` (sis), `S_EMBER` (kor).

**Parçalanmış Güneş nasıl çalışır:** hangi günün anomali günü olduğu **dünya tohumu + gün sayısından deterministik** türetilir (`SunAnomalyLogic`): hiçbir şey kaydedilmez,
sunucu yeniden başlasa da aynı sonucu verir ve aynı dünyadaki bütün oyuncular **aynı güneşi** görür. İki olay arası en az 6 gün (yerel-en-küçük karma yöntemiyle, özyinelemesiz),
ilk 3 gün sakin, günlük olasılık ~%4,5 (uzun dönemde birkaç yüz günde bir kaç olay). Gerçek gündüz-gece döngüsü, ışık ve bloklar DEĞİŞMEZ; yalnızca istemcide güneşin üstüne
karanlık parçalar çizilir. Güneş karesinin yerel eksenleri vanilla'nın kendi dönüş zinciriyle (`rotateY(-90)·rotateX(açı)`) türetilir, böylece kopmalar güneşin köşelerine
oturur. Ufuğa yakınken arazi örtüsü uygulanır; kapalı alanda, yağmurda ve ufuk altında söner. Gün içi zamanı sunucu bildirir, istemci ay efektiyle aynı yöntemle ilerletir.

**Gökyüzünün Hafızası (zorunlu zincir DEĞİL, yalnızca ihtimal ve görsel akrabalık):**
- İkinci Ay'dan sonra Halkalar ve Göz, Halkalar'dan sonra Göz, Monolith'ten sonra İkinci Ay ve Dev biraz daha olasıdır (`OmenLogic.memoryBoost`, çarpan 1,5-2,2; hiçbir tür baskın olmaz).
- İkinci Ay'ın çevresinde yıldızlar eksilir; Monolith belirince gökyüzü çok hafif kararır (bir varyantta); Halkalar belirirken bazen merkezde küçük bir göz açılır; Parçalanmış Güneş'ten sonraki gün
  güneşin yüzünde çok hafif bir iz kalır.

**Gözü geliştirdik (kimliği korunarak):** "Yukarı bakma. O da seni görüyor." ve Gözün Yankısı / Ragnarök bağlantısı AYNEN korunur. Görsel: 4 boyut (küçükten çok büyüğe; çok büyük göz
görüş alanına sığmaz), çevresinde hafif atmosfer dalgalanması (eşmerkezli soluk halkalar), bazen bir yanını karanlık yutar, bazen büyük kısmı karanlıkta kalıp yalnızca bir bölümü görünür.
Bebek hâlâ çok yavaş ve belli belirsiz izler.

**Bütün Canlılar - güvenlik:** yalnızca `minecraft:` mobları; boss (ejderha, Wither, Warden, Elder Guardian, Creaking), golem, gezgin tüccar, mod mobları (Kara Körük dâhil), binek/yolcu,
ve başka sistem tarafından donmuş moblar hiç etkilenmez. Dondurma `setNoAi` ile ve **kalıcı etiketle** yapılır (Execution'daki kalıpla aynı): sunucu kapanır, oyuncu çıkar/ölür, boyut değişir ya da
chunk yeniden yüklenirse mob otomatik serbest bırakılır. Olay oyuncu başınadır; yalnızca o oyuncunun çevresini ve yalnızca ona mesajı etkiler.

**Ayarlar:** `OmenConfig` (`ANOMALIES_ENABLED`, `ANOMALIES_AFTER_AXE`, `*_ENABLED` türleri tek tek, bekleme/süre sabitleri, Monolith sönme mesafeleri, Bütün Canlılar yarıçap/sayı/hızları,
Parçalanmış Güneş olasılık/aralık). `OmenConfig.TEST_MODE = true` her şeyi sıklaştırır (yayında `false` olmalı; test denetler). Mantık saf sınıflarda test edilir:
`OmenLogic`, `OmenShapes`, `SunAnomalyLogic`, `SunAnomalyShapes`, `AllWatchingLogic`, `AnomalyWhisperLogic` (test: `OmenLogicTest`, `AnomalyLogicTest`).

## Başıboş Ruhlar: kendi boyutlarını terk etmiş üç ruh (ilk üç tür)

Başıboş Ruhlar, kendi boyutlarını terk edip bu dünyaya sürüklenmiş, amacını ve kimliğini yitirmiş düşmanca ruhsal varlıklardır. Boyutlar arası geçiş onlara pahalıya mal oldu:
burada gördüğümüz hâlleri, gerçek güçlerinin yalnızca soluk bir kısmıdır. **Kendi dünyalarında çok daha korkunç, gelişmiş ve tehlikeli ruh türleri vardır**; bu
güncelleme yalnızca ilk üç türü ve genişletilebilir ruh ailesi altyapısını ekler (biyom, boyut, portal, blok, başka mob/boss YOK; ruhlar doğal olarak doğmaz).

Üçü de **tamamen düşmancadır**: oyuncuyu görünce tereddütsüz saldırır. Zorluk acımasızdır ama hileli değildir: her saldırının belirgin bir hazırlığı (ses, parçacık, hareket)
ve karşılık fırsatı vardır; duvardan vurmaz, kaçınılmaz hasar vermez. Tüm kararlar ve hasar yalnızca SUNUCUDA verilir (çok oyunculu güvenli).

| | Savrulmuş Ruh | Ruh Yiyen | Zincirli Ruh |
|---|---|---|---|
| Rol | yakın dövüş avcısı | menzilli avcı, baskı + iyileşme | ağır muhafız, alan kontrolü |
| Can / zırh | 40 / 2 | 60 / 4 | 120 / 8 |
| Hız | yüksek | orta | düşük |
| Hasar | pençe 6-8 | ruh oku 5-7 | savurma 9-12, darbe 10 |
| Boy | 1.9 blok | 2.7 blok | 2.6 blok (1.2 geniş) |
| Özel yetenek | Ruh Sıçrayışı | Ruh Emdirme | Zincirle Mühürleme + Ruhani Darbe |
| Ruh ödülü | 2 | 3 | 6 |

- **Savrulmuş Ruh:** oyuncunun çevresinde ani yön değişimleriyle döner, ARKASINA geçmeye çalışır; kombo hazırken yaklaşıp iki seri pençe vurur, sonra geri çekilir (komboların arası 2 sn: spam yok).
  **Ruh Sıçrayışı:** eğilir, ses ve parçacıkla uyarır (0.7 sn), kilitlediği YERE sıçrar (takip etmez; yana kaçılır); ıskalama/iniş sonrası 1.2 sn SAVUNMASIZdır.
- **Ruh Yiyen:** mesafeyi korur (yaklaşılırsa geri çekilir, görüş kaybolursa konum değiştirir). **Ruh Oku** oyuncunun hareket yönüne göre önden nişanlanır ama düz uçar.
  **Ruh Emdirme:** 1.2 sn hazırlıktan sonra oyuncuyla arasında görünür bir enerji akışı kurar; her 0.5 sn 2 hasar, bir kısmı ruhun canına döner. Bağ; görüş hattı kesilirse,
  16 bloktan uzaklaşılırsa veya tek seferde 10 hasar alırsa (**tek balta vuruşu / Yar Geç**) kopar ve ruh savunmasız kalır. İyileşme sınırlıdır: bağ başına en çok 8 can, ruhun
  ömrü boyunca en çok maks canın yarısı; **Hiddet'teki oyuncudan emilen enerji acıdır** (iyileşme yarıya iner).
- **Zincirli Ruh:** yürüyerek alanı daraltır. **Zincir Savurma:** 150° geniş yay (hazırlıkta yay zemine çizilir; son anda dönmeyi bırakır). **Ruhani Darbe:** yere ağır vuruş, genişleyen
  şok dalgası; halka sana ulaştığında SIÇRAYAN kurtulur. **Zincirle Mühürleme:** zinciri atılır (doğrultu hazırlığın sonunda kilitlenir; yana kaçılır); isabet ederse 1.8 sn %55 yavaşlama, %40 zıplama
  kısıtı ve ruha doğru hafif çekiş (oyuncu HAREKETSİZ KALMAZ). Kalkan zinciri karşılar. **Shunpo mührü kırar**, ruha tek vuruşta 12+ hasar da kırar; kurtulan oyuncu 8 sn yeniden mühürlenemez
  (art arda zincirleme yok). Her ağır saldırıdan sonra ruh savunmasız kalır.
- **Birlikte:** roller birbirini tamamlar (Zincirli kısıtlarken Savrulmuş yakın baskı kurar, Ruh Yiyen uzaktan vurur). `SpiritCoordinator`: bir hedefe aynı anda yalnızca TEK kontrol yeteneği
  (emme veya mühür) uygulanır; biri bitince 2.5 sn boşluk bırakılır. Karşılaşma düzenleri üyeleri asgari 3 blok arayla yerleştirir; en çok bir Zincirli ve bir Ruh Yiyen.
- **Ölüm:** ruhsal beden düşmez; parçalanıp dağılır (parçalar dışa savrulup küçülür, çekirdek parlayıp söner).
- **Ses:** vanilla ses olaylarının perde/karışımıyla kimlik verilmiştir (özel ses dosyası yok): kesik boğuk fısıltılar (Vex), derin uğultular (Wither/Enderman), ağır metal darbeleri (Demir Golem/Örs).

**Mevcut sistemlerle etkileşim**

- **Ruhsal doğa:** mermilere (ok vb.) %30 direnç. **Savaş Baltası bedeni keser:** vuruş, Yar Geç, fırlatma ve Shunpo kombosu direnci yok sayar ve +%10 hasar verir; baltanın her ruh rütbesi için +%1.5
  (rütbe 9: +%23.5). Normal silahlar tam hasar verir (yalnızca oklar zayıflar). Savunmasız anlarda her kaynaktan +%25 hasar.
- **Ruh dengesi:** türe göre SABİT küçük ödül (2/3/6; vanilla can/20 formülüyle aynı denge, ayarla kapatılabilir). Oyuncunun baltasına açık bir ruh/rütbe kapısı YOKTUR; doğal doğuş yok.
- **Baltanın sözü:** balta bir ruhu devirince ilk kez her tür için bir söz, sonra nadiren rütbesine göre (açıklama değil, soru doğurur).
- **Kıyım Zinciri:** ruhlar düşman sayılır (zincire puan verir, ruhun verdiği hasar zinciri kısaltır). **Execution:** ruhlar bitirici kataloğunda YOKTUR. **Hiddet, Yar Geç, Shunpo, Ruh Ağı:** yukarıdaki kurallarla.

**Test / geliştirme:** `/summon battleaxe:savrulmus_ruh` (veya `ruh_yiyen`, `zincirli_ruh`), ya da yetkililer için `/baltaruh`: `summon <tür>` (6 blok ötede), `encounter <düzen>`
(`tek_savrulmus tek_ruh_yiyen tek_zincirli avcilar catisma muhafiz uclu kusatma`; ruhlar size doğru bakar) ve `clear` (64 blok çevreyi temizler; ödül yok).

**Dengeleme:** `spirit/SpiritConfig` (ortak), `SavrulmusConfig`, `RuhYiyenConfig`, `ZincirliConfig`: can, hasar, bekleme süreleri, algılama mesafeleri, hazırlık süreleri.
**Genişletme:** yeni ruh türü = `SpiritKind` + varlık sınıfı (`SpiritEntity`) + `ModSpiritTypes` kaydı + istemci modeli. **Spawn altyapısı:** `SpiritEncounter.pick(...)` bir düzen seçer,
`SpiritSpawner.spawnEncounter(...)` yerleştirir; henüz hiçbir biyom/boyuta BAĞLI DEĞİL.

İstemci: `client/spirit/` (taban model + üç model + üç çizici). Model parçaları ve dokular **tek kaynaktan** üretilir: `tools/gen_spirit_assets.py` (Pillow gerekir; derleme bunu çalıştırmaz;
`*Parts.java` dosyaları üretilmiştir, elle düzenlenmez).

## Dosya yapısı

```
src/main/java/com/battleaxe/
    BattleAxeMod.java            giriş noktası
    item/ModItems.java           balta tanımı ve kaydı
    item/BattleAxeItem.java      sağ tık şarj saldırısı (sadece Yar Geç'li balta)
    effect/CritEffects.java      kritik vuruş parçacık efektleri
    component/ModComponents.java Ruh Bağı sayacı ve Hiddet görünüm bayrağı bileşenleri
    soul/                        Ruh Bağı: ayarlar, rütbe mantığı, görünüm, bonuslar, efektler, fısıltılar, ölüm olayı
    thrown/                      Ağır Balta Fırlatma: varlık, tracker, paket, yönetici, ayarlar, karar mantığı
    shunpo/                      Shunpo: ayarlar, saf mantık, büyü yardımcısı, ışınlanma yöneticisi
    yargec/                      Yar Geç: ayarlar, şarj/alan mantığı, saldırı, efektler, büyü yardımcısı
    mixin/PlayerMixin.java       vanilla kritik vuruşuna ve saldırıya bağlanan hook'lar
    mixin/LivingEntityMixin.java Ruh Ağı hasar ölçekleme hook'u (hurtServer başı)
    evolution/                   Hiddet Evrimi: Savaş Özü, aşamalar, dallar, aşırı yüklenme, hasar/etki kancaları, paketler
    nexus/                       Ruh Ağı: veri modeli, 100 düğüm tablosu (üretilir), kurallar, yönetici, hasar/Yar Geç/ruh/fısıltı mantığı, paketler
    berserker/                   Hiddet: ayarlar, durum mantığı, sunucu yöneticisi, efektler, ağ paketleri
    chain/                       Kıyım Zinciri: ayarlar, durum, saf mantık (ChainLogic, ChainHudMath), yönetici (bonuslar/olaylar/paket), dünya efektleri
    execution/                   Execution: bitirici animasyonlar (durum makinesi, Zombi/İskelet animasyonları, ExecutionCatalog + StyledExecution ek moblar, saf mantık)
    call/                        Baltanın Çağrısı: ayarlar, saf mantık (mesaj tablosu, ay geometrisi), yönetici, kalıcı veri, paket;
                                 Öncü Belirtiler: Omen* (OmenLogic/OmenShapes/OmenGeometry saf, OmenManager/OmenPayload sunucu), AxeAcquisition
    spirit/                      Başıboş Ruhlar: SpiritKind/SpiritConfig + üç tür (Savrulmus/RuhYiyen/Zincirli: Config, Logic = saf durum makinesi, Entity),
                                 SpiritEntity (taban), RuhMermisi/ZincirMuhru (sunucu simülasyonu), SpiritSeal (mühür), SpiritCoordinator, SpiritEncounter/SpiritSpawner,
                                 SpiritWhispers, SpiritCommand (/baltaruh), ModSpiritTypes
src/client/java/com/battleaxe/client/
    BattleAxeClient.java         istemci giriş noktası
    ClientBerserkerState.java    istemcideki Hiddet durumu (sadece HUD)
    BerserkerHud.java            HUD göstergesi ve vinyet
    ClientCameraShake.java       ekran titremesi
    YarGecChargeHud.java         Yar Geç şarj çubuğu
    ThrownBattleAxeRenderer.java fırlatılmış baltayı çizer (dönen / saplı)
    mixin/CameraMixin.java       titremeyi kameraya uygulayan hook
    nexus/                       Ruh Ağı ekranı (NexusScreen), istemci durumu, açıklama metinleri
    evolution/                   Hiddet Evrimi HUD'ı (dar dikey Savaş Özü çubuğu), ekranı ve istemci durumu
    call/MoonAxeEffect.java      Baltanın Çağrısı: ayın önünden geçen balta silueti (HUD katmanı)
    call/OmenEffect.java         Öncü Belirtiler: istemci durum makinesi, izdüşüm, çizim, "YILDIZI BUL!"
    call/OmenCanvas.java         Öncü Belirtiler: çokgen doldurma, kenar, arazi örtmesi (yalnızca fill)
    call/OmenOcclusion.java      Öncü Belirtiler: arazi/ağaç örtmesi için dünya-sabit ışın örnekleme
    spirit/                      Başıboş Ruhlar: SpiritModel/SpiritRenderer (taban), üç model + üç çizici, *Parts (tools/gen_spirit_assets.py üretir)
tools/
    gen_evolution_lang.py        Hiddet Evrimi dil girdileri
    gen_hammer_texture.py        Kara Körük çekicinin dokusunu kara_koruk.png'ye boyar
    gen_nexus.py                 Ruh Ağı düğüm tablosu (tek kaynak): doğrular, Java ve dil dosyalarını üretir
    gen_spirit_assets.py         Başıboş Ruhlar: model parçaları (Java) ve dokular tek kaynaktan
    test/                        Minecraft gerektirmeyen çekirdek testleri (run_tests.sh)
src/main/resources/
    fabric.mod.json              mod bilgisi
    battleaxe.mixins.json        mixin ayarı
    assets/battleaxe/            doku, model, dil dosyaları (en_us, tr_tr)
    data/battleaxe/              tarif ve tag'ler
    data/minecraft/tags/item/swords.json   baltayı "kılıç" olarak işaretler
```

Lisans: CC0-1.0 (Fabric örnek mod şablonunun varsayılanı).

## Kara Körük güncellemesi: Kara Çubuk, Örs ve Günlük

- **Ganimet (garanti, ölümde bir kez):** `battleaxe:kara_cubuk` (Kara Çubuk) ve içinde 4 kayıt bulunan yazılı kitap "Körüğün Ardındaki Akıl" (yazar: Kara Körük; vanilla `written_book` eşyası, içerik `KaraKorukLoot`).
- **Kara Körük'ün Örsü** (`battleaxe:kara_koruk_ors`): sağ tıkla açılır. Yuvalar soldan sağa: Savaş Baltası, Kara Çubuk, Blaze Çubuğu, (kapalı), sonuç. Sunucu taraflı menü; istemcide vanilla huni arayüzü görünür. Tarif: `BBB / _I_ / OOO` (blackstone, demir blok, obsidyen) — Fonksiyonel Bloklar sekmesinde de var.
- **Dönüşüm:** balta aynı eşya kalır; tüm bileşenleri (ruh, rütbe, büyü, ad...) korunur. Üzerine `battleaxe:black_handle` ve vanilla `unbreakable` eklenir. Siyah sap: `*_bh` doku/modelleri, `items/battle_axe*.json` içinde bu bileşene göre seçilir (fırlatılan balta aynı modeli kullanır).
