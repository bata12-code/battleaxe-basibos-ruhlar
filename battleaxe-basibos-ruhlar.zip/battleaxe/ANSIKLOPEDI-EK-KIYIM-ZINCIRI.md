# ANSİKLOPEDİ EKİ — Claude'un bu oturumda eklediği sistemler

(Proje ansiklopedisinin 9. bölümünden (Execution) sonra veya yeni bir bölüm olarak eklenebilir.)

## A. Execution genişlemesi: on altı yeni bitirici

Execution artık yalnızca Zombi ve İskelet'te değil, kayıt defteri kimliğiyle eşleşen on altı ek mobda da çalışır:
Örümcek (üç hızlı pençe), Mağara Örümceği (iki çevik kesik), Çöl Zombisi (kum tozlu ağır darbe), Bozkır İskeleti (buz kıvılcımlı iki kesik),
Wither İskeleti (iki yavaş ağır darbe, yükselen ruhlar), Zombileşmiş Piglin (kor ve alev), Piglin Barbarı (altın kıvılcımlı iki ağır savurma)
Korucu (balta düellosu: iki metal çarpışması, ardından tepeden son darbe), Bataklık İskeleti, Zombi Köylü, Yağmacı, Çağırıcı, Yıkıcı (dev: yavaş ve çok ağır darbe), Hoglin, Zoglin ve Piglin.

Bu moblar kod değil **veri satırlarıdır** (`ExecutionCatalog`): yeni mob eklemek tek satırdır. Bilerek eklenmeyenler: Creeper (fitili yapay
zekâdan bağımsız ilerler), Enderman, uçan moblar, bölünen moblar, Witch ve bosslar.

## B. Kıyım Zinciri: art arda öldürmenin ritmi

Savaş Baltasıyla süre dolmadan art arda düşman öldürdükçe bir zincir büyür; her öldürme süreyi yeniler, süre dolarsa zincir kopar.
Güçlü düşman daha çok sayılır (azami can 40+ -> 2, 150+ -> 3).

| Kademe | Zincir | Ad | Hasar | Saldırı hızı | Süre |
|---|---|---|---|---|---|
| 1 | 3+ | Kıyım | +0.5 | %4 | 6 sn |
| 2 | 6+ | Katliam | +1.0 | %8 | 7 sn |
| 3 | 10+ | Kıyamet | +1.5 | %12 | 8 sn |
| 4 | 15+ | Ragnarök | +2.0 | %16 | 9 sn |

- **HUD (bilerek minimal):** nişangâhın sağında ince bir geri sayan süre çubuğu, yanında küçük bir kombo sayacı, üstünde 4 minik kademe noktası.
  Sürekli yazı yoktur; son öldürmeden sonra yarı saydamlığa çekilir, olay anlarında (öldürme, süre azalması, kademe atlama) yeniden parlar.
  Yazı yalnızca kademe atlarken kısa bir başlık olarak görünür; zincir kopunca ince çubuk kırıklara ayrılıp düşer.
- **Dünya efektleri:** kademeyle büyüyen, dönen parçacık aurası; kademe atlama töreni (halka, ışık sütunu, kükreme, patlama).
- **Baltanın sesi:** kademe atlayınca balta rütbesine göre konuşur (mesafeli / susamış / sadık; 24 söz). Örnek: yüksek rütbede, en üst kademede
  *"Şimdi sor bana: Kim kimi buldu?"* — modun ana sorusuna doğrudan değinir.
- **Sistemler arası bağlar:** her kademe atlayışı Berserker Evrimi'ne küçük bir Savaş Özü verir (sınırlayıcıdan geçer); zincir kademesi Execution
  bitirici şansını kademe başına +%4 artırır; Execution bitiricisi de bir öldürme olarak zincire sayılır.

## B1. Beceri katmanı: zincir ritim ve hareket ister

Zincir artık yalnızca "durmadan öldür" değildir: iki karşıt güç vardır.

- **Hasar sarsar:** bir düşmandan hasar almak zincirin kalan süresini kısaltır (kalkanla engellenen ve çevre hasarı hariç). Savunmasız dalmak zinciri yakar.
- **Shunpo taşır:** başarılı bir Shunpo, kalan süreyi 2 saniye uzatır. Düşmanlar arasındaki boşluğu ışınlanarak aşmak, zinciri sürdürmenin yoludur.

Böylece Yar Geç (kalabalığı biçer), Execution (zinciri besler), Shunpo (zinciri taşır) ve kalkan (zinciri korur) tek bir ritim içinde birleşir.

## B2. Gözün Yankısı: susan şeyin geri dönüşü (lore)

Ansiklopedinin 13. bölümü der ki: baltayı edinince Öncü Belirtiler **kalıcı olarak susar** ve bunun sebebi açıklanmaz. Oyuncu, çağıranın balta olduğunu
sanır. Gözün Yankısı bu sessizliği bozar:

Kıyım Zinciri **Ragnarök**'e (15 zincir) ulaştığında, gece açık gökyüzünün altında, "Sana Bakan Şey" gökte bir an belirir. Birkaç saniye sonra balta
rütbesine göre tek bir söz söyler. Yüksek rütbede: *"Seni ben çağırmadım, [oyuncu]. Hiçbir zaman ben çağırmadım."* Orta rütbede: *"Bu bakış benim değil."*
Düşük rütbede: *"Yukarı bakma. O da seni görüyor."* Sonraki yankılarda daha kısa ve yorgun: *"Hâlâ orada. Ben de buradayım."*

Bu, modun ana sorusunu (**"Oyuncuyu çağıran şey gerçekten balta mıydı?"**) cevaplamaz; yalnızca iki ihtimalden birini zayıflatır. Balta çağırmadıysa, çağıran
neydi, ve baltayı da o mu çağırdı? Yankı nadirdir (ilk uygun Ragnarök'te kesin, sonra giderek azalır; en az 20 dakika arayla) ve göz hiçbir şey yapmaz, hiçbir şey vermez.

## Deneme modu

`ChainConfig.TEST_MODE = true` yapılırsa her öldürme 3 sayılır: 5 öldürmede dört kademenin hepsi görülür. Yayında `false` olmalıdır (test denetler).

## C. Doğrulama durumu (dürüst not)

Tüm saf mantık (zincir, HUD animasyon matematiği, Execution kataloğu, fısıltı seçimi, çeviri bütünlüğü, Evrim ve Execution bağlantıları)
`tools/test/run_tests.sh` ile test edilir ve geçer. Minecraft'a dokunan sınıflar gerçek Gradle derlemesinden geçirilemedi; yalnızca API
şekillerini taklit eden saplamalarla Java düzeyinde derlendi. **Oyun içi görsel doğrulama** (HUD yerleşimi ve hissi, kırık animasyonu, aura
yoğunluğu, fısıltı zamanlaması) yapılmadı ve kullanıcı tarafından denenmelidir.

---

## D. Kozmik Anomaliler: gerçekliğin çatladığı yer (lore ve atmosfer)

Öncü Belirtiler artık yalnızca "baltayı edinmeden önceki çağrı" değildir: dünya zaman zaman anlaşılmaz, devasa ve gerçeklik kurallarına aykırı olaylar yaşar. **Ve bu olaylar baltayı edindikten
sonra da sürer.** Eski dört belirti (gökte balta, göz, ufuktaki dev, imkânsız mimari) hâlâ baltanın edinilmesiyle kalıcı susar; ama gökyüzü susmaz.

- **İkinci Ay:** gökyüzünde gerçek aydan çok büyük, karanlık bir küre; yıldızlar eksilir.
- **İmkânsız Halkalar:** birbirinin içinden döngüsel geçen halkalar; bir halkanın merkezinde bazen küçük bir göz açılır (Gökyüzünün Hafızası).
- **İmkânsız Monolith:** gündüz de görünen, hiç yaklaşılamayan, özelliksiz siyah levha.
- **Bütün Canlılar Sana Bakıyor:** çevredeki bütün canlılar bir an aynı düşünceye sahipmiş gibi durup oyuncuya döner. *"Ensende bir soğukluk hissediyorsun."*
- **Parçalanmış Güneş:** bir gün boyunca güneş, sanki başka bir gök cismi çarpmış gibi parçalanmış doğar. Ertesi gün güneşin yüzünde bir iz kalabilir.

Balta bu olayları fark eder ve (baltayı edinmiş oyuncuya) rütbesine göre tek bir söz söyler; hiçbir şeyi açıklamaz:
*"Onu tanıyorum. Seni ilk gördüğüm gece de oradaydı."* (İkinci Ay, sadık) / *"Kara Körük bunu hiç dövemedi. Dövmeye cesaret edemedi."* (Halkalar, sadık) /
*"Yaklaşma. Yaklaşılacak bir yer değil."* (Monolith, mesafeli).

Ana soru derinleşir: Oyuncuyu çağıran şey gerçekten balta mıydı? Balta çağırmadıysa, bütün bu belirtileri, ikinci ayı, halkaları, monolith'i, gözü ve parçalanmış güneşi kim bırakıyor? Hiçbiri açıklanmaz.
Hiçbiri oyuncuyu bir göreve sokmaz. Hiçbiri bir boss'a dönüşmez.

**Doğrulama notu:** mantık, geometri, takvim ve güvenlik kuralları testle doğrulanır. Görsel kalite (özellikle ölçek, perspektif ve güneşin parçalanma görüntüsü) **oyun içinde denenmedi**; çizim kodu
Minecraft imzalarını taklit eden saplamalarla Java düzeyinde derlendi. `OmenConfig.TEST_MODE = true` ile tüm anomalileri sık sık görüp ayarlayabilirsin.
